package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.spitfire.core.domain.DisplayMode
import com.example.spitfire.sdk.SpitfireSdk
import com.example.ui.navigation.SpitfireScreen
import com.example.ui.screens.CameraScreen
import com.example.ui.screens.DevConsoleScreen
import com.example.ui.screens.DigitalTwinScreen
import com.example.ui.screens.FlyScreen
import com.example.ui.screens.GalleryInspectScreen
import com.example.ui.screens.MapScreen
import com.example.ui.screens.MissionsScreen
import com.example.ui.screens.SignatureDemosScreen
import com.example.ui.screens.SyncDataScreen
import com.example.ui.screens.TelemetryScreen
import com.example.ui.theme.AirframeBlue
import com.example.ui.theme.InstrumentBorder
import com.example.ui.theme.InstrumentCardBackground
import com.example.ui.theme.InstrumentMonoFont
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SpitfireBlack
import com.example.ui.theme.SpitfireTheme
import com.example.ui.theme.WarmInstrumentWhite

class MainActivity : ComponentActivity() {
    private val sdk = SpitfireSdk()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val deviceState by sdk.deviceState.collectAsState()

            SpitfireTheme(displayMode = deviceState.displayMode) {
                SpitfireHandheldApp(sdk = sdk)
            }
        }
    }
}

@Composable
fun SpitfireHandheldApp(sdk: SpitfireSdk) {
    var currentScreen by remember { mutableStateOf(SpitfireScreen.FLY) }
    val deviceState by sdk.deviceState.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = SpitfireBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // SPITFIRE HARDWARE HEADER BAR
            HardwareHeaderBar(
                deviceId = sdk.identity.deviceId,
                batteryPercent = deviceState.powerState.batteryPercent,
                linkQuality = deviceState.radioState.linkPercentage,
                activeMissionName = deviceState.activeMissionName ?: "NO ACTIVE MISSION",
                displayMode = deviceState.displayMode,
                onModeSelect = { sdk.setDisplayMode(it) }
            )

            // NAVIGATION BAR
            NavigationTabBar(
                currentScreen = currentScreen,
                onScreenSelect = { currentScreen = it }
            )

            // SCREEN VIEWPORT
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                when (currentScreen) {
                    SpitfireScreen.FLY -> FlyScreen(sdk = sdk)
                    SpitfireScreen.MISSIONS -> MissionsScreen(sdk = sdk)
                    SpitfireScreen.MAP -> MapScreen(sdk = sdk)
                    SpitfireScreen.CAMERA -> CameraScreen(sdk = sdk)
                    SpitfireScreen.GALLERY -> GalleryInspectScreen(sdk = sdk)
                    SpitfireScreen.TELEMETRY -> TelemetryScreen(sdk = sdk)
                    SpitfireScreen.TWIN -> DigitalTwinScreen(sdk = sdk)
                    SpitfireScreen.SYNC -> SyncDataScreen(sdk = sdk)
                    SpitfireScreen.DEV -> DevConsoleScreen(sdk = sdk)
                    SpitfireScreen.DEMOS -> SignatureDemosScreen(sdk = sdk)
                }
            }
        }
    }
}

@Composable
private fun HardwareHeaderBar(
    deviceId: String,
    batteryPercent: Int,
    linkQuality: Int,
    activeMissionName: String,
    displayMode: DisplayMode,
    onModeSelect: (DisplayMode) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(InstrumentCardBackground)
            .border(1.dp, InstrumentBorder)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                "SPITFIRE HANDHELD API",
                style = MaterialTheme.typography.titleMedium,
                color = WarmInstrumentWhite
            )
            Text(
                "$deviceId | $activeMissionName",
                style = MaterialTheme.typography.labelSmall,
                color = SignalAmber,
                fontFamily = InstrumentMonoFont
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "BAT $batteryPercent%  LINK $linkQuality%",
                style = MaterialTheme.typography.labelSmall,
                color = WarmInstrumentWhite,
                fontFamily = InstrumentMonoFont
            )

            Spacer(modifier = Modifier.width(12.dp))

            // DISPLAY MODE TOGGLER
            DisplayModePicker(
                currentMode = displayMode,
                onModeSelect = onModeSelect
            )
        }
    }
}

@Composable
private fun DisplayModePicker(
    currentMode: DisplayMode,
    onModeSelect: (DisplayMode) -> Unit
) {
    Row(
        modifier = Modifier
            .background(SpitfireBlack, RoundedCornerShape(2.dp))
            .border(1.dp, InstrumentBorder)
            .padding(2.dp)
    ) {
        DisplayMode.entries.forEach { mode ->
            val isSel = mode == currentMode
            Box(
                modifier = Modifier
                    .background(if (isSel) SignalAmber else Color.Transparent)
                    .clickable { onModeSelect(mode) }
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = mode.name.take(3),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isSel) SpitfireBlack else WarmInstrumentWhite,
                    fontFamily = InstrumentMonoFont
                )
            }
        }
    }
}

@Composable
private fun NavigationTabBar(
    currentScreen: SpitfireScreen,
    onScreenSelect: (SpitfireScreen) -> Unit
) {
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .background(SpitfireBlack)
            .border(1.dp, InstrumentBorder)
            .padding(4.dp)
    ) {
        items(SpitfireScreen.entries.toTypedArray()) { screen ->
            val isSelected = screen == currentScreen
            Box(
                modifier = Modifier
                    .padding(end = 4.dp)
                    .background(if (isSelected) AirframeBlue else InstrumentCardBackground, RoundedCornerShape(2.dp))
                    .border(1.dp, if (isSelected) SignalAmber else InstrumentBorder)
                    .clickable { onScreenSelect(screen) }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("nav_${screen.name.lowercase()}"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = screen.label,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (isSelected) WarmInstrumentWhite else WarmInstrumentWhite.copy(alpha = 0.7f),
                    fontFamily = InstrumentMonoFont
                )
            }
        }
    }
}
