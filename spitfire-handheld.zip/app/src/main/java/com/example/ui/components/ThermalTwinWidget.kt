package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.spitfire.core.domain.ThermalState
import com.example.spitfire.core.domain.ThermalStatus
import com.example.ui.theme.BritishEngineeringGreen
import com.example.ui.theme.InstrumentBorder
import com.example.ui.theme.InstrumentCardBackground
import com.example.ui.theme.InstrumentMonoFont
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.WarmInstrumentWhite
import com.example.ui.theme.WarningRed

@Composable
fun ThermalTwinWidget(
    thermalState: ThermalState,
    cpuUsagePercent: Int = 42,
    ramUsagePercent: Int = 58,
    modifier: Modifier = Modifier
) {
    val statusColor = when (thermalState.status) {
        ThermalStatus.NORMAL -> BritishEngineeringGreen
        ThermalStatus.WARM -> SignalAmber
        ThermalStatus.HOT, ThermalStatus.THROTTLING, ThermalStatus.CRITICAL -> WarningRed
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(InstrumentCardBackground, RoundedCornerShape(2.dp))
            .border(1.dp, InstrumentBorder, RoundedCornerShape(2.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SPITFIRE DIGITAL TWIN",
                style = MaterialTheme.typography.labelSmall,
                color = WarmInstrumentWhite
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "${thermalState.status}",
                style = MaterialTheme.typography.labelSmall,
                color = statusColor
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // CPU Metric
        ThermalRow(label = "CPU Core", value = "${thermalState.cpuTempC}°C", progress = cpuUsagePercent / 100f, barColor = statusColor)
        Spacer(modifier = Modifier.height(4.dp))

        // GPU Metric
        ThermalRow(label = "GPU Vision", value = "${thermalState.gpuTempC}°C", progress = 0.55f, barColor = BritishEngineeringGreen)
        Spacer(modifier = Modifier.height(4.dp))

        // Radio RF Metric
        ThermalRow(label = "RF Module", value = "${thermalState.radioTempC}°C", progress = 0.65f, barColor = SignalAmber)
        Spacer(modifier = Modifier.height(4.dp))

        // RAM Memory
        ThermalRow(label = "RAM Capacity", value = "$ramUsagePercent%", progress = ramUsagePercent / 100f, barColor = WarmInstrumentWhite)
    }
}

@Composable
private fun ThermalRow(
    label: String,
    value: String,
    progress: Float,
    barColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = WarmInstrumentWhite.copy(alpha = 0.8f),
            fontFamily = InstrumentMonoFont,
            modifier = Modifier.width(90.dp)
        )
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .weight(1f)
                .height(6.dp),
            color = barColor,
            trackColor = Color.DarkGray
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall,
            color = WarmInstrumentWhite,
            fontFamily = InstrumentMonoFont,
            modifier = Modifier.width(50.dp)
        )
    }
}
