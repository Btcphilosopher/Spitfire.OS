package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.spitfire.core.events.EventSeverity
import com.example.spitfire.sdk.SpitfireSdk
import com.example.ui.components.TactileButton
import com.example.ui.theme.BritishEngineeringGreen
import com.example.ui.theme.InstrumentBorder
import com.example.ui.theme.InstrumentCardBackground
import com.example.ui.theme.InstrumentMonoFont
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SpitfireBlack
import com.example.ui.theme.WarmInstrumentWhite
import com.example.ui.theme.WarningRed

@Composable
fun DevConsoleScreen(
    sdk: SpitfireSdk,
    modifier: Modifier = Modifier
) {
    val events = sdk.journal.eventsList
    val scope = rememberCoroutineScope()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SpitfireBlack)
            .padding(10.dp)
    ) {
        Text("SPITFIRE DEVELOPER CONSOLE & EVENT LAB", style = MaterialTheme.typography.titleLarge, color = WarmInstrumentWhite)
        Text("API EXPLORER | FAILURE INJECTION LAB | EVENT JOURNAL", style = MaterialTheme.typography.labelSmall, color = SignalAmber)

        Spacer(modifier = Modifier.height(8.dp))

        // FAILURE LAB CONTROLS
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(InstrumentCardBackground)
                .border(1.dp, InstrumentBorder)
                .padding(10.dp)
        ) {
            Text("SPITFIRE FAILURE LAB", style = MaterialTheme.typography.labelSmall, color = SignalAmber)
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TactileButton(
                    onClick = { sdk.injectLinkDegradation(45f) },
                    text = "PACKET LOSS 45%",
                    containerColor = SignalAmber,
                    modifier = Modifier.weight(1f)
                )
                TactileButton(
                    onClick = { sdk.injectLinkDegradation(100f) },
                    text = "SIMULATE LINK LOSS",
                    containerColor = WarningRed,
                    modifier = Modifier.weight(1f)
                )
                TactileButton(
                    onClick = { sdk.restoreSystemState() },
                    text = "RESTORE SYSTEM",
                    containerColor = BritishEngineeringGreen,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text("EVENT JOURNAL STREAM (${events.size})", style = MaterialTheme.typography.labelLarge, color = WarmInstrumentWhite)
        Spacer(modifier = Modifier.height(4.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            items(events) { ev ->
                val severityColor = when (ev.severity) {
                    EventSeverity.INFO -> BritishEngineeringGreen
                    EventSeverity.WARNING -> SignalAmber
                    EventSeverity.ERROR, EventSeverity.CRITICAL -> WarningRed
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                        .background(InstrumentCardBackground)
                        .border(1.dp, InstrumentBorder)
                        .padding(6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "[${ev.type}] from ${ev.source}",
                            style = MaterialTheme.typography.labelSmall,
                            color = severityColor,
                            fontFamily = InstrumentMonoFont
                        )
                        Text(ev.payload, style = MaterialTheme.typography.labelSmall, color = WarmInstrumentWhite)
                    }
                    Text(
                        "%tT".format(ev.timestamp),
                        style = MaterialTheme.typography.labelSmall,
                        color = WarmInstrumentWhite.copy(alpha = 0.6f),
                        fontFamily = InstrumentMonoFont
                    )
                }
            }
        }
    }
}
