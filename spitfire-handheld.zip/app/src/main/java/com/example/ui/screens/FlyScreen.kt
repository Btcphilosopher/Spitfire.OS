package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.spitfire.drone.FlightCommand
import com.example.spitfire.sdk.SpitfireSdk
import com.example.ui.components.AhrsHorizonCanvas
import com.example.ui.components.TactileButton
import com.example.ui.theme.BritishEngineeringGreen
import com.example.ui.theme.InstrumentBorder
import com.example.ui.theme.InstrumentCardBackground
import com.example.ui.theme.InstrumentMonoFont
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SpitfireBlack
import com.example.ui.theme.SpitfireGraphite
import com.example.ui.theme.WarmInstrumentWhite
import com.example.ui.theme.WarningRed
import kotlinx.coroutines.launch

@Composable
fun FlyScreen(
    sdk: SpitfireSdk,
    modifier: Modifier = Modifier
) {
    val telemetry by sdk.drone.telemetry.collectAsState()
    val scope = rememberCoroutineScope()
    var gimbalPitch by remember { mutableStateOf(telemetry.gimbal.pitchDegrees) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SpitfireBlack)
            .padding(8.dp)
    ) {
        // TOP STATUS BAR
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(InstrumentCardBackground)
                .border(1.dp, InstrumentBorder)
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "SPITFIRE S-01: ${telemetry.flightMode}",
                style = MaterialTheme.typography.titleMedium,
                color = SignalAmber,
                fontFamily = InstrumentMonoFont
            )
            Text(
                text = "LINK ${telemetry.linkQualityPercent}% | GPS ${telemetry.position.satelliteCount} SATS (${telemetry.position.fixType})",
                style = MaterialTheme.typography.labelSmall,
                color = WarmInstrumentWhite,
                fontFamily = InstrumentMonoFont
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // MAIN LIVE COCKPIT SPLIT
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            // LEFT: CAMERA VIEWPORT
            Box(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight()
                    .background(SpitfireGraphite)
                    .border(1.dp, InstrumentBorder)
            ) {
                // Camera Stream Placeholder with HUD Overlays
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("SPITFIRE VISION 24MM", color = SignalAmber, style = MaterialTheme.typography.labelSmall)
                        Text("1/1000 ISO 200 f/2.8", color = WarmInstrumentWhite, style = MaterialTheme.typography.labelSmall)
                    }

                    // Center Crosshair
                    Box(modifier = Modifier.align(Alignment.CenterHorizontally)) {
                        Text(
                            "+",
                            color = SignalAmber,
                            fontSize = 36.sp,
                            fontFamily = InstrumentMonoFont
                        )
                    }

                    // Bottom Camera Feed Info
                    Text(
                        "LAT ${"%08.4f".format(telemetry.position.latitude)}  LON ${"%08.4f".format(telemetry.position.longitude)}",
                        color = WarmInstrumentWhite,
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = InstrumentMonoFont
                    )
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            // RIGHT: AHRS TELEMETRY COCKPIT
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(SpitfireGraphite)
                    .border(1.dp, InstrumentBorder)
            ) {
                AhrsHorizonCanvas(
                    pitchDegrees = telemetry.attitude.pitchDegrees,
                    rollDegrees = telemetry.attitude.rollDegrees,
                    headingDegrees = telemetry.position.headingDegrees,
                    altitudeMeters = telemetry.position.altitudeMeters,
                    speedMps = telemetry.position.groundSpeedMps,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // TELEMETRY STRIP READOUTS
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(InstrumentCardBackground)
                .border(1.dp, InstrumentBorder)
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            MetricBlock("ALTITUDE", "%05.1f M".format(telemetry.position.altitudeMeters))
            MetricBlock("GROUND SPEED", "%04.1f M/S".format(telemetry.position.groundSpeedMps))
            MetricBlock("HEADING", "%03d°".format(telemetry.position.headingDegrees.toInt()))
            MetricBlock("BATTERY", "${telemetry.batteryPercent}%")
            MetricBlock("GIMBAL", "${telemetry.gimbal.pitchDegrees.toInt()}°")
        }

        Spacer(modifier = Modifier.height(6.dp))

        // COMMAND CONTROL BAR
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TactileButton(
                onClick = { scope.launch { sdk.captureImage() } },
                text = "CAPTURE",
                containerColor = BritishEngineeringGreen,
                modifier = Modifier.weight(1f),
                testTag = "capture_button"
            )
            TactileButton(
                onClick = { scope.launch { sdk.drone.sendCommand(FlightCommand.StartMission) } },
                text = "START",
                containerColor = SignalAmber,
                modifier = Modifier.weight(1f),
                testTag = "start_mission_button"
            )
            TactileButton(
                onClick = { scope.launch { sdk.drone.sendCommand(FlightCommand.ReturnToHome) } },
                text = "RTH",
                containerColor = InstrumentBorder,
                modifier = Modifier.weight(1f),
                testTag = "rth_button"
            )
            TactileButton(
                onClick = { scope.launch { sdk.drone.sendCommand(FlightCommand.EmergencyStop) } },
                text = "EMERGENCY",
                containerColor = WarningRed,
                modifier = Modifier.weight(1f),
                testTag = "emergency_button"
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // GIMBAL PITCH CONTROL SLIDER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("GIMBAL PITCH:", color = WarmInstrumentWhite, style = MaterialTheme.typography.labelSmall)
            Spacer(modifier = Modifier.width(8.dp))
            Slider(
                value = gimbalPitch,
                onValueChange = {
                    gimbalPitch = it
                    scope.launch { sdk.drone.sendCommand(FlightCommand.SetGimbalPitch(it)) }
                },
                valueRange = -90f..0f,
                colors = SliderDefaults.colors(
                    thumbColor = SignalAmber,
                    activeTrackColor = SignalAmber,
                    inactiveTrackColor = InstrumentBorder
                ),
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("${gimbalPitch.toInt()}°", color = WarmInstrumentWhite, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun MetricBlock(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = WarmInstrumentWhite.copy(alpha = 0.6f))
        Text(value, style = MaterialTheme.typography.titleMedium, color = WarmInstrumentWhite, fontFamily = InstrumentMonoFont)
    }
}
