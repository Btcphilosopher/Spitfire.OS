package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.spitfire.imagery.ImageRecord
import com.example.spitfire.mission.Mission
import com.example.ui.theme.AirframeBlue
import com.example.ui.theme.DataBlue
import com.example.ui.theme.InstrumentBorder
import com.example.ui.theme.InstrumentGridLine
import com.example.ui.theme.InstrumentMonoFont
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SpitfireGraphite
import com.example.ui.theme.WarningRed

@Composable
fun TactileMapCanvas(
    mission: Mission,
    droneLat: Double,
    droneLon: Double,
    droneHeading: Double,
    images: List<ImageRecord>,
    selectedImageId: String?,
    onImageSelected: (ImageRecord) -> Unit,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .clickable { /* Map pan/zoom hook */ }
    ) {
        val w = size.width
        val h = size.height

        // Dark Ordnance Survey styled background
        drawRect(color = SpitfireGraphite)

        // Grid lines
        val gridStep = 40.dp.toPx()
        var gx = 0f
        while (gx < w) {
            drawLine(
                color = InstrumentGridLine,
                start = Offset(gx, 0f),
                end = Offset(gx, h),
                strokeWidth = 1.dp.toPx()
            )
            gx += gridStep
        }
        var gy = 0f
        while (gy < h) {
            drawLine(
                color = InstrumentGridLine,
                start = Offset(0f, gy),
                end = Offset(w, gy),
                strokeWidth = 1.dp.toPx()
            )
            gy += gridStep
        }

        // Map Scale Projection Transformer (Humber Area)
        val baseLat = 53.7443
        val baseLon = -0.4552
        fun toCanvas(lat: Double, lon: Double): Offset {
            val dx = (lon - baseLon) * 60000f + w / 2f
            val dy = -(lat - baseLat) * 90000f + h / 2f
            return Offset(dx.toFloat(), dy.toFloat())
        }

        // Draw Mission Survey Polygon Area
        val areaPoints = mission.area.boundingCoordinates.map { toCanvas(it.first, it.second) }
        if (areaPoints.size >= 3) {
            val polyPath = Path().apply {
                moveTo(areaPoints[0].x, areaPoints[0].y)
                for (i in 1 until areaPoints.size) {
                    lineTo(areaPoints[i].x, areaPoints[i].y)
                }
                close()
            }
            drawPath(
                path = polyPath,
                color = AirframeBlue.copy(alpha = 0.25f)
            )
            drawPath(
                path = polyPath,
                color = AirframeBlue,
                style = Stroke(width = 1.5.dp.toPx())
            )
        }

        // Draw Waypoints Route
        val routePath = Path()
        mission.waypoints.forEachIndexed { idx, wp ->
            val p = toCanvas(wp.latitude, wp.longitude)
            if (idx == 0) routePath.moveTo(p.x, p.y) else routePath.lineTo(p.x, p.y)

            // Draw Waypoint Circle & Index
            drawCircle(color = SignalAmber, radius = 6.dp.toPx(), center = p)
            drawCircle(color = Color.Black, radius = 6.dp.toPx(), center = p, style = Stroke(width = 1.dp.toPx()))

            val label = "WP${wp.index}"
            val res = textMeasurer.measure(
                label,
                style = TextStyle(color = Color.White, fontSize = 10.sp, fontFamily = InstrumentMonoFont)
            )
            drawText(res, topLeft = Offset(p.x + 8.dp.toPx(), p.y - 10.dp.toPx()))
        }
        drawPath(
            path = routePath,
            color = SignalAmber,
            style = Stroke(width = 2.dp.toPx())
        )

        // Draw Geotagged Image Pin Markers
        images.forEach { img ->
            val p = toCanvas(img.position.latitude, img.position.longitude)
            val isSelected = img.imageId == selectedImageId
            val pinColor = if (isSelected) WarningRed else DataBlue

            drawCircle(color = pinColor, radius = if (isSelected) 9.dp.toPx() else 6.dp.toPx(), center = p)
            drawCircle(color = Color.White, radius = if (isSelected) 9.dp.toPx() else 6.dp.toPx(), center = p, style = Stroke(width = 1.5.dp.toPx()))

            val tag = if (img.annotations.isNotEmpty()) "${img.imageId} [!] " else img.imageId
            val tagRes = textMeasurer.measure(
                tag,
                style = TextStyle(color = pinColor, fontSize = 9.sp, fontFamily = InstrumentMonoFont)
            )
            drawText(tagRes, topLeft = Offset(p.x - tagRes.size.width / 2f, p.y + 10.dp.toPx()))
        }

        // Draw Drone Vector Aircraft Marker
        val dronePos = toCanvas(droneLat, droneLon)
        rotate(degrees = droneHeading.toFloat(), pivot = dronePos) {
            val droneShape = Path().apply {
                moveTo(dronePos.x, dronePos.y - 16.dp.toPx())
                lineTo(dronePos.x + 10.dp.toPx(), dronePos.y + 12.dp.toPx())
                lineTo(dronePos.x, dronePos.y + 6.dp.toPx())
                lineTo(dronePos.x - 10.dp.toPx(), dronePos.y + 12.dp.toPx())
                close()
            }
            drawPath(path = droneShape, color = SignalAmber)
            drawPath(path = droneShape, color = Color.White, style = Stroke(width = 1.5.dp.toPx()))
        }

        // Ordnance Survey Overlay Legend
        val legendText = "HUMBER FIELD GRID - 1:5000 | SPITFIRE GIS"
        val legendRes = textMeasurer.measure(
            legendText,
            style = TextStyle(color = InstrumentBorder, fontSize = 9.sp, fontFamily = InstrumentMonoFont)
        )
        drawText(legendRes, topLeft = Offset(12.dp.toPx(), h - 20.dp.toPx()))
    }
}
