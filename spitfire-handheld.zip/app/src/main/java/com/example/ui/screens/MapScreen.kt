package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.spitfire.sdk.SpitfireSdk
import com.example.ui.components.TactileMapCanvas
import com.example.ui.theme.InstrumentBorder
import com.example.ui.theme.InstrumentCardBackground
import com.example.ui.theme.InstrumentMonoFont
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SpitfireBlack
import com.example.ui.theme.SpitfireGraphite
import com.example.ui.theme.WarmInstrumentWhite

@Composable
fun MapScreen(
    sdk: SpitfireSdk,
    modifier: Modifier = Modifier
) {
    val telemetry by sdk.drone.telemetry.collectAsState()
    val activeMission by sdk.activeMission.collectAsState()
    val images by sdk.images.collectAsState()
    val selectedImage by sdk.selectedImage.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SpitfireBlack)
            .padding(8.dp)
    ) {
        // TOP HEADER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(InstrumentCardBackground)
                .border(1.dp, InstrumentBorder)
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "SPITFIRE TACTICAL GIS SURVEY MAP",
                style = MaterialTheme.typography.titleMedium,
                color = WarmInstrumentWhite
            )
            Text(
                "AIRCRAFT @ (${"%.4f".format(telemetry.position.latitude)}, ${"%.4f".format(telemetry.position.longitude)})",
                style = MaterialTheme.typography.labelSmall,
                color = SignalAmber,
                fontFamily = InstrumentMonoFont
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // SPLIT VIEW: MAP + IMAGE PREVIEW
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            // MAP CANVAS
            Box(
                modifier = Modifier
                    .weight(1.3f)
                    .fillMaxHeight()
                    .border(1.dp, InstrumentBorder)
            ) {
                TactileMapCanvas(
                    mission = activeMission,
                    droneLat = telemetry.position.latitude,
                    droneLon = telemetry.position.longitude,
                    droneHeading = telemetry.position.headingDegrees,
                    images = images,
                    selectedImageId = selectedImage?.imageId,
                    onImageSelected = { sdk.selectImage(it) },
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // GEOTAGGED IMAGE INSPECTION SIDE PANEL
            Column(
                modifier = Modifier
                    .weight(0.9f)
                    .fillMaxHeight()
                    .background(InstrumentCardBackground)
                    .border(1.dp, InstrumentBorder)
                    .padding(10.dp)
            ) {
                Text(
                    "GEOTAGGED IMAGE DETAIL",
                    style = MaterialTheme.typography.labelLarge,
                    color = SignalAmber
                )

                Spacer(modifier = Modifier.height(8.dp))

                if (selectedImage != null) {
                    val img = selectedImage!!
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .background(SpitfireGraphite)
                            .border(1.dp, InstrumentBorder),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                img.sampleTitle,
                                color = WarmInstrumentWhite,
                                style = MaterialTheme.typography.labelLarge
                            )
                            Text(
                                "ID: ${img.imageId}",
                                color = SignalAmber,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = InstrumentMonoFont
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("LAT: ${img.position.latitude}", style = MaterialTheme.typography.labelSmall, color = WarmInstrumentWhite, fontFamily = InstrumentMonoFont)
                    Text("LON: ${img.position.longitude}", style = MaterialTheme.typography.labelSmall, color = WarmInstrumentWhite, fontFamily = InstrumentMonoFont)
                    Text("ALTITUDE: ${img.position.altitudeMeters} M", style = MaterialTheme.typography.labelSmall, color = WarmInstrumentWhite, fontFamily = InstrumentMonoFont)
                    Text("ANNOTATIONS: ${img.annotations.size}", style = MaterialTheme.typography.labelSmall, color = SignalAmber)

                    Spacer(modifier = Modifier.height(8.dp))

                    img.annotations.forEach { ann ->
                        Text(
                            "• [${ann.defectCategory}] ${ann.label}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.Yellow
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("SELECT AN IMAGE MARKER ON THE MAP", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}
