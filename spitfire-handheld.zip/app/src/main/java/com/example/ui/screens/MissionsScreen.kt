package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.spitfire.mission.Mission
import com.example.spitfire.sdk.SpitfireSdk
import com.example.ui.components.TactileButton
import com.example.ui.theme.AirframeBlue
import com.example.ui.theme.BritishEngineeringGreen
import com.example.ui.theme.InstrumentBorder
import com.example.ui.theme.InstrumentCardBackground
import com.example.ui.theme.InstrumentMonoFont
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SpitfireBlack
import com.example.ui.theme.WarmInstrumentWhite

@Composable
fun MissionsScreen(
    sdk: SpitfireSdk,
    modifier: Modifier = Modifier
) {
    val activeMission by sdk.activeMission.collectAsState()

    var altitude by remember { mutableFloatStateOf(activeMission.altitudeMeters.toFloat()) }
    var speed by remember { mutableFloatStateOf(activeMission.speedMps.toFloat()) }
    var areaKm2 by remember { mutableFloatStateOf(activeMission.area.areaKm2.toFloat()) }

    val surveyEstimate = remember(altitude, speed, areaKm2) {
        sdk.calculateSurvey(areaKm2.toDouble(), altitude.toDouble(), speed.toDouble())
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SpitfireBlack)
            .padding(12.dp)
    ) {
        Text(
            text = "SPITFIRE SURVEY MISSION PLANNER",
            style = MaterialTheme.typography.titleLarge,
            color = WarmInstrumentWhite
        )
        Text(
            text = "HUMBER INDUSTRIAL CORRIDOR | FLIGHT GEOMETRY PROJECTION",
            style = MaterialTheme.typography.labelSmall,
            color = SignalAmber
        )

        Spacer(modifier = Modifier.height(12.dp))

        // SURVEY PARAMETER SLIDERS
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(InstrumentCardBackground, RoundedCornerShape(2.dp))
                .border(1.dp, InstrumentBorder)
                .padding(12.dp)
        ) {
            Text("SURVEY CONFIGURATION", style = MaterialTheme.typography.labelLarge, color = SignalAmber)
            Spacer(modifier = Modifier.height(8.dp))

            SliderRow(
                label = "ALTITUDE",
                valueText = "${altitude.toInt()} M",
                value = altitude,
                range = 30f..120f,
                onValueChange = { altitude = it }
            )

            SliderRow(
                label = "GROUND SPEED",
                valueText = "${speed.toInt()} M/S",
                value = speed,
                range = 4f..18f,
                onValueChange = { speed = it }
            )

            SliderRow(
                label = "AREA COVERAGE",
                valueText = "%.1f km²".format(areaKm2),
                value = areaKm2,
                range = 1f..12f,
                onValueChange = { areaKm2 = it }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // CALCULATED ESTIMATES
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(InstrumentCardBackground, RoundedCornerShape(2.dp))
                .border(1.dp, AirframeBlue)
                .padding(12.dp)
        ) {
            Text("ENGINEERING ESTIMATES (SIMULATED)", style = MaterialTheme.typography.labelSmall, color = AirframeBlue)
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                EstimateMetric("EST. IMAGES", "${surveyEstimate.imageCount}")
                EstimateMetric("FLIGHT TIME", "${surveyEstimate.flightTimeMinutes} MIN")
                EstimateMetric("DATA VOLUME", "${surveyEstimate.dataVolumeMB} MB")
                EstimateMetric("BATTERY REQ.", "${surveyEstimate.batteryRequirementPercent}%")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // WAYPOINTS LIST
        Text("MISSION WAYPOINTS (${activeMission.waypoints.size})", style = MaterialTheme.typography.labelLarge, color = WarmInstrumentWhite)
        Spacer(modifier = Modifier.height(6.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            items(activeMission.waypoints) { wp ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .background(InstrumentCardBackground)
                        .border(1.dp, InstrumentBorder)
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "WP-${wp.index}",
                        style = MaterialTheme.typography.labelLarge,
                        color = SignalAmber,
                        fontFamily = InstrumentMonoFont
                    )
                    Text(
                        text = "LAT ${"%.4f".format(wp.latitude)} LON ${"%.4f".format(wp.longitude)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = WarmInstrumentWhite,
                        fontFamily = InstrumentMonoFont
                    )
                    Text(
                        text = "${wp.altitudeMeters.toInt()}M @ ${wp.speedMps.toInt()}M/S",
                        style = MaterialTheme.typography.labelSmall,
                        color = AirframeBlue,
                        fontFamily = InstrumentMonoFont
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        TactileButton(
            onClick = {
                val updated = activeMission.copy(
                    altitudeMeters = altitude.toDouble(),
                    speedMps = speed.toDouble()
                )
                sdk.updateMission(updated)
            },
            text = "UPLOAD MISSION TO AIRCRAFT",
            containerColor = BritishEngineeringGreen,
            modifier = Modifier.fillMaxWidth(),
            testTag = "upload_mission_button"
        )
    }
}

@Composable
private fun SliderRow(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = WarmInstrumentWhite,
            modifier = Modifier.width(110.dp)
        )
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = SignalAmber,
                activeTrackColor = SignalAmber,
                inactiveTrackColor = InstrumentBorder
            ),
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            valueText,
            style = MaterialTheme.typography.labelSmall,
            color = SignalAmber,
            fontFamily = InstrumentMonoFont,
            modifier = Modifier.width(60.dp)
        )
    }
}

@Composable
private fun EstimateMetric(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = WarmInstrumentWhite.copy(alpha = 0.7f))
        Text(value, style = MaterialTheme.typography.titleMedium, color = WarmInstrumentWhite, fontFamily = InstrumentMonoFont)
    }
}
