package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AirframeBlue
import com.example.ui.theme.FieldOlive
import com.example.ui.theme.InstrumentBorder
import com.example.ui.theme.InstrumentMonoFont
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.WarmInstrumentWhite

@Composable
fun AhrsHorizonCanvas(
    pitchDegrees: Float,
    rollDegrees: Float,
    headingDegrees: Double,
    altitudeMeters: Double,
    speedMps: Double,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f

        // Draw Sky and Ground background split
        rotate(degrees = -rollDegrees, pivot = Offset(cx, cy)) {
            val pitchOffset = (pitchDegrees / 30f) * (h / 2f)
            val horizonY = cy + pitchOffset

            // Sky
            drawRect(
                color = AirframeBlue.copy(alpha = 0.85f),
                topLeft = Offset(0f, 0f),
                size = androidx.compose.ui.geometry.Size(w, horizonY.coerceIn(0f, h))
            )
            // Ground
            drawRect(
                color = FieldOlive.copy(alpha = 0.85f),
                topLeft = Offset(0f, horizonY.coerceIn(0f, h)),
                size = androidx.compose.ui.geometry.Size(w, (h - horizonY).coerceAtLeast(0f))
            )

            // Horizon line
            drawLine(
                color = WarmInstrumentWhite,
                start = Offset(cx - w * 0.4f, horizonY),
                end = Offset(cx + w * 0.4f, horizonY),
                strokeWidth = 2.dp.toPx()
            )

            // Pitch ladder lines (+10°, -10°)
            val p10 = (10f / 30f) * (h / 2f)
            drawLine(
                color = WarmInstrumentWhite.copy(alpha = 0.8f),
                start = Offset(cx - 30.dp.toPx(), horizonY - p10),
                end = Offset(cx + 30.dp.toPx(), horizonY - p10),
                strokeWidth = 1.5.dp.toPx()
            )
            drawLine(
                color = WarmInstrumentWhite.copy(alpha = 0.8f),
                start = Offset(cx - 30.dp.toPx(), horizonY + p10),
                end = Offset(cx + 30.dp.toPx(), horizonY + p10),
                strokeWidth = 1.5.dp.toPx()
            )
        }

        // Fixed Aircraft Reticle Symbol (Yellow Wings)
        val reticlePath = Path().apply {
            moveTo(cx - 40.dp.toPx(), cy)
            lineTo(cx - 15.dp.toPx(), cy)
            lineTo(cx - 10.dp.toPx(), cy + 10.dp.toPx())
            moveTo(cx + 40.dp.toPx(), cy)
            lineTo(cx + 15.dp.toPx(), cy)
            lineTo(cx + 10.dp.toPx(), cy + 10.dp.toPx())
            moveTo(cx - 5.dp.toPx(), cy)
            lineTo(cx + 5.dp.toPx(), cy)
        }
        drawPath(
            path = reticlePath,
            color = SignalAmber,
            style = Stroke(width = 3.dp.toPx())
        )

        // Top Compass Heading Strip
        drawRect(
            color = Color.Black.copy(alpha = 0.6f),
            topLeft = Offset(cx - 100.dp.toPx(), 8.dp.toPx()),
            size = androidx.compose.ui.geometry.Size(200.dp.toPx(), 26.dp.toPx())
        )
        drawRect(
            color = InstrumentBorder,
            topLeft = Offset(cx - 100.dp.toPx(), 8.dp.toPx()),
            size = androidx.compose.ui.geometry.Size(200.dp.toPx(), 26.dp.toPx()),
            style = Stroke(width = 1.dp.toPx())
        )
        val headingText = "HDG %03d°".format(headingDegrees.toInt())
        val headingResult = textMeasurer.measure(
            headingText,
            style = TextStyle(color = WarmInstrumentWhite, fontSize = 12.sp, fontFamily = InstrumentMonoFont)
        )
        drawText(
            textLayoutResult = headingResult,
            topLeft = Offset(cx - headingResult.size.width / 2f, 12.dp.toPx())
        )

        // Right Altitude Tape
        val altText = "ALT %05.1f M".format(altitudeMeters)
        val altResult = textMeasurer.measure(
            altText,
            style = TextStyle(color = WarmInstrumentWhite, fontSize = 11.sp, fontFamily = InstrumentMonoFont)
        )
        drawRect(
            color = Color.Black.copy(alpha = 0.6f),
            topLeft = Offset(w - 110.dp.toPx(), cy - 20.dp.toPx()),
            size = androidx.compose.ui.geometry.Size(102.dp.toPx(), 40.dp.toPx())
        )
        drawRect(
            color = SignalAmber,
            topLeft = Offset(w - 110.dp.toPx(), cy - 20.dp.toPx()),
            size = androidx.compose.ui.geometry.Size(102.dp.toPx(), 40.dp.toPx()),
            style = Stroke(width = 1.5.dp.toPx())
        )
        drawText(
            textLayoutResult = altResult,
            topLeft = Offset(w - 104.dp.toPx(), cy - altResult.size.height / 2f)
        )

        // Left Airspeed Tape
        val spdText = "SPD %04.1f M/S".format(speedMps)
        val spdResult = textMeasurer.measure(
            spdText,
            style = TextStyle(color = WarmInstrumentWhite, fontSize = 11.sp, fontFamily = InstrumentMonoFont)
        )
        drawRect(
            color = Color.Black.copy(alpha = 0.6f),
            topLeft = Offset(8.dp.toPx(), cy - 20.dp.toPx()),
            size = androidx.compose.ui.geometry.Size(112.dp.toPx(), 40.dp.toPx())
        )
        drawRect(
            color = InstrumentBorder,
            topLeft = Offset(8.dp.toPx(), cy - 20.dp.toPx()),
            size = androidx.compose.ui.geometry.Size(112.dp.toPx(), 40.dp.toPx()),
            style = Stroke(width = 1.dp.toPx())
        )
        drawText(
            textLayoutResult = spdResult,
            topLeft = Offset(14.dp.toPx(), cy - spdResult.size.height / 2f)
        )
    }
}
