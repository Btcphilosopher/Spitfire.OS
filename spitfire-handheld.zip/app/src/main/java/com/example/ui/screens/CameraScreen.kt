package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.spitfire.sdk.SpitfireSdk
import com.example.ui.components.TactileButton
import com.example.ui.theme.BritishEngineeringGreen
import com.example.ui.theme.InstrumentBorder
import com.example.ui.theme.InstrumentCardBackground
import com.example.ui.theme.InstrumentMonoFont
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SpitfireBlack
import com.example.ui.theme.SpitfireGraphite
import com.example.ui.theme.WarmInstrumentWhite
import kotlinx.coroutines.launch

@Composable
fun CameraScreen(
    sdk: SpitfireSdk,
    modifier: Modifier = Modifier
) {
    val cameraState by sdk.cameraState.collectAsState()
    val scope = rememberCoroutineScope()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SpitfireBlack)
            .padding(8.dp)
    ) {
        // TOP BAR
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(InstrumentCardBackground)
                .border(1.dp, InstrumentBorder)
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("SPITFIRE VISION OPTICS", style = MaterialTheme.typography.titleMedium, color = SignalAmber)
            Text("${cameraState.resolution} | SENSOR ${cameraState.sensorTemperatureC}°C", style = MaterialTheme.typography.labelSmall, color = WarmInstrumentWhite, fontFamily = InstrumentMonoFont)
        }

        Spacer(modifier = Modifier.height(6.dp))

        // VIEWPORT
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(SpitfireGraphite)
                .border(1.dp, InstrumentBorder),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "+",
                color = SignalAmber,
                fontSize = 48.sp,
                fontFamily = InstrumentMonoFont
            )

            // Minimalist Overlay Elements
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text("MODE: ${cameraState.mode}", color = WarmInstrumentWhite, style = MaterialTheme.typography.labelSmall)
                Text("FOCUS: ${cameraState.focusMode}", color = WarmInstrumentWhite, style = MaterialTheme.typography.labelSmall)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // OPTICS METRICS STRIP
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(InstrumentCardBackground)
                .border(1.dp, InstrumentBorder)
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            OpticBlock("FOCAL", "${cameraState.focalLengthMm} MM")
            OpticBlock("SHUTTER", cameraState.shutterSpeed)
            OpticBlock("ISO", "${cameraState.iso}")
            OpticBlock("APERTURE", cameraState.aperture)
            OpticBlock("WHITE BAL", cameraState.whiteBalance)
        }

        Spacer(modifier = Modifier.height(8.dp))

        TactileButton(
            onClick = { scope.launch { sdk.captureImage() } },
            text = "TRIGGER HIGH-RESOLUTION CAPTURE",
            containerColor = BritishEngineeringGreen,
            modifier = Modifier.fillMaxWidth(),
            testTag = "camera_capture_button"
        )
    }
}

@Composable
private fun OpticBlock(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
        Text(value, style = MaterialTheme.typography.titleMedium, color = WarmInstrumentWhite, fontFamily = InstrumentMonoFont)
    }
}
