package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.spitfire.sdk.SpitfireSdk
import com.example.ui.components.TactileButton
import com.example.ui.components.ThermalTwinWidget
import com.example.ui.theme.InstrumentBorder
import com.example.ui.theme.InstrumentCardBackground
import com.example.ui.theme.InstrumentMonoFont
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SpitfireBlack
import com.example.ui.theme.WarmInstrumentWhite
import com.example.ui.theme.WarningRed

@Composable
fun DigitalTwinScreen(
    sdk: SpitfireSdk,
    modifier: Modifier = Modifier
) {
    val deviceState by sdk.deviceState.collectAsState()
    var simTemp by remember { mutableFloatStateOf(38f) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SpitfireBlack)
            .padding(12.dp)
    ) {
        Text("SPITFIRE HANDHELD DIGITAL TWIN", style = MaterialTheme.typography.titleLarge, color = WarmInstrumentWhite)
        Text("FIELD COMPUTER ARCHITECTURE & DIAGNOSTICS", style = MaterialTheme.typography.labelSmall, color = SignalAmber)

        Spacer(modifier = Modifier.height(12.dp))

        // DEVICE IDENTIFICATION BLOCK
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(InstrumentCardBackground, RoundedCornerShape(2.dp))
                .border(1.dp, InstrumentBorder)
                .padding(12.dp)
        ) {
            Text("DEVICE PROFILE: ${sdk.identity.deviceId}", style = MaterialTheme.typography.labelLarge, color = SignalAmber)
            Spacer(modifier = Modifier.height(4.dp))
            Text("HARDWARE: ${sdk.identity.hardwareRevision} | SW: ${sdk.identity.softwareVersion}", style = MaterialTheme.typography.labelSmall, color = WarmInstrumentWhite, fontFamily = InstrumentMonoFont)
            Text("PROFILE: ${sdk.identity.manufacturingProfile} | REGION: ${sdk.identity.region}", style = MaterialTheme.typography.labelSmall, color = WarmInstrumentWhite, fontFamily = InstrumentMonoFont)
        }

        Spacer(modifier = Modifier.height(12.dp))

        // THERMAL DIGITAL TWIN
        ThermalTwinWidget(
            thermalState = deviceState.thermalState,
            cpuUsagePercent = (simTemp * 1.8f).toInt().coerceIn(10, 99)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // SIMULATED THERMAL LOAD CONTROLLER
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(InstrumentCardBackground)
                .border(1.dp, InstrumentBorder)
                .padding(12.dp)
        ) {
            Text("THERMAL STRESS SIMULATOR", style = MaterialTheme.typography.labelSmall, color = SignalAmber)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TactileButton(
                    onClick = {
                        simTemp = 38f
                        sdk.injectThermalLoad(simTemp)
                    },
                    text = "NORMAL (38°C)",
                    containerColor = InstrumentBorder,
                    modifier = Modifier.weight(1f)
                )
                TactileButton(
                    onClick = {
                        simTemp = 44f
                        sdk.injectThermalLoad(simTemp)
                    },
                    text = "WARM (44°C)",
                    containerColor = SignalAmber,
                    modifier = Modifier.weight(1f)
                )
                TactileButton(
                    onClick = {
                        simTemp = 54f
                        sdk.injectThermalLoad(simTemp)
                    },
                    text = "THROTTLE (54°C)",
                    containerColor = WarningRed,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
