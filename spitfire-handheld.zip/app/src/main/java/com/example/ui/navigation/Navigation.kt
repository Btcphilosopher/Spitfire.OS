package com.example.ui.navigation

enum class SpitfireScreen(val label: String) {
    FLY("FLY"),
    MISSIONS("MISSIONS"),
    MAP("MAP"),
    CAMERA("CAMERA"),
    GALLERY("GALLERY"),
    TELEMETRY("TELEMETRY"),
    TWIN("TWIN"),
    SYNC("SYNC"),
    DEV("DEV"),
    DEMOS("DEMOS")
}
