package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.spitfire.drone.FlightCommand
import com.example.spitfire.imagery.DefectCategory
import com.example.spitfire.sdk.SpitfireSdk
import com.example.ui.components.TactileButton
import com.example.ui.theme.AirframeBlue
import com.example.ui.theme.BritishEngineeringGreen
import com.example.ui.theme.InstrumentBorder
import com.example.ui.theme.InstrumentCardBackground
import com.example.ui.theme.InstrumentMonoFont
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SpitfireBlack
import com.example.ui.theme.WarmInstrumentWhite
import com.example.ui.theme.WarningRed
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SignatureDemosScreen(
    sdk: SpitfireSdk,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    var currentDemoLog by remember { mutableStateOf("SELECT A SIGNATURE DEMO SCENARIO BELOW") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SpitfireBlack)
            .padding(12.dp)
    ) {
        Text("SPITFIRE SIGNATURE FIELD DEMONSTRATIONS", style = MaterialTheme.typography.titleLarge, color = WarmInstrumentWhite)
        Text("GUIDED AEROSPACE SCENARIOS & CRITICAL USER JOURNEYS", style = MaterialTheme.typography.labelSmall, color = SignalAmber)

        Spacer(modifier = Modifier.height(10.dp))

        // DEMO LOG OUTPUT BOX
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .background(InstrumentCardBackground)
                .border(1.dp, SignalAmber)
                .padding(10.dp)
        ) {
            Text("SCENARIO EXECUTION LOG:", style = MaterialTheme.typography.labelSmall, color = SignalAmber)
            Spacer(modifier = Modifier.height(4.dp))
            Text(currentDemoLog, style = MaterialTheme.typography.labelSmall, color = WarmInstrumentWhite, fontFamily = InstrumentMonoFont)
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                DemoCard(
                    title = "DEMO 1: HUMBER BRIDGE FIELD INSPECTION CUJ",
                    description = "Executes full sequence: Connect -> Mission Load -> Auto Flight -> Camera Trigger -> Defect Annotation -> Export Report.",
                    buttonText = "RUN HUMBER INSPECTION",
                    buttonColor = BritishEngineeringGreen,
                    onRun = {
                        scope.launch {
                            currentDemoLog = "[STEP 1/5] Connecting to SPITFIRE S-01 Aircraft..."
                            sdk.drone.connect()
                            delay(800)
                            currentDemoLog = "[STEP 2/5] Uploading Humber Bridge Mission (13 Waypoints)..."
                            sdk.drone.sendCommand(FlightCommand.StartMission)
                            delay(1000)
                            currentDemoLog = "[STEP 3/5] Triggering Spitfire Vision optics capture at WP-4..."
                            sdk.captureImage()
                            delay(1000)
                            currentDemoLog = "[STEP 4/5] Logging Corrosion defect annotation on Deck Pier A-14..."
                            sdk.addAnnotation("IMG-0184", DefectCategory.CORROSION, "Flange Corrosion", "High priority structural rust.")
                            delay(800)
                            currentDemoLog = "[STEP 5/5] Enqueueing sync payload & generating mission report."
                            sdk.syncEngine.enqueue("REPORT", "REP-001", "Humber Bridge Full Inspection Package")
                            currentDemoLog = "✓ SCENARIO COMPLETE: All domain state objects updated!"
                        }
                    }
                )
            }

            item {
                DemoCard(
                    title = "DEMO 2: LOST LINK RECOVERY & FAILSAFE",
                    description = "Simulates packet loss -> Link degraded -> Failsafe hold loiter -> Link restoration.",
                    buttonText = "RUN LOST LINK LAB",
                    buttonColor = SignalAmber,
                    onRun = {
                        scope.launch {
                            currentDemoLog = "[STEP 1/4] Radio link nominal (94% quality, -62 dBm)..."
                            delay(800)
                            currentDemoLog = "[STEP 2/4] Introducing severe packet loss (45% degradation)..."
                            sdk.injectLinkDegradation(45f)
                            delay(1200)
                            currentDemoLog = "[STEP 3/4] Radio link complete dropout (100% loss). Failsafe triggered!"
                            sdk.injectLinkDegradation(100f)
                            delay(1500)
                            currentDemoLog = "[STEP 4/4] Radio link re-established. Vehicle status restored."
                            sdk.restoreSystemState()
                            currentDemoLog = "✓ SCENARIO COMPLETE: Event journal recorded lost link sequence."
                        }
                    }
                )
            }

            item {
                DemoCard(
                    title = "DEMO 3: OFFLINE FIELDWORK & QUEUE SYNC",
                    description = "Simulates offline image capture, annotations, and notes -> Reconnect -> Batch Sync.",
                    buttonText = "RUN OFFLINE FIELDWORK",
                    buttonColor = AirframeBlue,
                    onRun = {
                        scope.launch {
                            currentDemoLog = "[STEP 1/3] Device disconnected from network. Capturing offline data..."
                            sdk.captureImage()
                            sdk.syncEngine.enqueue("OFFLINE_NOTE", "NT-99", "Field note recorded offline in Humber region.")
                            delay(1000)
                            currentDemoLog = "[STEP 2/3] Network re-established. Processing 5 queued items..."
                            val syncedCount = sdk.syncEngine.processSyncQueue()
                            currentDemoLog = "✓ SCENARIO COMPLETE: $syncedCount items synchronized with checksums!"
                        }
                    }
                )
            }

            item {
                DemoCard(
                    title = "DEMO 4: HARDWARE DIGITAL TWIN THERMAL LOAD",
                    description = "Injects thermal load into CPU core -> Triggers thermal status WARM -> THROTTLING.",
                    buttonText = "RUN DIGITAL TWIN STRESS",
                    buttonColor = WarningRed,
                    onRun = {
                        scope.launch {
                            currentDemoLog = "[STEP 1/3] Baseline CPU temperature: 38.2°C (NORMAL)..."
                            delay(800)
                            currentDemoLog = "[STEP 2/3] Applying computational load. CPU Temp: 54.0°C (THROTTLING)..."
                            sdk.injectThermalLoad(54f)
                            delay(1500)
                            currentDemoLog = "[STEP 3/3] Cooling system active. Temperature restored to 38°C."
                            sdk.restoreSystemState()
                            currentDemoLog = "✓ SCENARIO COMPLETE: Thermal digital twin validated."
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun DemoCard(
    title: String,
    description: String,
    buttonText: String,
    buttonColor: androidx.compose.ui.graphics.Color,
    onRun: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(InstrumentCardBackground)
            .border(1.dp, InstrumentBorder)
            .padding(10.dp)
    ) {
        Text(title, style = MaterialTheme.typography.labelLarge, color = SignalAmber)
        Spacer(modifier = Modifier.height(4.dp))
        Text(description, style = MaterialTheme.typography.labelSmall, color = WarmInstrumentWhite)
        Spacer(modifier = Modifier.height(8.dp))

        TactileButton(
            onClick = onRun,
            text = buttonText,
            containerColor = buttonColor,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
