package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.spitfire.sdk.SpitfireSdk
import com.example.ui.components.TactileButton
import com.example.ui.theme.AirframeBlue
import com.example.ui.theme.BritishEngineeringGreen
import com.example.ui.theme.InstrumentBorder
import com.example.ui.theme.InstrumentCardBackground
import com.example.ui.theme.InstrumentMonoFont
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SpitfireBlack
import com.example.ui.theme.WarmInstrumentWhite
import kotlinx.coroutines.launch

@Composable
fun SyncDataScreen(
    sdk: SpitfireSdk,
    modifier: Modifier = Modifier
) {
    val queue by sdk.syncEngine.queue.collectAsState()
    val isSyncing by sdk.syncEngine.isSyncing.collectAsState()
    val scope = rememberCoroutineScope()
    var exportStatusMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SpitfireBlack)
            .padding(12.dp)
    ) {
        Text("SPITFIRE DATA SYNC & MISSION REPORT", style = MaterialTheme.typography.titleLarge, color = WarmInstrumentWhite)
        Text("OFFLINE QUEUE & ENTERPRISE EXPORT ENGINE", style = MaterialTheme.typography.labelSmall, color = SignalAmber)

        Spacer(modifier = Modifier.height(12.dp))

        // OFFLINE QUEUE STATUS
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(InstrumentCardBackground)
                .border(1.dp, InstrumentBorder)
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("QUEUED OBJECTS: ${queue.size}", style = MaterialTheme.typography.labelLarge, color = SignalAmber)
                Text("STATUS: ${if (isSyncing) "SYNCING..." else "IDLE / READY"}", style = MaterialTheme.typography.labelSmall, color = WarmInstrumentWhite)
            }

            TactileButton(
                onClick = { scope.launch { sdk.syncEngine.processSyncQueue() } },
                text = if (isSyncing) "SYNCING..." else "SYNCHRONISE ALL",
                containerColor = BritishEngineeringGreen,
                enabled = !isSyncing && queue.isNotEmpty(),
                testTag = "sync_all_button"
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            items(queue) { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .background(InstrumentCardBackground)
                        .border(1.dp, InstrumentBorder)
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("[${item.objectType}] ${item.objectId}", style = MaterialTheme.typography.labelSmall, color = SignalAmber, fontFamily = InstrumentMonoFont)
                        Text(item.summary, style = MaterialTheme.typography.labelSmall, color = WarmInstrumentWhite)
                    }
                    Text(item.status, style = MaterialTheme.typography.labelSmall, color = AirframeBlue, fontFamily = InstrumentMonoFont)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // EXPORT ENGINE
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(InstrumentCardBackground)
                .border(1.dp, InstrumentBorder)
                .padding(12.dp)
        ) {
            Text("EXPORT MISSION PACKAGE", style = MaterialTheme.typography.labelLarge, color = SignalAmber)
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TactileButton(
                    onClick = { exportStatusMessage = "Generated Mission Report PDF (Humber_Inspection_Report.pdf)" },
                    text = "REPORT PDF",
                    containerColor = AirframeBlue,
                    modifier = Modifier.weight(1f)
                )
                TactileButton(
                    onClick = { exportStatusMessage = "Exported Telemetry Stream (Telemetry_Log_3420.csv)" },
                    text = "TELEMETRY CSV",
                    containerColor = AirframeBlue,
                    modifier = Modifier.weight(1f)
                )
                TactileButton(
                    onClick = { exportStatusMessage = "Exported Annotations & Metadata JSON (Annotations.json)" },
                    text = "METADATA JSON",
                    containerColor = AirframeBlue,
                    modifier = Modifier.weight(1f)
                )
            }

            if (exportStatusMessage != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(exportStatusMessage!!, style = MaterialTheme.typography.labelSmall, color = BritishEngineeringGreen, fontFamily = InstrumentMonoFont)
            }
        }
    }
}
