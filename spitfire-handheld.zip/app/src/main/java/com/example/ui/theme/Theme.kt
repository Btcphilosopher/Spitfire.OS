package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.example.spitfire.core.domain.DisplayMode

private val SpitfireDarkColorScheme = darkColorScheme(
    primary = AirframeBlue,
    onPrimary = WarmInstrumentWhite,
    primaryContainer = BritishEngineeringGreen,
    onPrimaryContainer = WarmInstrumentWhite,
    secondary = SignalAmber,
    onSecondary = SpitfireBlack,
    tertiary = DataBlue,
    background = SpitfireBlack,
    onBackground = WarmInstrumentWhite,
    surface = SpitfireGraphite,
    onSurface = WarmInstrumentWhite,
    surfaceVariant = InstrumentCardBackground,
    onSurfaceVariant = SpitfireAluminium,
    outline = InstrumentBorder,
    error = WarningRed,
    onError = WarmInstrumentWhite
)

private val SpitfireDaylightColorScheme = lightColorScheme(
    primary = AirframeBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD4E3EB),
    onPrimaryContainer = SpitfireBlack,
    secondary = SignalAmber,
    onSecondary = SpitfireBlack,
    tertiary = FieldOlive,
    background = Color(0xFFEFEFEF),
    onBackground = SpitfireBlack,
    surface = Color.White,
    onSurface = SpitfireBlack,
    surfaceVariant = Color(0xFFDFE4E7),
    onSurfaceVariant = Color(0xFF2A3337),
    outline = Color(0xFF8B989E),
    error = WarningRed,
    onError = Color.White
)

private val SpitfireNightColorScheme = darkColorScheme(
    primary = NightRedText,
    onPrimary = NightRedBackground,
    primaryContainer = Color(0xFF4A0A0A),
    onPrimaryContainer = NightRedText,
    secondary = SignalAmber,
    onSecondary = NightRedBackground,
    tertiary = NightRedText,
    background = NightRedBackground,
    onBackground = NightRedText,
    surface = Color(0xFF220A0A),
    onSurface = NightRedText,
    surfaceVariant = Color(0xFF330F0F),
    onSurfaceVariant = NightRedText,
    outline = Color(0xFF661A1A),
    error = NightRedText,
    onError = NightRedBackground
)

@Composable
fun SpitfireTheme(
    displayMode: DisplayMode = DisplayMode.DAYLIGHT,
    content: @Composable () -> Unit
) {
    val colorScheme = when (displayMode) {
        DisplayMode.DAYLIGHT -> SpitfireDaylightColorScheme
        DisplayMode.LOW_LIGHT, DisplayMode.HIGH_CONTRAST -> SpitfireDarkColorScheme
        DisplayMode.NIGHT -> SpitfireNightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    SpitfireTheme(displayMode = if (darkTheme) DisplayMode.LOW_LIGHT else DisplayMode.DAYLIGHT, content = content)
}
