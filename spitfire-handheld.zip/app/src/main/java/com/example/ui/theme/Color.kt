package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// SPITFIRE ANGLO-FUTURIST AEROSPACE PALETTE
val SpitfireBlack = Color(0xFF101416)
val SpitfireGraphite = Color(0xFF252A2C)
val AirframeBlue = Color(0xFF294A5A)
val BritishEngineeringGreen = Color(0xFF334A42)
val WarmInstrumentWhite = Color(0xFFE9E6DD)
val SpitfireAluminium = Color(0xFFB7BBB7)
val TechnicalGrey = Color(0xFF737A7A)
val SignalAmber = Color(0xFFC3923B)
val WarningRed = Color(0xFFA94740)
val DataBlue = Color(0xFF467187)
val FieldOlive = Color(0xFF65705A)

// Secondary/Surface tokens
val InstrumentCardBackground = Color(0xFF1A2023)
val InstrumentBorder = Color(0xFF2E383D)
val InstrumentGridLine = Color(0xFF212A2F)
val HighContrastYellow = Color(0xFFFFD600)
val NightRedBackground = Color(0xFF180808)
val NightRedText = Color(0xFFFF3333)

