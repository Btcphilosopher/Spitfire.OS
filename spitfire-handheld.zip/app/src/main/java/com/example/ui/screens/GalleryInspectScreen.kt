package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.spitfire.imagery.DefectCategory
import com.example.spitfire.sdk.SpitfireSdk
import com.example.ui.components.TactileButton
import com.example.ui.theme.AirframeBlue
import com.example.ui.theme.BritishEngineeringGreen
import com.example.ui.theme.InstrumentBorder
import com.example.ui.theme.InstrumentCardBackground
import com.example.ui.theme.InstrumentMonoFont
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SpitfireBlack
import com.example.ui.theme.SpitfireGraphite
import com.example.ui.theme.WarmInstrumentWhite

@Composable
fun GalleryInspectScreen(
    sdk: SpitfireSdk,
    modifier: Modifier = Modifier
) {
    val images by sdk.images.collectAsState()
    val selectedImage by sdk.selectedImage.collectAsState()

    var selectedDefect by remember { mutableStateOf(DefectCategory.CORROSION) }
    var annotationNote by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SpitfireBlack)
            .padding(8.dp)
    ) {
        // HEADER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(InstrumentCardBackground)
                .border(1.dp, InstrumentBorder)
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("SPITFIRE GALLERY & INSPECT", style = MaterialTheme.typography.titleMedium, color = SignalAmber)
            Text("${images.size} CAPTURES IN MISSION RECORD", style = MaterialTheme.typography.labelSmall, color = WarmInstrumentWhite)
        }

        Spacer(modifier = Modifier.height(6.dp))

        // IMAGE CAROUSEL SELECTOR
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
        ) {
            items(images) { img ->
                val isSelected = img.imageId == selectedImage?.imageId
                Box(
                    modifier = Modifier
                        .padding(end = 6.dp)
                        .width(130.dp)
                        .fillMaxHeight()
                        .background(if (isSelected) AirframeBlue else InstrumentCardBackground)
                        .border(1.dp, if (isSelected) SignalAmber else InstrumentBorder)
                        .clickable { sdk.selectImage(img) }
                        .padding(6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(img.imageId, style = MaterialTheme.typography.labelSmall, color = WarmInstrumentWhite, fontFamily = InstrumentMonoFont)
                        Text(img.sampleTitle, style = MaterialTheme.typography.labelSmall, color = SignalAmber)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // MAIN INSPECTION WORKSPACE
        if (selectedImage != null) {
            val img = selectedImage!!

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                // LEFT: IMAGE VIEWPORT
                Box(
                    modifier = Modifier
                        .weight(1.2f)
                        .fillMaxHeight()
                        .background(SpitfireGraphite)
                        .border(1.dp, InstrumentBorder)
                        .padding(12.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(img.sampleTitle, color = WarmInstrumentWhite, style = MaterialTheme.typography.titleMedium)

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .background(Color.Black.copy(alpha = 0.4f))
                                .border(1.dp, SignalAmber),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("[ HIGH-RESOLUTION INSPECTION FRAME ]", color = SignalAmber, style = MaterialTheme.typography.labelSmall)
                        }

                        Column {
                            Text("EXPOSURE: ${img.cameraSettings.shutterSpeed} ISO ${img.cameraSettings.iso} ${img.cameraSettings.focalLengthMm}MM", style = MaterialTheme.typography.labelSmall, color = WarmInstrumentWhite, fontFamily = InstrumentMonoFont)
                            Text("LAT ${img.position.latitude} LON ${img.position.longitude} ALT ${img.position.altitudeMeters}M", style = MaterialTheme.typography.labelSmall, color = SignalAmber, fontFamily = InstrumentMonoFont)
                        }
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                // RIGHT: ANNOTATION TOOLBAR & DEFECT FORM
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .background(InstrumentCardBackground)
                        .border(1.dp, InstrumentBorder)
                        .padding(10.dp)
                ) {
                    Text("ADD STRUCTURAL DEFECT ANNOTATION", style = MaterialTheme.typography.labelLarge, color = SignalAmber)
                    Spacer(modifier = Modifier.height(8.dp))

                    Text("DEFECT CLASSIFICATION:", style = MaterialTheme.typography.labelSmall, color = WarmInstrumentWhite)
                    Spacer(modifier = Modifier.height(4.dp))

                    LazyRow(modifier = Modifier.fillMaxWidth()) {
                        items(DefectCategory.entries.toTypedArray()) { cat ->
                            val isSel = cat == selectedDefect
                            Box(
                                modifier = Modifier
                                    .padding(end = 4.dp)
                                    .background(if (isSel) SignalAmber else SpitfireGraphite, RoundedCornerShape(2.dp))
                                    .border(1.dp, InstrumentBorder)
                                    .clickable { selectedDefect = cat }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    cat.name,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSel) SpitfireBlack else WarmInstrumentWhite
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = annotationNote,
                        onValueChange = { annotationNote = it },
                        label = { Text("Field Inspection Note", color = WarmInstrumentWhite) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SignalAmber,
                            unfocusedBorderColor = InstrumentBorder,
                            focusedTextColor = WarmInstrumentWhite,
                            unfocusedTextColor = WarmInstrumentWhite
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    TactileButton(
                        onClick = {
                            sdk.addAnnotation(
                                imageId = img.imageId,
                                category = selectedDefect,
                                label = "${selectedDefect.name} Detected",
                                note = annotationNote.ifEmpty { "Field observation logged by operator." }
                            )
                            annotationNote = ""
                        },
                        text = "LOG ANNOTATION",
                        containerColor = BritishEngineeringGreen,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "log_annotation_button"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("EXISTING ANNOTATIONS (${img.annotations.size})", style = MaterialTheme.typography.labelSmall, color = WarmInstrumentWhite)
                    img.annotations.forEach { ann ->
                        Text("• [${ann.defectCategory}] ${ann.note}", style = MaterialTheme.typography.labelSmall, color = Color.Yellow)
                    }
                }
            }
        }
    }
}
