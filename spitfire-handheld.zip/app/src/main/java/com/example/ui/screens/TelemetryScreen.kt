package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.spitfire.sdk.SpitfireSdk
import com.example.ui.components.AhrsHorizonCanvas
import com.example.ui.theme.InstrumentBorder
import com.example.ui.theme.InstrumentCardBackground
import com.example.ui.theme.InstrumentMonoFont
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SpitfireBlack
import com.example.ui.theme.SpitfireGraphite
import com.example.ui.theme.WarmInstrumentWhite

@Composable
fun TelemetryScreen(
    sdk: SpitfireSdk,
    modifier: Modifier = Modifier
) {
    val telemetry by sdk.drone.telemetry.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SpitfireBlack)
            .padding(10.dp)
    ) {
        Text("SPITFIRE ENGINEERING TELEMETRY LOG", style = MaterialTheme.typography.titleLarge, color = WarmInstrumentWhite)
        Text("REAL-TIME HIGH-FREQUENCY VEHICLE BUS STREAM", style = MaterialTheme.typography.labelSmall, color = SignalAmber)

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            // AHRS DISPLAY
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .background(SpitfireGraphite)
                    .border(1.dp, InstrumentBorder)
            ) {
                AhrsHorizonCanvas(
                    pitchDegrees = telemetry.attitude.pitchDegrees,
                    rollDegrees = telemetry.attitude.rollDegrees,
                    headingDegrees = telemetry.position.headingDegrees,
                    altitudeMeters = telemetry.position.altitudeMeters,
                    speedMps = telemetry.position.groundSpeedMps,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // TELEMETRY METRICS COLUMN
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(start = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TelemetryRow("AIRCRAFT ID", telemetry.aircraftId)
                TelemetryRow("LATITUDE", "%.6f".format(telemetry.position.latitude))
                TelemetryRow("LONGITUDE", "%.6f".format(telemetry.position.longitude))
                TelemetryRow("ALTITUDE (GNSS)", "%.2f M".format(telemetry.position.altitudeMeters))
                TelemetryRow("ALTITUDE (BARO)", "%.2f M".format(telemetry.position.barometricAltitudeMeters))
                TelemetryRow("PITCH / ROLL / YAW", "%.1f° / %.1f° / %.1f°".format(telemetry.attitude.pitchDegrees, telemetry.attitude.rollDegrees, telemetry.attitude.yawDegrees))
                TelemetryRow("MOTOR BUS TEMP", "${telemetry.motorTemperatureC}°C")
                TelemetryRow("BATTERY VOLTAGE", "${telemetry.batteryVoltageVolts}V (${telemetry.currentAmps}A)")
                TelemetryRow("LINK RSSI", "${telemetry.rssiDbm} dBm (${telemetry.linkQualityPercent}%)")
            }
        }
    }
}

@Composable
private fun TelemetryRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(InstrumentCardBackground)
            .border(1.dp, InstrumentBorder)
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = WarmInstrumentWhite)
        Text(value, style = MaterialTheme.typography.labelLarge, color = SignalAmber, fontFamily = InstrumentMonoFont)
    }
}
