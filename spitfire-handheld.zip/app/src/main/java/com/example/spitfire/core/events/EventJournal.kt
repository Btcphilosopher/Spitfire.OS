package com.example.spitfire.core.events

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.util.concurrent.CopyOnWriteArrayList

class EventJournal {
    private val _events = CopyOnWriteArrayList<SpitfireEvent>()
    val eventsList: List<SpitfireEvent> get() = _events.toList()

    private val _eventFlow = MutableSharedFlow<SpitfireEvent>(extraBufferCapacity = 100)
    val eventFlow: SharedFlow<SpitfireEvent> = _eventFlow.asSharedFlow()

    fun record(event: SpitfireEvent) {
        _events.add(0, event) // latest first
        if (_events.size > 500) {
            _events.removeAt(_events.size - 1)
        }
        _eventFlow.tryEmit(event)
    }

    fun clear() {
        _events.clear()
    }
}
