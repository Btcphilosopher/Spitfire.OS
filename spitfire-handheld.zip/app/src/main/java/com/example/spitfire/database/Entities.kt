package com.example.spitfire.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "missions")
data class MissionEntity(
    @PrimaryKey val id: String,
    val name: String,
    val areaKm2: Double,
    val altitudeMeters: Double,
    val speedMps: Double,
    val waypointsJson: String,
    val lifecycle: String,
    val createdAt: Long
)

@Entity(tableName = "telemetry_logs")
data class TelemetryEntity(
    @PrimaryKey(autoGenerate = true) val logId: Long = 0,
    val missionId: String,
    val timestamp: Long,
    val latitude: Double,
    val longitude: Double,
    val altitudeMeters: Double,
    val speedMps: Double,
    val headingDegrees: Double,
    val batteryPercent: Int,
    val rssiDbm: Int
)

@Entity(tableName = "images")
data class ImageEntity(
    @PrimaryKey val imageId: String,
    val missionId: String,
    val timestamp: Long,
    val latitude: Double,
    val longitude: Double,
    val altitudeMeters: Double,
    val sampleTitle: String,
    val annotationsJson: String,
    val isSynced: Boolean
)

@Entity(tableName = "events")
data class EventEntity(
    @PrimaryKey val eventId: String,
    val timestamp: Long,
    val deviceId: String,
    val missionId: String?,
    val type: String,
    val severity: String,
    val payload: String
)

@Entity(tableName = "sync_queue")
data class SyncQueueEntity(
    @PrimaryKey val queueId: String,
    val objectType: String,
    val objectId: String,
    val payloadJson: String,
    val timestamp: Long,
    val status: String
)

@Entity(tableName = "field_notes")
data class FieldNoteEntity(
    @PrimaryKey val noteId: String,
    val missionId: String,
    val timestamp: Long,
    val textContent: String,
    val latitude: Double,
    val longitude: Double,
    val imageId: String?
)
