package com.example.spitfire.mission

data class MissionWaypoint(
    val id: String,
    val index: Int,
    val latitude: Double,
    val longitude: Double,
    val altitudeMeters: Double = 80.0,
    val speedMps: Double = 10.0,
    val action: String = "PHOTO_CAPTURE",
    val gimbalAngleDegrees: Float = -45.0f
)

data class MissionArea(
    val areaKm2: Double = 4.8,
    val boundingCoordinates: List<Pair<Double, Double>> = listOf(
        53.7480 to -0.4600,
        53.7480 to -0.4500,
        53.7400 to -0.4500,
        53.7400 to -0.4600
    )
)

enum class MissionLifecycle {
    DRAFT,
    READY,
    UPLOADING,
    UPLOADED,
    ACTIVE,
    PAUSED,
    COMPLETED,
    ABORTED,
    ARCHIVED
}

data class Mission(
    val id: String = "MIS-HUMBER-001",
    val name: String = "Humber Industrial Bridge Survey",
    val area: MissionArea = MissionArea(),
    val waypoints: List<MissionWaypoint> = generateHumberWaypoints(),
    val altitudeMeters: Double = 80.0,
    val speedMps: Double = 10.0,
    val cameraMode: String = "SURVEY_STILL",
    val imageIntervalSec: Double = 2.0,
    val frontOverlapPercent: Int = 80,
    val sideOverlapPercent: Int = 70,
    val gimbalAngleDegrees: Float = -60.0f,
    val notes: String = "High precision structural inspection of Humber Bridge deck and pylons.",
    val lifecycle: MissionLifecycle = MissionLifecycle.READY,
    val createdAt: Long = System.currentTimeMillis()
)

data class SurveyEstimate(
    val imageCount: Int,
    val flightTimeMinutes: Int,
    val areaCoverageKm2: Double,
    val dataVolumeMB: Int,
    val batteryRequirementPercent: Int
)

fun generateHumberWaypoints(): List<MissionWaypoint> {
    val baseLat = 53.7443
    val baseLon = -0.4552
    return (0..12).map { i ->
        MissionWaypoint(
            id = "WP-${i + 1}",
            index = i + 1,
            latitude = baseLat + (i * 0.0006),
            longitude = baseLon + (if (i % 2 == 0) 0.0010 else -0.0010),
            altitudeMeters = 80.0 + (i % 3) * 5.0,
            speedMps = 10.0,
            action = if (i % 2 == 0) "TRIGGER_CAMERA" else "WAYPOINT_PASS"
        )
    }
}
