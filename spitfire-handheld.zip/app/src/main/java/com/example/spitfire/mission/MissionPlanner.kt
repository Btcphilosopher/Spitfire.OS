package com.example.spitfire.mission

object MissionPlanner {

    fun calculateSurveyEstimates(
        areaKm2: Double,
        altitudeMeters: Double,
        speedMps: Double,
        frontOverlapPercent: Int,
        sideOverlapPercent: Int
    ): SurveyEstimate {
        // Engineering calculation estimates
        val flightDistanceMeters = areaKm2 * 10000.0 / (altitudeMeters * 0.2)
        val timeSec = flightDistanceMeters / maxOf(1.0, speedMps)
        val flightTimeMin = (timeSec / 60.0).toInt().coerceAtLeast(8)
        val imageIntervalSec = 2.0
        val totalImages = (timeSec / imageIntervalSec).toInt().coerceAtLeast(42)
        val dataVolMB = totalImages * 24 // 24MB raw image format per exposure
        val batteryReq = (flightTimeMin * 2.8).toInt().coerceIn(15, 95)

        return SurveyEstimate(
            imageCount = totalImages,
            flightTimeMinutes = flightTimeMin,
            areaCoverageKm2 = areaKm2,
            dataVolumeMB = dataVolMB,
            batteryRequirementPercent = batteryReq
        )
    }
}
