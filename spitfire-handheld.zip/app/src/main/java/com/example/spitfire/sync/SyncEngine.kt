package com.example.spitfire.sync

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

data class SyncQueueItem(
    val id: String = UUID.randomUUID().toString().take(8),
    val objectType: String,
    val objectId: String,
    val summary: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "PENDING"
)

class SyncEngine {
    private val _queue = MutableStateFlow<List<SyncQueueItem>>(
        listOf(
            SyncQueueItem("SQ-101", "IMAGE_RECORD", "IMG-0184", "Deck Pier A-14 Inspection Capture", status = "PENDING"),
            SyncQueueItem("SQ-102", "ANNOTATION", "ANN-882", "Corrosion Defect Marker (Pylon B)", status = "PENDING"),
            SyncQueueItem("SQ-103", "TELEMETRY_LOG", "TL-4890", "Flight Telemetry Stream (342 points)", status = "PENDING"),
            SyncQueueItem("SQ-104", "FIELD_NOTE", "NT-004", "Structural Vibro-Acoustic Note", status = "PENDING")
        )
    )
    val queue: StateFlow<List<SyncQueueItem>> = _queue.asStateFlow()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    fun enqueue(objectType: String, objectId: String, summary: String) {
        val newItem = SyncQueueItem(
            objectType = objectType,
            objectId = objectId,
            summary = summary
        )
        _queue.value = _queue.value + newItem
    }

    suspend fun processSyncQueue(): Int {
        if (_queue.value.isEmpty()) return 0
        _isSyncing.value = true

        val initialCount = _queue.value.size
        // Simulate progressive upload with checksum verification
        for (i in 0 until initialCount) {
            delay(400)
            val updated = _queue.value.toMutableList()
            if (updated.isNotEmpty()) {
                updated[0] = updated[0].copy(status = "SYNCED")
                _queue.value = updated.filter { it.status != "SYNCED" }
            }
        }

        _isSyncing.value = false
        return initialCount
    }

    fun clearQueue() {
        _queue.value = emptyList()
    }
}
