package com.example.spitfire.camera

import com.example.spitfire.core.domain.PositionState

data class CameraState(
    val mode: String = "STILL_SURVEY",
    val focalLengthMm: Int = 24,
    val resolution: String = "6000x4000 (24MP RAW)",
    val iso: Int = 200,
    val shutterSpeed: String = "1/1000",
    val aperture: String = "f/2.8",
    val whiteBalance: String = "5500K DAYLIGHT",
    val exposureCompensation: Float = 0.0f,
    val focusMode: String = "AUTO_INFINITY",
    val sensorTemperatureC: Float = 36.5f,
    val storageReady: Boolean = true
)

data class CaptureRequest(
    val mode: String = "STILL_SURVEY",
    val focalLengthMm: Int = 24,
    val iso: Int = 200,
    val shutterSpeed: String = "1/1000"
)

data class CaptureResult(
    val imageId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val position: PositionState,
    val cameraState: CameraState,
    val processingState: String = "SPITFIRE_VISION_COMPLETE"
)
