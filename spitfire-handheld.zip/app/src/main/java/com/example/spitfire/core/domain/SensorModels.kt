package com.example.spitfire.core.domain

enum class SensorAccuracy {
    UNRELIABLE,
    LOW,
    MEDIUM,
    HIGH
}

data class SensorReading(
    val sensorId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val values: Map<String, Double>,
    val accuracy: SensorAccuracy = SensorAccuracy.HIGH
)

data class ImuState(
    val pitch: Float = 0f,
    val roll: Float = 0f,
    val yaw: Float = 274f,
    val accelX: Float = 0.01f,
    val accelY: Float = 0.02f,
    val accelZ: Float = 9.81f,
    val gyroX: Float = 0.0f,
    val gyroY: Float = 0.0f,
    val gyroZ: Float = 0.0f,
    val quality: Int = 98,
    val timestamp: Long = System.currentTimeMillis()
)

enum class GnssFixType {
    NO_FIX,
    FIX_2D,
    FIX_3D,
    DGPS,
    RTK_FLOAT,
    RTK_FIXED
}

data class PositionState(
    val latitude: Double = 53.7443, // Humber Bridge Area
    val longitude: Double = -0.4552,
    val altitudeMeters: Double = 84.2,
    val barometricAltitudeMeters: Double = 84.5,
    val groundSpeedMps: Double = 12.4,
    val headingDegrees: Double = 274.0,
    val accuracyMeters: Double = 0.45,
    val fixType: GnssFixType = GnssFixType.RTK_FIXED,
    val satelliteCount: Int = 18,
    val timestamp: Long = System.currentTimeMillis()
)

enum class PowerLevel {
    FULL,
    NORMAL,
    LOW,
    CRITICAL,
    CHARGING,
    THERMAL_LIMIT
}

data class PowerState(
    val batteryPercent: Int = 82,
    val voltageVolts: Float = 14.8f,
    val currentAmps: Float = 1.4f,
    val temperatureC: Float = 31.5f,
    val chargeState: String = "DISCHARGING",
    val healthPercent: Int = 97,
    val remainingMinutes: Int = 210,
    val level: PowerLevel = PowerLevel.NORMAL
)

enum class ThermalStatus {
    NORMAL,
    WARM,
    HOT,
    THROTTLING,
    CRITICAL
}

data class ThermalState(
    val cpuTempC: Float = 38.2f,
    val gpuTempC: Float = 39.0f,
    val batteryTempC: Float = 31.5f,
    val radioTempC: Float = 41.0f,
    val cameraTempC: Float = 36.5f,
    val overallTempC: Float = 38.2f,
    val status: ThermalStatus = ThermalStatus.NORMAL
)

data class StorageState(
    val totalCapacityBytes: Long = 256L * 1024 * 1024 * 1024, // 256GB
    val usedBytes: Long = 42L * 1024 * 1024 * 1024,           // 42GB
    val availableBytes: Long = 214L * 1024 * 1024 * 1024,
    val healthPercent: Int = 99,
    val isLowStorage: Boolean = false
) {
    val usedPercent: Int get() = ((usedBytes.toDouble() / totalCapacityBytes) * 100).toInt()
}

enum class LinkQualityMode {
    EXCELLENT,
    GOOD,
    DEGRADED,
    POOR,
    INTERMITTENT,
    LOST
}

data class RadioState(
    val rssiDbm: Int = -62,
    val latencyMs: Int = 18,
    val packetLossPercent: Float = 0.2f,
    val throughputMbps: Float = 28.5f,
    val connectionState: String = "CONNECTED",
    val mode: LinkQualityMode = LinkQualityMode.EXCELLENT,
    val linkPercentage: Int = 94
)
