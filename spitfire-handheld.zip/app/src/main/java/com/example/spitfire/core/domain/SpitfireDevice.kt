package com.example.spitfire.core.domain

import kotlinx.coroutines.flow.StateFlow

interface SpitfireDevice {
    val identity: DeviceIdentity
    val state: StateFlow<DeviceState>

    suspend fun initialise()
    suspend fun shutdown()
    suspend fun restart()
    suspend fun setDisplayMode(mode: DisplayMode)
    suspend fun setSimulationMode(enabled: Boolean)
}
