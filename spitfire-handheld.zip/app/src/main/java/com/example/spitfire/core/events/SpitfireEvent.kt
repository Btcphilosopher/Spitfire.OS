package com.example.spitfire.core.events

import java.util.UUID

enum class EventSeverity {
    INFO,
    WARNING,
    ERROR,
    CRITICAL
}

enum class EventType {
    DRONE_CONNECTED,
    DRONE_DISCONNECTED,
    MISSION_STARTED,
    MISSION_PAUSED,
    MISSION_COMPLETED,
    IMAGE_CAPTURED,
    TELEMETRY_UPDATED,
    BATTERY_LOW,
    LINK_DEGRADED,
    GNSS_DEGRADED,
    CAMERA_ERROR,
    STORAGE_LOW,
    SYNC_STARTED,
    SYNC_COMPLETED,
    THERMAL_WARNING,
    COMMAND_EXECUTED
}

data class SpitfireEvent(
    val eventId: String = UUID.randomUUID().toString().take(8),
    val timestamp: Long = System.currentTimeMillis(),
    val deviceId: String = "SPITFIRE-HH-001",
    val missionId: String? = "MIS-HUMBER-001",
    val type: EventType,
    val severity: EventSeverity = EventSeverity.INFO,
    val source: String = "SYSTEM",
    val payload: String = ""
)
