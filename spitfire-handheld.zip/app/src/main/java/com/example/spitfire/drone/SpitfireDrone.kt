package com.example.spitfire.drone

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

interface SpitfireDrone {
    val telemetry: StateFlow<DroneTelemetry>
    val events: Flow<String>

    suspend fun connect()
    suspend fun disconnect()
    suspend fun sendCommand(command: FlightCommand): CommandResult
    suspend fun requestStatus()
}
