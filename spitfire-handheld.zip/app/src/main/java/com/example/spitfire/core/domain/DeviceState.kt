package com.example.spitfire.core.domain

enum class DeviceSystemStatus {
    OFFLINE,
    BOOTING,
    READY,
    CONNECTING,
    CONNECTED,
    MISSION_ACTIVE,
    MISSION_PAUSED,
    RETURNING,
    UPDATING,
    ERROR,
    SAFE_MODE
}

data class DeviceState(
    val status: DeviceSystemStatus = DeviceSystemStatus.READY,
    val powerState: PowerState = PowerState(),
    val thermalState: ThermalState = ThermalState(),
    val storageState: StorageState = StorageState(),
    val radioState: RadioState = RadioState(),
    val positionState: PositionState = PositionState(),
    val imuState: ImuState = ImuState(),
    val displayMode: DisplayMode = DisplayMode.DAYLIGHT,
    val isSimulationMode: Boolean = true,
    val activeMissionId: String? = "MIS-HUMBER-001",
    val activeMissionName: String? = "Humber Bridge Inspection",
    val connectedDroneId: String? = "SPITFIRE-S01",
    val lastCapturedImageAgoMinutes: Int = 2
)
