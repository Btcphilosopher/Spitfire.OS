package com.example.spitfire.core.domain

enum class OperatorRole {
    OBSERVER,
    OPERATOR,
    SURVEYOR,
    ENGINEER,
    SUPERVISOR,
    ADMINISTRATOR
}

enum class SpitfirePermission {
    VIEW_TELEMETRY,
    VIEW_CAMERA,
    CAPTURE_IMAGE,
    CREATE_MISSION,
    UPLOAD_MISSION,
    COMMAND_DRONE,
    EXPORT_DATA,
    ADMIN_DEVICE
}

data class OperatorIdentity(
    val operatorId: String = "OP-8492",
    val name: String = "Capt. Alex Vance",
    val callsign: String = "SPITFIRE-ALPHA",
    val role: OperatorRole = OperatorRole.SURVEYOR,
    val permissions: Set<SpitfirePermission> = setOf(
        SpitfirePermission.VIEW_TELEMETRY,
        SpitfirePermission.VIEW_CAMERA,
        SpitfirePermission.CAPTURE_IMAGE,
        SpitfirePermission.CREATE_MISSION,
        SpitfirePermission.UPLOAD_MISSION,
        SpitfirePermission.COMMAND_DRONE,
        SpitfirePermission.EXPORT_DATA
    )
) {
    fun hasPermission(permission: SpitfirePermission): Boolean =
        role == OperatorRole.ADMINISTRATOR || permissions.contains(permission)
}
