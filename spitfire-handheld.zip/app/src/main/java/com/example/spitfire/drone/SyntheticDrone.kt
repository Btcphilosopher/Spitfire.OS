package com.example.spitfire.drone

import com.example.spitfire.core.domain.GnssFixType
import com.example.spitfire.core.domain.PositionState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

class SyntheticDrone(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) : SpitfireDrone {

    private val _telemetry = MutableStateFlow(DroneTelemetry())
    override val telemetry: StateFlow<DroneTelemetry> = _telemetry.asStateFlow()

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 50)
    override val events: Flow<String> = _events.asSharedFlow()

    private var simulationJob: Job? = null
    private var stepCount = 0

    // Failure simulation flags
    var isLinkLost: Boolean = false
    var packetLossPercent: Float = 0.2f
    var isGnssDegraded: Boolean = false

    init {
        startSimulation()
    }

    fun startSimulation() {
        simulationJob?.cancel()
        simulationJob = scope.launch {
            val baseLat = 53.7443
            val baseLon = -0.4552
            var currentLat = baseLat
            var currentLon = baseLon
            var heading = 274.0
            var alt = 84.2
            var battery = 78.0

            while (true) {
                delay(300) // 3.3 Hz high quality flight telemetry
                stepCount++

                if (isLinkLost) {
                    _telemetry.value = _telemetry.value.copy(
                        linkQualityPercent = 0,
                        rssiDbm = -110,
                        flightMode = "FAILSAFE_HOLD"
                    )
                    continue
                }

                // Flight path oscillation around Humber Industrial Corridor
                val angle = stepCount * 0.05
                currentLat = baseLat + sin(angle) * 0.003
                currentLon = baseLon + cos(angle) * 0.005
                heading = (270.0 + sin(angle) * 15.0) % 360.0
                alt = 84.0 + sin(angle * 2) * 2.5
                battery = maxOf(5.0, battery - 0.005)

                val fix = if (isGnssDegraded) GnssFixType.FIX_2D else GnssFixType.RTK_FIXED
                val sats = if (isGnssDegraded) 6 else 18
                val linkPct = if (packetLossPercent > 5f) 45 else 94

                val newPos = PositionState(
                    latitude = currentLat,
                    longitude = currentLon,
                    altitudeMeters = alt,
                    barometricAltitudeMeters = alt + 0.3,
                    groundSpeedMps = 12.4 + sin(angle) * 1.2,
                    headingDegrees = heading,
                    accuracyMeters = if (isGnssDegraded) 4.2 else 0.45,
                    fixType = fix,
                    satelliteCount = sats,
                    timestamp = System.currentTimeMillis()
                )

                _telemetry.value = _telemetry.value.copy(
                    timestamp = System.currentTimeMillis(),
                    position = newPos,
                    attitude = AircraftAttitude(
                        pitchDegrees = (sin(angle * 1.5) * 4.0).toFloat(),
                        rollDegrees = (cos(angle * 1.2) * 3.0).toFloat(),
                        yawDegrees = heading.toFloat()
                    ),
                    gimbal = _telemetry.value.gimbal.copy(
                        pitchDegrees = -45.0f + (sin(angle) * 5.0).toFloat()
                    ),
                    batteryPercent = battery.toInt(),
                    linkQualityPercent = linkPct,
                    rssiDbm = if (packetLossPercent > 5f) -88 else -62,
                    flightTimeSeconds = stepCount / 3
                )
            }
        }
    }

    override suspend fun connect() {
        isLinkLost = false
        _events.emit("DRONE_CONNECTED: SPF-S01")
    }

    override suspend fun disconnect() {
        isLinkLost = true
        _events.emit("DRONE_DISCONNECTED: SPF-S01")
    }

    override suspend fun sendCommand(command: FlightCommand): CommandResult {
        return when (command) {
            is FlightCommand.ReturnToHome -> {
                _telemetry.value = _telemetry.value.copy(flightMode = "RTH")
                _events.emit("COMMAND: RETURN_TO_HOME_INITIATED")
                CommandResult("RTH", true, "Aircraft returning to launch point (53.7443, -0.4552)")
            }
            is FlightCommand.StartMission -> {
                _telemetry.value = _telemetry.value.copy(flightMode = "AUTO_SURVEY")
                _events.emit("COMMAND: MISSION_STARTED")
                CommandResult("START_MISSION", true, "Mission execution started")
            }
            is FlightCommand.PauseMission -> {
                _telemetry.value = _telemetry.value.copy(flightMode = "HOLD_LOITER")
                _events.emit("COMMAND: MISSION_PAUSED")
                CommandResult("PAUSE_MISSION", true, "Aircraft loitering in position")
            }
            is FlightCommand.SetGimbalPitch -> {
                _telemetry.value = _telemetry.value.copy(
                    gimbal = _telemetry.value.gimbal.copy(pitchDegrees = command.pitchDegrees)
                )
                CommandResult("SET_GIMBAL", true, "Gimbal pitch set to ${command.pitchDegrees}°")
            }
            is FlightCommand.TriggerCapture -> {
                _events.emit("COMMAND: CAMERA_TRIGGERED")
                CommandResult("CAPTURE", true, "Image capture triggered")
            }
            is FlightCommand.EmergencyStop -> {
                _telemetry.value = _telemetry.value.copy(flightMode = "EMERGENCY_LAND")
                CommandResult("EMERGENCY_STOP", true, "Emergency descent initiated")
            }
            FlightCommand.Takeoff -> CommandResult("TAKEOFF", true, "Takeoff armed")
            FlightCommand.Land -> CommandResult("LAND", true, "Landing sequence initialized")
        }
    }

    override suspend fun requestStatus() {
        _events.emit("STATUS_CHECK_OK")
    }
}
