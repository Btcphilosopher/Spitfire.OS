package com.example.spitfire.mission

import com.example.spitfire.drone.DroneTelemetry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ReplaySpeed(val multiplier: Float) {
    X1(1.0f),
    X2(2.0f),
    X10(10.0f)
}

class MissionReplay {
    private val recordedFrames = mutableListOf<DroneTelemetry>()
    private val _currentFrameIndex = MutableStateFlow(0)
    val currentFrameIndex: StateFlow<Int> = _currentFrameIndex.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _replaySpeed = MutableStateFlow(ReplaySpeed.X1)
    val replaySpeed: StateFlow<ReplaySpeed> = _replaySpeed.asStateFlow()

    val totalFrames: Int get() = recordedFrames.size

    fun loadFrames(frames: List<DroneTelemetry>) {
        recordedFrames.clear()
        recordedFrames.addAll(frames)
        _currentFrameIndex.value = 0
    }

    fun play() { _isPlaying.value = true }
    fun pause() { _isPlaying.value = false }
    fun setSpeed(speed: ReplaySpeed) { _replaySpeed.value = speed }

    fun stepForward() {
        if (recordedFrames.isNotEmpty()) {
            _currentFrameIndex.value = (_currentFrameIndex.value + 1) % recordedFrames.size
        }
    }

    fun getCurrentTelemetry(): DroneTelemetry? {
        if (recordedFrames.isEmpty()) return null
        val idx = _currentFrameIndex.value.coerceIn(0, recordedFrames.size - 1)
        return recordedFrames[idx]
    }
}
