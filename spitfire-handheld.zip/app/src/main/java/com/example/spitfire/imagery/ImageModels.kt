package com.example.spitfire.imagery

import com.example.spitfire.camera.CameraState
import com.example.spitfire.core.domain.PositionState

enum class DefectCategory {
    CRACK,
    CORROSION,
    SURFACE_DAMAGE,
    MISSING_COMPONENT,
    WATER_INGRESS,
    VEGETATION,
    STRUCTURAL_FEATURE,
    UNKNOWN
}

enum class AnnotationType {
    PIN,
    RECTANGLE,
    POLYGON,
    LINE,
    TEXT,
    MEASUREMENT,
    DEFECT_MARKER,
    INSPECTION_NOTE
}

data class ImageAnnotation(
    val id: String,
    val type: AnnotationType = AnnotationType.DEFECT_MARKER,
    val defectCategory: DefectCategory = DefectCategory.CORROSION,
    val label: String = "Corrosion Spot - Severity B",
    val normalizedX: Float = 0.45f,
    val normalizedY: Float = 0.35f,
    val normalizedWidth: Float = 0.15f,
    val normalizedHeight: Float = 0.12f,
    val severity: String = "MEDIUM",
    val note: String = "Pylon bolt flange showing localized rust pattern.",
    val timestamp: Long = System.currentTimeMillis()
)

data class ImageRecord(
    val imageId: String,
    val missionId: String = "MIS-HUMBER-001",
    val flightId: String = "FLT-20260926-01",
    val timestamp: Long = System.currentTimeMillis(),
    val position: PositionState = PositionState(),
    val cameraSettings: CameraState = CameraState(),
    val sensorId: String = "VISION-MK4-4K",
    val lensId: String = "SPITFIRE-OPTICS-24MM",
    val annotations: List<ImageAnnotation> = emptyList(),
    val isSynced: Boolean = false,
    val sampleTitle: String = "Deck Pier Section A-14"
)
