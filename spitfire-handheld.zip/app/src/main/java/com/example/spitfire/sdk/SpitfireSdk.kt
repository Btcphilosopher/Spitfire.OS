package com.example.spitfire.sdk

import com.example.spitfire.camera.CameraState
import com.example.spitfire.camera.CaptureRequest
import com.example.spitfire.camera.CaptureResult
import com.example.spitfire.core.domain.DeviceCapabilities
import com.example.spitfire.core.domain.DeviceIdentity
import com.example.spitfire.core.domain.DeviceState
import com.example.spitfire.core.domain.DeviceSystemStatus
import com.example.spitfire.core.domain.DisplayMode
import com.example.spitfire.core.domain.OperatorIdentity
import com.example.spitfire.core.domain.PowerLevel
import com.example.spitfire.core.domain.ThermalStatus
import com.example.spitfire.core.events.EventJournal
import com.example.spitfire.core.events.EventSeverity
import com.example.spitfire.core.events.EventType
import com.example.spitfire.core.events.SpitfireEvent
import com.example.spitfire.drone.CommandResult
import com.example.spitfire.drone.DroneTelemetry
import com.example.spitfire.drone.FlightCommand
import com.example.spitfire.drone.SyntheticDrone
import com.example.spitfire.imagery.DefectCategory
import com.example.spitfire.imagery.ImageAnnotation
import com.example.spitfire.imagery.ImageRecord
import com.example.spitfire.mission.Mission
import com.example.spitfire.mission.MissionPlanner
import com.example.spitfire.mission.MissionReplay
import com.example.spitfire.mission.SurveyEstimate
import com.example.spitfire.sync.SyncEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class SpitfireSdk(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) {
    val identity = DeviceIdentity()
    val operator = OperatorIdentity()

    val journal = EventJournal()
    val drone = SyntheticDrone(scope)
    val syncEngine = SyncEngine()
    val replayEngine = MissionReplay()

    private val _deviceState = MutableStateFlow(DeviceState())
    val deviceState: StateFlow<DeviceState> = _deviceState.asStateFlow()

    private val _cameraState = MutableStateFlow(CameraState())
    val cameraState: StateFlow<CameraState> = _cameraState.asStateFlow()

    private val _activeMission = MutableStateFlow(Mission())
    val activeMission: StateFlow<Mission> = _activeMission.asStateFlow()

    private val _images = MutableStateFlow<List<ImageRecord>>(generateSampleImages())
    val images: StateFlow<List<ImageRecord>> = _images.asStateFlow()

    private val _selectedImage = MutableStateFlow<ImageRecord?>(_images.value.firstOrNull())
    val selectedImage: StateFlow<ImageRecord?> = _selectedImage.asStateFlow()

    init {
        // Collect telemetry and mirror to device state
        scope.launch {
            drone.telemetry.collect { tel ->
                val prevDevice = _deviceState.value
                _deviceState.value = prevDevice.copy(
                    positionState = tel.position,
                    radioState = prevDevice.radioState.copy(
                        rssiDbm = tel.rssiDbm,
                        linkPercentage = tel.linkQualityPercent
                    ),
                    powerState = prevDevice.powerState.copy(
                        batteryPercent = maxOf(0, tel.batteryPercent - 5) // Handheld battery
                    )
                )
            }
        }

        // Record initial boot event
        journal.record(
            SpitfireEvent(
                type = EventType.COMMAND_EXECUTED,
                severity = EventSeverity.INFO,
                source = "SPITFIRE_BOOT",
                payload = "Spitfire Handheld API initialised successfully"
            )
        )
    }

    // --- DEVICE API ---
    fun setDisplayMode(mode: DisplayMode) {
        _deviceState.value = _deviceState.value.copy(displayMode = mode)
    }

    fun setSimulationMode(enabled: Boolean) {
        _deviceState.value = _deviceState.value.copy(isSimulationMode = enabled)
    }

    // --- CAMERA API ---
    suspend fun captureImage(): CaptureResult {
        val tel = drone.telemetry.value
        val req = CaptureRequest()
        val imgId = "IMG-${System.currentTimeMillis().toString().takeLast(4)}"

        val result = CaptureResult(
            imageId = imgId,
            position = tel.position,
            cameraState = _cameraState.value
        )

        val newRecord = ImageRecord(
            imageId = imgId,
            missionId = _activeMission.value.id,
            position = tel.position,
            cameraSettings = _cameraState.value,
            sampleTitle = "Capture at WP-${tel.flightTimeSeconds % 12 + 1}"
        )

        _images.value = listOf(newRecord) + _images.value
        _selectedImage.value = newRecord

        journal.record(
            SpitfireEvent(
                type = EventType.IMAGE_CAPTURED,
                severity = EventSeverity.INFO,
                source = "SPITFIRE_VISION",
                payload = "Captured image $imgId at (${tel.position.latitude}, ${tel.position.longitude})"
            )
        )

        syncEngine.enqueue("IMAGE_RECORD", imgId, "Field Image Capture $imgId")
        return result
    }

    fun selectImage(image: ImageRecord) {
        _selectedImage.value = image
    }

    fun addAnnotation(
        imageId: String,
        category: DefectCategory,
        label: String,
        note: String
    ) {
        val currentList = _images.value
        val updated = currentList.map { img ->
            if (img.imageId == imageId) {
                val newAnn = ImageAnnotation(
                    id = "ANN-${UUID.randomUUID().toString().take(4)}",
                    defectCategory = category,
                    label = label,
                    note = note
                )
                val updatedImg = img.copy(annotations = img.annotations + newAnn)
                if (_selectedImage.value?.imageId == imageId) {
                    _selectedImage.value = updatedImg
                }
                updatedImg
            } else img
        }
        _images.value = updated
        journal.record(
            SpitfireEvent(
                type = EventType.COMMAND_EXECUTED,
                source = "INSPECTION_MODE",
                payload = "Added $category annotation to $imageId"
            )
        )
    }

    // --- MISSION API ---
    fun updateMission(mission: Mission) {
        _activeMission.value = mission
        journal.record(
            SpitfireEvent(
                type = EventType.MISSION_STARTED,
                source = "MISSION_PLANNER",
                payload = "Mission ${mission.name} loaded with ${mission.waypoints.size} waypoints"
            )
        )
    }

    fun calculateSurvey(areaKm2: Double, altMeters: Double, speedMps: Double): SurveyEstimate {
        return MissionPlanner.calculateSurveyEstimates(areaKm2, altMeters, speedMps, 80, 70)
    }

    // --- FAILURE LAB & SIMULATION APIs ---
    fun injectLinkDegradation(packetLoss: Float) {
        drone.packetLossPercent = packetLoss
        drone.isLinkLost = packetLoss > 90f
        journal.record(
            SpitfireEvent(
                type = EventType.LINK_DEGRADED,
                severity = if (packetLoss > 50f) EventSeverity.WARNING else EventSeverity.INFO,
                source = "FAILURE_LAB",
                payload = "Injected packet loss: $packetLoss%"
            )
        )
    }

    fun injectThermalLoad(temperatureC: Float) {
        val status = when {
            temperatureC > 50f -> ThermalStatus.CRITICAL
            temperatureC > 42f -> ThermalStatus.THROTTLING
            temperatureC > 36f -> ThermalStatus.WARM
            else -> ThermalStatus.NORMAL
        }
        _deviceState.value = _deviceState.value.copy(
            thermalState = _deviceState.value.thermalState.copy(
                cpuTempC = temperatureC,
                status = status
            )
        )
        journal.record(
            SpitfireEvent(
                type = EventType.THERMAL_WARNING,
                severity = if (temperatureC > 42f) EventSeverity.WARNING else EventSeverity.INFO,
                source = "FAILURE_LAB",
                payload = "Injected thermal load: ${temperatureC}°C ($status)"
            )
        )
    }

    fun restoreSystemState() {
        drone.isLinkLost = false
        drone.packetLossPercent = 0.2f
        drone.isGnssDegraded = false
        _deviceState.value = _deviceState.value.copy(
            status = DeviceSystemStatus.READY,
            thermalState = _deviceState.value.thermalState.copy(cpuTempC = 38.2f, status = ThermalStatus.NORMAL)
        )
        journal.record(
            SpitfireEvent(
                type = EventType.COMMAND_EXECUTED,
                source = "FAILURE_LAB",
                payload = "System health and link metrics restored to nominal"
            )
        )
    }
}

private fun generateSampleImages(): List<ImageRecord> {
    return listOf(
        ImageRecord(
            imageId = "IMG-0184",
            sampleTitle = "Deck Pier Section A-14",
            annotations = listOf(
                ImageAnnotation(
                    id = "ANN-101",
                    defectCategory = DefectCategory.CORROSION,
                    label = "Corrosion Spot - Flange B",
                    severity = "HIGH",
                    note = "Structural rust pattern near mounting bolts."
                )
            )
        ),
        ImageRecord(
            imageId = "IMG-0185",
            sampleTitle = "Suspension Cable Collar North",
            annotations = listOf(
                ImageAnnotation(
                    id = "ANN-102",
                    defectCategory = DefectCategory.CRACK,
                    label = "Surface Micro-Crack",
                    severity = "MEDIUM",
                    note = "2.4cm hairline crack along steel casing."
                )
            )
        ),
        ImageRecord(
            imageId = "IMG-0186",
            sampleTitle = "Tower Top Beacon Assembly",
            annotations = emptyList()
        )
    )
}
