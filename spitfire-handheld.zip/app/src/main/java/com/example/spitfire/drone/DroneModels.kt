package com.example.spitfire.drone

import com.example.spitfire.core.domain.GnssFixType
import com.example.spitfire.core.domain.PositionState

data class AircraftAttitude(
    val pitchDegrees: Float = -2.5f,
    val rollDegrees: Float = 1.1f,
    val yawDegrees: Float = 274.0f
)

data class GimbalState(
    val pitchDegrees: Float = -45.0f,
    val yawDegrees: Float = 0.0f,
    val rollDegrees: Float = 0.0f,
    val mode: String = "TARGET_FOLLOW"
)

data class DroneTelemetry(
    val timestamp: Long = System.currentTimeMillis(),
    val aircraftId: String = "SPF-S01-UK8801",
    val position: PositionState = PositionState(),
    val attitude: AircraftAttitude = AircraftAttitude(),
    val gimbal: GimbalState = GimbalState(),
    val batteryPercent: Int = 78,
    val batteryVoltageVolts: Float = 22.8f,
    val currentAmps: Float = 18.5f,
    val motorTemperatureC: Float = 42.0f,
    val motorsStatus: String = "NOMINAL (4/4)",
    val linkQualityPercent: Int = 94,
    val rssiDbm: Int = -62,
    val flightMode: String = "AUTO_SURVEY",
    val isArmed: Boolean = true,
    val isFlying: Boolean = true,
    val flightTimeSeconds: Int = 840,
    val distanceTraveledMeters: Float = 3420.0f
)

sealed class FlightCommand {
    data object Takeoff : FlightCommand()
    data object Land : FlightCommand()
    data object ReturnToHome : FlightCommand()
    data object StartMission : FlightCommand()
    data object PauseMission : FlightCommand()
    data class SetGimbalPitch(val pitchDegrees: Float) : FlightCommand()
    data object TriggerCapture : FlightCommand()
    data object EmergencyStop : FlightCommand()
}

data class CommandResult(
    val commandName: String,
    val isSuccess: Boolean,
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)
