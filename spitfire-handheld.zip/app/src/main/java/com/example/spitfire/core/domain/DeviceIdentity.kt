package com.example.spitfire.core.domain

data class DeviceCapabilities(
    val hasGnss: Boolean = true,
    val hasImu: Boolean = true,
    val hasMagnetometer: Boolean = true,
    val hasBarometer: Boolean = true,
    val hasCamera: Boolean = true,
    val hasCellular: Boolean = true,
    val hasRadio: Boolean = true
)

data class DeviceIdentity(
    val deviceId: String = "SPITFIRE-HH-001",
    val serialNumber: String = "SPF-HH-2026-8801A",
    val hardwareRevision: String = "REVISION B",
    val firmwareVersion: String = "FW 3.7.12-PROD",
    val softwareVersion: String = "SPITFIRE 3.7.0",
    val buildNumber: String = "BUILD-8942-UK",
    val manufacturingProfile: String = "AEROSPACE RUGGED MK-IV",
    val region: String = "UK / EUROPE (868MHz / 2.4GHz)",
    val capabilities: DeviceCapabilities = DeviceCapabilities()
)

enum class DisplayMode {
    DAYLIGHT,
    LOW_LIGHT,
    NIGHT,
    HIGH_CONTRAST
}
