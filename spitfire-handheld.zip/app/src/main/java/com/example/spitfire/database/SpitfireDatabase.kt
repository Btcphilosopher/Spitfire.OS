package com.example.spitfire.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        MissionEntity::class,
        TelemetryEntity::class,
        ImageEntity::class,
        EventEntity::class,
        SyncQueueEntity::class,
        FieldNoteEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SpitfireDatabase : RoomDatabase() {
    abstract fun spitfireDao(): SpitfireDao

    companion object {
        @Volatile
        private var INSTANCE: SpitfireDatabase? = null

        fun getInstance(context: Context): SpitfireDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SpitfireDatabase::class.java,
                    "spitfire_handheld.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
