import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AgriDispensingService } from '../../core/services/agri-dispensing.service';
import { FieldCoverageGridCell } from '../../core/models/agri.model';

@Component({
  selector: 'app-agri-precision',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-full p-4 overflow-y-auto space-y-4 font-mono">
      <!-- Header -->
      <div class="flex items-center justify-between flex-wrap gap-2 pb-2 border-b border-[#252A2C]">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-bold text-[#65784F] px-2 py-0.5 rounded bg-[#65784F]/10 border border-[#65784F]/30">SIGNATURE SCREEN</span>
            <h2 class="text-lg font-bold text-white">SPITFIRE AGRI: PRECISION APPLICATION & CROP INTELLIGENCE</h2>
          </div>
          <p class="text-xs text-[#B5B8B3] mt-0.5">
            Variable-rate spray dynamics, granular dispensing, synthetic NDVI health maps & live tank payload consumption.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button
            type="button"
            (click)="toggleSpray()"
            [class.bg-[#65784F]]="sprayState().dispensingActive"
            [class.bg-[#A5463E]]="!sprayState().dispensingActive"
            class="px-3.5 py-1.5 text-white rounded-lg text-xs font-bold transition-all shadow flex items-center gap-1.5">
            <span class="material-icons text-sm">{{ sprayState().dispensingActive ? 'pause' : 'play_arrow' }}</span>
            <span>{{ sprayState().dispensingActive ? 'PAUSE DISPENSING' : 'START DISPENSING' }}</span>
          </button>
        </div>
      </div>

      <!-- Live Application Consumption Metrics Banner -->
      <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
        <div class="p-3 bg-[#14181B] border border-[#252A2C] rounded-xl">
          <div class="text-[9px] text-[#6D7474]">TANK LEVEL (12L)</div>
          <div class="text-base font-bold text-white mt-0.5">{{ sprayState().activeTankLevelLiters.toFixed(1) }} <span class="text-[10px] text-[#B5B8B3]">LITRES</span></div>
          <div class="text-[9px] text-[#65784F] mt-1">{{ ((sprayState().activeTankLevelLiters / 12) * 100).toFixed(0) }}% REMAINING</div>
        </div>

        <div class="p-3 bg-[#14181B] border border-[#252A2C] rounded-xl">
          <div class="text-[9px] text-[#6D7474]">APPLICATION FLOW RATE</div>
          <div class="text-base font-bold text-cyan-400 mt-0.5">{{ sprayState().flowRateLPerMin }} <span class="text-[10px] text-[#B5B8B3]">L/MIN</span></div>
          <div class="text-[9px] text-[#6D7474] mt-1">Pressure: {{ sprayState().pressureBar }} Bar</div>
        </div>

        <div class="p-3 bg-[#14181B] border border-[#252A2C] rounded-xl">
          <div class="text-[9px] text-[#6D7474]">DROPLET CLASS</div>
          <div class="text-base font-bold text-[#C18D38] mt-0.5">{{ sprayState().dropletClass }}</div>
          <div class="text-[9px] text-[#6D7474] mt-1">Drift Control: Optimal</div>
        </div>

        <div class="p-3 bg-[#14181B] border border-[#252A2C] rounded-xl">
          <div class="text-[9px] text-[#6D7474]">SWATH WIDTH & SPEED</div>
          <div class="text-base font-bold text-white mt-0.5">{{ sprayState().swathWidthM }}M / {{ sprayState().groundSpeedMs }}M/S</div>
          <div class="text-[9px] text-[#6D7474] mt-1">Alt: 4.2m AGL</div>
        </div>

        <div class="p-3 bg-[#14181B] border border-[#252A2C] rounded-xl">
          <div class="text-[9px] text-[#6D7474]">COVERED AREA</div>
          <div class="text-base font-bold text-emerald-400 mt-0.5">{{ fieldStats().treatedAreaHa }} / {{ fieldStats().totalFieldAreaHa }} <span class="text-[10px] text-[#B5B8B3]">HA</span></div>
          <div class="text-[9px] text-emerald-400 mt-1">{{ fieldStats().coverageEfficiencyPct }}% Completed</div>
        </div>

        <div class="p-3 bg-[#14181B] border border-[#252A2C] rounded-xl">
          <div class="text-[9px] text-[#6D7474]">UNIFORMITY CV%</div>
          <div class="text-base font-bold text-white mt-0.5">{{ fieldStats().uniformityCvPct }}%</div>
          <div class="text-[9px] text-[#6D7474] mt-1">Over-Spray: {{ fieldStats().overApplicationPct }}%</div>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- 2D Interactive Field Coverage Grid Heatmap (7 Cols) -->
        <div class="lg:col-span-7 bg-[#14181B] border border-[#252A2C] rounded-xl p-4 space-y-3">
          <div class="flex items-center justify-between text-xs">
            <span class="text-white font-bold">VARIABLE-RATE APPLICATION (VRA) FIELD GRID</span>
            <div class="flex items-center gap-2 text-[10px]">
              <span class="flex items-center gap-1 text-emerald-400"><span class="w-2 h-2 rounded-full bg-emerald-500"></span> Optimal</span>
              <span class="flex items-center gap-1 text-amber-400"><span class="w-2 h-2 rounded-full bg-amber-500"></span> Over-Dosed</span>
              <span class="flex items-center gap-1 text-cyan-400"><span class="w-2 h-2 rounded-full bg-cyan-500"></span> Under-Dosed</span>
              <span class="flex items-center gap-1 text-[#6D7474]"><span class="w-2 h-2 rounded-full bg-[#252A2C]"></span> Untreated</span>
            </div>
          </div>

          <!-- 16x16 Interactive Grid Cells -->
          <div class="grid grid-cols-16 gap-1 p-2 bg-[#101416] border border-[#252A2C] rounded-lg">
            @for (cell of coverageGrid(); track (cell.gridX + '-' + cell.gridY)) {
              <button
                type="button"
                (click)="selectedCell.set(cell)"
                class="aspect-square rounded-[2px] cursor-pointer transition-transform hover:scale-125 flex items-center justify-center text-[7px]"
                [class.ring-2]="selectedCell()?.gridX === cell.gridX && selectedCell()?.gridY === cell.gridY"
                [class.ring-white]="selectedCell()?.gridX === cell.gridX && selectedCell()?.gridY === cell.gridY"
                [style.backgroundColor]="getCellColor(cell)">
              </button>
            }
          </div>

          <!-- Cell Detail Inspection -->
          @if (selectedCell(); as cell) {
            <div class="p-2.5 bg-[#101416] border border-[#252A2C] rounded-lg text-xs flex items-center justify-between">
              <div>
                <span class="text-[#6D7474]">INSPECTING SECTOR [{{ cell.gridX }}, {{ cell.gridY }}]:</span>
                <span class="text-white font-bold ml-1">Crop Health: {{ cell.cropHealth }} (NDVI: {{ cell.ndvi }})</span>
              </div>
              <div class="text-[11px] text-[#C18D38]">
                Target: {{ cell.targetRate }} L/ha | Applied: {{ cell.appliedRate }} L/ha ({{ cell.status }})
              </div>
            </div>
          }
        </div>

        <!-- Agricultural Treatment Zones & Agronomic Health (5 Cols) -->
        <div class="lg:col-span-5 bg-[#14181B] border border-[#252A2C] rounded-xl p-4 space-y-3">
          <div class="flex items-center justify-between text-xs pb-2 border-b border-[#252A2C]">
            <span class="text-white font-bold">SYNTHETIC CROP HEALTH ZONES</span>
            <span class="text-[10px] text-[#65784F]">MULTISPECTRAL SENSOR</span>
          </div>

          <div class="space-y-2.5 text-xs">
            @for (zone of treatmentZones(); track zone.id) {
              <div class="p-3 bg-[#101416] border border-[#252A2C] rounded-lg space-y-1.5">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-white">{{ zone.name }}</span>
                  <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                        [class.bg-emerald-950]="zone.category === 'HEALTHY'"
                        [class.text-emerald-400]="zone.category === 'HEALTHY'"
                        [class.bg-amber-950]="zone.category === 'WEED_SUSPECT'"
                        [class.text-amber-400]="zone.category === 'WEED_SUSPECT'"
                        [class.bg-rose-950]="zone.category === 'STRESSED'"
                        [class.text-rose-400]="zone.category === 'STRESSED'">
                    {{ zone.category }}
                  </span>
                </div>
                <div class="grid grid-cols-3 gap-2 text-[10px] text-[#B5B8B3]">
                  <div>Area: {{ zone.areaHectares }} Ha</div>
                  <div>NDVI: {{ zone.ndviAverage }}</div>
                  <div>Dose: {{ zone.recommendedDoseLPerHa }} L/Ha</div>
                </div>
              </div>
            }
          </div>

          <!-- Dosing / Droplet Control Settings -->
          <div class="pt-2 border-t border-[#252A2C] space-y-2 text-xs">
            <div class="text-[10px] text-[#6D7474] uppercase">Dispensing Configuration</div>
            <div class="grid grid-cols-4 gap-1.5 text-[10px]">
              @for (cls of ['VERY_COARSE', 'COARSE', 'MEDIUM', 'FINE']; track cls) {
                <button
                  type="button"
                  (click)="setDroplet(cls)"
                  [class.bg-[#65784F]]="sprayState().dropletClass === cls"
                  [class.text-white]="sprayState().dropletClass === cls"
                  class="p-1.5 bg-[#101416] border border-[#252A2C] rounded text-center hover:bg-[#252A2C] text-[#B5B8B3] transition-colors">
                  {{ cls.replace('_', ' ') }}
                </button>
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AgriPrecision {
  private readonly agri = inject(AgriDispensingService);

  readonly sprayState = computed(() => this.agri.sprayState());
  readonly fieldStats = computed(() => this.agri.fieldStats());
  readonly coverageGrid = computed(() => this.agri.coverageGrid());
  readonly treatmentZones = computed(() => this.agri.treatmentZones());

  readonly selectedCell = signal<FieldCoverageGridCell | null>(this.coverageGrid()[0] || null);

  toggleSpray() {
    this.agri.toggleDispensing();
  }

  setDroplet(cls: string) {
    this.agri.setDropletClass(cls as 'VERY_COARSE' | 'COARSE' | 'MEDIUM' | 'FINE');
  }

  getCellColor(cell: FieldCoverageGridCell): string {
    if (cell.status === 'OPTIMAL') return '#10b981'; // green
    if (cell.status === 'OVER_APPLIED') return '#f59e0b'; // amber
    if (cell.status === 'UNDER_APPLIED') return '#06b6d4'; // cyan
    return '#1f2937'; // dark untreated
  }
}
