import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MissionLogisticsService } from '../../core/services/mission-logistics.service';
import { DeliveryState } from '../../core/models/payload.model';

@Component({
  selector: 'app-cargo-logistics',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-full p-4 overflow-y-auto space-y-4 font-mono">
      <!-- Header -->
      <div class="flex items-center justify-between flex-wrap gap-2 pb-2 border-b border-[#252A2C]">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-bold text-[#C18D38] px-2 py-0.5 rounded bg-[#C18D38]/10 border border-[#C18D38]/30">SIGNATURE SCREEN</span>
            <h2 class="text-lg font-bold text-white">CARGO & POSTAL LOGISTICS INTELLIGENCE</h2>
          </div>
          <p class="text-xs text-[#B5B8B3] mt-0.5">
            Full 13-stage autonomous delivery lifecycle, optical verification, multi-stop LIFO routing & cargo security telemetry.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button
            type="button"
            (click)="advanceDeliveryStage()"
            class="px-3 py-1.5 bg-[#294A5A] hover:bg-[#345e72] text-white rounded-lg text-xs font-bold transition-all shadow flex items-center gap-1.5">
            <span class="material-icons text-sm">fast_forward</span>
            <span>ADVANCE LIFECYCLE STATE</span>
          </button>
        </div>
      </div>

      <!-- 13-Stage Delivery Lifecycle Progress Bar -->
      <div class="bg-[#14181B] border border-[#252A2C] rounded-xl p-4 space-y-3">
        <div class="flex items-center justify-between text-xs">
          <span class="text-white font-bold">AUTONOMOUS DELIVERY LIFECYCLE (13 PHASES)</span>
          <span class="text-[11px] text-[#C18D38] font-bold">CURRENT: {{ currentDeliveryState() }}</span>
        </div>

        <!-- Stepper track -->
        <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-1.5 text-[10px]">
          @for (state of allStates; track state; let idx = $index) {
            <button
              type="button"
              (click)="setDeliveryState(state)"
              class="p-2 rounded border cursor-pointer transition-all flex flex-col justify-between h-14 text-left w-full"
              [class.bg-[#294A5A]]="currentDeliveryState() === state"
              [class.border-[#47728A]]="currentDeliveryState() === state"
              [class.text-white]="currentDeliveryState() === state"
              [class.bg-[#101416]]="currentDeliveryState() !== state"
              [class.border-[#252A2C]]="currentDeliveryState() !== state"
              [class.text-[#6D7474]]="currentDeliveryState() !== state">
              <div class="flex justify-between font-bold">
                <span>{{ idx + 1 }}.</span>
                @if (isStatePassed(state)) {
                  <span class="text-emerald-400">✓</span>
                }
              </div>
              <div class="font-bold truncate text-[10px]">{{ state }}</div>
            </button>
          }
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- Active Cargo Consignments Manifest (7 Cols) -->
        <div class="lg:col-span-7 bg-[#14181B] border border-[#252A2C] rounded-xl p-4 space-y-3">
          <div class="flex items-center justify-between text-xs">
            <span class="text-white font-bold">LOADED CONSIGNMENT MANIFEST & MULTI-STOP ROUTE</span>
            <span class="text-[#6D7474]">AIRCRAFT: SPITFIRE-001</span>
          </div>

          <div class="space-y-2.5">
            @for (item of loadedPayloads(); track item.id; let idx = $index) {
              <div class="p-3 bg-[#101416] border border-[#252A2C] hover:border-[#47728A] rounded-xl text-xs space-y-2 transition-all">
                <div class="flex items-start justify-between flex-wrap gap-2">
                  <div>
                    <div class="flex items-center gap-2">
                      <span class="w-5 h-5 rounded-full bg-[#294A5A] text-white flex items-center justify-center font-bold text-[10px]">
                        {{ idx + 1 }}
                      </span>
                      <span class="font-bold text-white text-sm">{{ item.name }}</span>
                    </div>
                    <div class="text-[10px] text-[#C18D38] mt-0.5">TRACKING: {{ item.trackingId }}</div>
                  </div>
                  <div class="flex items-center gap-1.5">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                          [class.bg-emerald-950]="item.secured"
                          [class.text-emerald-400]="item.secured"
                          [class.bg-rose-950]="!item.secured"
                          [class.text-rose-400]="!item.secured">
                      {{ item.secured ? '🔒 LOCKED & SECURED' : 'UNSECURED' }}
                    </span>
                    <span class="px-2 py-0.5 rounded bg-[#252A2C] text-white text-[10px] font-bold">
                      {{ item.massKg }} KG
                    </span>
                  </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-[#B5B8B3] pt-1 border-t border-[#252A2C]/60">
                  <div>
                    <span class="text-[#6D7474]">Destination:</span> {{ item.destinationAddress }}
                  </div>
                  <div>
                    <span class="text-[#6D7474]">Recipient:</span> {{ item.recipient }}
                  </div>
                  <div>
                    <span class="text-[#6D7474]">Delivery Mode:</span> {{ item.constraints.deliveryMethod }}
                  </div>
                  <div>
                    <span class="text-[#6D7474]">Temp Sensor:</span> 4.2°C (Optimal Range 2-6°C)
                  </div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Vision-Based Delivery Verification Engine (5 Cols) -->
        <div class="lg:col-span-5 bg-[#14181B] border border-[#252A2C] rounded-xl p-4 space-y-3">
          <div class="flex items-center justify-between text-xs pb-2 border-b border-[#252A2C]">
            <span class="text-white font-bold">VISION-BASED DELIVERY VERIFICATION</span>
            <span class="text-[10px] text-emerald-400">ML + CRYPTO SIGN</span>
          </div>

          <!-- Synthetic Downward Verification Nadir Feed -->
          <div class="relative w-full h-44 rounded-lg bg-zinc-950 border border-[#294A5A]/50 flex items-center justify-center overflow-hidden tactical-grid">
            <div class="absolute inset-0 scanline opacity-30"></div>
            
            <!-- Ground Drop Target Box -->
            <div class="w-24 h-24 border-2 border-emerald-400/80 bg-emerald-400/10 rounded flex items-center justify-center animate-pulse">
              <div class="w-12 h-12 bg-[#A5463E] rounded text-[8px] font-bold text-white flex items-center justify-center text-center p-1">
                NHS BLOOD CASE
              </div>
            </div>

            <div class="absolute bottom-2 left-2 text-[9px] text-emerald-400 bg-black/80 px-2 py-0.5 rounded">
              OPTICAL MATCH: 98.4% CONFIDENCE
            </div>
            <div class="absolute top-2 right-2 text-[9px] text-white bg-black/80 px-2 py-0.5 rounded">
              TETHER TENSION: 0.0 N (RELEASED)
            </div>
          </div>

          <!-- Verification Audit Logs -->
          <div class="p-2.5 bg-[#101416] border border-[#252A2C] rounded-lg text-xs space-y-1">
            <div class="text-[10px] text-[#6D7474] font-bold uppercase">Automated Verification Log</div>
            <div class="space-y-1 text-[10px] text-[#B5B8B3] max-h-32 overflow-y-auto">
              @for (log of verification().logs; track log) {
                <div class="leading-relaxed">{{ log }}</div>
              }
            </div>
          </div>

          <!-- Cryptographic Signoff Receipt Token -->
          <div class="p-2.5 bg-[#294A5A]/20 border border-[#294A5A] rounded-lg text-xs space-y-1">
            <div class="text-[9px] text-[#47728A] font-bold">CAA REGULATORY PROOF OF DEPOSIT</div>
            <div class="text-[10px] text-white break-all font-mono">
              SPITFIRE-VERIFY-7F4B9A1-NHS-BIRMINGHAM-2026-UKCAA
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class CargoLogistics {
  private readonly logistics = inject(MissionLogisticsService);

  readonly allStates: DeliveryState[] = [
    'CREATED', 'ALLOCATED', 'PACKED', 'LOADED', 'READY',
    'IN_FLIGHT', 'APPROACHING', 'DELIVERY_ZONE', 'DELIVERED',
    'VERIFIED', 'RETURNED', 'FAILED', 'CANCELLED'
  ];

  readonly currentDeliveryState = computed(() => this.logistics.activeDeliveryState());
  readonly loadedPayloads = computed(() => this.logistics.loadedPayloads());
  readonly verification = computed(() => this.logistics.verificationProgress());

  setDeliveryState(state: DeliveryState) {
    this.logistics.advanceDeliverySimulation(state);
  }

  advanceDeliveryStage() {
    const curr = this.currentDeliveryState();
    const idx = this.allStates.indexOf(curr);
    if (idx < this.allStates.length - 1) {
      this.logistics.advanceDeliverySimulation(this.allStates[idx + 1]);
    } else {
      this.logistics.advanceDeliverySimulation(this.allStates[0]);
    }
  }

  isStatePassed(state: DeliveryState): boolean {
    const currIdx = this.allStates.indexOf(this.currentDeliveryState());
    const targetIdx = this.allStates.indexOf(state);
    return targetIdx < currIdx;
  }
}
