import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MissionLogisticsService } from '../../core/services/mission-logistics.service';
import { FleetAircraft } from '../../core/models/aircraft.model';

@Component({
  selector: 'app-fleet-management',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-full p-4 overflow-y-auto space-y-4 font-mono">
      <!-- Header -->
      <div class="flex items-center justify-between flex-wrap gap-2 pb-2 border-b border-[#252A2C]">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-bold text-[#47728A] px-2 py-0.5 rounded bg-[#47728A]/10 border border-[#47728A]/30">FLEET DISPATCH</span>
            <h2 class="text-lg font-bold text-white">SPITFIRE AUTONOMOUS FLEET CONTROL</h2>
          </div>
          <p class="text-xs text-[#B5B8B3] mt-0.5">
            Fleet-wide payload capacity allocation, live telemetry tracking & multi-mission orchestration.
          </p>
        </div>

        <div class="flex items-center gap-3 text-xs">
          <div class="p-2 bg-[#14181B] border border-[#252A2C] rounded-lg">
            <span class="text-[#6D7474]">TOTAL FLEET:</span> <span class="text-white font-bold">12 AIRCRAFT</span>
          </div>
          <div class="p-2 bg-[#14181B] border border-[#252A2C] rounded-lg">
            <span class="text-[#6D7474]">ACTIVE MISSIONS:</span> <span class="text-emerald-400 font-bold">8 MISSIONS</span>
          </div>
        </div>
      </div>

      <!-- Fleet Aircraft Cards Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        @for (ac of fleet(); track ac.id) {
          <button
            type="button"
            (click)="selectedAircraft.set(ac)"
            [class.border-[#47728A]]="selectedAircraft()?.id === ac.id"
            [class.bg-[#181E21]]="selectedAircraft()?.id === ac.id"
            class="p-4 bg-[#14181B] border border-[#252A2C] rounded-xl cursor-pointer hover:border-[#47728A] transition-all space-y-3 text-left w-full">
            <div class="flex items-start justify-between">
              <div>
                <div class="font-bold text-white text-base">{{ ac.id }}</div>
                <div class="text-[10px] text-[#C18D38]">{{ ac.callsign }}</div>
              </div>
              <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                    [class.bg-emerald-950]="ac.status === 'IN_FLIGHT' || ac.status === 'DISPENSING'"
                    [class.text-emerald-400]="ac.status === 'IN_FLIGHT' || ac.status === 'DISPENSING'"
                    [class.bg-amber-950]="ac.status === 'PREFLIGHT_CHECK' || ac.status === 'LOADING'"
                    [class.text-amber-400]="ac.status === 'PREFLIGHT_CHECK' || ac.status === 'LOADING'"
                    [class.bg-[#252A2C]]="ac.status === 'IDLE_DEPOT'"
                    [class.text-[#B5B8B3]]="ac.status === 'IDLE_DEPOT'">
                {{ ac.status }}
              </span>
            </div>

            <!-- Battery & Installed Module -->
            <div class="space-y-1.5 text-xs text-[#B5B8B3]">
              <div class="flex justify-between text-[11px]">
                <span class="text-[#6D7474]">MODULE:</span>
                <span class="text-white font-bold">{{ ac.installedModule.type }}</span>
              </div>
              <div class="flex justify-between text-[11px]">
                <span class="text-[#6D7474]">BATTERY:</span>
                <span class="font-bold" [class.text-emerald-400]="ac.batteryPercent > 50" [class.text-amber-400]="ac.batteryPercent <= 50">{{ ac.batteryPercent }}%</span>
              </div>
              <div class="w-full h-1.5 bg-[#252A2C] rounded-full overflow-hidden">
                <div class="h-full bg-emerald-500 rounded-full" [style.width.%]="ac.batteryPercent"></div>
              </div>
            </div>

            <!-- Quick Telemetry Badges -->
            <div class="grid grid-cols-2 gap-2 pt-2 border-t border-[#252A2C] text-[10px] text-[#6D7474]">
              <div>ALT: <span class="text-white font-bold">{{ ac.telemetry.altitudeM }}m</span></div>
              <div>SPEED: <span class="text-white font-bold">{{ ac.telemetry.groundSpeedMs }}m/s</span></div>
            </div>
          </button>
        }
      </div>

      <!-- Selected Aircraft Detailed Telemetry & Mission Dispatcher -->
      @if (selectedAircraft(); as ac) {
        <div class="bg-[#14181B] border border-[#252A2C] rounded-xl p-4 space-y-3">
          <div class="flex items-center justify-between text-xs pb-2 border-b border-[#252A2C]">
            <span class="text-white font-bold">TELEMETRY DETAIL: {{ ac.id }} ({{ ac.callsign }})</span>
            <span class="text-[#47728A]">ACTIVE LINK: {{ ac.telemetry.linkSignalDbm }} dBm | SATELLITES: {{ ac.telemetry.gnssSatellites }}</span>
          </div>

          <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3 text-xs">
            <div class="p-2.5 bg-[#101416] rounded border border-[#252A2C]">
              <div class="text-[9px] text-[#6D7474]">VOLTAGE & CURRENT</div>
              <div class="text-sm font-bold text-white mt-0.5">{{ ac.telemetry.voltageV }}V / {{ ac.telemetry.currentA }}A</div>
            </div>
            <div class="p-2.5 bg-[#101416] rounded border border-[#252A2C]">
              <div class="text-[9px] text-[#6D7474]">POWER DRAW</div>
              <div class="text-sm font-bold text-cyan-400 mt-0.5">{{ (ac.telemetry.voltageV * ac.telemetry.currentA).toFixed(0) }} W</div>
            </div>
            <div class="p-2.5 bg-[#101416] rounded border border-[#252A2C]">
              <div class="text-[9px] text-[#6D7474]">HEADING</div>
              <div class="text-sm font-bold text-white mt-0.5">{{ ac.telemetry.headingDeg }}°</div>
            </div>
            <div class="p-2.5 bg-[#101416] rounded border border-[#252A2C]">
              <div class="text-[9px] text-[#6D7474]">TEMPERATURE</div>
              <div class="text-sm font-bold text-white mt-0.5">{{ ac.telemetry.temperatureC }}°C</div>
            </div>
            <div class="p-2.5 bg-[#101416] rounded border border-[#252A2C]">
              <div class="text-[9px] text-[#6D7474]">IMU HEALTH</div>
              <div class="text-sm font-bold text-emerald-400 mt-0.5">{{ ac.telemetry.imuHealth }}%</div>
            </div>
            <div class="p-2.5 bg-[#101416] rounded border border-[#252A2C]">
              <div class="text-[9px] text-[#6D7474]">ACTIVE MISSION</div>
              <div class="text-[11px] font-bold text-[#C18D38] mt-0.5 truncate">{{ ac.activeMissionId || 'STANDBY' }}</div>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class FleetManagement {
  private readonly logistics = inject(MissionLogisticsService);

  readonly fleet = computed(() => this.logistics.fleet());
  readonly selectedAircraft = signal<FleetAircraft | null>(this.fleet()[0] || null);
}
