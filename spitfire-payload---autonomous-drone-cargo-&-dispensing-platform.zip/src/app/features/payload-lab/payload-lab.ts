import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SpitfirePhysics, SPITFIRE_MK4_SPEC } from '../../core/services/spitfire-physics.service';

@Component({
  selector: 'app-payload-lab',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-full p-4 overflow-y-auto space-y-4 font-mono">
      <!-- Header -->
      <div class="flex items-center justify-between flex-wrap gap-2 pb-2 border-b border-[#252A2C]">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-bold text-[#47728A] px-2 py-0.5 rounded bg-[#47728A]/10 border border-[#47728A]/30">RESEARCH & REPLAY</span>
            <h2 class="text-lg font-bold text-white">PAYLOAD LAB & DETERMINISTIC REPLAY ENGINE</h2>
          </div>
          <p class="text-xs text-[#B5B8B3] mt-0.5">
            Physics parameter variation experiments, Edge ML inference benchmarks & timeline mission playback.
          </p>
        </div>

        <div class="flex items-center gap-2 text-xs">
          <span class="text-[#6D7474]">SEED:</span>
          <span class="px-2.5 py-1 bg-[#14181B] border border-[#252A2C] rounded text-white font-bold">SPITFIRE-PAYLOAD-2026</span>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- Column 1: Parameter Experiment Matrix (6 Cols) -->
        <div class="lg:col-span-6 bg-[#14181B] border border-[#252A2C] rounded-xl p-4 space-y-4">
          <div class="flex items-center justify-between text-xs pb-2 border-b border-[#252A2C]">
            <span class="text-white font-bold">PAYLOAD DYNAMICS EXPERIMENTAL MATRIX</span>
            <span class="text-[10px] text-[#C18D38]">SIMULATED SENSITIVITY</span>
          </div>

          <!-- Parameter Sliders -->
          <div class="space-y-3 text-xs">
            <div>
              <div class="flex justify-between text-[11px] mb-1">
                <span class="text-[#B5B8B3]">EXPERIMENTAL PAYLOAD MASS</span>
                <span class="text-white font-bold">{{ testPayloadMass() }} KG</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="18.0"
                step="0.5"
                [value]="testPayloadMass()"
                (input)="updateMass($event)"
                class="w-full accent-[#C18D38]" />
            </div>

            <div>
              <div class="flex justify-between text-[11px] mb-1">
                <span class="text-[#B5B8B3]">HEADWIND VELOCITY</span>
                <span class="text-white font-bold">{{ testWindSpeed() }} M/S</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="15.0"
                step="0.5"
                [value]="testWindSpeed()"
                (input)="updateWind($event)"
                class="w-full accent-[#294A5A]" />
            </div>

            <div>
              <div class="flex justify-between text-[11px] mb-1">
                <span class="text-[#B5B8B3]">AMBIENT AIR TEMPERATURE</span>
                <span class="text-white font-bold">{{ testTemp() }} °C</span>
              </div>
              <input
                type="range"
                min="-10.0"
                max="40.0"
                step="1.0"
                [value]="testTemp()"
                (input)="updateTemp($event)"
                class="w-full accent-[#47728A]" />
            </div>
          </div>

          <!-- Resulting Output Energy & Range Matrix -->
          <div class="grid grid-cols-2 gap-2.5 pt-2 border-t border-[#252A2C] text-xs">
            <div class="p-2.5 bg-[#101416] rounded border border-[#252A2C]">
              <div class="text-[9px] text-[#6D7474]">TOTAL TAKEOFF MASS</div>
              <div class="text-sm font-bold text-white mt-0.5">{{ calculatedMass() }} KG</div>
              <div class="text-[9px]" [class.text-emerald-400]="calculatedMass() <= 32.5" [class.text-rose-400]="calculatedMass() > 32.5">
                {{ calculatedMass() <= 32.5 ? 'Within MTOM Limit' : 'OVERWEIGHT BREACH' }}
              </div>
            </div>

            <div class="p-2.5 bg-[#101416] rounded border border-[#252A2C]">
              <div class="text-[9px] text-[#6D7474]">ESTIMATED MAX RANGE</div>
              <div class="text-sm font-bold text-emerald-400 mt-0.5">{{ dynamicEnergy().estimatedMaxRangeKm }} KM</div>
              <div class="text-[9px] text-[#6D7474]">Endurance: {{ dynamicEnergy().estimatedEnduranceMin }} min</div>
            </div>

            <div class="p-2.5 bg-[#101416] rounded border border-[#252A2C]">
              <div class="text-[9px] text-[#6D7474]">HOVER POWER DRAW</div>
              <div class="text-sm font-bold text-white mt-0.5">{{ dynamicEnergy().hoverPowerDrawW }} W</div>
            </div>

            <div class="p-2.5 bg-[#101416] rounded border border-[#252A2C]">
              <div class="text-[9px] text-[#6D7474]">CRUISE POWER DRAW</div>
              <div class="text-sm font-bold text-cyan-400 mt-0.5">{{ dynamicEnergy().cruisePowerDrawW }} W</div>
            </div>
          </div>
        </div>

        <!-- Column 2: Edge ML Benchmarks & Mission Replay Scrubber (6 Cols) -->
        <div class="lg:col-span-6 space-y-4">
          <!-- ML Model Performance Benchmark -->
          <div class="bg-[#14181B] border border-[#252A2C] rounded-xl p-4 space-y-3">
            <div class="flex items-center justify-between text-xs pb-1 border-b border-[#252A2C]">
              <span class="text-white font-bold">EDGE PERCEPTION BENCHMARK (NVIDIA JETSON AGX)</span>
              <span class="text-[10px] text-emerald-400">FPS: 70.4</span>
            </div>

            <div class="grid grid-cols-3 gap-2 text-xs">
              <div class="p-2 bg-[#101416] rounded border border-[#252A2C]">
                <div class="text-[9px] text-[#6D7474]">DETECTION LATENCY</div>
                <div class="text-sm font-bold text-white mt-0.5">14.2 MS</div>
                <div class="text-[9px] text-emerald-400">mAP@50: 94.2%</div>
              </div>

              <div class="p-2 bg-[#101416] rounded border border-[#252A2C]">
                <div class="text-[9px] text-[#6D7474]">WORLD VOXEL SYNC</div>
                <div class="text-sm font-bold text-white mt-0.5">2.4 MS</div>
                <div class="text-[9px] text-cyan-400">160k Voxels</div>
              </div>

              <div class="p-2 bg-[#101416] rounded border border-[#252A2C]">
                <div class="text-[9px] text-[#6D7474]">TRAJECTORY REROUTE</div>
                <div class="text-sm font-bold text-white mt-0.5">1.8 MS</div>
                <div class="text-[9px] text-emerald-400">Deterministic</div>
              </div>
            </div>
          </div>

          <!-- Deterministic Mission Replay Timeline -->
          <div class="bg-[#14181B] border border-[#252A2C] rounded-xl p-4 space-y-3">
            <div class="flex items-center justify-between text-xs pb-1 border-b border-[#252A2C]">
              <span class="text-white font-bold">DETERMINISTIC MISSION REPLAY</span>
              <span class="text-[10px] text-[#47728A]">TIME: T+{{ replayTime() }}S</span>
            </div>

            <!-- Replay Scrubber -->
            <div class="space-y-2 text-xs">
              <input
                type="range"
                min="0"
                max="120"
                step="1"
                [value]="replayTime()"
                (input)="updateReplayTime($event)"
                class="w-full accent-[#47728A] cursor-pointer" />

              <div class="flex justify-between text-[10px] text-[#6D7474]">
                <span>T+0s (Takeoff)</span>
                <span>T+35s (Perception)</span>
                <span>T+68s (Drop Zone)</span>
                <span>T+120s (Return)</span>
              </div>
            </div>

            <div class="p-2.5 bg-[#101416] rounded-lg border border-[#252A2C] text-xs flex items-center justify-between">
              <div>
                <span class="text-[#6D7474]">REPLAY EVENT:</span>
                <span class="text-white font-bold ml-1">{{ getReplayPhase(replayTime()) }}</span>
              </div>
              <span class="text-[10px] text-emerald-400 font-bold">REPRODUCIBLE RUN</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class PayloadLab {
  private readonly physics = inject(SpitfirePhysics);

  readonly testPayloadMass = signal<number>(8.4);
  readonly testWindSpeed = signal<number>(4.5);
  readonly testTemp = signal<number>(18.0);
  readonly replayTime = signal<number>(42);

  readonly calculatedMass = computed(() => {
    return Math.round((SPITFIRE_MK4_SPEC.emptyDryMassKg + 1.8 + this.testPayloadMass()) * 10) / 10;
  });

  readonly dynamicEnergy = computed(() => {
    return this.physics.calculateEnergyAndFlightDynamics(
      SPITFIRE_MK4_SPEC,
      this.calculatedMass(),
      this.testWindSpeed(),
      this.testTemp()
    );
  });

  updateMass(e: Event) {
    this.testPayloadMass.set(parseFloat((e.target as HTMLInputElement).value));
  }

  updateWind(e: Event) {
    this.testWindSpeed.set(parseFloat((e.target as HTMLInputElement).value));
  }

  updateTemp(e: Event) {
    this.testTemp.set(parseFloat((e.target as HTMLInputElement).value));
  }

  updateReplayTime(e: Event) {
    this.replayTime.set(parseInt((e.target as HTMLInputElement).value, 10));
  }

  getReplayPhase(t: number): string {
    if (t < 15) return 'TAKEOFF & VERTICAL CLIMB (15M AGL)';
    if (t < 40) return 'CRUISE TRANSITION & MULTI-SPECTRAL PERCEPTION';
    if (t < 65) return 'DELIVERY ZONE OPTICAL CONFIRMATION & HOVER';
    if (t < 80) return 'TETHER DESCENT & WINCH GROUND RELEASE';
    if (t < 100) return 'OPTICAL VERIFICATION COMPLETE & VERTICAL ASCENT';
    return 'SAFE RETURN-TO-BASE DEPOT CRUISE';
  }
}
