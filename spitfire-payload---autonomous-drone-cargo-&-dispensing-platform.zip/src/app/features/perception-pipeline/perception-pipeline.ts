import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SpatialPerceptionService } from '../../core/services/spatial-perception.service';
import { GeminiIntelligenceService } from '../../core/services/gemini-intelligence.service';
import { DetectedObject, PerceptionSensorSource } from '../../core/models/spatial.model';

@Component({
  selector: 'app-perception-pipeline',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-full p-4 overflow-y-auto space-y-4 font-mono">
      <!-- Header -->
      <div class="flex items-center justify-between flex-wrap gap-2 pb-2 border-b border-[#252A2C]">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-bold text-[#47728A] px-2 py-0.5 rounded bg-[#47728A]/10 border border-[#47728A]/30">SIGNATURE SCREEN</span>
            <h2 class="text-lg font-bold text-white">WHAT DOES THE DRONE SEE & THINK?</h2>
          </div>
          <p class="text-xs text-[#B5B8B3] mt-0.5">
            Synthetic Computer Vision pipeline: classification, confidence modeling, depth point-clouds & spatial reasoning engine.
          </p>
        </div>

        <!-- Sensor Stream Switcher -->
        <div class="flex items-center gap-1.5 bg-[#14181B] border border-[#252A2C] p-1 rounded-lg text-xs">
          <span class="text-[10px] text-[#6D7474] px-1">SENSOR STREAM:</span>
          <button
            type="button"
            (click)="activeSensorMode.set('RGB_CAMERA_4K')"
            [class.bg-[#294A5A]]="activeSensorMode() === 'RGB_CAMERA_4K'"
            [class.text-white]="activeSensorMode() === 'RGB_CAMERA_4K'"
            class="px-2 py-1 rounded hover:bg-[#252A2C] text-[#B5B8B3] transition-colors">
            RGB 4K
          </button>
          <button
            type="button"
            (click)="activeSensorMode.set('THERMAL_IR_640')"
            [class.bg-[#294A5A]]="activeSensorMode() === 'THERMAL_IR_640'"
            [class.text-white]="activeSensorMode() === 'THERMAL_IR_640'"
            class="px-2 py-1 rounded hover:bg-[#252A2C] text-[#B5B8B3] transition-colors">
            THERMAL IR
          </button>
          <button
            type="button"
            (click)="activeSensorMode.set('LIDAR_SPATIAL_SCANNER')"
            [class.bg-[#294A5A]]="activeSensorMode() === 'LIDAR_SPATIAL_SCANNER'"
            [class.text-white]="activeSensorMode() === 'LIDAR_SPATIAL_SCANNER'"
            class="px-2 py-1 rounded hover:bg-[#252A2C] text-[#B5B8B3] transition-colors">
            LiDAR DEPTH
          </button>
        </div>
      </div>

      <!-- Tri-View / Dual Perception Display -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- Panel 1 & 2: Synthetic Vision Viewport with Bounding Box Overlays (7 Cols) -->
        <div class="lg:col-span-7 bg-[#14181B] border border-[#252A2C] rounded-xl p-4 space-y-3">
          <div class="flex items-center justify-between text-xs">
            <span class="text-white font-bold flex items-center gap-2">
              <span class="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
              LIVE ONBOARD SENSOR FEED & INFERENCE
            </span>
            <span class="text-[#47728A]">INFERENCE: 14.2 MS (70.4 FPS)</span>
          </div>

          <!-- Synthetic Camera Frame Screen with Bounding Boxes -->
          <div
            class="relative w-full h-80 rounded-lg overflow-hidden border border-[#294A5A]/50 flex items-center justify-center tactical-grid select-none"
            [class.bg-gradient-to-b]="activeSensorMode() === 'RGB_CAMERA_4K'"
            [class.from-[#1a2c36]]="activeSensorMode() === 'RGB_CAMERA_4K'"
            [class.to-[#0e171c]]="activeSensorMode() === 'RGB_CAMERA_4K'"
            [class.bg-gradient-to-br]="activeSensorMode() === 'THERMAL_IR_640'"
            [class.from-purple-950]="activeSensorMode() === 'THERMAL_IR_640'"
            [class.via-orange-950]="activeSensorMode() === 'THERMAL_IR_640'"
            [class.to-zinc-950]="activeSensorMode() === 'THERMAL_IR_640'"
            [class.bg-zinc-950]="activeSensorMode() === 'LIDAR_SPATIAL_SCANNER'">
            
            <!-- Scanline Tactical Overlay -->
            <div class="absolute inset-0 scanline pointer-events-none opacity-40"></div>

            <!-- Optical Center Reticle Crosshairs -->
            <div class="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div class="w-16 h-16 border border-white/20 rounded-full flex items-center justify-center">
                <div class="w-2 h-2 bg-cyan-400/80 rounded-full"></div>
              </div>
            </div>

            <!-- Detected Object Bounding Boxes -->
            @for (obj of detectedObjects(); track obj.id) {
              <button
                type="button"
                (click)="selectedObject.set(obj)"
                class="absolute border-2 cursor-pointer transition-all hover:scale-[1.02] flex flex-col justify-between p-1 rounded text-left"
                [class.ring-2]="selectedObject()?.id === obj.id"
                [class.ring-white]="selectedObject()?.id === obj.id"
                [style.left.%]="obj.boundingBox2D.xMinPct"
                [style.top.%]="obj.boundingBox2D.yMinPct"
                [style.width.%]="obj.boundingBox2D.widthPct"
                [style.height.%]="obj.boundingBox2D.heightPct"
                [style.borderColor]="obj.threatLevel === 'CRITICAL_COLLISION_RISK' ? '#A5463E' : (obj.class === 'LANDING_AREA' ? '#10b981' : '#C18D38')"
                [style.backgroundColor]="obj.threatLevel === 'CRITICAL_COLLISION_RISK' ? 'rgba(165,70,62,0.2)' : 'rgba(193,141,56,0.1)'">
                
                <!-- Tag badge on top of bounding box -->
                <div class="flex items-center justify-between text-[9px] font-bold text-white px-1 py-0.5 rounded shadow"
                     [style.backgroundColor]="obj.threatLevel === 'CRITICAL_COLLISION_RISK' ? '#A5463E' : (obj.class === 'LANDING_AREA' ? '#10b981' : '#C18D38')">
                  <span>{{ obj.id }}: {{ obj.class }}</span>
                  <span>{{ (obj.confidence * 100).toFixed(0) }}%</span>
                </div>

                <!-- Dynamic Speed tag if moving -->
                @if (obj.isDynamic) {
                  <div class="text-[8px] text-cyan-300 font-bold bg-black/75 px-1 py-0.2 rounded self-start">
                    v={{ obj.velocity.x }}m/s ↗
                  </div>
                }
              </button>
            }

            <!-- Telemetry Overlay on Camera Feed -->
            <div class="absolute top-2 left-2 text-[10px] text-white/80 bg-black/60 px-2 py-1 rounded backdrop-blur-sm">
              <div>ALT: 18.5M | HDG: 124° | GS: 16.4 M/S</div>
              <div class="text-[9px] text-[#47728A]">PERCEPTION: SPITFIRE-CV-V4.2 [EDGE-RT]</div>
            </div>
          </div>

          <!-- Detections Table List -->
          <div class="space-y-1.5 text-xs">
            <div class="text-[#6D7474] text-[10px] uppercase">Detected Spatial Entities (Click to Inspect)</div>
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-2">
              @for (obj of detectedObjects(); track obj.id) {
                <button
                  type="button"
                  (click)="selectedObject.set(obj)"
                  [class.border-[#C18D38]]="selectedObject()?.id === obj.id"
                  [class.bg-[#252A2C]]="selectedObject()?.id === obj.id"
                  class="p-2 bg-[#101416] border border-[#252A2C] rounded-lg cursor-pointer hover:border-[#47728A] transition-all text-left w-full">
                  <div class="flex justify-between items-center">
                    <span class="font-bold text-white text-[11px]">{{ obj.id }}</span>
                    <span class="text-[10px]" [class.text-emerald-400]="obj.confidence > 0.9" [class.text-amber-400]="obj.confidence <= 0.9">
                      {{ (obj.confidence * 100).toFixed(0) }}%
                    </span>
                  </div>
                  <div class="text-[10px] text-[#6D7474] mt-0.5">{{ obj.class }}</div>
                  <div class="text-[9px] text-[#47728A] mt-1">{{ obj.clearanceDistanceM }}m clearance</div>
                </button>
              }
            </div>
          </div>
        </div>

        <!-- Panel 3: "What Does The Drone Think?" Transparent Reasoning Display (5 Cols) -->
        <div class="lg:col-span-5 space-y-4">
          <!-- Structured Reasoning Metrics -->
          <div class="bg-[#14181B] border border-[#252A2C] rounded-xl p-4 space-y-3">
            <div class="flex items-center justify-between pb-2 border-b border-[#252A2C]">
              <span class="text-xs font-bold text-white">WHAT DOES THE DRONE THINK?</span>
              <span class="text-[10px] text-emerald-400 bg-emerald-400/10 px-2 py-0.5 rounded border border-emerald-400/30">
                TRAJECTORY VALID
              </span>
            </div>

            <div class="grid grid-cols-2 gap-2.5 text-xs">
              <div class="p-2 bg-[#101416] rounded border border-[#252A2C]">
                <div class="text-[9px] text-[#6D7474]">OBJECTS DETECTED</div>
                <div class="text-sm font-bold text-white mt-0.5">8 ACTIVE</div>
                <div class="text-[9px] text-[#47728A]">2 Dynamic, 6 Static</div>
              </div>

              <div class="p-2 bg-[#101416] rounded border border-[#252A2C]">
                <div class="text-[9px] text-[#6D7474]">MIN OBSTACLE CLEARANCE</div>
                <div class="text-sm font-bold text-amber-400 mt-0.5">11.5 METRES</div>
                <div class="text-[9px] text-[#6D7474]">Hazard: WIRE-003</div>
              </div>

              <div class="p-2 bg-[#101416] rounded border border-[#252A2C]">
                <div class="text-[9px] text-[#6D7474]">PERCEPTION CONFIDENCE</div>
                <div class="text-sm font-bold text-emerald-400 mt-0.5">HIGH (94.2%)</div>
                <div class="text-[9px] text-[#6D7474]">RTK GNSS σ: 0.04m</div>
              </div>

              <div class="p-2 bg-[#101416] rounded border border-[#252A2C]">
                <div class="text-[9px] text-[#6D7474]">WORLD MODEL AGE</div>
                <div class="text-sm font-bold text-white mt-0.5">140 MS</div>
                <div class="text-[9px] text-[#6D7474]">Memory Sync: 0.3s</div>
              </div>
            </div>

            <!-- Dynamic Track Prediction Box -->
            <div class="p-2.5 bg-[#101416] border border-[#252A2C] rounded-lg text-xs space-y-1">
              <div class="text-[10px] text-[#C18D38] font-bold">DYNAMIC OBJECT TRACKING: VEHICLE 42</div>
              <div class="text-[11px] text-[#ECE9DF]">
                Position: (4.0m, -8.0m) | Velocity: 4.5 m/s North-East
              </div>
              <div class="text-[10px] text-[#6D7474]">
                Predicted (+2.0s): (13.0m, -5.6m) — Clearance corridor clear. Zero trajectory intersection.
              </div>
            </div>
          </div>

          <!-- Interactive Spatial Query Engine -->
          <div class="bg-[#14181B] border border-[#252A2C] rounded-xl p-4 space-y-3">
            <div class="flex items-center justify-between text-xs pb-1">
              <span class="text-white font-bold">SPATIAL REASONING QUERY ENGINE</span>
              <span class="text-[10px] text-[#47728A]">ONBOARD + GEMINI PRO</span>
            </div>

            <!-- Preset Queries -->
            <div class="flex flex-wrap gap-1.5 text-[11px]">
              <button
                type="button"
                (click)="runQuery('Is the delivery landing zone clear of pedestrians?')"
                class="px-2 py-1 bg-[#101416] hover:bg-[#252A2C] border border-[#252A2C] rounded text-[#B5B8B3] transition-colors">
                Is landing area clear?
              </button>
              <button
                type="button"
                (click)="runQuery('What obstacles exist within 20m of descent path?')"
                class="px-2 py-1 bg-[#101416] hover:bg-[#252A2C] border border-[#252A2C] rounded text-[#B5B8B3] transition-colors">
                Obstacles below me?
              </button>
              <button
                type="button"
                (click)="runQuery('Where is the nearest safe fallback zone?')"
                class="px-2 py-1 bg-[#101416] hover:bg-[#252A2C] border border-[#252A2C] rounded text-[#B5B8B3] transition-colors">
                Nearest safe fallback?
              </button>
            </div>

            <!-- Custom Query Input -->
            <div class="flex gap-2">
              <input
                type="text"
                [(ngModel)]="customQueryText"
                placeholder="Ask spatial reasoning engine..."
                class="flex-1 bg-[#101416] border border-[#252A2C] rounded-lg px-3 py-1.5 text-xs text-white placeholder-[#6D7474] focus:outline-none focus:border-[#47728A]"
                (keydown.enter)="runQuery(customQueryText)" />
              <button
                type="button"
                (click)="runQuery(customQueryText)"
                [disabled]="isQueryRunning()"
                class="px-3 py-1.5 bg-[#294A5A] hover:bg-[#345e72] text-white rounded-lg text-xs font-bold transition-all disabled:opacity-50">
                {{ isQueryRunning() ? 'PROCESSING...' : 'QUERY' }}
              </button>
            </div>

            <!-- Structured Query Answer Result -->
            @if (queryResult(); as result) {
              <div class="p-3 bg-[#101416] border border-[#47728A]/50 rounded-lg text-xs space-y-1.5 animate-fadeIn">
                <div class="flex items-center justify-between text-[10px] text-[#47728A]">
                  <span>RESPONSE ENGINE: {{ result.source }}</span>
                  <span class="text-emerald-400">STATUS: APPROVED</span>
                </div>
                <div class="text-[#ECE9DF] leading-relaxed">{{ result.answer }}</div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class PerceptionPipeline {
  private readonly spatial = inject(SpatialPerceptionService);
  private readonly gemini = inject(GeminiIntelligenceService);

  readonly activeSensorMode = signal<PerceptionSensorSource>('RGB_CAMERA_4K');
  readonly detectedObjects = computed(() => this.spatial.detectedObjects());
  readonly selectedObject = signal<DetectedObject | null>(this.detectedObjects()[0] || null);

  customQueryText = '';
  readonly isQueryRunning = signal<boolean>(false);
  readonly queryResult = signal<{ source: string; answer: string } | null>({
    source: 'SPITFIRE_SPATIAL_ENGINE',
    answer: 'Spatial check complete: Target zone DZ-01 (Pad Alpha) is 100% clear. Nearest hazard is WIRE-003 at 11.5m clearance with active buffer.'
  });

  async runQuery(query: string) {
    if (!query.trim()) return;
    this.isQueryRunning.set(true);

    try {
      const worldContext = {
        objects: this.detectedObjects(),
        zones: this.spatial.deliveryCandidates()
      };

      const res = await this.gemini.executeSpatialQuery(query, worldContext);
      if (res && res.data) {
        this.queryResult.set({
          source: res.source || 'SPITFIRE_SPATIAL_ENGINE',
          answer: res.data.answer || 'Spatial corridor validated.'
        });
      } else {
        const local = this.spatial.executeSpatialQuery(query);
        this.queryResult.set({
          source: 'DETERMINISTIC_RULE_ENGINE',
          answer: local.answer
        });
      }
    } catch {
      const local = this.spatial.executeSpatialQuery(query);
      this.queryResult.set({
        source: 'DETERMINISTIC_RULE_ENGINE',
        answer: local.answer
      });
    } finally {
      this.isQueryRunning.set(false);
    }
  }
}
