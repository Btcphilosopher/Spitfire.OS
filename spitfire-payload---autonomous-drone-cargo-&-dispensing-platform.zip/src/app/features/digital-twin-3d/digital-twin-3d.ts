import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  computed,
  effect,
  inject,
  output,
  signal,
  viewChild
} from '@angular/core';
import { CommonModule } from '@angular/common';
import * as THREE from 'three';
import { MissionLogisticsService } from '../../core/services/mission-logistics.service';
import { SpatialPerceptionService } from '../../core/services/spatial-perception.service';
import { AgriDispensingService } from '../../core/services/agri-dispensing.service';
import { DetectedObject } from '../../core/models/spatial.model';
import { PayloadItem, PayloadModule } from '../../core/models/payload.model';

export type CameraPreset = 'TACTICAL_ORBIT' | 'DRONE_FOLLOW' | 'FPV_SENSOR' | 'PAYLOAD_BAY' | 'NADIR_DROP';

@Component({
  selector: 'app-digital-twin-3d',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full min-h-[420px] bg-[#101416] overflow-hidden select-none border border-[#252A2C] rounded-xl">
      <!-- 3D Canvas Container -->
      <div #canvasContainer class="w-full h-full cursor-grab active:cursor-grabbing"></div>

      <!-- Top Tactical HUD Overlays -->
      <div class="absolute top-3 left-3 flex flex-wrap items-center gap-2 pointer-events-none">
        <div class="pointer-events-auto bg-[#14181B]/90 backdrop-blur-md border border-[#294A5A]/50 px-3 py-1.5 rounded-lg flex items-center gap-2 shadow-lg">
          <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
          <span class="text-xs font-mono font-bold tracking-wider text-[#ECE9DF]">3D SPATIAL DIGITAL TWIN</span>
          <span class="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#294A5A]/40 text-[#47728A] border border-[#294A5A]/60">WEBGL2</span>
        </div>

        <div class="pointer-events-auto bg-[#14181B]/85 backdrop-blur-md border border-[#252A2C] px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 text-xs text-[#B5B8B3] font-mono">
          <span class="text-xs text-[#C18D38]">FPS:</span>
          <span class="text-[#ECE9DF] font-bold">{{ fps() }}</span>
          <span class="text-[#6D7474] ml-1">|</span>
          <span class="text-xs text-[#47728A]">VOXELS:</span>
          <span class="text-[#ECE9DF]">160.9k</span>
        </div>
      </div>

      <!-- Camera Mode Selectors -->
      <div class="absolute top-3 right-3 flex items-center gap-1.5 bg-[#14181B]/90 backdrop-blur-md border border-[#252A2C] p-1 rounded-lg">
        <button
          type="button"
          (click)="setCameraPreset('TACTICAL_ORBIT')"
          [class.bg-[#294A5A]]="cameraMode() === 'TACTICAL_ORBIT'"
          [class.text-white]="cameraMode() === 'TACTICAL_ORBIT'"
          class="px-2.5 py-1 text-[11px] font-mono rounded hover:bg-[#252A2C] text-[#B5B8B3] transition-colors"
          title="Tactical Free Orbit">
          ORBIT
        </button>
        <button
          type="button"
          (click)="setCameraPreset('DRONE_FOLLOW')"
          [class.bg-[#294A5A]]="cameraMode() === 'DRONE_FOLLOW'"
          [class.text-white]="cameraMode() === 'DRONE_FOLLOW'"
          class="px-2.5 py-1 text-[11px] font-mono rounded hover:bg-[#252A2C] text-[#B5B8B3] transition-colors"
          title="Chase Follow Aircraft">
          CHASE
        </button>
        <button
          type="button"
          (click)="setCameraPreset('PAYLOAD_BAY')"
          [class.bg-[#294A5A]]="cameraMode() === 'PAYLOAD_BAY'"
          [class.text-white]="cameraMode() === 'PAYLOAD_BAY'"
          class="px-2.5 py-1 text-[11px] font-mono rounded hover:bg-[#252A2C] text-[#B5B8B3] transition-colors"
          title="Payload Bay Close-up">
          BAY
        </button>
        <button
          type="button"
          (click)="setCameraPreset('FPV_SENSOR')"
          [class.bg-[#294A5A]]="cameraMode() === 'FPV_SENSOR'"
          [class.text-white]="cameraMode() === 'FPV_SENSOR'"
          class="px-2.5 py-1 text-[11px] font-mono rounded hover:bg-[#252A2C] text-[#B5B8B3] transition-colors"
          title="Cockpit Sensor FPV">
          FPV
        </button>
        <button
          type="button"
          (click)="setCameraPreset('NADIR_DROP')"
          [class.bg-[#294A5A]]="cameraMode() === 'NADIR_DROP'"
          [class.text-white]="cameraMode() === 'NADIR_DROP'"
          class="px-2.5 py-1 text-[11px] font-mono rounded hover:bg-[#252A2C] text-[#B5B8B3] transition-colors"
          title="Downward Drop Camera">
          NADIR
        </button>
      </div>

      <!-- Layer Toggles (Bottom Left) -->
      <div class="absolute bottom-3 left-3 bg-[#14181B]/95 backdrop-blur-md border border-[#252A2C] p-2 rounded-lg flex flex-wrap items-center gap-1.5 max-w-xl text-[11px] font-mono">
        <span class="text-[#6D7474] text-[10px] uppercase font-bold tracking-wider mr-1">Layers:</span>
        <button
          type="button"
          (click)="toggleLayer('airframe')"
          [class.border-[#294A5A]]="layers().airframe"
          [class.bg-[#294A5A]/30]="layers().airframe"
          [class.text-[#ECE9DF]]="layers().airframe"
          class="px-2 py-0.5 rounded border border-[#252A2C] text-[#6D7474] hover:text-[#ECE9DF] transition-colors">
          Airframe
        </button>
        <button
          type="button"
          (click)="toggleLayer('payload')"
          [class.border-[#C18D38]]="layers().payload"
          [class.bg-[#C18D38]/20]="layers().payload"
          [class.text-[#C18D38]]="layers().payload"
          class="px-2 py-0.5 rounded border border-[#252A2C] text-[#6D7474] hover:text-[#ECE9DF] transition-colors">
          Payload Bay
        </button>
        <button
          type="button"
          (click)="toggleLayer('obstacles')"
          [class.border-[#A5463E]]="layers().obstacles"
          [class.bg-[#A5463E]/20]="layers().obstacles"
          [class.text-[#A5463E]]="layers().obstacles"
          class="px-2 py-0.5 rounded border border-[#252A2C] text-[#6D7474] hover:text-[#ECE9DF] transition-colors">
          Obstacles & Wires
        </button>
        <button
          type="button"
          (click)="toggleLayer('trajectory')"
          [class.border-[#47728A]]="layers().trajectory"
          [class.bg-[#47728A]/20]="layers().trajectory"
          [class.text-[#47728A]]="layers().trajectory"
          class="px-2 py-0.5 rounded border border-[#252A2C] text-[#6D7474] hover:text-[#ECE9DF] transition-colors">
          Trajectory
        </button>
        <button
          type="button"
          (click)="toggleLayer('pointcloud')"
          [class.border-cyan-500]="layers().pointcloud"
          [class.bg-cyan-500/20]="layers().pointcloud"
          [class.text-cyan-400]="layers().pointcloud"
          class="px-2 py-0.5 rounded border border-[#252A2C] text-[#6D7474] hover:text-[#ECE9DF] transition-colors">
          LiDAR / Depth
        </button>
        <button
          type="button"
          (click)="toggleLayer('field')"
          [class.border-[#65784F]]="layers().field"
          [class.bg-[#65784F]/20]="layers().field"
          [class.text-[#65784F]]="layers().field"
          class="px-2 py-0.5 rounded border border-[#252A2C] text-[#6D7474] hover:text-[#ECE9DF] transition-colors">
          Field & Agri Swath
        </button>
      </div>

      <!-- Live Drone Flight Coordinates HUD (Bottom Right) -->
      <div class="absolute bottom-3 right-3 bg-[#14181B]/95 backdrop-blur-md border border-[#252A2C] px-3 py-2 rounded-lg font-mono text-[11px] flex items-center gap-3">
        <div>
          <div class="text-[9px] text-[#6D7474]">ALTITUDE</div>
          <div class="text-sm font-bold text-white">{{ dronePos().z.toFixed(1) }} <span class="text-[10px] text-[#B5B8B3]">M AGL</span></div>
        </div>
        <div class="w-px h-6 bg-[#252A2C]"></div>
        <div>
          <div class="text-[9px] text-[#6D7474]">AIRSPEED</div>
          <div class="text-sm font-bold text-cyan-400">{{ activeAirspeed().toFixed(1) }} <span class="text-[10px] text-[#B5B8B3]">M/S</span></div>
        </div>
        <div class="w-px h-6 bg-[#252A2C]"></div>
        <div>
          <div class="text-[9px] text-[#6D7474]">COMBINED CG SHIFT</div>
          <div class="text-sm font-bold" [class.text-emerald-400]="cgResult().isWithinEnvelope" [class.text-rose-400]="!cgResult().isWithinEnvelope">
            {{ cgResult().cgShiftMm }} <span class="text-[10px] text-[#B5B8B3]">MM</span>
          </div>
        </div>
      </div>
    </div>
  `
})
export class DigitalTwin3d implements OnInit, OnDestroy {
  private readonly logistics = inject(MissionLogisticsService);
  private readonly spatial = inject(SpatialPerceptionService);
  private readonly agri = inject(AgriDispensingService);

  readonly canvasContainer = viewChild<ElementRef<HTMLDivElement>>('canvasContainer');

  // Outputs
  readonly objectSelected = output<DetectedObject | null>();
  readonly payloadSelected = output<PayloadItem | null>();

  // Reactive state
  readonly cameraMode = signal<CameraPreset>('TACTICAL_ORBIT');
  readonly fps = signal<number>(60);
  readonly dronePos = signal<{ x: number; y: number; z: number }>({ x: 0, y: 0, z: 18.5 });
  readonly activeAirspeed = signal<number>(18.0);

  readonly layers = signal({
    airframe: true,
    payload: true,
    obstacles: true,
    trajectory: true,
    pointcloud: false,
    field: true
  });

  readonly cgResult = computed(() => this.logistics.currentCGResult());
  readonly activeModule = computed(() => this.logistics.activeModule());
  readonly loadedPayloads = computed(() => this.logistics.loadedPayloads());

  // Three.js internal state
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId: number | null = null;
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();

  // 3D Object References
  private droneGroup!: THREE.Group;
  private propMeshes: THREE.Mesh[] = [];
  private payloadBayGroup!: THREE.Group;
  private trajectoryLineMesh!: THREE.Line;
  private pointCloudParticles!: THREE.Points;
  private sprayParticles!: THREE.Points;
  private obstaclesGroup!: THREE.Group;
  private fieldMeshGroup!: THREE.Group;
  private cgCrosshairMesh!: THREE.Mesh;

  // Orbit controls state
  private isDragging = false;
  private prevMouseX = 0;
  private prevMouseY = 0;
  private cameraRadius = 65;
  private cameraTheta = Math.PI / 4;
  private cameraPhi = Math.PI / 3.2;
  private targetLookAt = new THREE.Vector3(0, 5, 0);

  constructor() {
    // React to module changes to rebuild payload bay in 3D
    effect(() => {
      const mod = this.activeModule();
      const items = this.loadedPayloads();
      if (this.payloadBayGroup) {
        this.rebuildPayloadBay3D(mod, items);
      }
    });

    // React to layer toggles
    effect(() => {
      const l = this.layers();
      if (this.droneGroup) this.droneGroup.visible = l.airframe;
      if (this.payloadBayGroup) this.payloadBayGroup.visible = l.payload;
      if (this.obstaclesGroup) this.obstaclesGroup.visible = l.obstacles;
      if (this.trajectoryLineMesh) this.trajectoryLineMesh.visible = l.trajectory;
      if (this.pointCloudParticles) this.pointCloudParticles.visible = l.pointcloud;
      if (this.fieldMeshGroup) this.fieldMeshGroup.visible = l.field;
    });
  }

  ngOnInit() {
    setTimeout(() => {
      this.initThreeJS();
    }, 50);
  }

  ngOnDestroy() {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  setCameraPreset(preset: CameraPreset) {
    this.cameraMode.set(preset);
    if (preset === 'TACTICAL_ORBIT') {
      this.cameraRadius = 65;
      this.cameraTheta = Math.PI / 4;
      this.cameraPhi = Math.PI / 3.2;
      this.targetLookAt.set(10, 5, 0);
    } else if (preset === 'DRONE_FOLLOW') {
      this.cameraRadius = 14;
      this.cameraTheta = Math.PI / 6;
      this.cameraPhi = Math.PI / 2.6;
    } else if (preset === 'PAYLOAD_BAY') {
      this.cameraRadius = 4.5;
      this.cameraTheta = Math.PI / 3;
      this.cameraPhi = Math.PI / 2.1;
    } else if (preset === 'FPV_SENSOR') {
      this.cameraRadius = 0.5;
    } else if (preset === 'NADIR_DROP') {
      this.cameraRadius = 22;
      this.cameraPhi = 0.05; // Looking straight down
    }
  }

  toggleLayer(layerKey: 'airframe' | 'payload' | 'obstacles' | 'trajectory' | 'pointcloud' | 'field') {
    this.layers.update(l => ({ ...l, [layerKey]: !l[layerKey] }));
  }

  private initThreeJS() {
    const container = this.canvasContainer()?.nativeElement;
    if (!container) return;

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 500;

    // Scene setup
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x101416);
    this.scene.fog = new THREE.FogExp2(0x101416, 0.008);

    // Camera setup
    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.updateCameraPosition();

    // Renderer setup
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xdde5ed, 0.65);
    this.scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfff7e6, 1.2);
    sunLight.position.set(40, 70, 30);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    sunLight.shadow.camera.near = 10;
    sunLight.shadow.camera.far = 200;
    sunLight.shadow.camera.left = -60;
    sunLight.shadow.camera.right = 60;
    sunLight.shadow.camera.top = 60;
    sunLight.shadow.camera.bottom = -60;
    this.scene.add(sunLight);

    const blueFillLight = new THREE.DirectionalLight(0x294a5a, 0.5);
    blueFillLight.position.set(-40, 20, -30);
    this.scene.add(blueFillLight);

    // Ground Tactical Grid & Environment
    this.buildWorldEnvironment();

    // Build Spitfire Airframe
    this.buildSpitfireAirframe();

    // Build Trajectory & LiDAR Clouds
    this.buildTrajectoryMesh();
    this.buildLiDARPointCloud();

    // Event listeners
    container.addEventListener('mousedown', this.onMouseDown.bind(this));
    window.addEventListener('mousemove', this.onMouseMove.bind(this));
    window.addEventListener('mouseup', this.onMouseUp.bind(this));
    container.addEventListener('wheel', this.onMouseWheel.bind(this), { passive: true });
    window.addEventListener('resize', this.onWindowResize.bind(this));

    // Start render loop
    this.animate();
  }

  private buildWorldEnvironment() {
    // Tactical Ground Plane
    const groundGeo = new THREE.PlaneGeometry(240, 240, 48, 48);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x14181b,
      roughness: 0.9,
      metalness: 0.1,
      wireframe: false
    });
    const groundMesh = new THREE.Mesh(groundGeo, groundMat);
    groundMesh.rotation.x = -Math.PI / 2;
    groundMesh.receiveShadow = true;
    this.scene.add(groundMesh);

    // Ground Tactical Grid
    const gridHelper = new THREE.GridHelper(240, 48, 0x294a5a, 0x1f2428);
    gridHelper.position.y = 0.02;
    this.scene.add(gridHelper);

    // Primary Landing Pad Alpha
    const padGeo = new THREE.CylinderGeometry(4.5, 4.5, 0.15, 32);
    const padMat = new THREE.MeshStandardMaterial({ color: 0x252a2c, roughness: 0.4 });
    const padMesh = new THREE.Mesh(padGeo, padMat);
    padMesh.position.set(0, 0.08, 0);
    this.scene.add(padMesh);

    // Glowing Pad Ring
    const ringGeo = new THREE.RingGeometry(4.0, 4.3, 32);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0xc18d38, side: THREE.DoubleSide });
    const ringMesh = new THREE.Mesh(ringGeo, ringMat);
    ringMesh.rotation.x = -Math.PI / 2;
    ringMesh.position.set(0, 0.16, 0);
    this.scene.add(ringMesh);

    // Obstacles Group (Buildings, Trees, Power lines, Vehicles)
    this.obstaclesGroup = new THREE.Group();
    const objects = this.spatial.detectedObjects();

    for (const obj of objects) {
      if (obj.class === 'BUILDING') {
        const bldGeo = new THREE.BoxGeometry(obj.dimensions.x, obj.dimensions.z, obj.dimensions.y);
        const bldMat = new THREE.MeshStandardMaterial({ color: 0x252a2c, roughness: 0.7, metalness: 0.2 });
        const bldMesh = new THREE.Mesh(bldGeo, bldMat);
        bldMesh.position.set(obj.position.x, obj.position.z, obj.position.y);
        bldMesh.castShadow = true;
        bldMesh.receiveShadow = true;
        bldMesh.userData = { isObject: true, detectedObj: obj };
        this.obstaclesGroup.add(bldMesh);

        // Building wireframe edge outline for tactical look
        const edges = new THREE.EdgesGeometry(bldGeo);
        const line = new THREE.LineSegments(edges, new THREE.LineBasicMaterial({ color: 0x47728a, transparent: true, opacity: 0.6 }));
        line.position.copy(bldMesh.position);
        this.obstaclesGroup.add(line);
      } else if (obj.class === 'TREE') {
        // Trunk
        const trunkGeo = new THREE.CylinderGeometry(0.3, 0.4, 3, 8);
        const trunkMat = new THREE.MeshStandardMaterial({ color: 0x3d2817 });
        const trunkMesh = new THREE.Mesh(trunkGeo, trunkMat);
        trunkMesh.position.set(obj.position.x, 1.5, obj.position.y);
        this.obstaclesGroup.add(trunkMesh);

        // Foliage Cone
        const foliageGeo = new THREE.ConeGeometry(obj.dimensions.x / 2, obj.dimensions.z - 2, 8);
        const foliageMat = new THREE.MeshStandardMaterial({ color: 0x4f6048, roughness: 0.8 });
        const foliageMesh = new THREE.Mesh(foliageGeo, foliageMat);
        foliageMesh.position.set(obj.position.x, obj.position.z - (obj.dimensions.z - 2) / 2, obj.position.y);
        foliageMesh.castShadow = true;
        foliageMesh.userData = { isObject: true, detectedObj: obj };
        this.obstaclesGroup.add(foliageMesh);
      } else if (obj.class === 'POLE') {
        const poleGeo = new THREE.CylinderGeometry(0.2, 0.25, obj.dimensions.z, 8);
        const poleMat = new THREE.MeshStandardMaterial({ color: 0x6d7474 });
        const poleMesh = new THREE.Mesh(poleGeo, poleMat);
        poleMesh.position.set(obj.position.x, obj.dimensions.z / 2, obj.position.y);
        this.obstaclesGroup.add(poleMesh);
      } else if (obj.class === 'WIRE') {
        // Overhead Wire line
        const wireMat = new THREE.LineBasicMaterial({ color: 0xa5463e, linewidth: 2 });
        const wireGeo = new THREE.BufferGeometry().setFromPoints([
          new THREE.Vector3(obj.position.x - 16, obj.position.z, obj.position.y),
          new THREE.Vector3(obj.position.x + 16, obj.position.z, obj.position.y)
        ]);
        const wireLine = new THREE.Line(wireGeo, wireMat);
        this.obstaclesGroup.add(wireLine);
      } else if (obj.class === 'VEHICLE') {
        const vehGeo = new THREE.BoxGeometry(obj.dimensions.x, obj.dimensions.z, obj.dimensions.y);
        const vehMat = new THREE.MeshStandardMaterial({ color: 0xc18d38, roughness: 0.3 });
        const vehMesh = new THREE.Mesh(vehGeo, vehMat);
        vehMesh.position.set(obj.position.x, obj.position.z / 2, obj.position.y);
        vehMesh.castShadow = true;
        vehMesh.userData = { isObject: true, detectedObj: obj };
        this.obstaclesGroup.add(vehMesh);
      }
    }
    this.scene.add(this.obstaclesGroup);

    // Agricultural Field Zones
    this.fieldMeshGroup = new THREE.Group();
    const fieldGeo = new THREE.PlaneGeometry(70, 70, 16, 16);
    const fieldMat = new THREE.MeshStandardMaterial({
      color: 0x4f6048,
      roughness: 0.85,
      metalness: 0.05
    });
    const fieldMesh = new THREE.Mesh(fieldGeo, fieldMat);
    fieldMesh.rotation.x = -Math.PI / 2;
    fieldMesh.position.set(-40, 0.05, 55);
    fieldMesh.receiveShadow = true;
    this.fieldMeshGroup.add(fieldMesh);

    // Swath Lines Overlay
    const swathLinesGeo = new THREE.GridHelper(70, 14, 0x65784f, 0x3b4736);
    swathLinesGeo.position.set(-40, 0.07, 55);
    this.fieldMeshGroup.add(swathLinesGeo);

    this.scene.add(this.fieldMeshGroup);
  }

  private buildSpitfireAirframe() {
    this.droneGroup = new THREE.Group();

    // Central Airframe Pod (Carbon aerodynamic monocoque)
    const bodyGeo = new THREE.BoxGeometry(1.2, 0.45, 1.8);
    const carbonMat = new THREE.MeshStandardMaterial({
      color: 0x181e21,
      metalness: 0.8,
      roughness: 0.3
    });
    const bodyMesh = new THREE.Mesh(bodyGeo, carbonMat);
    bodyMesh.castShadow = true;
    this.droneGroup.add(bodyMesh);

    // Nose Sensor Turret (Gimbal sphere)
    const noseGeo = new THREE.SphereGeometry(0.22, 16, 16);
    const noseMat = new THREE.MeshStandardMaterial({ color: 0x294a5a, metalness: 0.9, roughness: 0.1 });
    const noseMesh = new THREE.Mesh(noseGeo, noseMat);
    noseMesh.position.set(0, -0.15, 0.95);
    this.droneGroup.add(noseMesh);

    // 6 Carbon Arms (Coaxial Hexacopter)
    this.propMeshes = [];
    const armAngles = [Math.PI / 6, Math.PI / 2, (5 * Math.PI) / 6, (7 * Math.PI) / 6, (3 * Math.PI) / 2, (11 * Math.PI) / 6];

    for (let i = 0; i < 6; i++) {
      const angle = armAngles[i];
      const armLength = 1.4;
      const armX = Math.cos(angle) * armLength;
      const armZ = Math.sin(angle) * armLength;

      const armGeo = new THREE.CylinderGeometry(0.04, 0.04, armLength, 8);
      const armMesh = new THREE.Mesh(armGeo, carbonMat);
      armMesh.position.set(armX / 2, 0.1, armZ / 2);
      armMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(armX, 0, armZ).normalize());
      this.droneGroup.add(armMesh);

      // Motor Pods
      const motorGeo = new THREE.CylinderGeometry(0.12, 0.12, 0.18, 12);
      const motorMat = new THREE.MeshStandardMaterial({ color: 0xb5b8b3, metalness: 0.9 });
      const motorMesh = new THREE.Mesh(motorGeo, motorMat);
      motorMesh.position.set(armX, 0.15, armZ);
      this.droneGroup.add(motorMesh);

      // Carbon 30-inch Propeller Blades
      const propGeo = new THREE.BoxGeometry(0.76, 0.015, 0.07);
      const propMat = new THREE.MeshStandardMaterial({ color: 0x101416, roughness: 0.2 });
      const propMesh = new THREE.Mesh(propGeo, propMat);
      propMesh.position.set(armX, 0.25, armZ);
      this.droneGroup.add(propMesh);
      this.propMeshes.push(propMesh);

      // Navigation LED lights
      const ledColor = i === 0 || i === 5 ? 0x00ff00 : (i === 2 || i === 3 ? 0xff0000 : 0xffffff);
      const ledLight = new THREE.PointLight(ledColor, 0.8, 4);
      ledLight.position.set(armX, -0.05, armZ);
      this.droneGroup.add(ledLight);
    }

    // Payload Bay Underbelly Container Group
    this.payloadBayGroup = new THREE.Group();
    this.payloadBayGroup.position.set(0, -0.35, 0);
    this.droneGroup.add(this.payloadBayGroup);

    // Initial payload bay build
    this.rebuildPayloadBay3D(this.activeModule(), this.loadedPayloads());

    // Position drone at altitude
    this.droneGroup.position.set(0, 18.5, 0);
    this.scene.add(this.droneGroup);
  }

  private rebuildPayloadBay3D(module: PayloadModule, items: PayloadItem[]) {
    // Clear previous bay children
    while (this.payloadBayGroup.children.length > 0) {
      const child = this.payloadBayGroup.children[0];
      this.payloadBayGroup.remove(child);
    }

    if (module.type === 'CARGO_BAY') {
      // Semi-transparent cargo bay casing
      const bayFrameGeo = new THREE.BoxGeometry(0.9, 0.5, 1.2);
      const bayFrameMat = new THREE.MeshStandardMaterial({
        color: 0x252a2c,
        metalness: 0.5,
        roughness: 0.4,
        transparent: true,
        opacity: 0.85
      });
      const bayMesh = new THREE.Mesh(bayFrameGeo, bayFrameMat);
      this.payloadBayGroup.add(bayMesh);

      // Render individual parcel boxes
      for (const item of items) {
        const w = item.dimensions.width / 1000;
        const l = item.dimensions.length / 1000;
        const h = item.dimensions.height / 1000;

        const boxGeo = new THREE.BoxGeometry(w, h, l);
        const boxColor = item.type === 'MedicalPackage' ? 0xa5463e : (item.type === 'IndustrialPackage' ? 0x47728a : 0xc18d38);
        const boxMat = new THREE.MeshStandardMaterial({
          color: boxColor,
          roughness: 0.5,
          metalness: 0.2
        });
        const boxMesh = new THREE.Mesh(boxGeo, boxMat);

        // Position inside bay relative to center
        const posX = (item.bayPosition.x - 220) / 1000;
        const posY = (item.bayPosition.z - 170) / 1000;
        const posZ = (item.bayPosition.y) / 1000;

        boxMesh.position.set(posX, posY, posZ);
        boxMesh.castShadow = true;
        boxMesh.userData = { isPayload: true, payloadItem: item };
        this.payloadBayGroup.add(boxMesh);
      }
    } else if (module.type === 'SPRAY_TANK') {
      // 12L Cylindrical Liquid Tank
      const tankGeo = new THREE.CylinderGeometry(0.35, 0.35, 1.0, 16);
      tankGeo.rotateX(Math.PI / 2);
      const tankMat = new THREE.MeshStandardMaterial({
        color: 0x294a5a,
        roughness: 0.2,
        metalness: 0.7,
        transparent: true,
        opacity: 0.9
      });
      const tankMesh = new THREE.Mesh(tankGeo, tankMat);
      this.payloadBayGroup.add(tankMesh);

      // Spray Boom with 4 atomising nozzles
      const boomGeo = new THREE.CylinderGeometry(0.02, 0.02, 2.4, 8);
      boomGeo.rotateZ(Math.PI / 2);
      const boomMat = new THREE.MeshStandardMaterial({ color: 0xb5b8b3 });
      const boomMesh = new THREE.Mesh(boomGeo, boomMat);
      boomMesh.position.set(0, -0.3, 0);
      this.payloadBayGroup.add(boomMesh);

      // Simulated mist spray particles
      this.buildSprayParticles();
    } else if (module.type === 'GRANULAR_HOPPER') {
      // Conical Fertilizer Hopper
      const hopperGeo = new THREE.ConeGeometry(0.42, 0.75, 16);
      hopperGeo.rotateX(Math.PI);
      const hopperMat = new THREE.MeshStandardMaterial({ color: 0x65784f, roughness: 0.4 });
      const hopperMesh = new THREE.Mesh(hopperGeo, hopperMat);
      this.payloadBayGroup.add(hopperMesh);

      // Centrifugal spinner plate
      const plateGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.03, 16);
      const plateMat = new THREE.MeshStandardMaterial({ color: 0xc18d38, metalness: 0.8 });
      const plateMesh = new THREE.Mesh(plateGeo, plateMat);
      plateMesh.position.set(0, -0.42, 0);
      this.payloadBayGroup.add(plateMesh);
    }
  }

  private buildSprayParticles() {
    const particleCount = 200;
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      positions[i] = (Math.random() - 0.5) * 2.2;
      positions[i + 1] = -0.3 - Math.random() * 3.5;
      positions[i + 2] = (Math.random() - 0.5) * 0.8;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const material = new THREE.PointsMaterial({
      color: 0x47728a,
      size: 0.08,
      transparent: true,
      opacity: 0.6
    });

    this.sprayParticles = new THREE.Points(geometry, material);
    this.payloadBayGroup.add(this.sprayParticles);
  }

  private buildTrajectoryMesh() {
    const waypoints = this.spatial.activeTrajectory().waypoints;
    const points: THREE.Vector3[] = waypoints.map(wp => new THREE.Vector3(wp.position.x, wp.position.z, wp.position.y));

    const curve = new THREE.CatmullRomCurve3(points);
    const curvePoints = curve.getPoints(100);
    const geometry = new THREE.BufferGeometry().setFromPoints(curvePoints);
    const material = new THREE.LineBasicMaterial({ color: 0x47728a, linewidth: 3 });

    this.trajectoryLineMesh = new THREE.Line(geometry, material);
    this.scene.add(this.trajectoryLineMesh);

    // Waypoint markers
    for (const wp of waypoints) {
      const wpGeo = new THREE.SphereGeometry(0.4, 8, 8);
      const wpColor = wp.phase === 'DELIVERY' ? 0xa5463e : (wp.phase === 'TAKEOFF' || wp.phase === 'RETURN' ? 0xc18d38 : 0x294a5a);
      const wpMat = new THREE.MeshBasicMaterial({ color: wpColor, wireframe: true });
      const wpMesh = new THREE.Mesh(wpGeo, wpMat);
      wpMesh.position.set(wp.position.x, wp.position.z, wp.position.y);
      this.scene.add(wpMesh);
    }
  }

  private buildLiDARPointCloud() {
    const pointCount = 3200;
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(pointCount * 3);
    const colors = new Float32Array(pointCount * 3);

    for (let i = 0; i < pointCount * 3; i += 3) {
      const x = (Math.random() - 0.5) * 80;
      const z = (Math.random() - 0.5) * 80;
      const y = Math.max(0, Math.sin(x * 0.1) * Math.cos(z * 0.1) * 6 + Math.random() * 2);

      positions[i] = x;
      positions[i + 1] = y;
      positions[i + 2] = z;

      // Height-based coloring (cyan to amber)
      colors[i] = y / 12;
      colors[i + 1] = 0.8 - (y / 20);
      colors[i + 2] = 0.9;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({
      size: 0.18,
      vertexColors: true,
      transparent: true,
      opacity: 0.75
    });

    this.pointCloudParticles = new THREE.Points(geometry, material);
    this.pointCloudParticles.visible = false;
    this.scene.add(this.pointCloudParticles);
  }

  private animate = () => {
    this.animationFrameId = requestAnimationFrame(this.animate);

    // Spin Propellers
    for (let i = 0; i < this.propMeshes.length; i++) {
      this.propMeshes[i].rotation.y += (i % 2 === 0 ? 0.45 : -0.45);
    }

    // Drone flight path animation along trajectory
    const time = Date.now() * 0.0008;
    const droneX = Math.sin(time * 0.5) * 22;
    const droneZ = Math.cos(time * 0.5) * 16;
    const droneY = 18.5 + Math.sin(time * 1.2) * 1.5;

    if (this.droneGroup) {
      this.droneGroup.position.set(droneX, droneY, droneZ);
      // Gentle bank angle
      this.droneGroup.rotation.z = -Math.cos(time * 0.5) * 0.12;
      this.droneGroup.rotation.y = time * 0.5 + Math.PI / 2;

      this.dronePos.set({ x: droneX, y: droneZ, z: droneY });
    }

    // Spray animation if active
    if (this.sprayParticles && this.agri.sprayState().dispensingActive) {
      const posAttr = this.sprayParticles.geometry.attributes['position'];
      const arr = posAttr.array as Float32Array;
      for (let i = 1; i < arr.length; i += 3) {
        arr[i] -= 0.15;
        if (arr[i] < -4.0) arr[i] = -0.3;
      }
      posAttr.needsUpdate = true;
    }

    // Camera follow mode
    if (this.cameraMode() === 'DRONE_FOLLOW') {
      this.targetLookAt.copy(this.droneGroup.position);
      this.updateCameraPosition();
    } else if (this.cameraMode() === 'PAYLOAD_BAY') {
      this.targetLookAt.copy(this.droneGroup.position);
      this.updateCameraPosition();
    }

    this.renderer.render(this.scene, this.camera);
  };

  private updateCameraPosition() {
    if (!this.camera) return;

    if (this.cameraMode() === 'TACTICAL_ORBIT' || this.cameraMode() === 'DRONE_FOLLOW' || this.cameraMode() === 'PAYLOAD_BAY') {
      const x = this.targetLookAt.x + this.cameraRadius * Math.sin(this.cameraPhi) * Math.cos(this.cameraTheta);
      const y = this.targetLookAt.y + this.cameraRadius * Math.cos(this.cameraPhi);
      const z = this.targetLookAt.z + this.cameraRadius * Math.sin(this.cameraPhi) * Math.sin(this.cameraTheta);

      this.camera.position.set(x, Math.max(1, y), z);
      this.camera.lookAt(this.targetLookAt);
    } else if (this.cameraMode() === 'FPV_SENSOR') {
      this.camera.position.set(this.droneGroup.position.x, this.droneGroup.position.y - 0.1, this.droneGroup.position.z + 0.9);
      this.camera.rotation.set(0, this.droneGroup.rotation.y, 0);
    } else if (this.cameraMode() === 'NADIR_DROP') {
      this.camera.position.set(this.droneGroup.position.x, this.droneGroup.position.y + 2.0, this.droneGroup.position.z);
      this.camera.lookAt(this.droneGroup.position.x, 0, this.droneGroup.position.z);
    }
  }

  // Mouse Orbit Navigation Handlers
  private onMouseDown(event: MouseEvent) {
    this.isDragging = true;
    this.prevMouseX = event.clientX;
    this.prevMouseY = event.clientY;

    // Raycast check for click selection
    const container = this.canvasContainer()?.nativeElement;
    if (!container) return;
    const rect = container.getBoundingClientRect();
    this.mouse.x = ((event.clientX - rect.left) / container.clientWidth) * 2 - 1;
    this.mouse.y = -((event.clientY - rect.top) / container.clientHeight) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects(this.scene.children, true);

    if (intersects.length > 0) {
      for (const hit of intersects) {
        if (hit.object.userData['isObject']) {
          this.objectSelected.emit(hit.object.userData['detectedObj']);
          break;
        } else if (hit.object.userData['isPayload']) {
          this.payloadSelected.emit(hit.object.userData['payloadItem']);
          break;
        }
      }
    }
  }

  private onMouseMove(event: MouseEvent) {
    if (!this.isDragging) return;

    const deltaX = event.clientX - this.prevMouseX;
    const deltaY = event.clientY - this.prevMouseY;

    this.cameraTheta -= deltaX * 0.008;
    this.cameraPhi = Math.max(0.08, Math.min(Math.PI / 2 - 0.05, this.cameraPhi - deltaY * 0.008));

    this.prevMouseX = event.clientX;
    this.prevMouseY = event.clientY;

    if (this.cameraMode() === 'TACTICAL_ORBIT' || this.cameraMode() === 'DRONE_FOLLOW') {
      this.updateCameraPosition();
    }
  }

  private onMouseUp() {
    this.isDragging = false;
  }

  private onMouseWheel(event: WheelEvent) {
    this.cameraRadius = Math.max(3, Math.min(180, this.cameraRadius + event.deltaY * 0.04));
    this.updateCameraPosition();
  }

  private onWindowResize() {
    const container = this.canvasContainer()?.nativeElement;
    if (!container || !this.renderer || !this.camera) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }
}
