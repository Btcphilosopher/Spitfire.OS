import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MissionLogisticsService } from '../../core/services/mission-logistics.service';
import { PayloadItem } from '../../core/models/payload.model';

@Component({
  selector: 'app-payload-designer',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-full p-4 overflow-y-auto space-y-4">
      <!-- Section Header -->
      <div class="flex items-center justify-between flex-wrap gap-2 pb-2 border-b border-[#252A2C]">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-[#C18D38] px-2 py-0.5 rounded bg-[#C18D38]/10 border border-[#C18D38]/30">SIGNATURE MODULE</span>
            <h2 class="text-lg font-bold text-white font-mono">PAYLOAD DESIGNER & AIRFRAME INTEGRATION</h2>
          </div>
          <p class="text-xs text-[#B5B8B3] mt-0.5">
            Physics-driven digital twin: mass, dimensions, centre of gravity, aerodynamics & permitted simulated envelope.
          </p>
        </div>

        <!-- Module Swap Switcher -->
        <div class="flex items-center gap-1.5 bg-[#14181B] border border-[#252A2C] p-1 rounded-lg">
          <span class="text-[10px] text-[#6D7474] font-mono px-1">INSTALLED MODULE:</span>
          @for (mod of availableModules(); track mod.moduleId) {
            <button
              type="button"
              (click)="selectModule(mod.moduleId)"
              [class.bg-[#294A5A]]="activeModule().moduleId === mod.moduleId"
              [class.text-white]="activeModule().moduleId === mod.moduleId"
              class="px-2.5 py-1 text-[11px] font-mono rounded hover:bg-[#252A2C] text-[#B5B8B3] transition-all">
              {{ mod.type.replace('_', ' ') }}
            </button>
          }
        </div>
      </div>

      <!-- CG Envelope Warning Banner if Out of Envelope -->
      @if (!cgResult().isWithinEnvelope) {
        <div class="p-3 bg-[#A5463E]/20 border-2 border-[#A5463E] rounded-xl flex items-start gap-3 animate-pulse">
          <span class="material-icons text-[#A5463E] text-2xl">warning</span>
          <div class="font-mono">
            <div class="text-sm font-bold text-[#A5463E]">PAYLOAD CONFIGURATION UNACCEPTABLE — CG OUTSIDE SIMULATED ENVELOPE</div>
            <div class="text-xs text-[#ECE9DF] mt-1 space-y-0.5">
              @for (reason of cgResult().warningReasons; track reason) {
                <div>• {{ reason }}</div>
              }
            </div>
            <div class="text-[11px] text-[#B5B8B3] mt-2">
              The autonomous flight controller will abort launch. Adjust payload bay positioning or engage automatic Load Optimizer.
            </div>
          </div>
        </div>
      }

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- Column 1: Payload Selection & 3D Bay Visualizer (7 Cols) -->
        <div class="lg:col-span-7 space-y-4">
          <!-- 2D/3D Payload Bay Cross-Section Schematics -->
          <div class="bg-[#14181B] border border-[#252A2C] p-4 rounded-xl space-y-3">
            <div class="flex items-center justify-between text-xs font-mono">
              <span class="text-[#ECE9DF] font-bold">SPITFIRE MK.IV PAYLOAD BAY SCHEMATIC</span>
              <span class="text-[#6D7474]">BAY SIZE: 440 × 620 × 340 MM</span>
            </div>

            <!-- Visual Bay Box with Packages & CG Crosshairs -->
            <div class="relative w-full h-56 bg-[#101416] border border-[#294A5A]/40 rounded-lg overflow-hidden tactical-grid flex items-center justify-center p-4">
              <!-- Airframe Center Axis Lines -->
              <div class="absolute inset-x-0 top-1/2 h-px bg-[#294A5A]/60 dashed"></div>
              <div class="absolute inset-y-0 left-1/2 w-px bg-[#294A5A]/60 dashed"></div>

              <!-- Permitted CG Envelope Safe Zone (Green Polygon Box) -->
              <div class="absolute border border-dashed border-emerald-500/50 bg-emerald-500/10 rounded pointer-events-none"
                   style="width: 48%; height: 55%; left: 26%; top: 22.5%;">
                <span class="absolute top-1 left-1.5 text-[8px] font-mono text-emerald-400">PERMITTED CG ENVELOPE</span>
              </div>

              <!-- Loaded Payload Boxes in Bay -->
              @for (item of loadedPayloads(); track item.id) {
                <button
                  type="button"
                  (click)="selectedPayloadItem.set(item)"
                  [class.ring-2]="selectedPayloadItem()?.id === item.id"
                  [class.ring-[#C18D38]]="selectedPayloadItem()?.id === item.id"
                  class="absolute rounded p-2 text-[10px] font-mono shadow-md cursor-pointer transition-transform hover:scale-105 flex flex-col justify-between text-left"
                  [style.width.px]="item.dimensions.width / 4.2"
                  [style.height.px]="item.dimensions.length / 4.2"
                  [style.left.px]="(item.bayPosition.x / 440) * 280 + 20"
                  [style.top.px]="(item.bayPosition.y + 100) / 200 * 120 + 20"
                  [style.backgroundColor]="item.type === 'MedicalPackage' ? 'rgba(165,70,62,0.85)' : (item.type === 'IndustrialPackage' ? 'rgba(71,114,138,0.85)' : 'rgba(193,141,56,0.85)')">
                  <div class="font-bold text-white truncate">{{ item.name }}</div>
                  <div class="flex justify-between text-[9px] text-white/90">
                    <span>{{ item.massKg }} KG</span>
                    <span>{{ item.type }}</span>
                  </div>
                </button>
              }

              <!-- Total Combined CG Marker Crosshair -->
              <div
                class="absolute w-5 h-5 -ml-2.5 -mt-2.5 rounded-full border-2 border-white flex items-center justify-center pointer-events-none z-10 transition-all duration-300"
                [class.bg-emerald-500]="cgResult().isWithinEnvelope"
                [class.bg-[#A5463E]]="!cgResult().isWithinEnvelope"
                [style.left.%]="((cgResult().totalCombinedCG.x - 200) / 100) * 100"
                [style.top.%]="((cgResult().totalCombinedCG.y + 50) / 100) * 100">
                <span class="w-1.5 h-1.5 rounded-full bg-white"></span>
              </div>
            </div>

            <!-- Bay Actions -->
            <div class="flex items-center justify-between flex-wrap gap-2 pt-1 font-mono text-xs">
              <div class="flex items-center gap-2">
                <button
                  type="button"
                  (click)="optimizeLoad()"
                  class="px-3 py-1.5 bg-[#294A5A] hover:bg-[#345e72] text-white rounded-lg flex items-center gap-1.5 font-bold transition-all shadow">
                  <span class="material-icons text-sm">auto_fix_high</span>
                  <span>OPTIMISE LOAD DISTRIBUTION</span>
                </button>
              </div>

              <div class="text-[11px] text-[#B5B8B3]">
                Total Items in Bay: <span class="text-white font-bold">{{ loadedPayloads().length }}</span>
              </div>
            </div>
          </div>

          <!-- Payload Presets Quick-Add Palette -->
          <div class="bg-[#14181B] border border-[#252A2C] p-4 rounded-xl space-y-3 font-mono">
            <div class="flex items-center justify-between text-xs">
              <span class="text-[#ECE9DF] font-bold">ADD PRESET PAYLOAD TO AIRFRAME</span>
              <span class="text-[#6D7474]">10 CLASSIFICATIONS</span>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              @for (preset of presetLibrary(); track preset.id) {
                <div class="p-2.5 bg-[#101416] border border-[#252A2C] hover:border-[#47728A] rounded-lg flex items-center justify-between transition-all">
                  <div class="overflow-hidden pr-2">
                    <div class="font-bold text-[#ECE9DF] truncate">{{ preset.name }}</div>
                    <div class="text-[10px] text-[#6D7474]">{{ preset.type }} • {{ preset.massKg }} kg</div>
                  </div>
                  <button
                    type="button"
                    (click)="addPreset(preset)"
                    class="px-2.5 py-1 bg-[#252A2C] hover:bg-[#294A5A] text-white rounded text-[11px] font-bold transition-colors">
                    + LOAD
                  </button>
                </div>
              }
            </div>
          </div>
        </div>

        <!-- Column 2: Selected Payload Inspector & Physics Engine (5 Cols) -->
        <div class="lg:col-span-5 space-y-4 font-mono">
          <!-- Selected Payload Parameters -->
          @if (selectedPayloadItem(); as sel) {
            <div class="bg-[#14181B] border border-[#252A2C] p-4 rounded-xl space-y-3">
              <div class="flex items-center justify-between pb-2 border-b border-[#252A2C]">
                <div>
                  <div class="text-[10px] text-[#C18D38]">INSPECTING ITEM</div>
                  <div class="text-sm font-bold text-white">{{ sel.name }}</div>
                </div>
                <button
                  type="button"
                  (click)="removeSelectedPayload()"
                  class="px-2 py-1 bg-[#A5463E]/20 hover:bg-[#A5463E] text-[#A5463E] hover:text-white rounded text-[10px] transition-colors">
                  UNLOAD
                </button>
              </div>

              <!-- Sliders: Mass & Dimensions -->
              <div class="space-y-2 text-xs">
                <div>
                  <div class="flex justify-between text-[11px]">
                    <span class="text-[#B5B8B3]">MASS</span>
                    <span class="text-white font-bold">{{ sel.massKg }} KG</span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="14.0"
                    step="0.1"
                    [value]="sel.massKg"
                    (input)="updateSelectedMass($event)"
                    class="w-full accent-[#C18D38] cursor-pointer" />
                </div>

                <div class="grid grid-cols-3 gap-2">
                  <div>
                    <span class="text-[9px] text-[#6D7474] block">WIDTH (X)</span>
                    <div class="text-xs font-bold text-[#ECE9DF]">{{ sel.dimensions.width }} MM</div>
                  </div>
                  <div>
                    <span class="text-[9px] text-[#6D7474] block">LENGTH (Y)</span>
                    <div class="text-xs font-bold text-[#ECE9DF]">{{ sel.dimensions.length }} MM</div>
                  </div>
                  <div>
                    <span class="text-[9px] text-[#6D7474] block">HEIGHT (Z)</span>
                    <div class="text-xs font-bold text-[#ECE9DF]">{{ sel.dimensions.height }} MM</div>
                  </div>
                </div>

                <!-- Bay Position Adjusters -->
                <div class="pt-2 border-t border-[#252A2C]/60">
                  <div class="text-[10px] text-[#6D7474] uppercase mb-1">Bay Coordinates</div>
                  <div class="grid grid-cols-2 gap-2">
                    <div>
                      <div class="text-[9px] text-[#B5B8B3]">BAY X: {{ sel.bayPosition.x }} MM</div>
                      <input
                        type="range"
                        min="50"
                        max="390"
                        [value]="sel.bayPosition.x"
                        (input)="updateBayCoordX($event)"
                        class="w-full accent-[#294A5A]" />
                    </div>
                    <div>
                      <div class="text-[9px] text-[#B5B8B3]">BAY Y: {{ sel.bayPosition.y }} MM</div>
                      <input
                        type="range"
                        min="-80"
                        max="80"
                        [value]="sel.bayPosition.y"
                        (input)="updateBayCoordY($event)"
                        class="w-full accent-[#294A5A]" />
                    </div>
                  </div>
                </div>

                <!-- Constraints Badges -->
                <div class="pt-2 border-t border-[#252A2C]/60 flex flex-wrap gap-1.5 text-[10px]">
                  <span class="px-2 py-0.5 rounded bg-[#252A2C] text-[#B5B8B3]">Method: {{ sel.constraints.deliveryMethod }}</span>
                  <span class="px-2 py-0.5 rounded" [class.bg-rose-900]="sel.constraints.fragile" [class.text-rose-200]="sel.constraints.fragile">
                    Fragile: {{ sel.constraints.fragile ? 'YES' : 'NO' }}
                  </span>
                  <span class="px-2 py-0.5 rounded bg-[#252A2C] text-[#B5B8B3]">Max G: {{ sel.constraints.maxGForce }}G</span>
                </div>
              </div>
            </div>
          }

          <!-- Live Combined Flight Physics & Energy Panel -->
          <div class="bg-[#14181B] border border-[#252A2C] p-4 rounded-xl space-y-3">
            <div class="text-xs text-[#ECE9DF] font-bold border-b border-[#252A2C] pb-2 flex items-center justify-between">
              <span>LIVE FLIGHT DYNAMICS & CG ENGINE</span>
              <span class="text-[10px] text-[#C18D38]">SIMULATED</span>
            </div>

            <div class="grid grid-cols-2 gap-3 text-xs">
              <div class="p-2.5 bg-[#101416] rounded-lg border border-[#252A2C]">
                <div class="text-[9px] text-[#6D7474]">TOTAL AIRFRAME MASS</div>
                <div class="text-base font-bold text-white mt-0.5">{{ cgResult().totalMassKg }} <span class="text-[10px] text-[#B5B8B3]">KG</span></div>
                <div class="text-[9px] text-[#6D7474] mt-1">MTOM Limit: 32.5 KG</div>
              </div>

              <div class="p-2.5 bg-[#101416] rounded-lg border border-[#252A2C]">
                <div class="text-[9px] text-[#6D7474]">COMBINED CG SHIFT</div>
                <div class="text-base font-bold text-cyan-400 mt-0.5">{{ cgResult().cgShiftMm }} <span class="text-[10px] text-[#B5B8B3]">MM</span></div>
                <div class="text-[9px] text-[#6D7474] mt-1">Tolerance: &lt; 35 MM</div>
              </div>

              <div class="p-2.5 bg-[#101416] rounded-lg border border-[#252A2C]">
                <div class="text-[9px] text-[#6D7474]">CRUISE POWER DRAW</div>
                <div class="text-base font-bold text-white mt-0.5">{{ energyResult().cruisePowerDrawW }} <span class="text-[10px] text-[#B5B8B3]">WATTS</span></div>
                <div class="text-[9px] text-[#A5463E] mt-1">+{{ energyResult().payloadEnergyPenaltyPct }}% Payload Penalty</div>
              </div>

              <div class="p-2.5 bg-[#101416] rounded-lg border border-[#252A2C]">
                <div class="text-[9px] text-[#6D7474]">ESTIMATED MAX RANGE</div>
                <div class="text-base font-bold text-emerald-400 mt-0.5">{{ energyResult().estimatedMaxRangeKm }} <span class="text-[10px] text-[#B5B8B3]">KM</span></div>
                <div class="text-[9px] text-[#6D7474] mt-1">Safe Return: {{ energyResult().safeReturnRadiusKm }} KM</div>
              </div>
            </div>

            <!-- Envelope Margin Meter -->
            <div>
              <div class="flex justify-between text-[10px] text-[#B5B8B3] mb-1">
                <span>STABILITY MARGIN TO ENVELOPE LIMIT</span>
                <span class="font-bold text-white">{{ cgResult().envelopeMarginPercent }}%</span>
              </div>
              <div class="w-full h-2 bg-[#252A2C] rounded-full overflow-hidden">
                <div
                  class="h-full transition-all duration-300 rounded-full"
                  [class.bg-emerald-500]="cgResult().envelopeMarginPercent > 35"
                  [class.bg-amber-500]="cgResult().envelopeMarginPercent <= 35 && cgResult().envelopeMarginPercent > 10"
                  [class.bg-rose-500]="cgResult().envelopeMarginPercent <= 10"
                  [style.width.%]="cgResult().envelopeMarginPercent"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class PayloadDesigner {
  private readonly logistics = inject(MissionLogisticsService);

  readonly availableModules = computed(() => this.logistics.availableModules());
  readonly activeModule = computed(() => this.logistics.activeModule());
  readonly loadedPayloads = computed(() => this.logistics.loadedPayloads());
  readonly cgResult = computed(() => this.logistics.currentCGResult());
  readonly energyResult = computed(() => this.logistics.currentEnergyEstimate());
  readonly presetLibrary = computed(() => this.logistics.availablePayloadPresets());

  readonly selectedPayloadItem = signal<PayloadItem | null>(this.loadedPayloads()[0] || null);

  selectModule(moduleId: string) {
    this.logistics.installModule(moduleId);
  }

  addPreset(preset: PayloadItem) {
    const newItem: PayloadItem = {
      ...preset,
      id: `PL-${Date.now().toString().slice(-4)}`,
      bayPosition: { x: 220, y: 0, z: 120 }
    };
    this.logistics.addPayloadToBay(newItem);
    this.selectedPayloadItem.set(newItem);
  }

  removeSelectedPayload() {
    const sel = this.selectedPayloadItem();
    if (sel) {
      this.logistics.removePayloadFromBay(sel.id);
      this.selectedPayloadItem.set(this.loadedPayloads()[0] || null);
    }
  }

  updateSelectedMass(event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    const sel = this.selectedPayloadItem();
    if (sel) {
      this.selectedPayloadItem.set({ ...sel, massKg: val });
      this.logistics.loadedPayloads.update(items => items.map(i => i.id === sel.id ? { ...i, massKg: val } : i));
    }
  }

  updateBayCoordX(event: Event) {
    const val = parseInt((event.target as HTMLInputElement).value, 10);
    const sel = this.selectedPayloadItem();
    if (sel) {
      this.logistics.updatePayloadPosition(sel.id, val, sel.bayPosition.y, sel.bayPosition.z);
    }
  }

  updateBayCoordY(event: Event) {
    const val = parseInt((event.target as HTMLInputElement).value, 10);
    const sel = this.selectedPayloadItem();
    if (sel) {
      this.logistics.updatePayloadPosition(sel.id, sel.bayPosition.x, val, sel.bayPosition.z);
    }
  }

  optimizeLoad() {
    this.logistics.optimizeLoadDistribution();
  }
}
