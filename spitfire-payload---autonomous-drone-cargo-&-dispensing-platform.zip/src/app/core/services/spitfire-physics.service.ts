import { Injectable, signal } from '@angular/core';
import { AircraftSpec, CGCalculationResult, EnergyMissionEstimate } from '../models/aircraft.model';
import { PayloadItem, PayloadModule, Vector3D } from '../models/payload.model';

export const SPITFIRE_MK4_SPEC: AircraftSpec = {
  modelId: 'SPITFIRE-MK4-AV',
  name: 'Spitfire Mk.IV Heavy Lift Autonomous Airframe',
  airframeType: 'HEXACOPTER_COAXIAL',
  emptyDryMassKg: 14.2,
  maxTakeoffMassKg: 32.5,
  maxPayloadMassKg: 18.3,
  batteryCapacityWh: 710, // 6S 32Ah LiHV
  nominalVoltageV: 22.8,
  rotorDiameterM: 0.762, // 30-inch carbon props
  rotorCount: 6,
  bayDimensions: { width: 440, length: 620, height: 340 }, // mm
  emptyCG: { x: 250, y: 0, z: 140 }, // mm from nose datum
  permittedEnvelope: {
    minX: 215, // mm forward limit
    maxX: 285, // mm aft limit
    minY: -35, // mm left limit
    maxY: 35,  // mm right limit
    minZ: 100, // mm lower limit
    maxZ: 180  // mm upper limit
  },
  cruiseAirspeedMs: 18.0,
  maxAirspeedMs: 28.0,
  maxWindLimitMs: 14.0,
  maxClimbRateMs: 6.0,
  maxDescentRateMs: 4.5
};

@Injectable({
  providedIn: 'root'
})
export class SpitfirePhysics {
  readonly spec = signal<AircraftSpec>(SPITFIRE_MK4_SPEC);

  calculateCombinedCG(
    spec: AircraftSpec,
    module: PayloadModule,
    payloads: PayloadItem[]
  ): CGCalculationResult {
    const emptyMass = spec.emptyDryMassKg;
    const moduleMass = module.dryMassKg;
    const aircraftCG = spec.emptyCG;

    // Module sits in center of bay
    const moduleCG: Vector3D = {
      x: spec.emptyCG.x,
      y: 0,
      z: spec.emptyCG.z - 10
    };

    let totalPayloadMass = 0;
    let sumMX = 0;
    let sumMY = 0;
    let sumMZ = 0;

    for (const item of payloads) {
      const m = item.massKg;
      totalPayloadMass += m;
      // Absolute position in airframe datum = bay base datum + item bayPosition + item internal CG
      const posX = spec.emptyCG.x + (item.bayPosition.x - spec.bayDimensions.width / 2) + item.centreOfGravity.x;
      const posY = item.bayPosition.y + item.centreOfGravity.y;
      const posZ = spec.emptyCG.z + (item.bayPosition.z - spec.bayDimensions.height / 2) + item.centreOfGravity.z;

      sumMX += m * posX;
      sumMY += m * posY;
      sumMZ += m * posZ;
    }

    const totalMass = emptyMass + moduleMass + totalPayloadMass;
    const payloadCombinedCG: Vector3D = totalPayloadMass > 0
      ? { x: sumMX / totalPayloadMass, y: sumMY / totalPayloadMass, z: sumMZ / totalPayloadMass }
      : { x: spec.emptyCG.x, y: 0, z: spec.emptyCG.z };

    // Total Combined CG
    const totalCGX = (emptyMass * aircraftCG.x + moduleMass * moduleCG.x + sumMX) / totalMass;
    const totalCGY = (emptyMass * aircraftCG.y + moduleMass * moduleCG.y + sumMY) / totalMass;
    const totalCGZ = (emptyMass * aircraftCG.z + moduleMass * moduleCG.z + sumMZ) / totalMass;

    const totalCombinedCG: Vector3D = {
      x: Math.round(totalCGX * 10) / 10,
      y: Math.round(totalCGY * 10) / 10,
      z: Math.round(totalCGZ * 10) / 10
    };

    const dx = totalCombinedCG.x - aircraftCG.x;
    const dy = totalCombinedCG.y - aircraftCG.y;
    const dz = totalCombinedCG.z - aircraftCG.z;
    const cgShiftMm = Math.round(Math.sqrt(dx * dx + dy * dy + dz * dz) * 10) / 10;

    const env = spec.permittedEnvelope;
    const warningReasons: string[] = [];

    const withinX = totalCombinedCG.x >= env.minX && totalCombinedCG.x <= env.maxX;
    const withinY = totalCombinedCG.y >= env.minY && totalCombinedCG.y <= env.maxY;
    const withinZ = totalCombinedCG.z >= env.minZ && totalCombinedCG.z <= env.maxZ;

    if (!withinX) {
      warningReasons.push(totalCombinedCG.x < env.minX 
        ? `Forward CG limit breached (${totalCombinedCG.x}mm < ${env.minX}mm min)` 
        : `Aft CG limit breached (${totalCombinedCG.x}mm > ${env.maxX}mm max)`);
    }
    if (!withinY) {
      warningReasons.push(`Lateral balance offset exceeds tolerance (${Math.abs(totalCombinedCG.y)}mm > ${env.maxY}mm)`);
    }
    if (!withinZ) {
      warningReasons.push(`Vertical CG outside stability threshold (${totalCombinedCG.z}mm)`);
    }

    const isOverweight = totalMass > spec.maxTakeoffMassKg;
    if (isOverweight) {
      warningReasons.push(`Total MTOM exceeded (${totalMass.toFixed(1)}kg > ${spec.maxTakeoffMassKg}kg MTOM limit)`);
    }

    const isWithinEnvelope = withinX && withinY && withinZ && !isOverweight;
    const massMarginKg = Math.max(0, spec.maxTakeoffMassKg - totalMass);

    // Calculate margin percent to nearest envelope limit
    const marginX = Math.min(totalCombinedCG.x - env.minX, env.maxX - totalCombinedCG.x);
    const marginY = Math.min(totalCombinedCG.y - env.minY, env.maxY - totalCombinedCG.y);
    const marginZ = Math.min(totalCombinedCG.z - env.minZ, env.maxZ - totalCombinedCG.z);
    const minRawMargin = Math.min(marginX, marginY, marginZ);
    const envelopeMarginPercent = Math.max(0, Math.min(100, Math.round((minRawMargin / 20) * 100)));

    let statusLabel: 'ACCEPTABLE' | 'MARGINAL_WARNING' | 'UNACCEPTABLE_ENVELOPE_BREACH' | 'OVERWEIGHT' = 'ACCEPTABLE';
    if (isOverweight) {
      statusLabel = 'OVERWEIGHT';
    } else if (!isWithinEnvelope) {
      statusLabel = 'UNACCEPTABLE_ENVELOPE_BREACH';
    } else if (envelopeMarginPercent < 25) {
      statusLabel = 'MARGINAL_WARNING';
    }

    return {
      aircraftEmptyCG: spec.emptyCG,
      payloadCombinedCG,
      totalCombinedCG,
      cgShiftMm,
      totalMassKg: Math.round(totalMass * 100) / 100,
      payloadMassKg: Math.round((totalPayloadMass + moduleMass) * 100) / 100,
      massMarginKg: Math.round(massMarginKg * 10) / 10,
      isWithinEnvelope,
      envelopeMarginPercent,
      warningReasons,
      statusLabel
    };
  }

  calculateEnergyAndFlightDynamics(
    spec: AircraftSpec,
    totalMassKg: number,
    windSpeedMs = 4.0,
    temperatureC = 18.0
  ): EnergyMissionEstimate {
    // Air density standard adjusted for temp
    const airDensityRho = 1.225 * (288.15 / (273.15 + temperatureC));
    const g = 9.80665;
    const weightNewtons = totalMassKg * g;
    const rotorAreaTotal = spec.rotorCount * Math.PI * Math.pow(spec.rotorDiameterM / 2, 2);
    const figureOfMeritEta = 0.68; // Propulsive efficiency

    // Actuator disk induced hover power
    const inducedHoverPowerW = Math.sqrt(Math.pow(weightNewtons, 3) / (2 * airDensityRho * rotorAreaTotal)) / figureOfMeritEta;
    const avionicsPowerW = 45; // Avionics, LiDAR, Jetson compute, comms
    const hoverPowerDrawW = Math.round(inducedHoverPowerW + avionicsPowerW);

    // Cruise aerodynamic power
    const cruiseSpeed = Math.max(10, spec.cruiseAirspeedMs - (windSpeedMs * 0.4));
    const parasiteDragAreaCdA = 0.08 + (totalMassKg > 20 ? 0.03 : 0.015);
    const parasitePower = 0.5 * airDensityRho * Math.pow(cruiseSpeed, 3) * parasiteDragAreaCdA;
    const inducedCruisePower = (Math.pow(weightNewtons, 2) / (2 * airDensityRho * rotorAreaTotal * cruiseSpeed)) / figureOfMeritEta;
    const cruisePowerDrawW = Math.round(inducedCruisePower + parasitePower + avionicsPowerW);

    const usableBatteryWh = spec.batteryCapacityWh * 0.85; // 15% reserve limit
    const estimatedEnduranceMin = Math.round((usableBatteryWh / cruisePowerDrawW) * 60);
    const estimatedMaxRangeKm = Math.round(((cruiseSpeed * 3.6) * (estimatedEnduranceMin / 60)) * 10) / 10;
    const safeReturnRadiusKm = Math.round((estimatedMaxRangeKm * 0.42) * 10) / 10; // Safe return with headwind margin

    const emptyWeightNewtons = spec.emptyDryMassKg * g;
    const emptyPower = Math.sqrt(Math.pow(emptyWeightNewtons, 3) / (2 * airDensityRho * rotorAreaTotal)) / figureOfMeritEta + avionicsPowerW;
    const payloadEnergyPenaltyPct = Math.round(((cruisePowerDrawW - emptyPower) / emptyPower) * 100);

    return {
      hoverPowerDrawW,
      cruisePowerDrawW,
      payloadEnergyPenaltyPct,
      estimatedCruiseSpeedMs: Math.round(cruiseSpeed * 10) / 10,
      estimatedMaxRangeKm,
      estimatedEnduranceMin,
      reserveCapacityPct: 15,
      safeReturnRadiusKm
    };
  }
}
