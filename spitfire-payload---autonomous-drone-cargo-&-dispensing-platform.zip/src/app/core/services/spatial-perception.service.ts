import { Injectable, signal } from '@angular/core';
import { DeliveryZoneCandidate, DetectedObject, SpatialUncertaintyState, TrajectoryPlan } from '../models/spatial.model';

@Injectable({
  providedIn: 'root'
})
export class SpatialPerceptionService {
  // World objects
  readonly detectedObjects = signal<DetectedObject[]>([
    {
      id: 'BLD-001',
      class: 'BUILDING',
      confidence: 0.99,
      source: 'RGB_CAMERA_4K',
      modelVersion: 'SPITFIRE-YOLO-SEG-V4.2',
      position: { x: 35, y: -20, z: 6 },
      dimensions: { x: 18, y: 14, z: 12 },
      velocity: { x: 0, y: 0, z: 0 },
      predictedPositions: [{ tSec: 1, pos: { x: 35, y: -20, z: 6 } }, { tSec: 2, pos: { x: 35, y: -20, z: 6 } }, { tSec: 5, pos: { x: 35, y: -20, z: 6 } }],
      isDynamic: false,
      clearanceDistanceM: 28.4,
      threatLevel: 'NONE',
      boundingBox2D: { xMinPct: 15, yMinPct: 30, widthPct: 28, heightPct: 42 },
      timestamp: Date.now() - 120,
      lastSeenTime: Date.now() - 120
    },
    {
      id: 'BLD-002',
      class: 'ROOF',
      confidence: 0.97,
      source: 'LIDAR_SPATIAL_SCANNER',
      modelVersion: 'SPITFIRE-POINTNET-V3',
      position: { x: 35, y: -20, z: 12.2 },
      dimensions: { x: 16, y: 12, z: 0.4 },
      velocity: { x: 0, y: 0, z: 0 },
      predictedPositions: [{ tSec: 1, pos: { x: 35, y: -20, z: 12.2 } }, { tSec: 2, pos: { x: 35, y: -20, z: 12.2 } }],
      isDynamic: false,
      clearanceDistanceM: 29.1,
      threatLevel: 'NONE',
      boundingBox2D: { xMinPct: 16, yMinPct: 22, widthPct: 26, heightPct: 14 },
      timestamp: Date.now() - 90,
      lastSeenTime: Date.now() - 90
    },
    {
      id: 'TREE-014',
      class: 'TREE',
      confidence: 0.94,
      source: 'RGB_CAMERA_4K',
      modelVersion: 'SPITFIRE-YOLO-SEG-V4.2',
      position: { x: 12, y: 22, z: 3.7 },
      dimensions: { x: 5.2, y: 5.2, z: 7.4 },
      velocity: { x: 0, y: 0, z: 0 },
      predictedPositions: [{ tSec: 1, pos: { x: 12, y: 22, z: 3.7 } }],
      isDynamic: false,
      clearanceDistanceM: 14.8,
      threatLevel: 'CAUTION',
      boundingBox2D: { xMinPct: 62, yMinPct: 40, widthPct: 20, heightPct: 38 },
      timestamp: Date.now() - 150,
      lastSeenTime: Date.now() - 150
    },
    {
      id: 'POLE-008',
      class: 'POLE',
      confidence: 0.91,
      source: 'LIDAR_SPATIAL_SCANNER',
      modelVersion: 'SPITFIRE-POINTNET-V3',
      position: { x: -18, y: 15, z: 4.5 },
      dimensions: { x: 0.4, y: 0.4, z: 9.0 },
      velocity: { x: 0, y: 0, z: 0 },
      predictedPositions: [{ tSec: 1, pos: { x: -18, y: 15, z: 4.5 } }],
      isDynamic: false,
      clearanceDistanceM: 19.2,
      threatLevel: 'CAUTION',
      boundingBox2D: { xMinPct: 8, yMinPct: 35, widthPct: 4, heightPct: 45 },
      timestamp: Date.now() - 200,
      lastSeenTime: Date.now() - 200
    },
    {
      id: 'WIRE-003',
      class: 'WIRE',
      confidence: 0.68,
      source: 'LIDAR_SPATIAL_SCANNER',
      modelVersion: 'SPITFIRE-WIRE-DETECT-V2',
      position: { x: -18, y: 25, z: 8.2 },
      dimensions: { x: 32, y: 0.04, z: 0.04 },
      velocity: { x: 0, y: 0, z: 0 },
      predictedPositions: [{ tSec: 1, pos: { x: -18, y: 25, z: 8.2 } }],
      isDynamic: false,
      clearanceDistanceM: 11.5,
      threatLevel: 'CRITICAL_COLLISION_RISK',
      boundingBox2D: { xMinPct: 5, yMinPct: 28, widthPct: 85, heightPct: 4 },
      timestamp: Date.now() - 80,
      lastSeenTime: Date.now() - 80
    },
    {
      id: 'VEH-042',
      class: 'VEHICLE',
      confidence: 0.96,
      source: 'RGB_CAMERA_4K',
      modelVersion: 'SPITFIRE-YOLO-SEG-V4.2',
      position: { x: 4, y: -8, z: 0.8 },
      dimensions: { x: 4.8, y: 2.1, z: 1.6 },
      velocity: { x: 4.5, y: 1.2, z: 0 },
      predictedPositions: [
        { tSec: 1, pos: { x: 8.5, y: -6.8, z: 0.8 } },
        { tSec: 2, pos: { x: 13.0, y: -5.6, z: 0.8 } },
        { tSec: 5, pos: { x: 26.5, y: -2.0, z: 0.8 } }
      ],
      isDynamic: true,
      clearanceDistanceM: 9.2,
      threatLevel: 'CAUTION',
      boundingBox2D: { xMinPct: 45, yMinPct: 62, widthPct: 18, heightPct: 15 },
      timestamp: Date.now() - 60,
      lastSeenTime: Date.now() - 60
    },
    {
      id: 'PERS-007',
      class: 'PERSON',
      confidence: 0.89,
      source: 'RGB_CAMERA_4K',
      modelVersion: 'SPITFIRE-YOLO-SEG-V4.2',
      position: { x: -8, y: -14, z: 0.9 },
      dimensions: { x: 0.6, y: 0.5, z: 1.8 },
      velocity: { x: 0.8, y: -0.3, z: 0 },
      predictedPositions: [
        { tSec: 1, pos: { x: -7.2, y: -14.3, z: 0.9 } },
        { tSec: 2, pos: { x: -6.4, y: -14.6, z: 0.9 } }
      ],
      isDynamic: true,
      clearanceDistanceM: 16.1,
      threatLevel: 'NONE',
      boundingBox2D: { xMinPct: 22, yMinPct: 58, widthPct: 6, heightPct: 19 },
      timestamp: Date.now() - 110,
      lastSeenTime: Date.now() - 110
    },
    {
      id: 'ZONE-PAD-01',
      class: 'LANDING_AREA',
      confidence: 0.98,
      source: 'RGB_CAMERA_4K',
      modelVersion: 'SPITFIRE-YOLO-SEG-V4.2',
      position: { x: 0, y: 0, z: 0 },
      dimensions: { x: 4.0, y: 4.0, z: 0.1 },
      velocity: { x: 0, y: 0, z: 0 },
      predictedPositions: [{ tSec: 1, pos: { x: 0, y: 0, z: 0 } }],
      isDynamic: false,
      clearanceDistanceM: 0.0,
      threatLevel: 'NONE',
      boundingBox2D: { xMinPct: 38, yMinPct: 70, widthPct: 24, heightPct: 22 },
      timestamp: Date.now() - 50,
      lastSeenTime: Date.now() - 50
    }
  ]);

  // Delivery zone candidates
  readonly deliveryCandidates = signal<DeliveryZoneCandidate[]>([
    {
      id: 'DZ-01',
      name: 'Primary Depot Landing Pad (Pad Alpha)',
      zoneClass: 'LANDING_PAD',
      coordinates: { x: 0, y: 0, z: 0 },
      clearanceRadiusM: 8.5,
      maxObstacleHeightAroundM: 1.2,
      surfaceType: 'CONCRETE',
      slopeDeg: 0.4,
      mlConfidence: 0.99,
      ruleSafetyScore: 98,
      peopleClearanceM: 16.1,
      wiresDetectedNear: false,
      verdict: 'APPROVED_SAFE'
    },
    {
      id: 'DZ-02',
      name: 'North Warehouse Yard Drop Point',
      zoneClass: 'WAREHOUSE_YARD',
      coordinates: { x: 48, y: -15, z: 0 },
      clearanceRadiusM: 6.2,
      maxObstacleHeightAroundM: 3.5,
      surfaceType: 'ASPHALT',
      slopeDeg: 1.1,
      mlConfidence: 0.94,
      ruleSafetyScore: 91,
      peopleClearanceM: 22.0,
      wiresDetectedNear: false,
      verdict: 'APPROVED_SAFE'
    },
    {
      id: 'DZ-03',
      name: 'Farm Access Track Verge',
      zoneClass: 'FARM_TRACK',
      coordinates: { x: -32, y: 40, z: 0 },
      clearanceRadiusM: 4.8,
      maxObstacleHeightAroundM: 7.4,
      surfaceType: 'GRAVEL',
      slopeDeg: 2.8,
      mlConfidence: 0.88,
      ruleSafetyScore: 82,
      peopleClearanceM: 45.0,
      wiresDetectedNear: true,
      verdict: 'RESTRICTED_CAUTION',
      rejectionReason: 'Overhead 11kV distribution line detected at 11.5m clearance. Descent restricted to vertical cylinder.'
    },
    {
      id: 'DZ-04',
      name: 'Commercial Flat Rooftop (Building B)',
      zoneClass: 'ROOFTOP',
      coordinates: { x: 35, y: -20, z: 12.2 },
      clearanceRadiusM: 5.5,
      maxObstacleHeightAroundM: 0.8,
      surfaceType: 'CONCRETE',
      slopeDeg: 0.2,
      mlConfidence: 0.96,
      ruleSafetyScore: 94,
      peopleClearanceM: 35.0,
      wiresDetectedNear: false,
      verdict: 'APPROVED_SAFE'
    }
  ]);

  // Spatial uncertainty state
  readonly spatialUncertainty = signal<SpatialUncertaintyState>({
    perceptionUncertaintyPct: 8.4,
    spatialOccupancyVoxelCount: {
      free: 142500,
      occupied: 18420,
      dynamic: 450,
      unknown: 8600,
      restricted: 12300
    },
    gnssVarianceM: 0.04, // RTK-GNSS dual antenna fix
    windTurbulenceFactor: 0.22,
    fogVisibilityM: 4800,
    activeAvoidanceState: 'CLEAR_TO_PROCEED',
    spatialAgeMs: 140
  });

  // Active trajectory
  readonly activeTrajectory = signal<TrajectoryPlan>({
    id: 'TRAJ-MISSION-SPITFIRE-04',
    waypoints: [
      { id: 'WP-00', phase: 'TAKEOFF', position: { x: 0, y: 0, z: 0 }, speedTargetMs: 0, headingDeg: 45 },
      { id: 'WP-01', phase: 'TAKEOFF', position: { x: 0, y: 0, z: 15 }, speedTargetMs: 4.0, headingDeg: 45 },
      { id: 'WP-02', phase: 'CRUISE', position: { x: 20, y: 10, z: 25 }, speedTargetMs: 18.0, headingDeg: 62 },
      { id: 'WP-03', phase: 'CRUISE', position: { x: 45, y: 5, z: 25 }, speedTargetMs: 18.0, headingDeg: 78 },
      { id: 'WP-04', phase: 'APPROACH', position: { x: 48, y: -10, z: 15 }, speedTargetMs: 8.0, headingDeg: 120 },
      { id: 'WP-05', phase: 'HOVER', position: { x: 48, y: -15, z: 5 }, speedTargetMs: 0.5, headingDeg: 120, hoverDurationSec: 4 },
      { id: 'WP-06', phase: 'DESCENT', position: { x: 48, y: -15, z: 1.5 }, speedTargetMs: 0.8, headingDeg: 120 },
      { id: 'WP-07', phase: 'DELIVERY', position: { x: 48, y: -15, z: 0.2 }, speedTargetMs: 0.0, headingDeg: 120, deliveryActionRequired: true },
      { id: 'WP-08', phase: 'ASCENT', position: { x: 48, y: -15, z: 20 }, speedTargetMs: 5.0, headingDeg: 240 },
      { id: 'WP-09', phase: 'RETURN', position: { x: 0, y: 0, z: 20 }, speedTargetMs: 18.0, headingDeg: 240 },
      { id: 'WP-10', phase: 'DESCENT', position: { x: 0, y: 0, z: 0 }, speedTargetMs: 1.0, headingDeg: 0 }
    ],
    totalDistanceM: 284.5,
    estimatedFlightTimeSec: 68,
    energyRequiredWh: 34.2,
    minClearanceMarginM: 11.5,
    riskScore: 6,
    obstacleIntersections: 0,
    status: 'VALIDATED_SAFE'
  });

  // Query engine answers
  executeSpatialQuery(queryText: string): { question: string; answer: string; structuredData: Record<string, unknown> } {
    const q = queryText.toLowerCase();

    if (q.includes('clear') || q.includes('obstacle') || q.includes('below')) {
      const nearestObstacle = [...this.detectedObjects()].sort((a, b) => a.clearanceDistanceM - b.clearanceDistanceM)[0];
      return {
        question: queryText,
        answer: `Spatial analysis shows nominal clearance. Nearest classified obstacle is ${nearestObstacle.id} (${nearestObstacle.class}) at ${nearestObstacle.clearanceDistanceM.toFixed(1)}m. Overhead wire WIRE-003 has been mapped with caution corridor.`,
        structuredData: {
          status: 'CLEAR_WITH_CORRIDOR',
          nearestObstacleId: nearestObstacle.id,
          clearanceM: nearestObstacle.clearanceDistanceM,
          dynamicObjectsTrackingCount: this.detectedObjects().filter(o => o.isDynamic).length,
          avoidanceRecommendation: 'CLEAR_TO_PROCEED'
        }
      };
    } else if (q.includes('place') || q.includes('landing') || q.includes('zone') || q.includes('drop')) {
      const bestZone = this.deliveryCandidates().find(z => z.verdict === 'APPROVED_SAFE') || this.deliveryCandidates()[0];
      return {
        question: queryText,
        answer: `Identified optimal delivery zone: "${bestZone.name}" (${bestZone.zoneClass}). Safety score: ${bestZone.ruleSafetyScore}/100, Surface: ${bestZone.surfaceType} with slope ${bestZone.slopeDeg}°, ML confidence: ${(bestZone.mlConfidence * 100).toFixed(0)}%. No wires or moving pedestrians in 15m radius.`,
        structuredData: {
          candidateId: bestZone.id,
          name: bestZone.name,
          surface: bestZone.surfaceType,
          safetyScore: bestZone.ruleSafetyScore,
          mlConfidence: bestZone.mlConfidence,
          coordinates: bestZone.coordinates
        }
      };
    } else if (q.includes('fallback') || q.includes('abort') || q.includes('emergency')) {
      return {
        question: queryText,
        answer: `Designated Primary Safe Fallback Zone is Depot Pad Alpha (x: 0m, y: 0m, z: 0m) with 100% clearance verification. Secondary emergency ground area available at Farm Track Verge (x: -32m, y: 40m).`,
        structuredData: {
          primaryFallback: 'Pad Alpha (0, 0, 0)',
          distanceM: 0,
          energyNeededWh: 2.1,
          emergencyDescentProfile: 'VERTICAL_AUTO_BRAKE'
        }
      };
    } else {
      return {
        question: queryText,
        answer: `Spatial Engine evaluated 8 world objects and 4 candidate delivery zones. Current spatial uncertainty is low (${this.spatialUncertainty().perceptionUncertaintyPct}%). All 3D trajectory corridors pass UK CAA simulated envelope rules.`,
        structuredData: {
          objectsTracked: this.detectedObjects().length,
          uncertaintyPct: this.spatialUncertainty().perceptionUncertaintyPct,
          spatialModelAge: `${this.spatialUncertainty().spatialAgeMs}ms`,
          trajectoryValid: true
        }
      };
    }
  }

  updateObjectPosition(id: string, deltaX: number, deltaY: number) {
    this.detectedObjects.update(objs => objs.map(o => {
      if (o.id === id) {
        const newPos = { ...o.position, x: o.position.x + deltaX, y: o.position.y + deltaY };
        return {
          ...o,
          position: newPos,
          timestamp: Date.now()
        };
      }
      return o;
    }));
  }
}
