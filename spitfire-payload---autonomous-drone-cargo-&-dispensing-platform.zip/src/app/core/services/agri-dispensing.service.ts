import { Injectable, signal, computed } from '@angular/core';
import { AgriSpraySimulationState, CropHealthCategory, FieldCoverageGridCell, FieldStatistics, GranularSimulationState, TreatmentZone } from '../models/agri.model';

@Injectable({
  providedIn: 'root'
})
export class AgriDispensingService {
  // Treatment zones in simulated field
  readonly treatmentZones = signal<TreatmentZone[]>([
    {
      id: 'ZONE-A',
      name: 'North-West Barley Field (Section 1)',
      category: 'HEALTHY',
      areaHectares: 1.8,
      recommendedDoseLPerHa: 40,
      ndviAverage: 0.82,
      weedDensityPct: 3.2,
      polygon: [{ x: -60, y: 30 }, { x: -20, y: 30 }, { x: -20, y: 80 }, { x: -60, y: 80 }]
    },
    {
      id: 'ZONE-B',
      name: 'Central Rapeseed Infestation (Section 2)',
      category: 'WEED_SUSPECT',
      areaHectares: 0.9,
      recommendedDoseLPerHa: 120, // Targeted spot application
      ndviAverage: 0.54,
      weedDensityPct: 38.5,
      polygon: [{ x: -10, y: 30 }, { x: 30, y: 30 }, { x: 30, y: 80 }, { x: -10, y: 80 }]
    },
    {
      id: 'ZONE-C',
      name: 'East Wheat Field (Section 3 - Water Stressed)',
      category: 'STRESSED',
      areaHectares: 1.5,
      recommendedDoseLPerHa: 65,
      ndviAverage: 0.61,
      weedDensityPct: 8.0,
      polygon: [{ x: 40, y: 30 }, { x: 80, y: 30 }, { x: 80, y: 80 }, { x: 40, y: 80 }]
    }
  ]);

  // Spray simulation state
  readonly sprayState = signal<AgriSpraySimulationState>({
    activeTankLevelLiters: 9.6,
    tankCapacityLiters: 12.0,
    flowRateLPerMin: 2.8,
    dropletClass: 'COARSE',
    swathWidthM: 3.2,
    targetApplicationRateLPerHa: 80,
    simulatedWindSpeedMs: 3.5,
    simulatedWindDirectionDeg: 220,
    groundSpeedMs: 6.5,
    dispensingActive: true,
    pressureBar: 3.2,
    pumpRpm: 2450,
    consumedLiters: 2.4,
    remainingFlightTimeForSprayMin: 14.5,
    remainingCoverableAreaHa: 1.2
  });

  // Granular simulation state
  readonly granularState = signal<GranularSimulationState>({
    activeHopperMassKg: 12.5,
    hopperCapacityKg: 15.0,
    granularType: 'NPK 20-10-10',
    spreadWidthM: 6.0,
    feedRateKgPerMin: 3.5,
    spinnerSpeedRpm: 1200,
    dispensingActive: false
  });

  // 2D/3D Grid Coverage Map (16x16 grid for interactive visualisation)
  readonly coverageGrid = signal<FieldCoverageGridCell[]>(this.generateInitialCoverageGrid());

  // Summary statistics
  readonly fieldStats = computed<FieldStatistics>(() => {
    const grid = this.coverageGrid();
    const totalCells = grid.length;
    let applied = 0;
    let over = 0;
    let under = 0;
    let untreated = 0;

    for (const cell of grid) {
      if (cell.status === 'OPTIMAL') applied++;
      else if (cell.status === 'OVER_APPLIED') { applied++; over++; }
      else if (cell.status === 'UNDER_APPLIED') { applied++; under++; }
      else untreated++;
    }

    return {
      totalFieldAreaHa: 4.2,
      treatedAreaHa: Math.round(((applied / totalCells) * 4.2) * 100) / 100,
      coverageEfficiencyPct: Math.round((applied / totalCells) * 100),
      overApplicationPct: Math.round((over / totalCells) * 100),
      underApplicationPct: Math.round((under / totalCells) * 100),
      untreatedPct: Math.round((untreated / totalCells) * 100),
      driftRiskScore: 12, // low risk in Coarse droplet mode
      uniformityCvPct: 8.4 // Coefficient of Variation
    };
  });

  private generateInitialCoverageGrid(): FieldCoverageGridCell[] {
    const cells: FieldCoverageGridCell[] = [];
    const size = 16;
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        // Create realistic field gradient
        let health: CropHealthCategory = 'HEALTHY';
        let ndvi = 0.82;
        let targetRate = 40;

        if (x >= 5 && x <= 10 && y >= 4 && y <= 11) {
          health = 'WEED_SUSPECT';
          ndvi = 0.52;
          targetRate = 120;
        } else if (x > 10) {
          health = 'STRESSED';
          ndvi = 0.63;
          targetRate = 65;
        }

        // Simulated spray tracks across the field
        let appliedRate = 0;
        let status: FieldCoverageGridCell['status'] = 'UNTREATED';

        if (y < 9) { // drone has already flown lines 0 to 8
          appliedRate = targetRate * (0.95 + (Math.sin(x * 0.8 + y) * 0.1));
          if (appliedRate > targetRate * 1.15) {
            status = 'OVER_APPLIED';
          } else if (appliedRate < targetRate * 0.85) {
            status = 'UNDER_APPLIED';
          } else {
            status = 'OPTIMAL';
          }
        }

        cells.push({
          gridX: x,
          gridY: y,
          targetRate,
          appliedRate: Math.round(appliedRate),
          status,
          cropHealth: health,
          ndvi: Math.round(ndvi * 100) / 100
        });
      }
    }
    return cells;
  }

  toggleDispensing() {
    this.sprayState.update(s => ({ ...s, dispensingActive: !s.dispensingActive }));
  }

  setDropletClass(cls: 'VERY_COARSE' | 'COARSE' | 'MEDIUM' | 'FINE') {
    this.sprayState.update(s => ({ ...s, dropletClass: cls }));
  }

  setTargetRate(rate: number) {
    this.sprayState.update(s => ({ ...s, targetApplicationRateLPerHa: rate }));
  }
}
