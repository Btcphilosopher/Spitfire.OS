import { Injectable, signal, computed, inject } from '@angular/core';
import { DeliveryState, PayloadItem, PayloadModule } from '../models/payload.model';
import { FleetAircraft } from '../models/aircraft.model';
import { SpitfirePhysics, SPITFIRE_MK4_SPEC } from './spitfire-physics.service';

@Injectable({
  providedIn: 'root'
})
export class MissionLogisticsService {
  private readonly physics = inject(SpitfirePhysics);

  // Available interchangeable modules
  readonly availableModules = signal<PayloadModule[]>([
    {
      moduleId: 'MOD-CARGO-01',
      name: 'Standard Rapid-Deploy Cargo Bay',
      type: 'CARGO_BAY',
      dryMassKg: 1.8,
      maxPayloadCapacityKg: 18.0,
      maxVolumeLiters: 92.5,
      installed: true,
      softwareVersion: 'FW-MOD-CB-v3.1.2',
      calibrationDate: '2026-08-14',
      maintenanceState: 'OPTIMAL',
      telemetry: {
        temperatureC: 16.5,
        lockEngaged: true,
        doorClosed: true,
        sensorHealthPercent: 99
      }
    },
    {
      moduleId: 'MOD-SPRAY-12',
      name: 'Precision Variable-Rate Spray Tank (12L)',
      type: 'SPRAY_TANK',
      dryMassKg: 2.6,
      maxPayloadCapacityKg: 16.0,
      maxVolumeLiters: 12.0,
      installed: false,
      softwareVersion: 'FW-AGRI-PWM-v4.0.1',
      calibrationDate: '2026-09-02',
      maintenanceState: 'OPTIMAL',
      telemetry: {
        temperatureC: 14.8,
        lockEngaged: true,
        doorClosed: true,
        pressureKpa: 320,
        flowRateLPerMin: 2.4,
        tankLevelPercent: 88,
        pumpActive: false,
        sensorHealthPercent: 98
      }
    },
    {
      moduleId: 'MOD-HOPPER-15',
      name: 'Centrifugal Granular & Seed Hopper (15kg)',
      type: 'GRANULAR_HOPPER',
      dryMassKg: 2.9,
      maxPayloadCapacityKg: 15.0,
      maxVolumeLiters: 22.0,
      installed: false,
      softwareVersion: 'FW-AGRI-SPIN-v2.8',
      calibrationDate: '2026-08-28',
      maintenanceState: 'OPTIMAL',
      telemetry: {
        temperatureC: 15.2,
        lockEngaged: true,
        doorClosed: true,
        sensorHealthPercent: 97
      }
    },
    {
      moduleId: 'MOD-SAMPLER-04',
      name: 'Autonomous Environmental Micro-Sampler Pod',
      type: 'SAMPLER',
      dryMassKg: 2.1,
      maxPayloadCapacityKg: 6.0,
      maxVolumeLiters: 14.0,
      installed: false,
      softwareVersion: 'FW-BIO-SAMP-v1.9',
      calibrationDate: '2026-09-10',
      maintenanceState: 'OPTIMAL',
      telemetry: {
        temperatureC: 4.2, // chilled storage
        lockEngaged: true,
        doorClosed: true,
        sensorHealthPercent: 100
      }
    }
  ]);

  // Currently installed module on active airframe
  readonly activeModule = signal<PayloadModule>(this.availableModules()[0]);

  // Pre-configured payload items library
  readonly availablePayloadPresets = signal<PayloadItem[]>([
    {
      id: 'PL-MED-842',
      name: 'NHS Emergency Blood & Plasma Case',
      type: 'MedicalPackage',
      massKg: 5.8,
      dimensions: { width: 340, length: 420, height: 210 },
      centreOfGravity: { x: 0, y: 0, z: 0 },
      bayPosition: { x: 220, y: 0, z: 120 },
      bayRotationDeg: 0,
      constraints: {
        minTempC: 2.0,
        maxTempC: 6.0,
        maxTiltDegrees: 15,
        maxGForce: 2.2,
        fragile: true,
        hazmat: false,
        securementRequired: true,
        orientationFixed: true,
        deliveryMethod: 'WINCH_DROP'
      },
      physics: {
        massKg: 5.8,
        volumeLiters: 29.9,
        centreOfGravity: { x: 0, y: 0, z: 0 },
        inertiaTensorKgM2: { ixx: 0.082, iyy: 0.114, izz: 0.142 },
        dragCoefficient: 0.72,
        frontalAreaM2: 0.071,
        energyPenaltyWhPerKm: 4.2,
        status: 'CALIBRATED'
      },
      trackingId: 'GB-NHS-99214-CRIT',
      recipient: 'Queen Elizabeth Hospital Trauma Wing',
      destinationAddress: 'Helipad Drop Point Alpha, Edgbaston, Birmingham B15 2TH',
      destinationCoords: { lat: 52.4532, lng: -1.9382, altM: 142 },
      deliveryState: 'PACKED',
      priority: 'EMERGENCY_CRITICAL',
      secured: true
    },
    {
      id: 'PL-POST-104',
      name: 'Royal Mail Express Postal Case Alpha',
      type: 'Parcel',
      massKg: 3.2,
      dimensions: { width: 260, length: 340, height: 160 },
      centreOfGravity: { x: 5, y: -8, z: 0 },
      bayPosition: { x: 120, y: -60, z: 100 },
      bayRotationDeg: 0,
      constraints: {
        maxTiltDegrees: 45,
        maxGForce: 3.5,
        fragile: false,
        hazmat: false,
        securementRequired: true,
        orientationFixed: false,
        deliveryMethod: 'SOFT_LANDING'
      },
      physics: {
        massKg: 3.2,
        volumeLiters: 14.1,
        centreOfGravity: { x: 5, y: -8, z: 0 },
        inertiaTensorKgM2: { ixx: 0.038, iyy: 0.048, izz: 0.062 },
        dragCoefficient: 0.81,
        frontalAreaM2: 0.044,
        energyPenaltyWhPerKm: 2.1,
        status: 'SIMULATED'
      },
      trackingId: 'RM-SPIT-004812-GB',
      recipient: 'Oakridge Logistics Depot',
      destinationAddress: 'Bay 4, Solihull Industrial Estate, B90 4SS',
      destinationCoords: { lat: 52.3921, lng: -1.8214, altM: 118 },
      deliveryState: 'LOADED',
      priority: 'HIGH',
      secured: true
    },
    {
      id: 'PL-IND-501',
      name: 'Rolls-Royce High-Tolerance Turbine Sensor Spares',
      type: 'IndustrialPackage',
      massKg: 4.4,
      dimensions: { width: 280, length: 380, height: 190 },
      centreOfGravity: { x: 0, y: 12, z: -5 },
      bayPosition: { x: 300, y: 50, z: 100 },
      bayRotationDeg: 90,
      constraints: {
        maxTiltDegrees: 25,
        maxGForce: 2.8,
        fragile: true,
        hazmat: false,
        securementRequired: true,
        orientationFixed: true,
        deliveryMethod: 'WINCH_DROP'
      },
      physics: {
        massKg: 4.4,
        volumeLiters: 20.2,
        centreOfGravity: { x: 0, y: 12, z: -5 },
        inertiaTensorKgM2: { ixx: 0.056, iyy: 0.072, izz: 0.098 },
        dragCoefficient: 0.76,
        frontalAreaM2: 0.053,
        energyPenaltyWhPerKm: 3.0,
        status: 'CALIBRATED'
      },
      trackingId: 'RR-AERO-09412-GB',
      recipient: 'Ansty Aerospace Test Center',
      destinationAddress: 'Hangar 7, Coventry CV7 9JR',
      destinationCoords: { lat: 52.4411, lng: -1.4128, altM: 95 },
      deliveryState: 'ALLOCATED',
      priority: 'HIGH',
      secured: true
    },
    {
      id: 'PL-SENS-09',
      name: 'Hyperspectral Environmental Survey Pod',
      type: 'SensorPayload',
      massKg: 1.4,
      dimensions: { width: 140, length: 220, height: 110 },
      centreOfGravity: { x: 0, y: 0, z: 0 },
      bayPosition: { x: 220, y: 0, z: 240 },
      bayRotationDeg: 0,
      constraints: {
        maxTiltDegrees: 60,
        maxGForce: 4.0,
        fragile: true,
        hazmat: false,
        securementRequired: true,
        orientationFixed: true,
        deliveryMethod: 'BAY_EJECT'
      },
      physics: {
        massKg: 1.4,
        volumeLiters: 3.3,
        centreOfGravity: { x: 0, y: 0, z: 0 },
        inertiaTensorKgM2: { ixx: 0.012, iyy: 0.018, izz: 0.024 },
        dragCoefficient: 0.45,
        frontalAreaM2: 0.015,
        energyPenaltyWhPerKm: 0.8,
        status: 'OBSERVED'
      },
      trackingId: 'DEFRA-ENV-4491-GB',
      recipient: 'UK Centre for Ecology & Hydrology',
      destinationAddress: 'Warwickshire Wetland Station Site B',
      destinationCoords: { lat: 52.3214, lng: -1.5421, altM: 82 },
      deliveryState: 'READY',
      priority: 'ROUTINE',
      secured: true
    }
  ]);

  // Currently loaded payloads in the active aircraft bay
  readonly loadedPayloads = signal<PayloadItem[]>([
    this.availablePayloadPresets()[0],
    this.availablePayloadPresets()[1]
  ]);

  // Active delivery workflow state for parcel simulation
  readonly activeDeliveryState = signal<DeliveryState>('IN_FLIGHT');
  readonly verificationProgress = signal<{
    phase: 'APPROACH' | 'ZONE_CHECK' | 'LOWERING' | 'RELEASE' | 'OPTICAL_CONFIRMATION' | 'VERIFIED_COMPLETE';
    opticalConfidence: number;
    packagePresentInZone: boolean;
    winchTensionN: number;
    altitudeM: number;
    logs: string[];
  }>({
    phase: 'OPTICAL_CONFIRMATION',
    opticalConfidence: 0.984,
    packagePresentInZone: true,
    winchTensionN: 0.2, // load released
    altitudeM: 3.2,
    logs: [
      '[10:42:01] APPROACH: Arrived at Delivery Site DZ-02 (Pad North)',
      '[10:42:04] ZONE_CHECK: Optical LiDAR scan verified clearance. 0 pedestrians detected.',
      '[10:42:08] LOWERING: Winch line descended 8.4m at 0.6 m/s.',
      '[10:42:12] RELEASE: Ground contact detected. Winch latch electronically released.',
      '[10:42:14] OPTICAL_CONFIRMATION: ML Vision Model detected package at target coordinates (Confidence 98.4%).',
      '[10:42:16] VERIFIED: Delivery signed with cryptographic cryptographic proof of deposit.'
    ]
  });

  // Fleet state
  readonly fleet = signal<FleetAircraft[]>([
    {
      id: 'SPITFIRE-001',
      callsign: 'Merlin-Alpha',
      spec: SPITFIRE_MK4_SPEC,
      installedModule: this.availableModules()[0],
      loadedPayloads: [this.availablePayloadPresets()[0]],
      status: 'IN_FLIGHT',
      batteryPercent: 78,
      telemetry: {
        latitude: 52.4532,
        longitude: -1.9382,
        altitudeM: 28.5,
        groundSpeedMs: 16.4,
        headingDeg: 124,
        climbRateMs: 0.1,
        voltageV: 23.4,
        currentA: 28.2,
        temperatureC: 21.4,
        gnssSatellites: 24,
        imuHealth: 100,
        linkSignalDbm: -54
      },
      activeMissionId: 'MSN-NHS-URGENT-84'
    },
    {
      id: 'SPITFIRE-002',
      callsign: 'Typhoon-Heavy',
      spec: SPITFIRE_MK4_SPEC,
      installedModule: this.availableModules()[0],
      loadedPayloads: [this.availablePayloadPresets()[1], this.availablePayloadPresets()[2]],
      status: 'PREFLIGHT_CHECK',
      batteryPercent: 96,
      telemetry: {
        latitude: 52.3921,
        longitude: -1.8214,
        altitudeM: 0.0,
        groundSpeedMs: 0.0,
        headingDeg: 0,
        climbRateMs: 0.0,
        voltageV: 25.1,
        currentA: 0.8,
        temperatureC: 18.2,
        gnssSatellites: 26,
        imuHealth: 100,
        linkSignalDbm: -48
      }
    },
    {
      id: 'SPITFIRE-003',
      callsign: 'Harvest-Spec-03',
      spec: SPITFIRE_MK4_SPEC,
      installedModule: this.availableModules()[1], // Spray tank
      loadedPayloads: [],
      status: 'DISPENSING',
      batteryPercent: 64,
      telemetry: {
        latitude: 52.2841,
        longitude: -1.6124,
        altitudeM: 4.2,
        groundSpeedMs: 6.5,
        headingDeg: 90,
        climbRateMs: 0.0,
        voltageV: 22.8,
        currentA: 34.5,
        temperatureC: 22.6,
        gnssSatellites: 22,
        imuHealth: 100,
        linkSignalDbm: -61
      },
      activeMissionId: 'MSN-AGRI-SPRAY-ZONE-B'
    },
    {
      id: 'SPITFIRE-004',
      callsign: 'Kestrel-Rapid',
      spec: SPITFIRE_MK4_SPEC,
      installedModule: this.availableModules()[3], // Sampler
      loadedPayloads: [this.availablePayloadPresets()[3]],
      status: 'IDLE_DEPOT',
      batteryPercent: 100,
      telemetry: {
        latitude: 52.4862,
        longitude: -1.8904,
        altitudeM: 0.0,
        groundSpeedMs: 0.0,
        headingDeg: 0,
        climbRateMs: 0.0,
        voltageV: 25.2,
        currentA: 0.4,
        temperatureC: 17.5,
        gnssSatellites: 28,
        imuHealth: 100,
        linkSignalDbm: -42
      }
    }
  ]);

  // Computed live CG of active aircraft
  readonly currentCGResult = computed(() => {
    return this.physics.calculateCombinedCG(
      SPITFIRE_MK4_SPEC,
      this.activeModule(),
      this.loadedPayloads()
    );
  });

  // Computed energy and range estimates
  readonly currentEnergyEstimate = computed(() => {
    const cg = this.currentCGResult();
    return this.physics.calculateEnergyAndFlightDynamics(
      SPITFIRE_MK4_SPEC,
      cg.totalMassKg
    );
  });

  // Actions
  installModule(moduleId: string) {
    const mod = this.availableModules().find(m => m.moduleId === moduleId);
    if (mod) {
      this.availableModules.update(list => list.map(m => ({ ...m, installed: m.moduleId === moduleId })));
      this.activeModule.set(mod);
      if (mod.type !== 'CARGO_BAY') {
        // Agricultural or sampler modules use their internal bulk material instead of standalone parcel boxes
        this.loadedPayloads.set([]);
      }
    }
  }

  addPayloadToBay(payload: PayloadItem) {
    this.loadedPayloads.update(items => [...items, payload]);
  }

  removePayloadFromBay(payloadId: string) {
    this.loadedPayloads.update(items => items.filter(i => i.id !== payloadId));
  }

  updatePayloadPosition(payloadId: string, posX: number, posY: number, posZ: number) {
    this.loadedPayloads.update(items => items.map(item => {
      if (item.id === payloadId) {
        return {
          ...item,
          bayPosition: { x: posX, y: posY, z: posZ }
        };
      }
      return item;
    }));
  }

  optimizeLoadDistribution() {
    const items = [...this.loadedPayloads()];
    if (items.length <= 1) return;

    // Load optimizer sorts items by mass and balances them along longitudinal axis (X) and lateral axis (Y=0)
    // to bring combined CG directly to the target sweet spot (X=250mm, Y=0mm, Z=140mm)
    const bayDim = SPITFIRE_MK4_SPEC.bayDimensions;
    const sorted = [...items].sort((a, b) => b.massKg - a.massKg);

    let currentX = 100;
    const optimized = sorted.map((item) => {
      const itemWidth = item.dimensions.width;
      const xPos = Math.min(bayDim.width - itemWidth / 2, Math.max(itemWidth / 2, currentX + itemWidth / 2));
      currentX += itemWidth + 20;

      // Center laterally Y=0
      return {
        ...item,
        bayPosition: {
          x: xPos,
          y: 0,
          z: Math.max(60, item.dimensions.height / 2)
        },
        secured: true,
        deliveryState: 'LOADED' as DeliveryState
      };
    });

    this.loadedPayloads.set(optimized);
  }

  advanceDeliverySimulation(nextState: DeliveryState) {
    this.activeDeliveryState.set(nextState);
  }
}
