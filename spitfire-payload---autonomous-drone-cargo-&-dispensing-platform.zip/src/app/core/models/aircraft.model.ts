import { Dimensions3D, PayloadItem, PayloadModule, Vector3D } from './payload.model';

export interface EnvelopeLimit {
  minX: number; // mm
  maxX: number;
  minY: number;
  maxY: number;
  minZ: number;
  maxZ: number;
}

export interface AircraftSpec {
  modelId: string;
  name: string;
  airframeType: 'HEXACOPTER_COAXIAL' | 'OCTOCOPTER_TILT' | 'VTOL_TANDEM';
  emptyDryMassKg: number;
  maxTakeoffMassKg: number; // MTOM
  maxPayloadMassKg: number;
  batteryCapacityWh: number;
  nominalVoltageV: number;
  rotorDiameterM: number;
  rotorCount: number;
  bayDimensions: Dimensions3D; // mm
  emptyCG: Vector3D; // mm relative to airframe origin
  permittedEnvelope: EnvelopeLimit;
  cruiseAirspeedMs: number;
  maxAirspeedMs: number;
  maxWindLimitMs: number;
  maxClimbRateMs: number;
  maxDescentRateMs: number;
}

export interface CGCalculationResult {
  aircraftEmptyCG: Vector3D;
  payloadCombinedCG: Vector3D;
  totalCombinedCG: Vector3D;
  cgShiftMm: number;
  totalMassKg: number;
  payloadMassKg: number;
  massMarginKg: number;
  isWithinEnvelope: boolean;
  envelopeMarginPercent: number;
  warningReasons: string[];
  statusLabel: 'ACCEPTABLE' | 'MARGINAL_WARNING' | 'UNACCEPTABLE_ENVELOPE_BREACH' | 'OVERWEIGHT';
}

export interface EnergyMissionEstimate {
  hoverPowerDrawW: number;
  cruisePowerDrawW: number;
  payloadEnergyPenaltyPct: number;
  estimatedCruiseSpeedMs: number;
  estimatedMaxRangeKm: number;
  estimatedEnduranceMin: number;
  reserveCapacityPct: number;
  safeReturnRadiusKm: number;
}

export interface FleetAircraft {
  id: string;
  callsign: string;
  spec: AircraftSpec;
  installedModule: PayloadModule;
  loadedPayloads: PayloadItem[];
  status: 'IDLE_DEPOT' | 'PREFLIGHT_CHECK' | 'LOADING' | 'IN_FLIGHT' | 'DISPENSING' | 'RETURNING' | 'MAINTENANCE';
  batteryPercent: number;
  telemetry: {
    latitude: number;
    longitude: number;
    altitudeM: number;
    groundSpeedMs: number;
    headingDeg: number;
    climbRateMs: number;
    voltageV: number;
    currentA: number;
    temperatureC: number;
    gnssSatellites: number;
    imuHealth: number;
    linkSignalDbm: number;
  };
  activeMissionId?: string;
}
