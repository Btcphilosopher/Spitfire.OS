export type CropType = 'Winter Wheat' | 'Spring Barley' | 'Oilseed Rape' | 'Potatoes' | 'Sugar Beet' | 'Field Beans';

export type CropHealthCategory = 'HEALTHY' | 'STRESSED' | 'DISEASE_SUSPECT' | 'WEED_SUSPECT' | 'UNKNOWN';

export interface TreatmentZone {
  id: string;
  name: string;
  category: CropHealthCategory;
  areaHectares: number;
  recommendedDoseLPerHa: number;
  ndviAverage: number;
  weedDensityPct: number;
  polygon: { x: number; y: number }[]; // meters relative to field origin
}

export interface AgriSpraySimulationState {
  activeTankLevelLiters: number;
  tankCapacityLiters: number;
  flowRateLPerMin: number;
  dropletClass: 'VERY_COARSE' | 'COARSE' | 'MEDIUM' | 'FINE';
  swathWidthM: number;
  targetApplicationRateLPerHa: number;
  simulatedWindSpeedMs: number;
  simulatedWindDirectionDeg: number;
  groundSpeedMs: number;
  dispensingActive: boolean;
  pressureBar: number;
  pumpRpm: number;
  consumedLiters: number;
  remainingFlightTimeForSprayMin: number;
  remainingCoverableAreaHa: number;
}

export interface GranularSimulationState {
  activeHopperMassKg: number;
  hopperCapacityKg: number;
  granularType: 'NPK 20-10-10' | 'Urea 46N' | 'White Clover Seed' | 'Cover Crop Blend';
  spreadWidthM: number;
  feedRateKgPerMin: number;
  spinnerSpeedRpm: number;
  dispensingActive: boolean;
}

export interface FieldCoverageGridCell {
  gridX: number;
  gridY: number;
  targetRate: number;
  appliedRate: number;
  status: 'OPTIMAL' | 'OVER_APPLIED' | 'UNDER_APPLIED' | 'UNTREATED' | 'OFF_TARGET_DRIFT';
  cropHealth: CropHealthCategory;
  ndvi: number;
}

export interface FieldStatistics {
  totalFieldAreaHa: number;
  treatedAreaHa: number;
  coverageEfficiencyPct: number;
  overApplicationPct: number;
  underApplicationPct: number;
  untreatedPct: number;
  driftRiskScore: number;
  uniformityCvPct: number;
}
