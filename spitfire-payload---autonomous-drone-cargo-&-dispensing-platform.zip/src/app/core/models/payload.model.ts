export type PayloadType = 
  | 'Parcel'
  | 'MedicalPackage'
  | 'IndustrialPackage'
  | 'AgriculturalLiquid'
  | 'AgriculturalGranular'
  | 'SeedPayload'
  | 'SamplingPayload'
  | 'ToolPayload'
  | 'SensorPayload'
  | 'CustomPayload';

export type DeliveryMethod = 'WINCH_DROP' | 'SOFT_LANDING' | 'PRECISION_SPRAY' | 'GRANULAR_SPREAD' | 'PARACHUTE_DEPLOY' | 'BAY_EJECT';

export type ModuleType = 
  | 'CARGO_BAY'
  | 'SPRAY_TANK'
  | 'GRANULAR_HOPPER'
  | 'SEED_MODULE'
  | 'SAMPLER'
  | 'CAMERA_MODULE'
  | 'THERMAL_MODULE'
  | 'LIDAR_MODULE';

export type DeliveryState = 
  | 'CREATED'
  | 'ALLOCATED'
  | 'PACKED'
  | 'LOADED'
  | 'READY'
  | 'IN_FLIGHT'
  | 'APPROACHING'
  | 'DELIVERY_ZONE'
  | 'DELIVERED'
  | 'VERIFIED'
  | 'RETURNED'
  | 'FAILED'
  | 'CANCELLED';

export interface Vector3D {
  x: number; // mm in payload bay or m in world
  y: number;
  z: number;
}

export interface Dimensions3D {
  width: number;  // mm (X-axis)
  length: number; // mm (Y-axis)
  height: number; // mm (Z-axis)
}

export interface PayloadConstraints {
  minTempC?: number;
  maxTempC?: number;
  maxTiltDegrees: number;
  maxGForce: number;
  fragile: boolean;
  hazmat: boolean;
  hazmatClass?: string;
  securementRequired: boolean;
  orientationFixed: boolean;
  deliveryMethod: DeliveryMethod;
}

export interface PayloadPhysics {
  massKg: number;
  volumeLiters: number;
  centreOfGravity: Vector3D; // mm relative to payload centroid
  inertiaTensorKgM2: { ixx: number; iyy: number; izz: number };
  dragCoefficient: number;
  frontalAreaM2: number;
  energyPenaltyWhPerKm: number;
  status: 'SIMULATED' | 'ESTIMATED' | 'CALIBRATED' | 'OBSERVED';
}

export interface PayloadItem {
  id: string;
  name: string;
  type: PayloadType;
  massKg: number;
  dimensions: Dimensions3D;
  centreOfGravity: Vector3D;
  bayPosition: Vector3D; // position inside the aircraft payload bay (mm)
  bayRotationDeg: number;
  constraints: PayloadConstraints;
  physics: PayloadPhysics;
  trackingId?: string;
  recipient?: string;
  destinationAddress?: string;
  destinationCoords?: { lat: number; lng: number; altM: number };
  deliveryState: DeliveryState;
  priority: 'ROUTINE' | 'HIGH' | 'EMERGENCY_CRITICAL';
  secured: boolean;
  loadedTimestamp?: number;
}

export interface PayloadModule {
  moduleId: string;
  name: string;
  type: ModuleType;
  dryMassKg: number;
  maxPayloadCapacityKg: number;
  maxVolumeLiters: number;
  installed: boolean;
  softwareVersion: string;
  calibrationDate: string;
  maintenanceState: 'OPTIMAL' | 'SERVICE_DUE' | 'CALIBRATION_REQUIRED';
  telemetry: {
    temperatureC: number;
    lockEngaged: boolean;
    doorClosed: boolean;
    pressureKpa?: number;
    flowRateLPerMin?: number;
    tankLevelPercent?: number;
    pumpActive?: boolean;
    sensorHealthPercent: number;
  };
}
