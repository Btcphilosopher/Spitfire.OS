import { Vector3D } from './payload.model';

export type DetectedObjectClass = 
  | 'BUILDING'
  | 'TREE'
  | 'POLE'
  | 'WIRE'
  | 'VEHICLE'
  | 'PERSON'
  | 'ROAD'
  | 'ROOF'
  | 'FIELD'
  | 'WATER'
  | 'LANDING_AREA'
  | 'PACKAGE_ZONE'
  | 'LIVESTOCK'
  | 'UNKNOWN_HAZARD';

export type DeliveryZoneClass = 
  | 'OPEN_GROUND'
  | 'ROOFTOP'
  | 'DESIGNATED_DROP_ZONE'
  | 'LANDING_PAD'
  | 'LOADING_BAY'
  | 'FARM_TRACK'
  | 'FIELD_EDGE'
  | 'WAREHOUSE_YARD';

export type PerceptionSensorSource = 
  | 'RGB_CAMERA_4K'
  | 'MULTISPECTRAL_4BAND'
  | 'THERMAL_IR_640'
  | 'LIDAR_SPATIAL_SCANNER'
  | 'SONAR_PROXIMITY'
  | 'RADAR_ALTIMETER'
  | 'SPATIAL_MEMORY_DB';

export type ObstacleAvoidanceRecommendation = 
  | 'HOLD'
  | 'BRAKE'
  | 'REROUTE'
  | 'ASCEND'
  | 'DESCEND'
  | 'RETURN'
  | 'ABORT'
  | 'CLEAR_TO_PROCEED';

export interface BoundingBox2D {
  xMinPct: number; // 0 to 100% of camera frame
  yMinPct: number;
  widthPct: number;
  heightPct: number;
}

export interface BoundingBox3D {
  min: Vector3D;
  max: Vector3D;
}

export interface DetectedObject {
  id: string;
  class: DetectedObjectClass;
  confidence: number; // 0.0 - 1.0
  source: PerceptionSensorSource;
  modelVersion: string;
  position: Vector3D; // relative to world or aircraft (m)
  dimensions: Vector3D; // width, length, height (m)
  velocity: Vector3D; // m/s
  predictedPositions: { tSec: number; pos: Vector3D }[]; // predicted future trajectory
  isDynamic: boolean;
  clearanceDistanceM: number;
  threatLevel: 'NONE' | 'CAUTION' | 'CRITICAL_COLLISION_RISK';
  boundingBox2D: BoundingBox2D;
  timestamp: number;
  lastSeenTime: number;
}

export interface DeliveryZoneCandidate {
  id: string;
  name: string;
  zoneClass: DeliveryZoneClass;
  coordinates: { x: number; y: number; z: number }; // m
  clearanceRadiusM: number;
  maxObstacleHeightAroundM: number;
  surfaceType: 'CONCRETE' | 'ASPHALT' | 'SHORT_GRASS' | 'GRAVEL' | 'SLOPE_EARTH' | 'UNEVEN_DECK';
  slopeDeg: number;
  mlConfidence: number;
  ruleSafetyScore: number; // 0-100
  peopleClearanceM: number;
  wiresDetectedNear: boolean;
  verdict: 'APPROVED_SAFE' | 'RESTRICTED_CAUTION' | 'REJECTED_UNSAFE';
  rejectionReason?: string;
}

export interface Waypoint {
  id: string;
  phase: 'TAKEOFF' | 'CRUISE' | 'APPROACH' | 'HOVER' | 'DESCENT' | 'DELIVERY' | 'ASCENT' | 'RETURN';
  position: Vector3D; // m
  speedTargetMs: number;
  headingDeg: number;
  hoverDurationSec?: number;
  deliveryActionRequired?: boolean;
}

export interface TrajectoryPlan {
  id: string;
  waypoints: Waypoint[];
  totalDistanceM: number;
  estimatedFlightTimeSec: number;
  energyRequiredWh: number;
  minClearanceMarginM: number;
  riskScore: number; // 0 to 100
  obstacleIntersections: number;
  status: 'VALIDATED_SAFE' | 'REROUTE_COMPUTING' | 'REJECTED_OBSTACLE_COLLISION' | 'DEGRADED_UNCERTAINTY';
}

export interface SpatialUncertaintyState {
  perceptionUncertaintyPct: number;
  spatialOccupancyVoxelCount: { free: number; occupied: number; dynamic: number; unknown: number; restricted: number };
  gnssVarianceM: number;
  windTurbulenceFactor: number;
  fogVisibilityM: number;
  activeAvoidanceState: ObstacleAvoidanceRecommendation;
  spatialAgeMs: number;
}
