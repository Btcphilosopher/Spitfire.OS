import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppActiveTab, SpitfireHeader } from './shared/components/spitfire-header';
import { DigitalTwin3d } from './features/digital-twin-3d/digital-twin-3d';
import { PayloadDesigner } from './features/payload-designer/payload-designer';
import { PerceptionPipeline } from './features/perception-pipeline/perception-pipeline';
import { CargoLogistics } from './features/cargo-logistics/cargo-logistics';
import { AgriPrecision } from './features/agri-precision/agri-precision';
import { FleetManagement } from './features/fleet-management/fleet-management';
import { PayloadLab } from './features/payload-lab/payload-lab';
import { MissionLogisticsService } from './core/services/mission-logistics.service';
import { SpatialPerceptionService } from './core/services/spatial-perception.service';
import { DetectedObject } from './core/models/spatial.model';
import { PayloadItem } from './core/models/payload.model';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    SpitfireHeader,
    DigitalTwin3d,
    PayloadDesigner,
    PerceptionPipeline,
    CargoLogistics,
    AgriPrecision,
    FleetManagement,
    PayloadLab
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col h-screen w-screen bg-[#101416] text-[#ECE9DF] select-none overflow-hidden font-sans">
      <!-- British Aerospace Master Header -->
      <app-spitfire-header
        [activeTab]="activeTab()"
        (tabSelected)="onTabChange($event)" />

      <!-- Main Workspace Area -->
      <main class="flex-1 min-h-0 relative overflow-hidden">
        @switch (activeTab()) {
          <!-- TAB 1: World & Digital Twin (Hero Screen) -->
          @case ('WORLD_TWIN') {
            <div class="w-full h-full p-3 grid grid-cols-1 lg:grid-cols-12 gap-3 overflow-hidden">
              <!-- 3D Viewport (8 Cols) -->
              <div class="lg:col-span-8 h-full flex flex-col min-h-[380px]">
                <app-digital-twin-3d
                  class="w-full flex-1"
                  (objectSelected)="onWorldObjectSelected($event)"
                  (payloadSelected)="onPayloadSelected($event)" />
              </div>

              <!-- Right Tactical Telemetry & World Inspector (4 Cols) -->
              <div class="lg:col-span-4 h-full flex flex-col gap-3 overflow-y-auto font-mono text-xs pr-1">
                <!-- Airframe Status Card -->
                <div class="bg-[#14181B] border border-[#252A2C] rounded-xl p-3.5 space-y-2.5">
                  <div class="flex items-center justify-between border-b border-[#252A2C] pb-2">
                    <span class="font-bold text-white flex items-center gap-1.5">
                      <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
                      SPITFIRE MK.IV HEAVY LIFT
                    </span>
                    <span class="text-[10px] text-[#C18D38] px-1.5 py-0.5 rounded bg-[#C18D38]/10 border border-[#C18D38]/30">ACTIVE</span>
                  </div>

                  <div class="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <div class="text-[9px] text-[#6D7474]">CURRENT PAYLOAD MODULE</div>
                      <div class="text-white font-bold">{{ activeModule().type }}</div>
                    </div>
                    <div>
                      <div class="text-[9px] text-[#6D7474]">TOTAL TAKEOFF MASS</div>
                      <div class="text-white font-bold">{{ cgResult().totalMassKg }} / 32.5 KG</div>
                    </div>
                    <div>
                      <div class="text-[9px] text-[#6D7474]">COMBINED CG STATUS</div>
                      <div class="font-bold" [class.text-emerald-400]="cgResult().isWithinEnvelope" [class.text-rose-400]="!cgResult().isWithinEnvelope">
                        {{ cgResult().statusLabel.replace('_', ' ') }}
                      </div>
                    </div>
                    <div>
                      <div class="text-[9px] text-[#6D7474]">CRUISE ENDURANCE</div>
                      <div class="text-cyan-400 font-bold">{{ energyResult().estimatedEnduranceMin }} MIN ({{ energyResult().estimatedMaxRangeKm }} KM)</div>
                    </div>
                  </div>
                </div>

                <!-- World Inspector (Raycast Selection) -->
                <div class="bg-[#14181B] border border-[#252A2C] rounded-xl p-3.5 space-y-2.5 flex-1">
                  <div class="flex items-center justify-between border-b border-[#252A2C] pb-1.5">
                    <span class="font-bold text-white">WORLD OBJECT INSPECTOR</span>
                    <span class="text-[10px] text-[#47728A]">CLICK 3D ENTITY</span>
                  </div>

                  @if (inspectedObject(); as obj) {
                    <div class="p-2.5 bg-[#101416] rounded-lg border border-[#47728A]/40 space-y-1.5 animate-fadeIn">
                      <div class="flex justify-between items-center">
                        <span class="font-bold text-white text-sm">{{ obj.id }}</span>
                        <span class="text-[10px] font-bold px-2 py-0.5 rounded bg-[#294A5A] text-cyan-300">
                          {{ obj.class }}
                        </span>
                      </div>

                      <div class="grid grid-cols-2 gap-2 text-[10px] text-[#B5B8B3] pt-1 border-t border-[#252A2C]">
                        <div>Confidence: <span class="text-white font-bold">{{ (obj.confidence * 100).toFixed(1) }}%</span></div>
                        <div>Clearance: <span class="text-amber-400 font-bold">{{ obj.clearanceDistanceM }}m</span></div>
                        <div>Position: ({{ obj.position.x }}m, {{ obj.position.y }}m)</div>
                        <div>Height: <span class="text-white">{{ obj.dimensions.z }}m</span></div>
                        <div>Sensor Source: {{ obj.source }}</div>
                        <div>Threat: <span [class.text-rose-400]="obj.threatLevel !== 'NONE'">{{ obj.threatLevel }}</span></div>
                      </div>
                    </div>
                  } @else {
                    <div class="p-4 text-center text-[#6D7474] text-xs">
                      Click any 3D building, tree, vehicle, wire, or landing pad to inspect spatial attributes.
                    </div>
                  }

                  <!-- Quick System Reasoning Summary -->
                  <div class="pt-2 border-t border-[#252A2C] space-y-1 text-[11px]">
                    <div class="text-[#6D7474] uppercase text-[9px] font-bold">Autonomous Spatial Decision</div>
                    <div class="text-[#ECE9DF] leading-relaxed">
                      All delivery corridors verified. 0 active collisions predicted along 10-waypoint trajectory. CAA simulated envelope approved.
                    </div>
                  </div>
                </div>
              </div>
            </div>
          }

          <!-- TAB 2: Payload Designer & Fit -->
          @case ('PAYLOAD_DESIGNER') {
            <app-payload-designer class="w-full h-full block" />
          }

          <!-- TAB 3: Perception & "What Does Drone See" -->
          @case ('PERCEPTION_PIPELINE') {
            <app-perception-pipeline class="w-full h-full block" />
          }

          <!-- TAB 4: Cargo & Postal Logistics -->
          @case ('CARGO_LOGISTICS') {
            <app-cargo-logistics class="w-full h-full block" />
          }

          <!-- TAB 5: Spitfire Agri Precision -->
          @case ('AGRI_PRECISION') {
            <app-agri-precision class="w-full h-full block" />
          }

          <!-- TAB 6: Fleet Operations -->
          @case ('FLEET_OPERATIONS') {
            <app-fleet-management class="w-full h-full block" />
          }

          <!-- TAB 7: Payload Lab & Replay -->
          @case ('PAYLOAD_LAB') {
            <app-payload-lab class="w-full h-full block" />
          }
        }
      </main>
    </div>
  `
})
export class App {
  private readonly logistics = inject(MissionLogisticsService);
  private readonly spatial = inject(SpatialPerceptionService);

  readonly activeTab = signal<AppActiveTab>('WORLD_TWIN');
  readonly inspectedObject = signal<DetectedObject | null>(this.spatial.detectedObjects()[0] || null);

  readonly activeModule = this.logistics.activeModule;
  readonly cgResult = this.logistics.currentCGResult;
  readonly energyResult = this.logistics.currentEnergyEstimate;

  onTabChange(tab: AppActiveTab) {
    this.activeTab.set(tab);
  }

  onWorldObjectSelected(obj: DetectedObject | null) {
    if (obj) {
      this.inspectedObject.set(obj);
    }
  }

  onPayloadSelected(payload: PayloadItem | null) {
    if (payload) {
      this.activeTab.set('PAYLOAD_DESIGNER');
    }
  }
}
