import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';

export type AppActiveTab = 
  | 'WORLD_TWIN'
  | 'PAYLOAD_DESIGNER'
  | 'PERCEPTION_PIPELINE'
  | 'CARGO_LOGISTICS'
  | 'AGRI_PRECISION'
  | 'FLEET_OPERATIONS'
  | 'PAYLOAD_LAB';

@Component({
  selector: 'app-spitfire-header',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="w-full bg-[#101416] border-b border-[#252A2C] px-4 py-2.5 flex flex-col gap-2">
      <!-- Top Row: Spitfire Aerospace Title & Regulatory Simulation Badge -->
      <div class="flex items-center justify-between flex-wrap gap-3">
        <!-- Title & Brand -->
        <div class="flex items-center gap-3">
          <div class="w-9 h-9 rounded-lg bg-[#294A5A] border border-[#47728A] flex items-center justify-center font-black text-white text-base tracking-tighter shadow-md">
            SP
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h1 class="text-base font-bold tracking-wider text-white font-mono uppercase">SPITFIRE PAYLOAD</h1>
              <span class="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#252A2C] text-[#B5B8B3] border border-[#6D7474]/40">v4.8-PRO</span>
              <span class="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#4F6048]/30 text-[#65784F] border border-[#65784F]/50">BRITISH AUTONOMOUS AIRFRAME</span>
            </div>
            <p class="text-[11px] text-[#6D7474] font-mono">AUTONOMOUS DRONE CARGO, DISPENSING & SPATIAL INTELLIGENCE PLATFORM</p>
          </div>
        </div>

        <!-- Prominent Simulation Mode Indicator & Regulatory Boundary Notice -->
        <div class="flex items-center gap-3">
          <div class="bg-[#A5463E]/15 border border-[#A5463E]/50 px-3 py-1.5 rounded-lg flex items-center gap-2.5">
            <span class="w-2.5 h-2.5 rounded-full bg-[#A5463E] animate-pulse"></span>
            <div>
              <div class="text-[11px] font-mono font-bold text-[#A5463E] tracking-wider">SIMULATION & DECISION-SUPPORT MODE</div>
              <div class="text-[9px] text-[#B5B8B3] font-mono leading-tight">
                UK CAA Operational Authorisation Required for BVLOS & Article Dropping. No real-world actuator link.
              </div>
            </div>
          </div>

          <!-- Seed & Telemetry Health -->
          <div class="hidden lg:flex items-center gap-2 bg-[#14181B] border border-[#252A2C] px-3 py-1.5 rounded-lg font-mono text-[11px]">
            <div class="text-[#6D7474]">SEED: <span class="text-[#ECE9DF] font-semibold">SPITFIRE-2026</span></div>
            <div class="w-px h-4 bg-[#252A2C]"></div>
            <div class="flex items-center gap-1.5 text-emerald-400">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              <span>RTK-GNSS LOCK (26 SAT)</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Bottom Row: Navigation Tabs -->
      <nav class="flex items-center gap-1 overflow-x-auto border-t border-[#252A2C]/60 pt-2 pb-0.5 text-xs font-mono scrollbar-none">
        <button
          type="button"
          (click)="tabSelected.emit('WORLD_TWIN')"
          [class.bg-[#294A5A]]="activeTab() === 'WORLD_TWIN'"
          [class.text-white]="activeTab() === 'WORLD_TWIN'"
          [class.border-[#47728A]]="activeTab() === 'WORLD_TWIN'"
          class="px-3 py-1.5 rounded-lg border border-transparent text-[#B5B8B3] hover:bg-[#252A2C] hover:text-white transition-all flex items-center gap-1.5 whitespace-nowrap">
          <span class="material-icons text-sm">public</span>
          <span>1. WORLD & DIGITAL TWIN</span>
        </button>

        <button
          type="button"
          (click)="tabSelected.emit('PAYLOAD_DESIGNER')"
          [class.bg-[#294A5A]]="activeTab() === 'PAYLOAD_DESIGNER'"
          [class.text-white]="activeTab() === 'PAYLOAD_DESIGNER'"
          [class.border-[#47728A]]="activeTab() === 'PAYLOAD_DESIGNER'"
          class="px-3 py-1.5 rounded-lg border border-transparent text-[#B5B8B3] hover:bg-[#252A2C] hover:text-white transition-all flex items-center gap-1.5 whitespace-nowrap">
          <span class="material-icons text-sm">view_in_ar</span>
          <span>2. PAYLOAD DESIGNER & FIT</span>
        </button>

        <button
          type="button"
          (click)="tabSelected.emit('PERCEPTION_PIPELINE')"
          [class.bg-[#294A5A]]="activeTab() === 'PERCEPTION_PIPELINE'"
          [class.text-white]="activeTab() === 'PERCEPTION_PIPELINE'"
          [class.border-[#47728A]]="activeTab() === 'PERCEPTION_PIPELINE'"
          class="px-3 py-1.5 rounded-lg border border-transparent text-[#B5B8B3] hover:bg-[#252A2C] hover:text-white transition-all flex items-center gap-1.5 whitespace-nowrap">
          <span class="material-icons text-sm">visibility</span>
          <span>3. PERCEPTION & "WHAT DRONE SEES"</span>
        </button>

        <button
          type="button"
          (click)="tabSelected.emit('CARGO_LOGISTICS')"
          [class.bg-[#294A5A]]="activeTab() === 'CARGO_LOGISTICS'"
          [class.text-white]="activeTab() === 'CARGO_LOGISTICS'"
          [class.border-[#47728A]]="activeTab() === 'CARGO_LOGISTICS'"
          class="px-3 py-1.5 rounded-lg border border-transparent text-[#B5B8B3] hover:bg-[#252A2C] hover:text-white transition-all flex items-center gap-1.5 whitespace-nowrap">
          <span class="material-icons text-sm">local_shipping</span>
          <span>4. CARGO & POSTAL LOGISTICS</span>
        </button>

        <button
          type="button"
          (click)="tabSelected.emit('AGRI_PRECISION')"
          [class.bg-[#294A5A]]="activeTab() === 'AGRI_PRECISION'"
          [class.text-white]="activeTab() === 'AGRI_PRECISION'"
          [class.border-[#47728A]]="activeTab() === 'AGRI_PRECISION'"
          class="px-3 py-1.5 rounded-lg border border-transparent text-[#B5B8B3] hover:bg-[#252A2C] hover:text-white transition-all flex items-center gap-1.5 whitespace-nowrap">
          <span class="material-icons text-sm">agriculture</span>
          <span>5. SPITFIRE AGRI PRECISION</span>
        </button>

        <button
          type="button"
          (click)="tabSelected.emit('FLEET_OPERATIONS')"
          [class.bg-[#294A5A]]="activeTab() === 'FLEET_OPERATIONS'"
          [class.text-white]="activeTab() === 'FLEET_OPERATIONS'"
          [class.border-[#47728A]]="activeTab() === 'FLEET_OPERATIONS'"
          class="px-3 py-1.5 rounded-lg border border-transparent text-[#B5B8B3] hover:bg-[#252A2C] hover:text-white transition-all flex items-center gap-1.5 whitespace-nowrap">
          <span class="material-icons text-sm">flight</span>
          <span>6. FLEET OPERATIONS</span>
        </button>

        <button
          type="button"
          (click)="tabSelected.emit('PAYLOAD_LAB')"
          [class.bg-[#294A5A]]="activeTab() === 'PAYLOAD_LAB'"
          [class.text-white]="activeTab() === 'PAYLOAD_LAB'"
          [class.border-[#47728A]]="activeTab() === 'PAYLOAD_LAB'"
          class="px-3 py-1.5 rounded-lg border border-transparent text-[#B5B8B3] hover:bg-[#252A2C] hover:text-white transition-all flex items-center gap-1.5 whitespace-nowrap">
          <span class="material-icons text-sm">science</span>
          <span>7. PAYLOAD LAB & REPLAY</span>
        </button>
      </nav>
    </header>
  `
})
export class SpitfireHeader {
  readonly activeTab = input.required<AppActiveTab>();
  readonly tabSelected = output<AppActiveTab>();
}
