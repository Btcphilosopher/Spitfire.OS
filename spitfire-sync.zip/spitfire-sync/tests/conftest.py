from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from spitfire_sync.config import ScenarioFile, SimulationConfig, SiteConfig, SpitfireConfig  # noqa: E402
from spitfire_sync.models.geometry import NavigationFrame, Vec3  # noqa: E402
from spitfire_sync.models.state import (  # noqa: E402
    AgentStatus,
    ArmedStatus,
    BatteryState,
    DroneState,
    FlightMode,
)


def small_site() -> SiteConfig:
    """A compact 4-aircraft site for fast integration tests."""
    return SiteConfig(
        name="Test Paddock (fictional)",
        field_vertices=[(0.0, 0.0), (260.0, 0.0), (260.0, 160.0), (0.0, 160.0)],
        exclusion_zones=[{"zone_id": "shed", "vertices": [(110.0, 70.0), (150.0, 70.0), (150.0, 100.0),
                                                         (110.0, 100.0)]}],
        launch_origin=(-30.0, -60.0), launch_spacing_m=30.0, recovery_centre=(150.0, -70.0),
        boundary_margin_m=120.0,
    )


def small_scenario(seed: int = 7, **sim_updates) -> ScenarioFile:  # type: ignore[no-untyped-def]
    sim = SimulationConfig(seed=seed, n_drones=4, duration_limit_s=900.0, site=small_site(), randomise=True)
    sim = SimulationConfig.model_validate({**sim.model_dump(), **sim_updates})
    return ScenarioFile(system=SpitfireConfig(), simulation=sim)


@pytest.fixture
def scenario_small() -> ScenarioFile:
    return small_scenario()


def make_state(drone: str = "drone-01", boot: str = "b0", seq: int = 1, t: float = 100.0,
               pos: tuple[float, float, float] = (0.0, 0.0, 30.0), vel: tuple[float, float, float] = (0.0, 0.0, 0.0),
               unc: float = 2.0, frame: NavigationFrame = NavigationFrame.ENU, clock_unc: float = 0.01,
               status: AgentStatus = AgentStatus.EXECUTING) -> DroneState:
    p = Vec3(x=pos[0], y=pos[1], z=pos[2], frame=frame)
    v = Vec3(x=vel[0], y=vel[1], z=vel[2], frame=frame)
    return DroneState(drone_id=drone, boot_id=boot, sequence_number=seq, observation_time=t,
                      observation_time_uncertainty=clock_unc, position=p, velocity=v, position_uncertainty=unc,
                      navigation_frame=frame, battery_state=BatteryState(remaining_fraction=0.8,
                                                                          remaining_energy_wh=48.0),
                      flight_mode=FlightMode.OFFBOARD, armed_status=ArmedStatus.ARMED, agent_status=status)
