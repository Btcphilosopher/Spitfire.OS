"""Crossing trajectories, segment-level detection, reservations, hold points, scheduling resolution."""

import numpy as np
from conftest import small_scenario

from spitfire_sync.config import KinematicLimits, SeparationConfig, SpitfireConfig
from spitfire_sync.models.geometry import Vec3
from spitfire_sync.models.trajectory import (
    ConflictKind,
    EndBehaviour,
    Phase,
    Reservation,
    ReservationKind,
    Trajectory,
    Volume,
    VolumeKind,
)
from spitfire_sync.scheduling import Leg, Scheduler, StartState, TrajectoryBuilder
from spitfire_sync.scheduling.scheduler import DroneRequest, EndKind, EndSpec
from spitfire_sync.separation import Buffers, ConflictChecker, HoldPointChecker, ReservationTable
from spitfire_sync.simulation.scenario import build_mission, fleet_config

SEP = SeparationConfig(horizontal_m=15.0, vertical_m=8.0)
ZERO = Buffers(0.0, 0.0)


def line(drone, p0, p1, t0, t1, n=2):  # type: ignore[no-untyped-def]
    ts = np.linspace(t0, t1, n)
    P = np.linspace(p0, p1, n)
    return Trajectory(drone_id=drone, t=ts.tolist(), x=P[:, 0].tolist(), y=P[:, 1].tolist(), z=P[:, 2].tolist(),
                      phase=[Phase.TRANSIT] * n, task=[None] * n, end_behaviour=EndBehaviour.LANDED)


def test_crossing_detected_between_sampled_waypoints():
    # Two aircraft cross at (100, 100) at t=10.  Only end points are sampled: a
    # point-by-point check at the samples (t=0, t=20) would see 140+ m.
    a = line("a", (0, 100, 50), (200, 100, 50), 0, 20)
    b = line("b", (100, 0, 50), (100, 200, 50), 0, 20)
    pts = np.linalg.norm(a.arrays()[1] - b.arrays()[1], axis=1)
    assert pts.min() > 140
    c = ConflictChecker(SEP).pair(a, b, ZERO, ZERO)
    assert len(c) == 1
    assert c[0].kind == ConflictKind.TRAJECTORY_PAIR
    # 15 m required at a closing speed of 14.14 m/s => conflict from ~8.94 s to ~11.06 s
    assert abs(c[0].t_start - (10 - 15 / (10 * 2 ** 0.5))) < 0.01
    assert abs(c[0].t_end - (10 + 15 / (10 * 2 ** 0.5))) < 0.01
    assert c[0].min_horizontal_m < 1.0


def test_time_separated_crossing_is_not_a_conflict():
    a = line("a", (0, 100, 50), (200, 100, 50), 0, 20)
    b = line("b", (100, 0, 50), (100, 200, 50), 30, 50)
    assert ConflictChecker(SEP).pair(a, b, ZERO, ZERO) == []


def test_vertical_separation_resolves_crossing():
    a = line("a", (0, 100, 50), (200, 100, 50), 0, 20)
    b = line("b", (100, 0, 62), (100, 200, 62), 0, 20)
    assert ConflictChecker(SEP).pair(a, b, ZERO, ZERO) == []
    # ... unless buffers (position/timing uncertainty) eat into the vertical margin
    assert ConflictChecker(SEP).pair(a, b, Buffers(2.5, 0.0), Buffers(2.5, 0.0))


def test_timing_uncertainty_buffer_widens_required_separation():
    # parallel lanes 30 m apart: fine with no uncertainty, conflict with 2 s timing uncertainty at 10 m/s
    a = line("a", (0, 0, 50), (200, 0, 50), 0, 20)
    b = line("b", (0, 30, 50), (200, 30, 50), 0, 20)
    chk = ConflictChecker(SEP)
    assert chk.pair(a, b, ZERO, ZERO) == []
    assert chk.pair(a, b, Buffers(0.0, 1.0), Buffers(0.0, 1.0))


def test_ground_positions_ignored_and_landed_aircraft_not_airborne():
    a = line("a", (0, 0, 0), (0, 0, 0), 0, 20)
    b = line("b", (5, 0, 0), (5, 0, 0), 0, 20)
    assert ConflictChecker(SEP).pair(a, b, ZERO, ZERO) == []


def test_reservation_conflict_in_shared_recovery_area_and_slot_sequencing():
    vol = Volume(kind=VolumeKind.CYLINDER, points=[(0.0, 0.0)], radius_m=20.0, z_min=0.0, z_max=25.0)
    r1 = Reservation(reservation_id="rec/a", holder="a", kind=ReservationKind.RECOVERY_AREA, volume=vol,
                     t_start=10.0, t_end=40.0, resource="recovery")
    descend_b = line("b", (5, 0, 60), (5, 0, 0), 20, 50, n=31)
    rep = ConflictChecker(SEP).reservations(descend_b, [r1], ZERO)
    assert rep and rep[0].kind == ConflictKind.RESERVATION
    table = ReservationTable()
    table.add(r1)
    assert table.free_slot("recovery", earliest=15.0, duration=20.0, capacity=1) == 40.0
    late = line("b", (5, 0, 60), (5, 0, 0), 25, 55, n=31)  # reaches 25 m only after t=40
    assert ConflictChecker(SEP).reservations(late, [r1], ZERO) == []


def test_hold_point_shared_by_two_aircraft_is_rejected():
    chk = ConflictChecker(SEP)
    hp = HoldPointChecker(chk, SEP)
    other = {"b": Vec3.enu(100.0, 100.0, 90.0)}
    res = hp.check("a", Vec3.enu(102.0, 100.0, 92.0), 0.0, 100.0, {}, other, [])
    assert not res.safe
    assert hp.check("a", Vec3.enu(160.0, 100.0, 92.0), 0.0, 100.0, {}, other, []).safe


def test_hold_point_on_another_aircrafts_path_is_rejected():
    chk = ConflictChecker(SEP)
    hp = HoldPointChecker(chk, SEP)
    path = {"b": line("b", (0, 0, 90), (400, 0, 90), 0, 40, n=41)}
    assert not hp.check("a", Vec3.enu(200.0, 0.0, 90.0), 0.0, 100.0, path, {}, []).safe
    assert hp.check("a", Vec3.enu(200.0, 80.0, 90.0), 0.0, 100.0, path, {}, []).safe


def test_trajectory_builder_respects_limits():
    lim = KinematicLimits(max_speed_m_s=12.0, max_accel_m_s2=2.0, max_climb_m_s=3.0, max_descent_m_s=2.0)
    b = TrajectoryBuilder(lim)
    tr = b.build("a", (0, 0, 0), 0.0, [Leg((0, 0, 60), 10, Phase.TAKEOFF), Leg((300, 0, 60), 12, Phase.TRANSIT),
                                       Leg((300, 0, 10), 10, Phase.LANDING)])
    T, P = tr.arrays()
    v = np.diff(P, axis=0) / np.diff(T)[:, None]
    assert np.linalg.norm(v[:, :2], axis=1).max() <= 12.0 + 1e-6
    assert v[:, 2].max() <= 3.0 + 1e-6 and -v[:, 2].min() <= 2.0 + 1e-6
    a = np.diff(v[:, 0]) / np.diff(T)[1:]
    assert np.abs(a).max() <= 2.0 * 1.2  # sampled-profile acceleration within limit (+chord tolerance)


def test_scheduler_resolves_head_on_conflict_by_delay_or_band():
    sc = small_scenario()
    system = fleet_config(sc.simulation, sc.system)
    mission = build_mission(sc.simulation, system)
    chk = ConflictChecker(system.separation, mission)
    sch = Scheduler(mission, system, chk)
    # two aircraft fly the same lane in opposite directions at the same time
    lane = mission.tasks[0]
    starts = {d: mission.pad(d).position for d in ("drone-01", "drone-02")}
    reqs = [DroneRequest(d, StartState((p.x, p.y, 0.0), 10.0, True, "b"), [(lane, d == "drone-02")],
                         EndSpec(EndKind.HOLD, (-60.0 if d == "drone-01" else 330.0, 200.0, 80.0 if d == "drone-01"
                                                else 86.0)), None) for d, p in starts.items()]
    buffers = sch.buffers_for(None, ["drone-01", "drone-02"])
    scheduled, failed = sch.schedule_requests(reqs, {}, [], buffers)
    assert not failed
    rep = chk.check({d: s.trajectory for d, s in scheduled.items()}, buffers=buffers)
    assert rep.ok
    assert scheduled["drone-02"].resolution.value.startswith("RESOLVED_BY")


def test_static_exclusion_zone_check():
    sc = small_scenario()
    system = fleet_config(sc.simulation, sc.system)
    mission = build_mission(sc.simulation, system)
    chk = ConflictChecker(system.separation, mission)
    through_shed = line("a", (60, 85, 35), (200, 85, 35), 0, 20, n=40)
    rep = chk.static(through_shed, Buffers.from_config(system.separation))
    assert any(c.kind == ConflictKind.EXCLUSION_ZONE for c in rep)
    assert any(t for t in mission.tasks if t.task_id.endswith("a"))  # lanes were split around the shed
