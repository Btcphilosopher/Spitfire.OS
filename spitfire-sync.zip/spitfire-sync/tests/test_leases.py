import pytest

from spitfire_sync.config import LeaseConfig
from spitfire_sync.coordination.leases import AgentLeaseTable, LeaseManager
from spitfire_sync.models.commands import LeaseState
from spitfire_sync.reasons import ReasonCode

CFG = LeaseConfig(duration_s=10.0, renew_interval_s=3.0, renewal_validity_s=4.0, expiry_margin_s=1.5,
                  onboard_safety_margin_s=0.5)


def test_one_authoritative_owner_per_task():
    lm = LeaseManager(CFG, epoch=2)
    lm.grant("L1", "d1", "b1", 1, now=0.0)
    ok, why = lm.can_grant("L1", "d2")
    assert not ok and why == ReasonCode.LEASE_ACTIVE_ELSEWHERE
    with pytest.raises(PermissionError):
        lm.grant("L1", "d2", "b2", 1, now=1.0)
    assert lm.owner("L1") == "d1"


def test_lease_expiry_includes_margin_and_clock_uncertainty():
    lm = LeaseManager(CFG, epoch=2)
    lz = lm.grant("L1", "d1", "b1", 1, now=0.0)
    lm.max_clock_uncertainty = 0.4
    assert lm.tick(10.0 + 1.5 + 0.3) == []  # still possibly active
    exp = lm.tick(10.0 + 1.5 + 0.5)
    assert [r.lease.lease_id for r in exp] == [lz.lease_id]
    assert lm.get(lz.lease_id).state == LeaseState.EXPIRED
    assert lm.can_grant("L1", "d2")[0]


def test_revoked_lease_blocks_reassignment_until_expiry():
    lm = LeaseManager(CFG, epoch=2)
    lz = lm.grant("L1", "d1", "b1", 1, now=0.0)
    lm.revoke(lz.lease_id, now=2.0)
    assert not lm.can_grant("L1", "d2")[0]  # holder may not have received the revocation
    assert lm.renew(lz.lease_id, 3.0) is None  # revoked leases are not renewed
    lm.tick(12.0)
    assert lm.can_grant("L1", "d2")[0]


def test_remainder_requires_parent_ownership_resolution():
    lm = LeaseManager(CFG, epoch=2)
    lz = lm.grant("L1", "d1", "b1", 1, now=0.0)
    lm.register_parent("L1.r1", "L1")
    ok, why = lm.can_grant("L1.r1", "d2")
    assert not ok and why == ReasonCode.PARENT_OWNERSHIP_UNRESOLVED
    # the same holder may continue its own remainder (supersedes its parent lease)
    assert lm.can_grant("L1.r1", "d1")[0]
    lm.release(lz.lease_id, now=5.0)  # authoritative release by the holder
    assert lm.can_grant("L1.r1", "d2")[0]


def test_renewal_extends_and_release_is_terminal():
    lm = LeaseManager(CFG, epoch=2)
    lz = lm.grant("L1", "d1", "b1", 1, now=0.0)
    new = lm.renew(lz.lease_id, 8.0)
    assert new.expires_at == 18.0
    assert lm.release(lz.lease_id, 9.0)
    assert not lm.release(lz.lease_id, 9.5)
    assert lm.tick(100.0) == []


def test_agent_side_validity_uses_latest_time_bound_boot_and_epoch():
    lm = LeaseManager(CFG, epoch=2)
    lz = lm.grant("L1", "d1", "boot-A", 1, now=0.0)
    t = AgentLeaseTable(CFG)
    assert t.add(lz, "boot-B", 2) == ReasonCode.WRONG_BOOT_ID
    assert t.add(lz, "boot-A", 3) == ReasonCode.STALE_EPOCH
    assert t.add(lz, "boot-A", 2) == ReasonCode.OK
    assert t.valid("L1", 9.4, "boot-A", 2)[0]
    ok, why = t.valid("L1", 9.6, "boot-A", 2)  # stops onboard_safety_margin before expiry
    assert not ok and why == ReasonCode.LEASE_EXPIRED
    assert t.valid("L1", 5.0, "boot-A", 3)[1] == ReasonCode.STALE_EPOCH  # new coordinator epoch
    assert t.renew(lz.lease_id, 20.0, "boot-A") == ReasonCode.OK
    assert t.valid("L1", 15.0, "boot-A", 2)[0]
