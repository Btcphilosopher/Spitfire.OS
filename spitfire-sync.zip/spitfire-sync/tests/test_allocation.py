from conftest import small_scenario

from spitfire_sync.allocation import CostModel, DroneCommitment, GreedyAllocator, OptimisingAllocator
from spitfire_sync.models.geometry import Vec3
from spitfire_sync.models.state import (
    AgentStatus,
    BatteryState,
    EstimatedDroneState,
    FleetSnapshot,
    FleetUncertainty,
    Freshness,
)
from spitfire_sync.reasons import ReasonCode
from spitfire_sync.scheduling.routing import Router
from spitfire_sync.simulation.scenario import build_mission, fleet_config


def setup(energy=60.0, stale=()):  # type: ignore[no-untyped-def]
    sc = small_scenario()
    system = fleet_config(sc.simulation, sc.system)
    m = build_mission(sc.simulation, system)
    ids = [p.drone_id for p in system.fleet]
    drones = {}
    for d in ids:
        p = m.pad(d).position
        drones[d] = EstimatedDroneState(
            drone_id=d, boot_id="b", freshness=Freshness.STALE if d in stale else Freshness.FRESH, as_of=0.0,
            last_observation_time=0.0, age_s=0.0, observed_position=p, position=p, velocity=Vec3.enu(0, 0, 0),
            position_uncertainty=2.0, predicted=True, prediction_valid_until=2.0, assessable=True,
            clock_uncertainty=0.01, battery_state=BatteryState(remaining_fraction=energy / 60, remaining_energy_wh=energy),
            agent_status=AgentStatus.IDLE)
    snap = FleetSnapshot(as_of=0.0, drones=drones, uncertainty=FleetUncertainty(
        max_position_uncertainty=2, max_clock_uncertainty=0.01, position_uncertainty={d: 2.0 for d in ids},
        clock_uncertainty={d: 0.01 for d in ids}))
    profiles = {p.drone_id: p for p in system.fleet}
    cm = CostModel(m, system.allocation, system.constraints, profiles, Router(m, 12.5))
    com = {d: DroneCommitment(d, (drones[d].position.x, drones[d].position.y, 0.0), 0.0,
                              energy - system.constraints.reserve_fraction * 60, True) for d in ids}
    return m, snap, system, cm, com


def test_greedy_is_deterministic_and_assigns_each_task_once():
    m, snap, system, cm, com = setup()
    a1 = GreedyAllocator(cm).assign(m.tasks, snap, system.constraints, com)
    a2 = GreedyAllocator(cm).assign(m.tasks, snap, system.constraints, com)
    assert a1.per_drone == a2.per_drone
    ids = a1.task_ids()
    assert sorted(ids) == sorted(t.task_id for t in m.tasks)
    assert len(ids) == len(set(ids))  # no duplicated work


def test_payload_compatibility_respected():
    m, snap, system, cm, com = setup()
    a = GreedyAllocator(cm).assign(m.tasks, snap, system.constraints, com)
    payloads = {p.drone_id: p.payloads for p in system.fleet}
    tasks = {t.task_id: t for t in m.tasks}
    for d, lst in a.per_drone.items():
        for x in lst:
            assert tasks[x.task_id].payload_required in payloads[d]


def test_battery_reserve_makes_assignment_infeasible():
    m, snap, system, cm, com = setup(energy=16.0)  # barely above the 15 Wh reserve
    a = GreedyAllocator(cm).assign(m.tasks, snap, system.constraints, com)
    assert not a.task_ids()
    assert set(a.unassigned.values()) == {ReasonCode.BATTERY_RESERVE_INSUFFICIENT}


def test_unavailable_aircraft_excluded():
    m, snap, system, cm, com = setup(stale=("drone-01",))
    a = GreedyAllocator(cm).assign(m.tasks, snap, system.constraints, com)
    assert "drone-01" not in a.per_drone and a.excluded_drones["drone-01"] == ReasonCode.AIRCRAFT_NOT_AVAILABLE


def test_optimiser_assigns_everything_with_no_worse_makespan_estimate():
    m, snap, system, cm, com = setup()
    g = GreedyAllocator(cm).assign(m.tasks, snap, system.constraints, com)
    o = OptimisingAllocator(cm).assign(m.tasks, snap, system.constraints, com)
    assert sorted(o.task_ids()) == sorted(g.task_ids())
    assert o.makespan_estimate_s <= g.makespan_estimate_s * 1.05
