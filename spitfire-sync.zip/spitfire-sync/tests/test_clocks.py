import asyncio

import numpy as np

from spitfire_sync.clocks import ClockSyncEstimator, CoordinationTimescale, SimulatedClock, Timebase, run_virtual
from spitfire_sync.clocks.clock import MessageAge, TimeEstimate
from spitfire_sync.reasons import ReasonCode


def test_virtual_loop_runs_hours_instantly_and_in_order():
    async def main():
        loop = asyncio.get_running_loop()
        order = []

        async def w(d, n):
            await asyncio.sleep(d)
            order.append((n, loop.time()))

        await asyncio.gather(w(3600, "b"), w(5, "a"), w(7200, "c"))
        return order

    out = run_virtual(main)
    assert [n for n, _ in out] == ["a", "b", "c"]
    assert out[-1][1] == 7200.0


def _exchanges(drift_ppm, offset, n=40, rng_seed=0, base_delay=0.03, jitter=0.02, asym=0.0):
    """Simulate NTP-style exchanges between a reference clock (true time) and a
    drifting local clock: local = (t - t0) * (1 + drift) + offset."""
    rng = np.random.default_rng(rng_seed)
    rho = drift_ppm * 1e-6
    est = ClockSyncEstimator(max_relative_drift_ppm=200)
    t = 1000.0
    for _ in range(n):
        d1 = base_delay + rng.exponential(jitter) + asym
        d2 = base_delay + rng.exponential(jitter)
        t1_true = t
        t2 = t1_true + d1
        t3 = t2 + 0.001
        t4_true = t3 + d2
        local = lambda tt: tt * (1 + rho) + offset  # noqa: E731
        est.add_exchange(local(t1_true), t2, t3, local(t4_true), "ref-A")
        t += 2.0
    return est, local, t


def test_offset_estimate_bound_contains_truth_with_drift_and_asymmetry():
    for drift in (-80.0, 0.0, 120.0):
        est, local, t = _exchanges(drift, offset=-3456.7, asym=0.04)
        now_local = local(t)
        e = est.estimate(now_local)
        true_offset = t - now_local
        assert e.synchronised
        assert abs(e.offset - true_offset) <= e.uncertainty + 1e-9  # rigorous bound holds
        assert e.uncertainty < 0.06  # a few tens of ms with ~30 ms one-way delays


def test_uncertainty_grows_with_age_since_last_sample():
    est, local, t = _exchanges(50.0, offset=10.0)
    u0 = est.estimate(local(t)).uncertainty
    u1 = est.estimate(local(t + 600.0)).uncertainty
    assert u1 > u0 + 0.1  # 200 ppm x 600 s = 0.12 s


def test_timestamp_jump_is_detected_and_estimator_restarts():
    est, local, t = _exchanges(0.0, offset=0.0)
    # the reference timescale steps by +2 s (e.g. a bad correction upstream)
    t1 = local(t)
    upd = est.add_exchange(t1, t + 2.03, t + 2.031, local(t + 0.06), "ref-A")
    assert upd.jump_detected
    assert ReasonCode.CLOCK_JUMP_DETECTED in upd.reasons
    assert est.estimate(local(t + 0.06)).samples == 1


def test_reference_change_resets_sync():
    est, local, t = _exchanges(0.0, offset=0.0)
    upd = est.add_exchange(local(t), t + 0.03, t + 0.031, local(t + 0.06), "ref-B")
    assert ReasonCode.CLOCK_REFERENCE_CHANGED in upd.reasons
    assert est.estimate(local(t + 0.06)).samples == 1


def test_unsynchronised_estimator_reports_infinite_uncertainty():
    e = ClockSyncEstimator().estimate(5.0)
    assert not e.synchronised and e.uncertainty == float("inf")


def test_simulated_clock_drift_utc_jump_and_reboot():
    async def main():
        tb = Timebase()
        c = SimulatedClock(tb, "n1", drift_ppm=100.0, mono_offset=50.0)
        ts = CoordinationTimescale(c, epoch=1)
        m0, coord0, utc0 = c.monotonic(), ts.now(), c.utc()
        await asyncio.sleep(1000.0)
        dm = c.monotonic() - m0
        assert abs(dm - 1000.0 * (1 + 100e-6)) < 1e-6  # drift
        # a UTC step does not move monotonic time or the coordination timescale
        before = ts.now()
        c.inject_utc_jump(+37.0)
        assert abs(ts.now() - before) < 1e-9
        assert c.utc() - utc0 > 1036.0
        old_boot = c.boot_id
        c.reboot(new_mono_offset=0.0)
        assert c.boot_id != old_boot
        assert c.monotonic() < 1.0  # monotonic restarts after reboot
        return coord0

    run_virtual(main)


def test_message_age_combines_uncertainties():
    age = MessageAge.compute(TimeEstimate(100.0, 0.02), issued_at=99.5, sender_uncertainty=0.03)
    assert abs(age.age_s - 0.5) < 1e-12
    assert abs(age.uncertainty_s - 0.05) < 1e-12
    assert abs(age.max_age_s - 0.55) < 1e-12
