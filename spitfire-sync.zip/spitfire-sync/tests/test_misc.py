import numpy as np
from conftest import small_scenario

from spitfire_sync.allocation.energy import EnergyModel
from spitfire_sync.config import EnergyModelConfig, FreshnessPolicy
from spitfire_sync.models.geometry import Vec3
from spitfire_sync.models.state import AgentStatus, EstimatedDroneState, Freshness
from spitfire_sync.models.trajectory import Phase, Trajectory
from spitfire_sync.separation import contract_region, kinematic_region
from spitfire_sync.simulation.simulator import run_realtime


def est(age: float) -> EstimatedDroneState:
    p = Vec3.enu(100.0, 100.0, 40.0)
    return EstimatedDroneState(drone_id="d", boot_id="b", freshness=Freshness.LOST, as_of=100.0 + age,
                               last_observation_time=100.0, age_s=age, observed_position=p, position=p,
                               velocity=Vec3.enu(0, 0, 0), position_uncertainty=2.0, predicted=False,
                               prediction_valid_until=None, assessable=True, clock_uncertainty=0.01,
                               agent_status=AgentStatus.EXECUTING)


def test_kinematic_region_grows_bounded_and_flags_unassessable():
    pol = FreshnessPolicy(max_speed_m_s=15.0, max_assessable_radius_m=150.0, reachable_horizon_s=60.0)
    r1, ok1 = kinematic_region(est(2.0), 102.0, pol, 0.0, 120.0)
    r2, ok2 = kinematic_region(est(8.0), 108.0, pol, 0.0, 120.0)
    r3, ok3 = kinematic_region(est(200.0), 300.0, pol, 0.0, 120.0)
    assert r1.volume.radius_m < r2.volume.radius_m <= r3.volume.radius_m
    assert ok1 and ok2 and not ok3
    assert r3.volume.radius_m <= 15.0 * 60.0 + 3.0  # capped at the bounded horizon


def test_contract_region_covers_only_the_planned_corridor_until_lease_expiry():
    ts = list(np.arange(0, 61, 1.0))
    tr = Trajectory(drone_id="d", t=ts, x=[8.0 * t for t in ts], y=[0.0] * len(ts), z=[35.0] * len(ts),
                    phase=[Phase.SURVEY] * len(ts), task=["L1"] * len(ts))
    r = contract_region(tr, t_known=10.0, t_until=20.0, inflate_m=5.0, holder="d")
    xs = [p[0] for p in r.volume.points]
    assert min(xs) >= 80.0 - 1e-6 and max(xs) <= 160.0 + 1e-6
    assert r.volume.contains(120.0, 0.0, 35.0) and not r.volume.contains(300.0, 0.0, 35.0)


def test_energy_model_monotonic_in_speed_and_climb():
    em = EnergyModel(EnergyModelConfig())
    assert em.power_w(10, 0) > em.power_w(5, 0) > em.power_w(0, 0)
    assert em.power_w(0, 3) > em.power_w(0, 0) == em.power_w(0, -2)  # descent not regenerative
    assert em.recover_energy_wh(0, 0, 30, (500, 0), 60, 10) > em.recover_energy_wh(0, 0, 30, (100, 0), 60, 10)


def test_realtime_playback_mode_runs_same_code_path():
    sc = small_scenario(seed=3, duration_limit_s=40.0)
    res = run_realtime(sc, speed=40.0)  # wall-clock paced, 40x
    assert res.shutdown_clean
    assert 35.0 <= res.sim_duration_s <= 200.0
    assert res.ingest_stats and all(v["accepted"] > 0 for v in res.ingest_stats.values())
