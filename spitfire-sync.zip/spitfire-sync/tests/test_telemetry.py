import math

from conftest import make_state

from spitfire_sync.config import FreshnessPolicy, TelemetryConfig
from spitfire_sync.models.geometry import NavigationFrame
from spitfire_sync.models.state import Freshness
from spitfire_sync.reasons import ReasonCode
from spitfire_sync.telemetry import StateStore, TelemetryIngestor


def store():
    return StateStore(["drone-01"], TelemetryConfig())


def test_duplicate_observations_are_rejected():
    s = store()
    assert s.ingest(make_state(seq=1, t=100.0), 100.05).accepted
    r = s.ingest(make_state(seq=1, t=100.0), 100.10)
    assert not r.accepted and r.reasons == [ReasonCode.DUPLICATE_OBSERVATION]
    assert s.ingestor.stats["drone-01"].duplicates == 1


def test_out_of_order_delivery_does_not_regress_estimate():
    s = store()
    s.ingest(make_state(seq=1, t=100.0, pos=(0, 0, 30)), 100.05)
    s.ingest(make_state(seq=3, t=101.0, pos=(5, 0, 30), vel=(5, 0, 0)), 101.05)
    r = s.ingest(make_state(seq=2, t=100.5, pos=(2.5, 0, 30), vel=(5, 0, 0)), 101.10)
    assert not r.accepted and r.reasons == [ReasonCode.OUT_OF_ORDER]
    assert s.ingestor.latest("drone-01").sequence_number == 3
    # raw log keeps every observation, accepted or not
    assert len(s.ingestor.raw_log) == 3
    assert [o.accepted for o in s.ingestor.raw_log] == [True, True, False]


def test_missing_observations_are_counted():
    s = store()
    s.ingest(make_state(seq=1, t=100.0), 100.05)
    r = s.ingest(make_state(seq=5, t=102.0), 102.05)
    assert r.accepted and ReasonCode.SEQUENCE_GAP in r.reasons and r.gap == 3


def test_sequence_reset_after_reboot_is_accepted_and_old_boot_rejected():
    s = store()
    s.ingest(make_state(seq=900, t=100.0, boot="b0"), 100.05)
    r = s.ingest(make_state(seq=1, t=105.0, boot="b1"), 105.05)
    assert r.accepted and r.new_boot and ReasonCode.SEQUENCE_RESET_NEW_BOOT in r.reasons
    late = s.ingest(make_state(seq=901, t=100.5, boot="b0"), 105.2)
    assert not late.accepted and late.reasons == [ReasonCode.STALE_BOOT]


def test_invalid_and_non_finite_positions_rejected():
    s = store()
    r = s.ingest(make_state(pos=(math.nan, 0, 30)), 100.0)
    assert not r.accepted and r.reasons == [ReasonCode.INVALID_POSITION]
    r = s.ingest(make_state(seq=2, unc=-1.0), 100.0)
    assert ReasonCode.INVALID_UNCERTAINTY in r.reasons


def test_incompatible_frame_rejected():
    s = store()
    r = s.ingest(make_state(frame=NavigationFrame.NED), 100.0)
    assert not r.accepted and r.reasons == [ReasonCode.FRAME_MISMATCH]


def test_impossible_motion_rejected_then_reset_after_persistent_disagreement():
    ing = TelemetryIngestor(TelemetryConfig(consecutive_rejects_before_reset=3))
    ing.ingest(make_state(seq=1, t=100.0, pos=(0, 0, 30)), 100.05)
    r = ing.ingest(make_state(seq=2, t=100.5, pos=(300, 0, 30)), 100.55)  # implies 600 m/s
    assert not r.accepted and ReasonCode.IMPLAUSIBLE_SPEED in r.reasons
    r = ing.ingest(make_state(seq=3, t=101.0, pos=(3, 0, 30), vel=(6, 0, 0)), 101.05)  # plausible
    assert r.accepted
    r = ing.ingest(make_state(seq=4, t=101.5, pos=(4, 0, 30), vel=(-15, 0, 0)), 101.55)  # ~36 m/s^2
    assert not r.accepted and ReasonCode.IMPOSSIBLE_ACCELERATION in r.reasons
    # if the "impossible" track persists, the previously accepted fix is the suspect: reset and accept
    far = [(900, 0, 30), (901, 0, 30), (902, 0, 30)]
    results = [ing.ingest(make_state(seq=5 + i, t=102.0 + 0.5 * i, pos=p), 102.05 + 0.5 * i) for i, p in enumerate(far)]
    # rejection count (incl. the acceleration reject above) reaches 3 on the second far fix
    assert [x.accepted for x in results] == [False, True, True]
    assert results[1].reset_after_rejects and not results[2].reset_after_rejects


def test_future_timestamp_rejected():
    s = store()
    r = s.ingest(make_state(t=110.0, clock_unc=0.1), 100.0)
    assert not r.accepted and r.reasons == [ReasonCode.FUTURE_TIMESTAMP]


def test_freshness_and_bounded_prediction():
    s = store()
    pol = FreshnessPolicy(fresh_max_age_s=1.5, stale_max_age_s=6.0, prediction_horizon_s=2.0)
    s.ingest(make_state(seq=1, t=100.0, pos=(0, 0, 30), vel=(8, 0, 0)), 100.05)
    e1 = s.estimate("drone-01", 100.5, pol)
    assert e1.freshness == Freshness.FRESH and e1.predicted
    assert abs(e1.position.x - 4.0) < 1e-9  # constant-velocity prediction
    assert e1.prediction_valid_until == 102.0
    e2 = s.estimate("drone-01", 103.0, pol)
    assert e2.freshness == Freshness.STALE and not e2.predicted
    assert e2.position.x == 0.0  # last-known position, NOT presented as current
    assert e2.position_uncertainty > e1.position_uncertainty
    e3 = s.estimate("drone-01", 120.0, pol)
    assert e3.freshness == Freshness.LOST and not e3.assessable
    assert ReasonCode.POSITION_UNASSESSABLE in e3.reasons
    # raw observation is untouched by estimation
    assert s.ingestor.latest("drone-01").position.x == 0.0


def test_uncertainty_increases_monotonically_with_age():
    s = store()
    pol = FreshnessPolicy()
    s.ingest(make_state(seq=1, t=100.0, vel=(5, 0, 0)), 100.0)
    us = [s.estimate("drone-01", 100.0 + a, pol).position_uncertainty for a in (0.1, 0.5, 1.0, 1.9, 3.0, 10.0)]
    assert all(b >= a for a, b in zip(us, us[1:]))


def test_never_seen_aircraft_in_snapshot():
    s = StateStore(["drone-01", "drone-02"], TelemetryConfig())
    s.ingest(make_state(), 100.0)
    snap = s.snapshot(100.2, FreshnessPolicy())
    assert snap.drones["drone-02"].freshness == Freshness.NEVER_SEEN
    assert snap.fresh() == ["drone-01"]
