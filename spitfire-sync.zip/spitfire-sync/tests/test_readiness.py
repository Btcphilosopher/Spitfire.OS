"""Readiness protocol from the aircraft's side: local validation, binding of
acknowledgements, readiness expiry, missed start deadlines, start gating."""

import asyncio

from harness import FakeAdapter, Harness

from spitfire_sync.clocks import run_virtual
from spitfire_sync.coordination.leases import plan_lease_task
from spitfire_sync.models.commands import TaskLease
from spitfire_sync.models.geometry import Vec3
from spitfire_sync.models.messages import MessageType, PlanCommitPayload, PlanProposalPayload, ProgressStatus
from spitfire_sync.models.trajectory import ContingencyAssignment, DronePlan, Phase, PlanPurpose, Trajectory
from spitfire_sync.reasons import ReasonCode


def plan_for(h: Harness, start_in: float = 20.0, version: int = 1, boot: str | None = None,
             purpose: PlanPurpose = PlanPurpose.INITIAL, climb_rate: float = 2.0) -> DronePlan:
    t0 = h.now() + start_in
    ts = [t0 + i for i in range(31)]
    z = [min(climb_rate * i, 30.0) for i in range(31)]
    tr = Trajectory(drone_id="drone-01", t=ts, x=[0.0] * 31, y=[0.0] * 31, z=z, phase=[Phase.TAKEOFF] * 31,
                    task=[None] * 31)
    return DronePlan(drone_id="drone-01", expected_boot_id=boot or h.aclock.boot_id, plan_version=version,
                     purpose=purpose, effective_from=t0, trajectory=tr, task_ids=[],
                     contingency=ContingencyAssignment(contingency_altitude_m=80.0, hold_point=Vec3.enu(0, 50, 80),
                                                       lost_link_action="GOTO_CONTINGENCY_HOLD",
                                                       land_position=Vec3.enu(0, 0, 0)))


def proposal(h: Harness, dp: DronePlan, mv: int = 1) -> PlanProposalPayload:
    return PlanProposalPayload(plan_id=f"p{dp.plan_version}", plan_digest=dp.digest(mv, h.epoch), drone_plan=dp,
                               readiness_deadline=h.now() + 8, timing_tolerance_s=0.25, participants=["drone-01"])


def commit(h: Harness, dp: DronePlan, mv: int = 1, digest: str | None = None) -> PlanCommitPayload:
    lz = TaskLease(lease_id="L-plan", task_id=plan_lease_task("drone-01"), holder="drone-01",
                   holder_boot_id=h.aclock.boot_id, coordinator_epoch=h.epoch, plan_version=dp.plan_version,
                   issued_at=h.now(), expires_at=h.now() + 60)
    return PlanCommitPayload(commit_id=f"commit/p{dp.plan_version}", plan_id=f"p{dp.plan_version}",
                             plan_digest=digest or dp.digest(mv, h.epoch), plan_version=dp.plan_version,
                             effective_from=dp.effective_from, leases=[lz])


def run(script):  # type: ignore[no-untyped-def]
    async def main():
        h = script.factory()
        task = asyncio.ensure_future(h.agent.run())
        await h.serve(3.0)  # clock sync converges
        await script(h)
        h.agent.stop()
        await task
        return h

    return run_virtual(main)


def acks(h):  # type: ignore[no-untyped-def]
    return [e.payload for e in h.of_type(MessageType.PLAN_ACK)]


def test_valid_proposal_acknowledged_ready_and_bound():
    async def s(h):  # type: ignore[no-untyped-def]
        await h.send(MessageType.PLAN_PROPOSAL, proposal(h, plan_for(h)))
        await h.serve(4.0)
    s.factory = lambda: Harness()
    h = run(s)
    a = acks(h)[0]
    assert a.ready and a.drone_boot_id == h.aclock.boot_id and a.plan_version == 1
    assert a.clock_uncertainty_s < 0.25
    env = h.of_type(MessageType.PLAN_ACK)[0]
    assert a.readiness_expires_at > env.issued_at + h.cfg.timing.readiness_validity_s - 1.0  # readiness expires


def test_local_validation_rejects_wrong_boot_energy_and_kinematics():
    async def s(h):  # type: ignore[no-untyped-def]
        await h.send(MessageType.PLAN_PROPOSAL, proposal(h, plan_for(h, boot="drone-01-boot9")))
        await h.send(MessageType.PLAN_PROPOSAL, proposal(h, plan_for(h, version=2, climb_rate=6.0)))
        await h.serve(4.0)
    s.factory = lambda: Harness()
    h = run(s)
    by_plan = {a.plan_id: a for a in acks(h)}
    a1, a2 = by_plan["p1"], by_plan["p2"]
    assert not a1.ready and ReasonCode.WRONG_BOOT_ID in a1.reasons
    assert not a2.ready and ReasonCode.KINEMATICALLY_INFEASIBLE in a2.reasons

    async def s2(h):  # type: ignore[no-untyped-def]
        await h.send(MessageType.PLAN_PROPOSAL, proposal(h, plan_for(h)))
        await h.serve(4.0)
    s2.factory = lambda: Harness(adapter=FakeAdapter(energy_wh=14.0))  # below the 15 Wh reserve
    h2 = run(s2)
    assert ReasonCode.INSUFFICIENT_ENERGY in acks(h2)[0].reasons


def test_commit_bound_to_digest_and_executes_at_committed_time():
    async def s(h):  # type: ignore[no-untyped-def]
        dp = plan_for(h, start_in=6.0)
        await h.send(MessageType.PLAN_PROPOSAL, proposal(h, dp))
        await h.serve(3.5)
        await h.send(MessageType.PLAN_COMMIT, commit(h, dp, digest="0" * 64))  # tampered binding
        await h.send(MessageType.PLAN_COMMIT, commit(h, dp))
        await h.serve(12.0)
    s.factory = lambda: Harness()
    h = run(s)
    cacks = [e.payload.ack for e in h.of_type(MessageType.COMMAND_ACK)]
    # same-instant deliveries may be reordered by the network: check both outcomes regardless of order
    assert any(a.reason == ReasonCode.ACK_BINDING_MISMATCH and not a.accepted for a in cacks)
    assert any(a.reason == ReasonCode.COMMITTED and a.accepted for a in cacks)
    started = [e.payload for e in h.of_type(MessageType.TASK_PROGRESS) if e.payload.status == ProgressStatus.STARTED]
    assert started, "aircraft did not start"
    assert ("arm", None) in h.adapter.calls


def test_readiness_expires_before_commit():
    async def s(h):  # type: ignore[no-untyped-def]
        dp = plan_for(h, start_in=60.0)
        await h.send(MessageType.PLAN_PROPOSAL, proposal(h, dp))
        await h.serve(3.0 + h.cfg.timing.readiness_validity_s + 2.0)
        await h.send(MessageType.PLAN_COMMIT, commit(h, dp))
        await h.serve(30.0)
    s.factory = lambda: Harness()
    h = run(s)
    ack = h.of_type(MessageType.COMMAND_ACK)[0].payload.ack
    assert not ack.accepted and ack.reason == ReasonCode.READINESS_EXPIRED


def test_commit_arriving_after_start_deadline_is_refused_as_missed_start():
    async def s(h):  # type: ignore[no-untyped-def]
        dp = plan_for(h, start_in=1.0)
        await h.send(MessageType.PLAN_PROPOSAL, proposal(h, dp))
        await h.serve(5.5)  # start time passes before the commit arrives
        await h.send(MessageType.PLAN_COMMIT, commit(h, dp))
        await h.serve(7.0)
    s.factory = lambda: Harness()
    h = run(s)
    ack = h.of_type(MessageType.COMMAND_ACK)[0].payload.ack
    assert ack.reason == ReasonCode.START_DEADLINE_MISSED
    missed = [e.payload for e in h.of_type(MessageType.TASK_PROGRESS) if e.payload.status == ProgressStatus.START_MISSED]
    assert missed
    assert not [c for c in h.adapter.calls if c[0] == "arm"]


def test_arming_failure_reports_start_failed():
    async def s(h):  # type: ignore[no-untyped-def]
        dp = plan_for(h, start_in=6.0)
        await h.send(MessageType.PLAN_PROPOSAL, proposal(h, dp))
        await h.serve(3.5)
        await h.send(MessageType.PLAN_COMMIT, commit(h, dp))
        await h.serve(12.0)
    ad = FakeAdapter()
    ad.arm_ok = False
    s.factory = lambda: Harness(adapter=ad)
    h = run(s)
    failed = [e.payload for e in h.of_type(MessageType.TASK_PROGRESS) if e.payload.status == ProgressStatus.START_FAILED]
    assert failed and failed[0].reason == ReasonCode.START_FAILED


def test_lease_lapse_pauses_execution():
    async def s(h):  # type: ignore[no-untyped-def]
        dp = plan_for(h, start_in=6.0)
        await h.send(MessageType.PLAN_PROPOSAL, proposal(h, dp))
        await h.serve(3.5)
        c = commit(h, dp)
        short = c.leases[0].model_copy(update={"expires_at": h.now() + 9.0})  # no renewals will follow
        await h.send(MessageType.PLAN_COMMIT, c.model_copy(update={"leases": [short]}))
        await h.serve(20.0)
    s.factory = lambda: Harness()
    h = run(s)
    paused = [e.payload for e in h.of_type(MessageType.TASK_PROGRESS) if e.payload.status == ProgressStatus.PAUSED]
    assert paused and paused[0].reason == ReasonCode.LEASE_EXPIRED
    assert ("hold", None) in h.adapter.calls
