import asyncio
import time

import pytest

from spitfire_sync.adapters.base import AdapterDisabledError
from spitfire_sync.adapters.mavsdk_adapter import (
    HARDWARE_ENV,
    HARDWARE_TOKEN,
    DispatchGate,
    HardwareDispatchDisabled,
    MavsdkAdapter,
    MavsdkAdapterConfig,
)
from spitfire_sync.config import ContingencyConfig, DroneProfile, SpitfireConfig
from spitfire_sync.contingencies.policy import FindingSeverity, validate_against_autopilot, validate_fleet
from spitfire_sync.models.frames import GeodeticPosition
from spitfire_sync.models.geometry import Vec3

GOOD = {"RTL_RETURN_ALT": 80.0, "NAV_DLL_ACT": 0.0, "COM_DL_LOSS_T": 45.0, "COM_OF_LOSS_T": 1.0, "BAT_LOW_THR": 0.15,
        "BAT_CRIT_THR": 0.07, "COM_LOW_BAT_ACT": 3.0, "GF_ACTION": 1.0, "MPC_XY_VEL_MAX": 15.0,
        "MPC_Z_VEL_MAX_UP": 3.0, "MPC_Z_VEL_MAX_DN": 2.0}


def test_consistent_autopilot_settings_pass():
    f = validate_against_autopilot(DroneProfile(drone_id="d1"), GOOD, 0.25, 80.0)
    assert [x for x in f if x.severity != FindingSeverity.INFO] == []


@pytest.mark.parametrize("change,check", [
    ({"RTL_RETURN_ALT": 60.0}, "RTL_RETURN_ALT"),
    ({"BAT_LOW_THR": 0.30}, "BAT_LOW_THR"),
    ({"BAT_CRIT_THR": 0.20}, "BAT_CRIT_THR"),
    ({"GF_ACTION": 0.0}, "GF_ACTION"),
    ({"MPC_XY_VEL_MAX": 10.0}, "MPC_XY_VEL_MAX"),
    ({"COM_DL_LOSS_T": 10.0}, "COM_DL_LOSS_T"),
])
def test_inconsistent_autopilot_settings_flagged(change, check):
    f = validate_against_autopilot(DroneProfile(drone_id="d1"), {**GOOD, **change}, 0.25, 80.0)
    assert any(x.check == check for x in f)


def test_fleet_contingency_layers_must_be_unique_and_under_ceiling():
    cfg = SpitfireConfig(fleet=[DroneProfile(drone_id="a"), DroneProfile(drone_id="b"),
                                DroneProfile(drone_id="c", contingency=ContingencyConfig(lost_link_action="LAND_IN_PLACE"))])
    f = validate_fleet(cfg, 120.0, {"a": 90.0, "b": 90.0, "c": None}, 8.0,
                       params={"a": GOOD | {"RTL_RETURN_ALT": 90.0}, "b": GOOD | {"RTL_RETURN_ALT": 90.0}, "c": GOOD})
    assert any(x.check == "contingency_altitude" and x.severity == FindingSeverity.ERROR for x in f)
    assert not any(x.drone_id == "c" and x.check == "contingency_altitude" for x in f)


ORIGIN = GeodeticPosition(latitude_deg=47.397742, longitude_deg=8.545594, height_m=488.0)


def test_mavsdk_adapter_disabled_by_default():
    with pytest.raises(AdapterDisabledError):
        MavsdkAdapter(MavsdkAdapterConfig(), ORIGIN, time.monotonic)


def test_sitl_mode_requires_loopback_url():
    with pytest.raises(AdapterDisabledError):
        DispatchGate(MavsdkAdapterConfig(enabled=True, mode="sitl", connection_url="udp://10.1.2.3:14540"), env={})
    assert DispatchGate(MavsdkAdapterConfig(enabled=True, mode="sitl", connection_url="udp://:14540"), env={}).commands_allowed


def test_hardware_mode_is_monitor_only_unless_doubly_enabled():
    cfg = MavsdkAdapterConfig(enabled=True, mode="hardware", connection_url="serial:///dev/ttyUSB0:57600")
    g = DispatchGate(cfg, env={})
    with pytest.raises(HardwareDispatchDisabled):
        g.require()
    assert not DispatchGate(cfg, env={HARDWARE_ENV: HARDWARE_TOKEN}).commands_allowed  # config flag also needed
    cfg2 = cfg.model_copy(update={"hardware_dispatch_enabled": True})
    assert not DispatchGate(cfg2, env={}).commands_allowed  # environment acknowledgement also needed
    assert DispatchGate(cfg2, env={HARDWARE_ENV: HARDWARE_TOKEN}).commands_allowed


def test_hardware_monitor_mode_blocks_commands_at_the_adapter():
    cfg = MavsdkAdapterConfig(enabled=True, mode="hardware", connection_url="serial:///dev/ttyUSB0:57600")
    ad = MavsdkAdapter(cfg, ORIGIN, time.monotonic, env={})
    for coro in (ad.arm(), ad.hold(), ad.land(), ad.return_to_launch(), ad.set_setpoint(Vec3.enu(0, 0, 10),
                                                                                        Vec3.enu(0, 0, 0))):
        with pytest.raises(HardwareDispatchDisabled):
            asyncio.run(coro)


def test_adapter_frame_conversion_between_mission_and_autopilot_origins():
    from spitfire_sync.models.frames import LocalTangentFrame

    ad = MavsdkAdapter(MavsdkAdapterConfig(enabled=True), ORIGIN, time.monotonic, env={})
    # autopilot EKF origin 100 m north and 50 m east of the mission origin
    ap_origin = LocalTangentFrame(origin=ORIGIN).to_geodetic(Vec3.enu(50.0, 100.0, 0.0))
    ad._ap_frame = LocalTangentFrame(origin=ap_origin)
    ned = ad.to_autopilot_ned(Vec3.enu(50.0, 100.0, 20.0))
    assert abs(ned.x) < 0.01 and abs(ned.y) < 0.01 and abs(ned.z + 20.0) < 0.01  # same point, NED down = -20
    ned2 = ad.to_autopilot_ned(Vec3.enu(60.0, 130.0, 0.0))
    assert abs(ned2.x - 30.0) < 0.01 and abs(ned2.y - 10.0) < 0.01
