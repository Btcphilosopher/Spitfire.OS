"""End-to-end simulations on the small 4-aircraft site (virtual time).

These exercise the full chain: simulated telemetry -> assignment -> scheduled
trajectories -> conflict checking -> coordinated execution -> evaluation.
"""

import hashlib
import json

import pytest
from conftest import small_scenario

from spitfire_sync.evaluation.metrics import compute_metrics
from spitfire_sync.simulation.simulator import run_simulation

pytestmark = pytest.mark.slow


def _kinds(res):  # type: ignore[no-untyped-def]
    return [e.kind for e in res.coordinator_timeline]


@pytest.fixture(scope="module")
def nominal():
    return run_simulation(small_scenario(seed=7))


def test_nominal_mission_completes_with_separation_and_clean_shutdown(nominal):
    m = compute_metrics(nominal)
    assert nominal.outcome is not None and nominal.outcome.finished
    assert m.tasks_unfinished == 0 and not nominal.outcome.unassigned_tasks
    assert m.coverage_fraction > 0.95
    assert m.true_separation_infringements_s == 0.0
    assert m.predicted_separation_violations == 0
    assert m.concurrent_duplicate_execution == 0
    assert m.sync_start_abs_max_s < nominal.system.timing.start_tolerance_s
    assert nominal.shutdown_clean and not nominal.errors
    assert all(s.value == "LANDED" for s in nominal.outcome.drone_states.values())


def test_coordinator_never_reads_ground_truth(nominal):
    # The coordinator's state store only ever contains telemetry that came through the network.
    st = nominal.ingest_stats
    assert all(v["received"] > 0 for v in st.values())
    assert all(v["accepted"] <= v["received"] for v in st.values())


def test_sequenced_recovery_in_shared_area(nominal):
    rec = sorted(nominal.outcome.recoveries, key=lambda r: r["slot_start"])
    for a, b in zip(rec, rec[1:]):
        assert a["slot_end"] <= b["slot_start"] + 1e-6  # one aircraft in the recovery volume at a time


def _digest(res):  # type: ignore[no-untyped-def]
    h = hashlib.sha256()
    for d in sorted(res.truth):
        for s in res.truth[d][::10]:
            h.update(json.dumps([round(s.t, 6), [round(v, 6) for v in s.pos], s.mode.value]).encode())
    h.update(json.dumps([(round(e.time, 6), e.kind, e.drone_id) for e in res.coordinator_timeline]).encode())
    return h.hexdigest()


def test_simulation_is_deterministic_for_a_seed(nominal):
    again = run_simulation(small_scenario(seed=7))
    assert _digest(again) == _digest(nominal)
    other = run_simulation(small_scenario(seed=8))
    assert _digest(other) != _digest(nominal)


def test_partial_start_failure_continues_and_reallocates():
    res = run_simulation(small_scenario(seed=7, drones=[{"drone_id": "drone-02", "arm_failure": True}]))
    k = _kinds(res)
    assert "start_failed" in k and "partial_start_continue" in k
    assert "task_reassigned" in k
    m = compute_metrics(res)
    assert res.outcome.drone_states["drone-02"].value == "FAILED"
    assert m.tasks_unfinished == 0 and m.coverage_fraction > 0.95
    assert m.concurrent_duplicate_execution == 0


def test_partial_start_abort_all_policy():
    sc = small_scenario(seed=7, drones=[{"drone_id": "drone-02", "arm_failure": True}])
    sc = sc.model_copy(update={"system": sc.system.model_copy(update={
        "coordinator": sc.system.coordinator.model_copy(update={"partial_start_policy": "abort_all"})})})
    res = run_simulation(sc)
    k = _kinds(res)
    assert "partial_start_abort" in k
    assert any(e.kind.value == "COORDINATION_ABORT" for e in res.coordinator_record.events)
    # aircraft executed their own contingency (not an emergency): they land, no autopilot failsafe
    assert compute_metrics(res).autopilot_failsafes == 0
    assert all(res.landed_events[d] for d in res.truth if d != "drone-02")


def test_link_outage_pause_reconciliation_and_resume():
    res = run_simulation(small_scenario(seed=7, link_episodes=[
        {"node_id": "drone-03", "start_s": 60.0, "end_s": 80.0, "label": "outage", "profile": {"loss": 1.0}}]))
    k = _kinds(res)
    assert "link_restored" in k and "reconciled" in k and "resumed" in k
    m = compute_metrics(res)
    assert m.recovery_after_comm_loss_s and max(m.recovery_after_comm_loss_s) < 90.0
    assert m.true_separation_infringements_s == 0.0
    assert m.tasks_unfinished == 0 and m.concurrent_duplicate_execution == 0


def test_companion_reboot_is_detected_and_reconciled():
    res = run_simulation(small_scenario(seed=7, drones=[{"drone_id": "drone-01", "reboot_at_s": 70.0}]))
    k = _kinds(res)
    assert "reboot_detected" in k and "reconciled" in k
    assert res.ingest_stats["drone-01"]["reboots"] == 1
    m = compute_metrics(res)
    assert m.tasks_unfinished == 0 and m.concurrent_duplicate_execution == 0
    assert len(res.agent_records["drone-01"]) == 2  # two boots


def test_coordinator_failure_enters_documented_degraded_mode():
    res = run_simulation(small_scenario(seed=7, coordinator_crash_at_s=90.0))
    m = compute_metrics(res)
    for d, recs in res.agent_records.items():
        kinds = [e[1] for r in recs for e in r.events]
        assert "coordinator_link_lost" in kinds and "contingency" in kinds, d
    assert all(res.landed_events[d] for d in res.truth)  # every aircraft landed via its own contingency
    assert m.autopilot_failsafes == 0
    assert m.true_separation_infringements_s == 0.0
    assert m.concurrent_duplicate_execution == 0


def test_mission_obstruction_splits_lanes_and_replans():
    res = run_simulation(small_scenario(seed=7, obstructions=[
        {"at_s": 60.0, "zone_id": "spraying", "vertices": [(180, 100), (240, 100), (240, 150), (180, 150)]}]))
    k = _kinds(res)
    assert "mission_obstruction" in k
    assert any(t.endswith(".o1") or ".o" in t for t in res.task_registry)
    m = compute_metrics(res)
    assert m.true_separation_infringements_s == 0.0
    assert res.outcome.finished
