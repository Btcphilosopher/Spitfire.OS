import math

import numpy as np
import pytest

from spitfire_sync.models.frames import (
    GeodeticPosition,
    LocalTangentFrame,
    ecef_to_geodetic,
    enu_to_ned,
    geodetic_to_ecef,
    ned_to_enu,
)
from spitfire_sync.models.geometry import FrameMismatchError, NavigationFrame, Vec3
from spitfire_sync.models.trajectory import Phase, Trajectory

ORIGIN = GeodeticPosition(latitude_deg=52.2050, longitude_deg=-0.1200, height_m=45.0)


def test_enu_ned_axes_and_round_trip():
    v = Vec3.enu(3.0, 4.0, 5.0)  # east 3, north 4, up 5
    n = enu_to_ned(v)
    assert n.frame == NavigationFrame.NED
    assert (n.x, n.y, n.z) == (4.0, 3.0, -5.0)  # north, east, down
    back = ned_to_enu(n)
    assert (back.x, back.y, back.z) == (3.0, 4.0, 5.0)


def test_conversion_rejects_wrong_input_frame():
    with pytest.raises(FrameMismatchError):
        enu_to_ned(Vec3.ned(1, 2, 3))
    with pytest.raises(FrameMismatchError):
        ned_to_enu(Vec3.enu(1, 2, 3))


def test_mixing_frames_is_rejected_not_silently_combined():
    with pytest.raises(FrameMismatchError):
        _ = Vec3.enu(1, 2, 3) + Vec3.ned(1, 2, 3)
    with pytest.raises(FrameMismatchError):
        Vec3.ned(1, 2, 3).distance_to(Vec3.enu(0, 0, 0))


def test_trajectory_must_be_enu():
    with pytest.raises(ValueError):
        Trajectory(drone_id="d", frame=NavigationFrame.NED, t=[0, 1], x=[0, 1], y=[0, 0], z=[0, 0],
                   phase=[Phase.TRANSIT, Phase.TRANSIT], task=[None, None])


def test_ecef_geodetic_round_trip_submillimetre():
    for lat, lon, h in [(52.2, -0.12, 45.0), (-33.9, 151.2, 10.0), (0.0, 0.0, 0.0), (78.0, 15.0, 500.0)]:
        g = GeodeticPosition(latitude_deg=lat, longitude_deg=lon, height_m=h)
        r = ecef_to_geodetic(geodetic_to_ecef(g))
        assert abs(r.latitude_deg - lat) < 1e-9
        assert abs(r.longitude_deg - lon) < 1e-9
        assert abs(r.height_m - h) < 1e-3


def test_known_ecef_value_on_equator():
    x, y, z = geodetic_to_ecef(GeodeticPosition(latitude_deg=0, longitude_deg=0, height_m=0))
    assert x == pytest.approx(6378137.0)
    assert y == pytest.approx(0.0, abs=1e-6)
    assert z == pytest.approx(0.0, abs=1e-6)


def test_local_frame_axes_and_scale():
    f = LocalTangentFrame(origin=ORIGIN)
    o = f.to_enu(ORIGIN)
    assert o.norm() < 1e-6
    north = f.to_enu(GeodeticPosition(latitude_deg=ORIGIN.latitude_deg + 0.001, longitude_deg=ORIGIN.longitude_deg,
                                      height_m=ORIGIN.height_m))
    assert north.y == pytest.approx(111.25, abs=0.5)  # ~111.25 m per 0.001 deg latitude at 52 deg
    assert abs(north.x) < 0.01
    east = f.to_enu(GeodeticPosition(latitude_deg=ORIGIN.latitude_deg, longitude_deg=ORIGIN.longitude_deg + 0.001,
                                     height_m=ORIGIN.height_m))
    assert east.x == pytest.approx(111.32 * math.cos(math.radians(52.205)), rel=0.01)
    up = f.to_enu(GeodeticPosition(latitude_deg=ORIGIN.latitude_deg, longitude_deg=ORIGIN.longitude_deg,
                                   height_m=ORIGIN.height_m + 30.0))
    assert up.z == pytest.approx(30.0, abs=1e-6)


def test_local_frame_round_trip():
    f = LocalTangentFrame(origin=ORIGIN)
    for p in [Vec3.enu(500, -300, 40), Vec3.enu(-1200, 900, 110), Vec3.enu(0.5, 0.5, 0.5)]:
        q = f.to_enu(f.to_geodetic(p))
        assert np.allclose(q.as_array(), p.as_array(), atol=1e-6)


def test_local_frame_refuses_points_beyond_extent():
    f = LocalTangentFrame(origin=ORIGIN, max_extent_m=1000.0)
    with pytest.raises(ValueError):
        f.to_enu(GeodeticPosition(latitude_deg=ORIGIN.latitude_deg + 0.1, longitude_deg=ORIGIN.longitude_deg,
                                  height_m=0))
