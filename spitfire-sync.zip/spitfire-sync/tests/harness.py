"""Small virtual-time harness: one agent with a fake autopilot plus a scripted
'coordinator' endpoint that sends hand-built envelopes."""

from __future__ import annotations

import asyncio
from typing import Any

from spitfire_sync.adapters.base import AircraftAdapter, BatterySample, NavSample
from spitfire_sync.clocks import SimulatedClock, Timebase
from spitfire_sync.config import DroneProfile, SpitfireConfig
from spitfire_sync.coordination.agent import DroneAgent
from spitfire_sync.coordination.guard import Role
from spitfire_sync.models.geometry import Vec3
from spitfire_sync.models.messages import Envelope, MessageType, TimeSyncResponsePayload
from spitfire_sync.models.state import ArmedStatus, FlightMode
from spitfire_sync.transport import HmacAuthenticator, LinkProfile, MessageCodec, SimNetwork, derive_demo_keys


class FakeAdapter(AircraftAdapter):
    def __init__(self, pos=(0.0, 0.0, 0.0), energy_wh=60.0) -> None:  # type: ignore[no-untyped-def]
        self.pos = Vec3.enu(*pos)
        self.energy = energy_wh
        self.mode = FlightMode.ON_GROUND
        self.is_armed = False
        self.calls: list[tuple[str, Any]] = []
        self.arm_ok = True

    async def connect(self) -> None: ...

    async def close(self) -> None: ...

    def navigation(self) -> NavSample:
        return NavSample(self.pos, Vec3.enu(0, 0, 0), 2.0, 0.0, True)

    def battery(self) -> BatterySample:
        return BatterySample(self.energy / 60.0, self.energy)

    def flight_mode(self) -> FlightMode:
        return self.mode

    def armed(self) -> ArmedStatus:
        return ArmedStatus.ARMED if self.is_armed else ArmedStatus.DISARMED

    async def arm(self) -> bool:
        self.calls.append(("arm", None))
        self.is_armed = self.arm_ok
        return self.arm_ok

    async def set_setpoint(self, position: Vec3, velocity: Vec3) -> None:
        self.calls.append(("setpoint", position))
        self.mode = FlightMode.OFFBOARD
        self.pos = position

    async def hold(self) -> None:
        self.calls.append(("hold", None))
        if self.mode != FlightMode.ON_GROUND:
            self.mode = FlightMode.HOLD

    async def goto(self, position: Vec3, speed_m_s: float) -> None:
        self.calls.append(("goto", position))

    async def land(self) -> None:
        self.calls.append(("land", None))

    async def return_to_launch(self) -> None:
        self.calls.append(("rtl", None))

    def autopilot_params(self) -> dict[str, float]:
        return {}


class Harness:
    """Builds: network, an agent 'drone-01' and a scripted coordinator endpoint."""

    def __init__(self, epoch: int = 3, config: SpitfireConfig | None = None, adapter: FakeAdapter | None = None,
                 loss: float = 0.0) -> None:
        self.tb = Timebase()
        self.net = SimNetwork(self.tb, 1, LinkProfile(latency_s=0.02, jitter_s=0.0, loss=loss, duplicate=0.0))
        self.keys = derive_demo_keys(["coordinator", "drone-01", "intruder"], 1)
        self.roles = {"coordinator": Role.COORDINATOR, "drone-01": Role.AIRCRAFT}
        self.cfg = config or SpitfireConfig()
        self.cclock = SimulatedClock(self.tb, "coordinator", mono_offset=100.0)
        self.offset = 1_795_000_000.0 - 100.0
        self.ctx = self.net.endpoint("coordinator", self.cclock)
        self.ccodec = MessageCodec(HmacAuthenticator(self.keys, "coordinator"))
        self.aclock = SimulatedClock(self.tb, "drone-01", drift_ppm=30.0, mono_offset=5000.0)
        self.adapter = adapter or FakeAdapter()
        self.agent = DroneAgent("drone-01", self.aclock, self.net.endpoint("drone-01", self.aclock),
                                MessageCodec(HmacAuthenticator({k: self.keys[k] for k in ("drone-01", "coordinator")})),
                                self.cfg, DroneProfile(drone_id="drone-01"), self.adapter, "coordinator", self.roles)
        self.epoch = epoch
        self.seq = 0
        self.inbox: list[Envelope] = []

    def now(self) -> float:
        return self.cclock.monotonic() + self.offset

    async def send(self, mtype: MessageType, payload: Any, validity: float = 5.0, epoch: int | None = None,
                   message_id: str | None = None, sender: str = "coordinator", mission_version: int = 1,
                   issued_at: float | None = None) -> Envelope:
        self.seq += 1
        t = self.now() if issued_at is None else issued_at
        env = Envelope(message_id=message_id or f"c/{self.seq}", type=mtype, sender_id=sender,
                       recipient_id="drone-01", boot_id="coord-boot", coordinator_epoch=self.epoch if epoch is None
                       else epoch, mission_version=mission_version, sequence_number=self.seq, issued_at=t,
                       expires_at=t + validity, payload=payload)
        codec = self.ccodec if sender == "coordinator" else MessageCodec(HmacAuthenticator(self.keys, sender))
        await self.ctx.send("drone-01", codec.encode(env))
        return env

    async def serve(self, until: float) -> None:
        """Answer time-sync requests and collect everything else until world time ``until``."""
        while self.tb.now() < until:
            for data, rx in self.ctx.recv_nowait_timestamped():
                env = self.ccodec.decode(data)
                if env.type == MessageType.TIME_SYNC_REQUEST:
                    p = env.payload
                    t2 = rx + self.offset if rx is not None else self.now()
                    await self.send(MessageType.TIME_SYNC_RESPONSE, TimeSyncResponsePayload(
                        request_id=p.request_id, t1_local=p.t1_local, t2_reference=t2, t3_reference=self.now(),
                        reference_id=f"coord-boot/e{self.epoch}"))
                else:
                    self.inbox.append(env)
            await asyncio.sleep(0.05)

    def of_type(self, mtype: MessageType) -> list[Envelope]:
        return [e for e in self.inbox if e.type == mtype]
