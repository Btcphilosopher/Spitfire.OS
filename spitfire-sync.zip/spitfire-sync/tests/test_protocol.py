"""Message admission, idempotent retries, stale-coordinator rejection."""

import asyncio

from harness import Harness

from spitfire_sync.clocks import run_virtual
from spitfire_sync.clocks.clock import TimeEstimate
from spitfire_sync.coordination.guard import MessageGuard, Role
from spitfire_sync.models.commands import CommandType, CoordinationCommand
from spitfire_sync.models.messages import (
    CommandPayload,
    Envelope,
    HeartbeatPayload,
    MessageType,
    PlanCommitPayload,
)
from spitfire_sync.reasons import ReasonCode
from spitfire_sync.transport import HmacAuthenticator, MessageCodec, derive_demo_keys

KEYS = derive_demo_keys(["coordinator", "drone-01", "drone-02"], 9)
ROLES = {"coordinator": Role.COORDINATOR, "drone-01": Role.AIRCRAFT, "drone-02": Role.AIRCRAFT}


def env(mtype=MessageType.HEARTBEAT, payload=None, sender="coordinator", epoch=5, t=1000.0, validity=5.0,  # type: ignore[no-untyped-def]
        mid="m1", recipient="drone-01", seq=1):
    e = Envelope(message_id=mid, type=mtype, sender_id=sender, recipient_id=recipient, boot_id="b",
                 coordinator_epoch=epoch, mission_version=1, sequence_number=seq, issued_at=t, expires_at=t + validity,
                 payload=payload or HeartbeatPayload(reference_id="r"))
    return HmacAuthenticator(KEYS).sign(e)


def guard(now=1000.5, unc=0.0):  # type: ignore[no-untyped-def]
    return MessageGuard("drone-01", HmacAuthenticator(KEYS), ROLES, lambda: TimeEstimate(now, unc))


def test_valid_message_accepted_and_duplicate_rejected():
    g = guard()
    e = env()
    assert g.check(e).accepted
    r = g.check(e)
    assert not r.accepted and r.reason == ReasonCode.DUPLICATE_MESSAGE


def test_expired_message_rejected_conservatively_with_clock_uncertainty():
    assert guard(now=1006.0).check(env()).reason == ReasonCode.MESSAGE_EXPIRED
    # not yet expired by the estimate, but might be given the uncertainty => rejected
    assert guard(now=1004.9, unc=0.2).check(env()).reason == ReasonCode.MESSAGE_EXPIRED


def test_unauthorised_sender_role_rejected():
    commit = PlanCommitPayload(commit_id="c", plan_id="p", plan_digest="d", plan_version=1, effective_from=0.0)
    e = env(MessageType.PLAN_COMMIT, commit, sender="drone-02")
    assert guard().check(e).reason == ReasonCode.UNAUTHORISED


def test_tampered_or_unsigned_message_rejected():
    e = env()
    tampered = e.model_copy(update={"mission_version": 99})
    assert guard().check(tampered).reason == ReasonCode.BAD_SIGNATURE
    forged = e.model_copy(update={"auth_tag": None, "message_id": "m2"})
    assert guard().check(forged).reason == ReasonCode.BAD_SIGNATURE


def test_wrong_recipient_and_unknown_sender_and_version():
    assert guard().check(env(recipient="drone-02")).reason == ReasonCode.WRONG_RECIPIENT
    e = env().model_copy(update={"sender_id": "mallory"})
    assert guard().check(e).reason == ReasonCode.UNKNOWN_SENDER
    v = HmacAuthenticator(KEYS).sign(env().model_copy(update={"protocol_version": "2.0", "auth_tag": None}))
    assert guard().check(v).reason == ReasonCode.UNSUPPORTED_PROTOCOL_VERSION


def test_stale_epoch_rejected_after_newer_coordinator_seen():
    g = guard()
    assert g.check(env(epoch=5, mid="a")).accepted
    r = g.check(env(epoch=6, mid="b"))
    assert r.accepted and r.new_epoch
    assert g.check(env(epoch=5, mid="c")).reason == ReasonCode.STALE_EPOCH


def test_envelope_type_must_match_payload():
    import pytest
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        Envelope(message_id="x", type=MessageType.COMMAND, sender_id="coordinator", recipient_id="d", boot_id="b",
                 coordinator_epoch=1, mission_version=1, sequence_number=1, issued_at=0, expires_at=1,
                 payload=HeartbeatPayload(reference_id="r"))


def test_codec_round_trip_preserves_nan_and_auth():
    codec = MessageCodec(HmacAuthenticator(KEYS))
    e = env()
    d = codec.decode(codec.encode(e))
    assert d.auth_tag is not None and HmacAuthenticator(KEYS).verify(d)


def _hold_cmd(h: Harness, cid: str = "cmd-1") -> CommandPayload:
    return CommandPayload(command=CoordinationCommand(
        command_id=cid, command_type=CommandType.HOLD_POSITION, target_drone_id="drone-01",
        target_boot_id=h.aclock.boot_id, issued_at=h.now(), expires_at=h.now() + 5))


def test_command_retries_are_idempotent_and_lost_acks_recovered():
    async def main():
        h = Harness()
        task = asyncio.ensure_future(h.agent.run())
        await h.serve(3.0)
        await h.send(MessageType.COMMAND, _hold_cmd(h))
        await h.serve(4.0)
        # retry with the same command_id (e.g. the first ack was lost) and a new message id
        await h.send(MessageType.COMMAND, _hold_cmd(h))
        await h.serve(5.0)
        h.agent.stop()
        await task
        return h

    h = run_virtual(main)
    acks = [e.payload.ack for e in h.of_type(MessageType.COMMAND_ACK)]
    assert len(acks) == 2 and acks[0].command_id == acks[1].command_id == "cmd-1"
    assert not acks[0].duplicate and acks[1].duplicate
    assert len([c for c in h.agent.record.events if c[1] == "command"]) == 1  # executed once


def test_stale_coordinator_command_rejected_by_agent():
    async def main():
        h = Harness(epoch=4)
        task = asyncio.ensure_future(h.agent.run())
        await h.serve(3.0)  # agent learns epoch 4 from sync responses
        await h.send(MessageType.COMMAND, _hold_cmd(h, "old"), epoch=3)
        await h.serve(4.0)
        h.agent.stop()
        await task
        return h

    h = run_virtual(main)
    assert not h.of_type(MessageType.COMMAND_ACK)
    assert h.agent.guard.rejections.get(ReasonCode.STALE_EPOCH) == 1


def test_command_for_previous_boot_is_refused():
    async def main():
        h = Harness()
        task = asyncio.ensure_future(h.agent.run())
        await h.serve(3.0)
        p = _hold_cmd(h)
        p = CommandPayload(command=p.command.model_copy(update={"target_boot_id": "drone-01-boot0-old"}))
        await h.send(MessageType.COMMAND, p)
        await h.serve(4.0)
        h.agent.stop()
        await task
        return h

    h = run_virtual(main)
    ack = h.of_type(MessageType.COMMAND_ACK)[0].payload.ack
    assert not ack.accepted and ack.reason == ReasonCode.WRONG_BOOT_ID
