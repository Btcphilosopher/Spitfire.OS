# SPITFIRE.OS - Drone Synchronisation Core (`spitfire-sync`)

Supervisory coordination for fleets of civilian survey drones (mapping, agricultural
inspection, infrastructure monitoring): timestamped state sharing, task allocation with
expiring leases, conflict-checked time-parameterised trajectories, readiness-gated
coordinated starts, and explicit degraded-mode handling - built and evaluated in a
deterministic simulator first.

Flight stabilisation, attitude/motor control and aircraft failsafes stay in the autopilot.
This package only sends supervisory setpoints and mode commands through an adapter. The real
autopilot adapter (MAVSDK v4) is **disabled by default**, was **not** run against PX4 SITL in
the build environment, and has never been flown. See [docs/SITL.md](docs/SITL.md).

> Every number in this repository is a property of the simulation model. It is modelled
> performance, not demonstrated aircraft performance. A simulation with no collisions is not
> evidence of safety; separation checks cover only the modelled aircraft and hazards.

## Quick start

```bash
python -m pip install -e ".[test]"          # Python >= 3.11; numpy, scipy, pydantic, matplotlib
```

```bash
./scripts/run_tests.sh                       # 95 tests, ~3-4 min; writes docs/TEST_RESULTS.md
```

```bash
python -m spitfire_sync demo --seed 42 --out results/demo           # six-aircraft demonstration
```

```bash
python -m spitfire_sync evaluate --seeds 1-12 --workers 4 --out results/eval
```

```bash
python -m spitfire_sync validate-config configs/demo_agricultural.toml
```

```bash
python -m spitfire_sync demo --realtime --speed 10 --out results/rt  # wall-clock paced playback
```

```bash
python -m spitfire_sync playback results/demo/trace.json --speed 20  # replay the decision timeline
```

Without installing, prefix commands with `PYTHONPATH=src`. `./scripts/generate_results.sh`
regenerates everything under `results/`.

## Pipeline and interfaces

```
simulated telemetry -> task assignment -> scheduled trajectories -> conflict checking
                    -> coordinated execution -> evaluation
```

The public interfaces follow the requested shape (see `examples/api_walkthrough.py`, which
runs them inside a live simulated mission):

```python
snapshot   = state_store.snapshot(as_of=clock.now(), freshness_policy=config.freshness)
assignment = allocator.assign(tasks=mission.pending_tasks, fleet=snapshot, constraints=config.constraints)
plan       = scheduler.schedule(assignment=assignment, existing_reservations=reservations,
                                uncertainty=snapshot.uncertainty, snapshot=snapshot, ...).plan
conflicts  = conflict_checker.check(plan)               # ConflictReport (.ok, .conflicts with reason codes)
await coordinator.propose(plan)                          # ProposalResult
await coordinator.commit_when_ready(plan)                # CommitResult(status=COMMITTED | NOT_READY | ...)
result = await simulator.run(mission=mission, coordinator=factory, seed=42)   # SimulationResult
```

Results are structured objects with `ReasonCode`s (`reasons.py`); nothing relies on printed
status messages.

| Requirement | Where |
|---|---|
| Typed records (`DroneState`, `FleetSnapshot`, `MissionTask`, `Trajectory`, `Reservation`, `CoordinationCommand`, `CommandAcknowledgement`, `SafetyEvent`) | `src/spitfire_sync/models/` |
| ENU planning frame, explicit ENU/NED/WGS84 conversion, frame rejection | `models/frames.py`, `models/geometry.py`, [COORDINATES](docs/COORDINATES.md) |
| Monotonic / UTC / peer offset / uncertainty / message age; drift, jumps, reboot | `clocks/`, [TIMING](docs/TIMING.md) |
| Telemetry: duplicates, reordering, delays, gaps, invalid positions, impossible motion, reboot sequence resets; raw vs estimated | `telemetry/` |
| Central coordinator; epochs; expiring leases; one owner per lease; degraded mode on coordinator failure (no election/consensus) | `coordination/`, [ARCHITECTURE](docs/ARCHITECTURE.md) |
| Cost function, greedy baseline, Hungarian + local-search optimiser, energy model (assumption) | `allocation/`, [ALLOCATION](docs/ALLOCATION.md) |
| Readiness protocol, expiry, bindings, partial acks, missed deadlines, partial-start policy | `coordination/`, [PROTOCOL](docs/PROTOCOL.md) |
| Speed/accel/climb limits, segment-exact conflicts, uncertainty buffers, reservations, conflict resolution, hold-point safety | `scheduling/`, `separation/`, [SEPARATION](docs/SEPARATION.md) |
| Versioned messages with ids, epochs, expiry; idempotent retries; authentication (HMAC, no invented crypto) | `models/messages.py`, `transport/`, [SECURITY](docs/SECURITY.md) |
| Degraded operation (stale telemetry, lost link, reserve, navigation, deviation, drop-out, obstruction, ownership conflict) | `contingencies/`, `coordination/mission_runner.py`, [DEGRADED_OPERATION](docs/DEGRADED_OPERATION.md) |
| Seeded simulator, 4-12 aircraft, accelerated + real-time | `simulation/`, [SIMULATION](docs/SIMULATION.md) |
| Metrics, distributions across seeds, plots, timeline | `evaluation/` |
| Optional MAVSDK adapter, disabled by default, hardware gated | `adapters/mavsdk_adapter.py`, [SITL](docs/SITL.md) |

## The demonstration (`results/demo/`)

Six simulated aircraft survey the fictional **Larkspur Farm**: a 550 x 360 m field, a
farmhouse exclusion zone that splits three lanes, 12 survey lanes, two survey and two transit
bands, six launch pads and one shared recovery area. Scripted faults, hidden from the
coordinator: drone-02's link is delayed (2.5 s latency, 20 % loss) from t = 120 s, then drops
out completely for 14 s; drone-03 draws 2.1 times the modelled power.

Seed 42 (`results/demo/report.md`, figures `trajectories.png`, `altitude.png`,
`separation.png`, `timeline.png`):

| # | Step | What happened |
|---|---|---|
| 1 | Initial state collection | all six FRESH after clock sync |
| 2 | Survey-lane allocation | greedy cost-based assignment, payload constraints respected |
| 3 | Conflict-checked scheduling | 0 conflicts after resolution (3 aircraft delayed, 1 re-ordered) |
| 4 | Coordinated departure | all commits acknowledged; max start error 1.3 ms (tolerance 250 ms) |
| 5 | Task execution | 12/12 lanes complete; coverage 98.1 % |
| 6 | Delayed link | stale at 121.9 s; leases not renewed -> drone-02 paused onboard at 127.5 s; its pause report was lost, the coordinator inferred it from telemetry; after reconnection it reconciled and resumed 29.3 s after the link came back |
| 7 | Battery reserve | drone-03 reached its reserve at 248.6 s (learned consumption factor), stopped and released its leases |
| 8 | Suspension and reassignment | its unflown lanes were reassigned after ownership resolution (commits 1.5 s and 13.3 s after suspension); 0 m duplicated |
| 9 | Sequenced recovery | drone-03 got the first slot after drone-04; landings at 259, 340, 394, 421, 483, 510 s, one aircraft at a time in the recovery area |
| 10 | Report | min true separation 30.2 m, 0 s infringement, 0 predicted violations, 0 autopilot failsafes, ack latency p95 300 ms |

The remaining ~1.9 % of the field is uncovered in **every** run including nominal ones: it lies
in the slanted field corners outside the lane swaths, which is a lane-layout property, not
lost work.

## Results across seeds (`results/`)

Fault scenario above, 12 seeds (`results/evaluation_demo_faults/`):

| Metric | min | median | p95 | max |
|---|---|---|---|---|
| Survey coverage | 98.06 % | 98.09 % | 98.14 % | 98.14 % |
| Lanes completed | 12/12 in all 12 seeds | | | |
| Duplicate execution (length / concurrent) | 0 m / 0 | | | |
| Mission duration [s] | 487.5 | 497.8 | 566.6 | 600.0 |
| Minimum true separation [m] | 28.3 | 30.7 | 39.6 | 40.0 |
| True separation infringement [s] | 0 | 0 | 0 | 0 |
| Predicted separation violations (as-commanded plans) | 0 | 0 | 0 | 0 |
| Max synchronised-start error [ms] | 0.85 | 1.32 | 2.37 | 2.38 |
| Command ack latency p95 [ms] | 300 | 300 | 1248 | 1300 |
| Reassignment delay (suspension -> commit) [s] | 11.0 | 12.3 | 14.1 | 14.1 |
| Resume after link restoration [s] | 20.8 | 22.3 | 28.4 | 29.4 |
| Fleet energy (model) [Wh] | 161 | 171 | 179 | 181 |
| Autopilot failsafes | 0 | 0 | 0 | 0 |

Nominal site, greedy vs optional optimiser, 8 seeds (`results/allocator_*`): median mission
duration 490 s vs 461 s, fleet energy 150 Wh vs 139 Wh; both 12/12 lanes, 0 infringements.

Fleet size (nominal site, 4 seeds each, `results/fleet_*`): 4, 8 and 12 aircraft all complete
12/12 lanes with 0 infringements; median minimum true separation 30.9 / 32.3 / 28.7 m. With 12
aircraft, six use unique contingency layers and six use `LAND_IN_PLACE` (fewer layers fit
under the ceiling).

Test suite: **95 passed** ([docs/TEST_RESULTS.md](docs/TEST_RESULTS.md), raw output in
`test_output.txt`).

## What is deliberately not claimed

* **No leader election or consensus.** Coordinator failure leads to the documented degraded
  mode: aircraft hold, then fly their own contingency and land. Restart is an operator procedure.
* **Hold positions after a coordinator crash are not jointly deconflicted.** Aircraft hold where
  their leases lapsed, at slightly different times. The simulated crash runs showed no
  infringement. Before the contingency layers were spaced 10 m apart, a run did show a 7.8 m
  approach; that finding is why they are now 10 m apart.
* **The energy model is a planning assumption**, not an endurance model.
* **PX4 parameter names and semantics** used by `validate-config` were not verifiable against
  PX4 documentation from the build environment.
* **HMAC with symmetric per-sender keys** is integrity protection for the simulation; real links
  need asymmetric signatures or mutually authenticated transport (see SECURITY.md).
* **Separation** covers only this fleet and configured hazards; real operations need onboard
  detect-and-avoid and autopilot geofences.

## Repository

```
spitfire-sync/
├── pyproject.toml   README.md   test_output.txt
├── configs/         demo_agricultural.toml, nominal_agricultural.toml, sitl_example.toml
├── src/spitfire_sync/
│   ├── models/ clocks/ telemetry/ transport/ coordination/ allocation/
│   ├── scheduling/ separation/ contingencies/ simulation/ adapters/ evaluation/
│   ├── config.py  reasons.py  cli.py
├── scripts/         run_tests.sh, generate_results.sh, write_test_report.py
├── examples/        api_walkthrough.py, run_demo.py, custom_fault_scenario.py
├── tests/           95 tests (unit + virtual-time integration)
├── docs/            ARCHITECTURE, COORDINATES, TIMING, PROTOCOL, SEPARATION, ALLOCATION,
│                    DEGRADED_OPERATION, SIMULATION, SITL, SECURITY, TEST_RESULTS
└── results/         demo/, evaluation_demo_faults/, allocator_greedy/, allocator_optimal/, fleet_{4,8,12}/
```
