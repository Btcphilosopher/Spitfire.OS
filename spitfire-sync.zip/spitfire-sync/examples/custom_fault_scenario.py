"""Build a scenario in code: 8 aircraft, a companion reboot, a navigation
degradation and an operator-reported obstruction; print structured outcomes.

    PYTHONPATH=src python examples/custom_fault_scenario.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from spitfire_sync.config import DroneSimSpec, ObstructionEvent, ScenarioFile, SimulationConfig  # noqa: E402
from spitfire_sync.evaluation.metrics import compute_metrics  # noqa: E402
from spitfire_sync.simulation.simulator import run_simulation  # noqa: E402

sim = SimulationConfig(
    seed=11, n_drones=8,
    drones=[DroneSimSpec(drone_id="drone-05", reboot_at_s=110.0),
            DroneSimSpec(drone_id="drone-07", nav_degradation=[(150.0, 400.0, 6.0)])],
    obstructions=[ObstructionEvent(at_s=90.0, zone_id="sprayer", vertices=[(400, 240), (470, 240), (470, 320),
                                                                            (400, 320)])],
)
res = run_simulation(ScenarioFile(simulation=sim))
m = compute_metrics(res)
print("finished:", res.outcome.finished, "| completed:", len(res.outcome.completed_tasks),
      "| unassigned:", res.outcome.unassigned_tasks)
print("coverage %.1f %% | min true separation %.1f m | infringement %.1f s"
      % (m.coverage_fraction * 100, m.min_true_separation_m, m.true_separation_infringements_s))
print("safety events:", m.safety_events)
for e in res.outcome.timeline:
    if e.kind in ("reboot_detected", "navigation_degraded", "mission_obstruction", "hold_for_obstruction",
                  "reconciled", "resumed", "task_reassigned", "recovery_scheduled"):
        print(f"  {res.coord_world_of(e.time):7.1f}s {e.kind:<22} {e.drone_id or '':<9} {e.reason.value}")
