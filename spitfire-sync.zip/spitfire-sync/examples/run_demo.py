"""Run the six-aircraft demonstration programmatically and print the checklist.

    PYTHONPATH=src python examples/run_demo.py
"""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from spitfire_sync.config import load_scenario  # noqa: E402
from spitfire_sync.evaluation.plots import make_all  # noqa: E402
from spitfire_sync.evaluation.report import write_run_report  # noqa: E402
from spitfire_sync.simulation.simulator import run_simulation  # noqa: E402

scenario = load_scenario(ROOT / "configs" / "demo_agricultural.toml")
result = run_simulation(scenario, seed=42)  # accelerated virtual time, deterministic
out = ROOT / "results" / "demo_example"
report = write_run_report(result, out, make_all(result, out))
for item in report["checklist"]:
    print(f"{item['step']:>2}. {'OK ' if item['demonstrated'] else '-- '}{item['title']}: {item['evidence']}")
print("summary:", {k: round(v, 3) for k, v in report["summary"].items()})
