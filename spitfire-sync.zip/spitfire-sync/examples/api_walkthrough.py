"""Walk through the coordination pipeline step by step with the public API.

    PYTHONPATH=src python examples/api_walkthrough.py

1. a full simulated mission is run so aircraft agents exist and send telemetry;
2. inside that mission we also show, on a separate coordinator snapshot, the
   individual steps: snapshot -> assign -> schedule -> check -> propose -> commit.

All results are structured objects with reason codes (nothing is parsed from logs).
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from spitfire_sync.allocation import CostModel, GreedyAllocator  # noqa: E402
from spitfire_sync.clocks import run_virtual  # noqa: E402
from spitfire_sync.config import load_scenario  # noqa: E402
from spitfire_sync.coordination.coordinator import Coordinator  # noqa: E402
from spitfire_sync.scheduling import Scheduler  # noqa: E402
from spitfire_sync.scheduling.routing import Router  # noqa: E402
from spitfire_sync.simulation.simulator import Simulator  # noqa: E402

CONFIG = Path(__file__).resolve().parents[1] / "configs" / "nominal_agricultural.toml"


class WalkthroughCoordinator(Coordinator):
    """A coordinator that, once telemetry has arrived, runs the pipeline steps
    explicitly and prints their structured results.  The mission runner then
    continues with its own (identical) pipeline."""

    async def run(self) -> None:  # noqa: D401
        asyncio.ensure_future(self._walkthrough())
        await super().run()

    async def _walkthrough(self) -> None:
        await self.clock.sleep(3.0)  # let telemetry and clock sync arrive
        config, mission = self.cfg, self.mission
        state_store, clock = self.state, self.timescale

        snapshot = state_store.snapshot(as_of=clock.now(), freshness_policy=config.freshness)
        print("snapshot:", {d: e.freshness.value for d, e in snapshot.drones.items()},
              f"max clock uncertainty {snapshot.uncertainty.max_clock_uncertainty * 1000:.1f} ms")

        router = Router(mission, clearance_m=12.5)
        allocator = GreedyAllocator(CostModel(mission, config.allocation, config.constraints,
                                              {p.drone_id: p for p in config.fleet}, router))
        assignment = allocator.assign(tasks=mission.pending_tasks, fleet=snapshot, constraints=config.constraints)
        print("assignment:", {d: [t.task_id for t in v] for d, v in assignment.per_drone.items()},
              "unassigned:", assignment.unassigned)

        scheduler = Scheduler(mission, config, self.checker)
        reservations: list = []
        result = scheduler.schedule(assignment=assignment, existing_reservations=reservations,
                                    uncertainty=snapshot.uncertainty, snapshot=snapshot,
                                    start_time=clock.now() + 15.0, epoch=self.epoch, mission_version=999,
                                    plan_id="walkthrough")
        plan = result.plan
        print("schedule resolutions:", plan.resolutions if plan else result.failed)

        conflicts = self.checker.check(plan)
        print("conflict check:", "OK" if conflicts.ok else [c.reason.value for c in conflicts.conflicts])
        # By now the mission runner has committed its own plan and leased the lanes, so this
        # competing plan is refused with LEASE_ACTIVE_ELSEWHERE: one authoritative owner per lease.
        await self.propose(plan)
        res = await self.commit_when_ready(plan, deadline=clock.now() + 4.0, wait_for_acks=False)
        print("commit_when_ready:", res.status.value, {d: [r.value for r in v] for d, v in res.not_ready.items()})


async def main() -> None:
    scenario = load_scenario(CONFIG)
    simulator = Simulator(scenario)
    result = await simulator.run(coordinator=lambda kw: WalkthroughCoordinator(**kw), seed=42)
    o = result.outcome
    print(f"mission finished={o.finished} completed={len(o.completed_tasks)} "
          f"unassigned={len(o.unassigned_tasks)} duration={result.sim_duration_s:.0f}s (simulated)")


if __name__ == "__main__":
    run_virtual(main)
