# Multi-seed evaluation (4 seeds, 12 aircraft, allocator greedy)

> All figures are properties of the simulation model (kinematic aircraft, simple energy model, simulated network). They are modelled performance, not demonstrated aircraft performance. A simulation without collisions is not evidence of safety; separation checks cover only the modelled aircraft and hazards and do not replace onboard detect-and-avoid or autopilot failsafes.

| Metric | n | min | p5 | median | p95 | max |
|---|---|---|---|---|---|---|
| coverage_fraction | 4 | 0.9806 | 0.9806 | 0.9808 | 0.9811 | 0.9812 |
| duplicate_length_m | 4 | 0 | 0 | 0 | 0 | 0 |
| concurrent_duplicate_execution | 4 | 0 | 0 | 0 | 0 | 0 |
| mission_duration_s | 4 | 479.5 | 479.6 | 483 | 486.6 | 486.8 |
| total_travel_distance_m | 4 | 1.781e+04 | 1.781e+04 | 1.826e+04 | 1.87e+04 | 1.87e+04 |
| total_energy_wh | 4 | 217.6 | 219.5 | 231.4 | 237.2 | 238.1 |
| min_true_separation_m | 4 | 20.14 | 21.36 | 28.66 | 29.07 | 29.07 |
| true_separation_infringements_s | 4 | 0 | 0 | 0 | 0 | 0 |
| predicted_separation_violations | 4 | 0 | 0 | 0 | 0 | 0 |
| sync_start_abs_max_s | 4 | 0.00095 | 0.0009883 | 0.001507 | 0.002021 | 0.002059 |
| command_ack_latency_p95_s | 4 | 0.3 | 0.3 | 0.3 | 0.3 | 0.3 |
| reassignment_delay_max_s | 0 | - | - | - | - | - |
| recovery_after_comm_loss_max_s | 0 | - | - | - | - | - |
| autopilot_failsafes | 4 | 0 | 0 | 0 | 0 | 0 |

## Per seed

| seed | finished | tasks done | unfinished | coverage | min sep [m] | infringement [s] | max start err [ms] | errors | clean shutdown |
|---|---|---|---|---|---|---|---|---|---|
| 1 | True | 12 | 0 | 98.1 % | 29.1 | 0.0 | 0.95 | 0 | True |
| 2 | True | 12 | 0 | 98.1 % | 28.3 | 0.0 | 1.81 | 0 | True |
| 3 | True | 12 | 0 | 98.1 % | 20.1 | 0.0 | 1.21 | 0 | True |
| 4 | True | 12 | 0 | 98.1 % | 29.1 | 0.0 | 2.06 | 0 | True |
