# SPITFIRE.OS demonstration report - Larkspur Farm (fictional)

Seed 42, 6 aircraft, simulated duration 510 s (wall 42.4 s). Clean shutdown: True. Errors: 0.

> All figures are properties of the simulation model (kinematic aircraft, simple energy model, simulated network). They are modelled performance, not demonstrated aircraft performance. A simulation without collisions is not evidence of safety; separation checks cover only the modelled aircraft and hazards and do not replace onboard detect-and-avoid or autopilot failsafes.

## Demonstration checklist

| # | Step | Shown | t [s] | Evidence |
|---|---|---|---|---|
| 1 | Initial state collection | yes | 0.5 | fresh aircraft: ['drone-01', 'drone-02', 'drone-03', 'drone-04', 'drone-05', 'drone-06'] |
| 2 | Survey-lane allocation | yes | 0.5 | greedy: {'drone-01': ['L06a', 'L06b', 'L08(rev)'], 'drone-02': ['L05a', 'L05b'], 'drone-03': ['L04a', 'L04b', 'L09(rev)'], 'drone-04': ['L01'], 'drone-05': ['L02', 'L07(rev)'], 'drone-06': ['L03']} |
| 3 | Conflict-checked scheduling | yes | 0.5 | conflicts after resolution: 0; resolutions {'drone-01': 'OK', 'drone-02': 'RESOLVED_BY_DELAY', 'drone-03': 'RESOLVED_BY_DELAY', 'drone-04': 'OK', 'drone-05': 'RESOLVED_BY_DELAY', 'drone-06': 'RESOLVED_BY_REORDER'} |
| 4 | Coordinated departure | yes | 1.3 | commit acked by ['drone-01', 'drone-02', 'drone-03', 'drone-04', 'drone-05', 'drone-06']; max abs start error 1.3 ms (tolerance 250 ms) |
| 5 | Task execution | yes | 113.3 | 12 tasks completed; coverage 98.1 % |
| 6 | One delayed communication link | yes | 121.9 | stale telemetry at 121.9 s; aircraft paused onboard (lease lapse) at 127.5 s; coordinator registered the pause at 155.3 s; work resumed 29.3 s after the link was restored |
| 7 | One aircraft reaching its battery reserve | yes | 248.6 | drone-03 at 248.6 s |
| 8 | Safe suspension and reassignment | yes | 250.3 | reassignment committed 1.5, 13.3 s after suspension; duplicate survey length 0.0 m |
| 9 | Sequenced recovery | yes | 166.5 | landing order: drone-04@259.1s, drone-03@340.4s, drone-02@393.6s, drone-01@420.8s, drone-06@483.0s, drone-05@510.0s |
| 10 | Final coverage and timing report | yes | 510.0 | metric: see summary below |

## Summary metrics

| Metric | Value |
|---|---|
| coverage_fraction | 98.1 % |
| duplicate_length_m | 0.00 |
| concurrent_duplicate_execution | 0.00 |
| mission_duration_s | 492.25 |
| total_travel_distance_m | 12046.22 |
| total_energy_wh | 158.87 |
| min_true_separation_m | 30.23 |
| true_separation_infringements_s | 0.00 |
| predicted_separation_violations | 0.00 |
| sync_start_abs_max_s | 1.32 ms |
| command_ack_latency_p95_s | 300 ms |
| reassignment_delay_max_s | 13.30 |
| recovery_after_comm_loss_max_s | 29.25 |
| autopilot_failsafes | 0.00 |

## Synchronised start (initial plan)

Error = true start of execution (agent clock mapped to world time) minus the committed start (coordination timescale mapped to world time). Take-off error is the physical response (first crossing of 0.5 m) relative to the plan.

| Aircraft | Start error [ms] | Take-off error [s] |
|---|---|---|
| drone-01 | -0.35 | -0.13 |
| drone-02 | 1.16 | -0.15 |
| drone-03 | 0.01 | -0.13 |
| drone-04 | 0.06 | -0.13 |
| drone-05 | -1.32 | -0.13 |
| drone-06 | 0.59 | -0.13 |

## Per-aircraft (truth)

| Aircraft | Distance [m] | Energy (model) [Wh] |
|---|---|---|
| drone-01 | 2303 | 23.4 |
| drone-02 | 1661 | 22.4 |
| drone-03 | 1776 | 40.6 |
| drone-04 | 1236 | 14.1 |
| drone-05 | 2412 | 30.1 |
| drone-06 | 2657 | 28.2 |

## Recovery sequence

| Aircraft | Priority | Slot start [s] | Landed [s] |
|---|---|---|---|
| drone-04 | normal | 236.67 | 259.1 |
| drone-03 | reserve | 319.04 | 340.4 |
| drone-02 | normal | 372.17 | 393.6 |
| drone-01 | normal | 398.96 | 420.8 |
| drone-06 | normal | 461.1 | 483.0 |
| drone-05 | normal | 488.48 | 510.0 |

## Key coordination events

| t [s] | Event | Aircraft | Reason |
|---|---|---|---|
| 1.3 | commit_result |  | COMMITTED |
| 121.9 | stale_telemetry | drone-02 | STALE_TELEMETRY |
| 132.6 | lease_expired | drone-02 | LEASE_EXPIRED |
| 144.1 | hold_for_uncertain_aircraft | drone-05 | UNCERTAIN_REGION_CONFLICT |
| 144.5 | aircraft_paused | drone-05 | COMMAND_EXECUTED |
| 146.6 | link_lost | drone-02 | STATE_LOST |
| 150.1 | position_unassessable | drone-02 | POSITION_UNASSESSABLE |
| 150.4 | reconciled | drone-05 | RECONCILED |
| 150.4 | remainder_created | drone-05 | OK |
| 154.9 | link_restored | drone-02 | LINK_RESTORED |
| 155.3 | aircraft_paused | drone-02 | LEASE_EXPIRED |
| 156.6 | reconciled | drone-05 | RECONCILED |
| 157.2 | commit_result |  | COMMITTED |
| 157.2 | resumed | drone-05 | OK |
| 161.4 | reconciled | drone-02 | RECONCILED |
| 161.8 | commit_result |  | COMMITTED |
| 161.8 | resumed | drone-02 | OK |
| 166.5 | commit_result |  | COMMITTED |
| 166.5 | recovery_scheduled | drone-04 | OK |
| 248.6 | task_suspended | drone-03 | BATTERY_RESERVE_BREACH |
| 248.6 | battery_reserve | drone-03 | BATTERY_RESERVE_BREACH |
| 249.5 | reallocation |  | OK |
| 250.3 | commit_result |  | COMMITTED |
| 250.3 | task_reassigned | drone-05 | OK |
| 251.1 | commit_result |  | COMMITTED |
| 251.1 | recovery_scheduled | drone-03 | OK |
| 255.5 | reallocation |  | OK |
| 259.1 | landed | drone-04 | OK |
| 261.5 | reallocation |  | OK |
| 262.3 | commit_result |  | COMMITTED |
| 262.3 | task_reassigned | drone-06 | OK |
| 295.6 | commit_result |  | COMMITTED |
| 295.6 | recovery_scheduled | drone-02 | OK |
| 298.4 | commit_result |  | COMMITTED |
| 298.4 | recovery_scheduled | drone-01 | OK |
| 340.4 | landed | drone-03 | OK |
| 393.6 | landed | drone-02 | OK |
| 401.2 | commit_result |  | COMMITTED |
| 401.2 | recovery_scheduled | drone-06 | OK |
| 416.4 | commit_result |  | COMMITTED |
| 416.4 | recovery_scheduled | drone-05 | OK |
| 420.8 | landed | drone-01 | OK |
| 483.0 | landed | drone-06 | OK |
| 510.0 | landed | drone-05 | OK |
| 510.0 | mission_finished |  | OK |

## Figures

![plan_view](trajectories.png)
![altitude](altitude.png)
![separation](separation.png)
![timeline](timeline.png)
