# Multi-seed evaluation (12 seeds, 6 aircraft, allocator greedy)

> All figures are properties of the simulation model (kinematic aircraft, simple energy model, simulated network). They are modelled performance, not demonstrated aircraft performance. A simulation without collisions is not evidence of safety; separation checks cover only the modelled aircraft and hazards and do not replace onboard detect-and-avoid or autopilot failsafes.

| Metric | n | min | p5 | median | p95 | max |
|---|---|---|---|---|---|---|
| coverage_fraction | 12 | 0.9806 | 0.9807 | 0.9809 | 0.9814 | 0.9814 |
| duplicate_length_m | 12 | 0 | 0 | 0 | 0 | 0 |
| concurrent_duplicate_execution | 12 | 0 | 0 | 0 | 0 | 0 |
| mission_duration_s | 12 | 487.5 | 487.8 | 497.8 | 566.6 | 600 |
| total_travel_distance_m | 12 | 1.194e+04 | 1.2e+04 | 1.338e+04 | 1.357e+04 | 1.357e+04 |
| total_energy_wh | 12 | 161 | 161.3 | 171.4 | 179.4 | 180.6 |
| min_true_separation_m | 12 | 28.28 | 28.87 | 30.71 | 39.63 | 39.96 |
| true_separation_infringements_s | 12 | 0 | 0 | 0 | 0 | 0 |
| predicted_separation_violations | 12 | 0 | 0 | 0 | 0 | 0 |
| sync_start_abs_max_s | 12 | 0.0008548 | 0.0009254 | 0.001323 | 0.002368 | 0.002376 |
| command_ack_latency_p95_s | 12 | 0.3 | 0.3 | 0.3 | 1.248 | 1.3 |
| reassignment_delay_max_s | 11 | 11 | 11.25 | 12.3 | 14.05 | 14.1 |
| recovery_after_comm_loss_max_s | 11 | 20.84 | 21.03 | 22.26 | 28.44 | 29.44 |
| autopilot_failsafes | 12 | 0 | 0 | 0 | 0 | 0 |

## Per seed

| seed | finished | tasks done | unfinished | coverage | min sep [m] | infringement [s] | max start err [ms] | errors | clean shutdown |
|---|---|---|---|---|---|---|---|---|---|
| 1 | True | 12 | 0 | 98.1 % | 35.7 | 0.0 | 1.32 | 0 | True |
| 2 | True | 12 | 0 | 98.1 % | 30.7 | 0.0 | 0.85 | 0 | True |
| 3 | True | 12 | 0 | 98.1 % | 28.3 | 0.0 | 1.08 | 0 | True |
| 4 | True | 12 | 0 | 98.1 % | 39.4 | 0.0 | 2.06 | 0 | True |
| 5 | True | 12 | 0 | 98.1 % | 29.4 | 0.0 | 1.26 | 0 | True |
| 6 | True | 12 | 0 | 98.1 % | 30.8 | 0.0 | 1.29 | 0 | True |
| 7 | True | 12 | 0 | 98.1 % | 40.0 | 0.0 | 0.98 | 0 | True |
| 8 | True | 12 | 0 | 98.1 % | 31.8 | 0.0 | 1.56 | 0 | True |
| 9 | True | 12 | 0 | 98.1 % | 38.9 | 0.0 | 2.36 | 0 | True |
| 10 | True | 12 | 0 | 98.1 % | 30.2 | 0.0 | 1.90 | 0 | True |
| 11 | True | 12 | 0 | 98.1 % | 29.7 | 0.0 | 1.32 | 0 | True |
| 12 | True | 12 | 0 | 98.1 % | 30.5 | 0.0 | 2.38 | 0 | True |
