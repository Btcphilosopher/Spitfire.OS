# Multi-seed evaluation (8 seeds, 6 aircraft, allocator optimal)

> All figures are properties of the simulation model (kinematic aircraft, simple energy model, simulated network). They are modelled performance, not demonstrated aircraft performance. A simulation without collisions is not evidence of safety; separation checks cover only the modelled aircraft and hazards and do not replace onboard detect-and-avoid or autopilot failsafes.

| Metric | n | min | p5 | median | p95 | max |
|---|---|---|---|---|---|---|
| coverage_fraction | 8 | 0.9809 | 0.981 | 0.9812 | 0.9814 | 0.9814 |
| duplicate_length_m | 8 | 0 | 0 | 0 | 0 | 0 |
| concurrent_duplicate_execution | 8 | 0 | 0 | 0 | 0 | 0 |
| mission_duration_s | 8 | 441.5 | 443.3 | 461.3 | 469.8 | 471.3 |
| total_travel_distance_m | 8 | 1.176e+04 | 1.176e+04 | 1.183e+04 | 1.184e+04 | 1.184e+04 |
| total_energy_wh | 8 | 133 | 133.3 | 138.7 | 142.9 | 143 |
| min_true_separation_m | 8 | 28.4 | 28.48 | 28.71 | 30.96 | 30.96 |
| true_separation_infringements_s | 8 | 0 | 0 | 0 | 0 | 0 |
| predicted_separation_violations | 8 | 0 | 0 | 0 | 0 | 0 |
| sync_start_abs_max_s | 8 | 0.0008548 | 0.0008997 | 0.001294 | 0.002514 | 0.002757 |
| command_ack_latency_p95_s | 8 | 0.245 | 0.2642 | 0.3 | 0.75 | 0.75 |
| reassignment_delay_max_s | 0 | - | - | - | - | - |
| recovery_after_comm_loss_max_s | 0 | - | - | - | - | - |
| autopilot_failsafes | 8 | 0 | 0 | 0 | 0 | 0 |

## Per seed

| seed | finished | tasks done | unfinished | coverage | min sep [m] | infringement [s] | max start err [ms] | errors | clean shutdown |
|---|---|---|---|---|---|---|---|---|---|
| 1 | True | 12 | 0 | 98.1 % | 28.6 | 0.0 | 1.32 | 0 | True |
| 2 | True | 12 | 0 | 98.1 % | 31.0 | 0.0 | 0.85 | 0 | True |
| 3 | True | 12 | 0 | 98.1 % | 31.0 | 0.0 | 2.76 | 0 | True |
| 4 | True | 12 | 0 | 98.1 % | 28.7 | 0.0 | 2.06 | 0 | True |
| 5 | True | 12 | 0 | 98.1 % | 31.0 | 0.0 | 1.26 | 0 | True |
| 6 | True | 12 | 0 | 98.1 % | 28.7 | 0.0 | 1.55 | 0 | True |
| 7 | True | 12 | 0 | 98.1 % | 28.6 | 0.0 | 0.98 | 0 | True |
| 8 | True | 12 | 0 | 98.1 % | 28.4 | 0.0 | 1.21 | 0 | True |
