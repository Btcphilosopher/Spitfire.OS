# Multi-seed evaluation (4 seeds, 8 aircraft, allocator greedy)

> All figures are properties of the simulation model (kinematic aircraft, simple energy model, simulated network). They are modelled performance, not demonstrated aircraft performance. A simulation without collisions is not evidence of safety; separation checks cover only the modelled aircraft and hazards and do not replace onboard detect-and-avoid or autopilot failsafes.

| Metric | n | min | p5 | median | p95 | max |
|---|---|---|---|---|---|---|
| coverage_fraction | 4 | 0.9809 | 0.9809 | 0.981 | 0.9813 | 0.9813 |
| duplicate_length_m | 4 | 0 | 0 | 0 | 0 | 0 |
| concurrent_duplicate_execution | 4 | 0 | 0 | 0 | 0 | 0 |
| mission_duration_s | 4 | 451.5 | 454.4 | 470.9 | 476.6 | 477.5 |
| total_travel_distance_m | 4 | 1.448e+04 | 1.475e+04 | 1.626e+04 | 1.64e+04 | 1.642e+04 |
| total_energy_wh | 4 | 170.1 | 171.3 | 178.1 | 181.5 | 182.1 |
| min_true_separation_m | 4 | 20.38 | 21.77 | 32.35 | 35.14 | 35.16 |
| true_separation_infringements_s | 4 | 0 | 0 | 0 | 0 | 0 |
| predicted_separation_violations | 4 | 0 | 0 | 0 | 0 | 0 |
| sync_start_abs_max_s | 4 | 0.000948 | 0.0009749 | 0.001595 | 0.002653 | 0.002757 |
| command_ack_latency_p95_s | 4 | 0.3 | 0.3 | 0.3 | 0.3 | 0.3 |
| reassignment_delay_max_s | 0 | - | - | - | - | - |
| recovery_after_comm_loss_max_s | 0 | - | - | - | - | - |
| autopilot_failsafes | 4 | 0 | 0 | 0 | 0 | 0 |

## Per seed

| seed | finished | tasks done | unfinished | coverage | min sep [m] | infringement [s] | max start err [ms] | errors | clean shutdown |
|---|---|---|---|---|---|---|---|---|---|
| 1 | True | 12 | 0 | 98.1 % | 35.0 | 0.0 | 1.13 | 0 | True |
| 2 | True | 12 | 0 | 98.1 % | 35.2 | 0.0 | 0.95 | 0 | True |
| 3 | True | 12 | 0 | 98.1 % | 29.7 | 0.0 | 2.76 | 0 | True |
| 4 | True | 12 | 0 | 98.1 % | 20.4 | 0.0 | 2.06 | 0 | True |
