# Multi-seed evaluation (4 seeds, 4 aircraft, allocator greedy)

> All figures are properties of the simulation model (kinematic aircraft, simple energy model, simulated network). They are modelled performance, not demonstrated aircraft performance. A simulation without collisions is not evidence of safety; separation checks cover only the modelled aircraft and hazards and do not replace onboard detect-and-avoid or autopilot failsafes.

| Metric | n | min | p5 | median | p95 | max |
|---|---|---|---|---|---|---|
| coverage_fraction | 4 | 0.9808 | 0.9808 | 0.981 | 0.9814 | 0.9814 |
| duplicate_length_m | 4 | 0 | 0 | 0 | 0 | 0 |
| concurrent_duplicate_execution | 4 | 0 | 0 | 0 | 0 | 0 |
| mission_duration_s | 4 | 469.5 | 473 | 493.8 | 495.6 | 495.8 |
| total_travel_distance_m | 4 | 9798 | 9902 | 1.051e+04 | 1.053e+04 | 1.053e+04 |
| total_energy_wh | 4 | 103 | 103.9 | 110.8 | 112.8 | 112.9 |
| min_true_separation_m | 4 | 29 | 29.03 | 30.87 | 32.63 | 32.65 |
| true_separation_infringements_s | 4 | 0 | 0 | 0 | 0 | 0 |
| predicted_separation_violations | 4 | 0 | 0 | 0 | 0 | 0 |
| sync_start_abs_max_s | 4 | 0.0007323 | 0.0007643 | 0.001025 | 0.001125 | 0.001128 |
| command_ack_latency_p95_s | 4 | 0.3 | 0.3 | 0.3 | 0.7973 | 0.885 |
| reassignment_delay_max_s | 0 | - | - | - | - | - |
| recovery_after_comm_loss_max_s | 0 | - | - | - | - | - |
| autopilot_failsafes | 4 | 0 | 0 | 0 | 0 | 0 |

## Per seed

| seed | finished | tasks done | unfinished | coverage | min sep [m] | infringement [s] | max start err [ms] | errors | clean shutdown |
|---|---|---|---|---|---|---|---|---|---|
| 1 | True | 12 | 0 | 98.1 % | 29.2 | 0.0 | 1.10 | 0 | True |
| 2 | True | 12 | 0 | 98.1 % | 32.6 | 0.0 | 0.95 | 0 | True |
| 3 | True | 12 | 0 | 98.1 % | 32.6 | 0.0 | 1.13 | 0 | True |
| 4 | True | 12 | 0 | 98.1 % | 29.0 | 0.0 | 0.73 | 0 | True |
