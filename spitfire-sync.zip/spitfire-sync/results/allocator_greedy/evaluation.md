# Multi-seed evaluation (8 seeds, 6 aircraft, allocator greedy)

> All figures are properties of the simulation model (kinematic aircraft, simple energy model, simulated network). They are modelled performance, not demonstrated aircraft performance. A simulation without collisions is not evidence of safety; separation checks cover only the modelled aircraft and hazards and do not replace onboard detect-and-avoid or autopilot failsafes.

| Metric | n | min | p5 | median | p95 | max |
|---|---|---|---|---|---|---|
| coverage_fraction | 8 | 0.9808 | 0.9808 | 0.981 | 0.9813 | 0.9813 |
| duplicate_length_m | 8 | 0 | 0 | 0 | 0 | 0 |
| concurrent_duplicate_execution | 8 | 0 | 0 | 0 | 0 | 0 |
| mission_duration_s | 8 | 467.3 | 469.7 | 490.3 | 502 | 503.9 |
| total_travel_distance_m | 8 | 1.313e+04 | 1.32e+04 | 1.398e+04 | 1.42e+04 | 1.425e+04 |
| total_energy_wh | 8 | 143.7 | 145.3 | 149.6 | 159.3 | 162 |
| min_true_separation_m | 8 | 28.38 | 28.94 | 30.71 | 33.73 | 34.11 |
| true_separation_infringements_s | 8 | 0 | 0 | 0 | 0 | 0 |
| predicted_separation_violations | 8 | 0 | 0 | 0 | 0 | 0 |
| sync_start_abs_max_s | 8 | 0.0008548 | 0.0008997 | 0.001277 | 0.001885 | 0.002062 |
| command_ack_latency_p95_s | 8 | 0.3 | 0.3 | 0.3 | 0.5633 | 0.705 |
| reassignment_delay_max_s | 0 | - | - | - | - | - |
| recovery_after_comm_loss_max_s | 0 | - | - | - | - | - |
| autopilot_failsafes | 8 | 0 | 0 | 0 | 0 | 0 |

## Per seed

| seed | finished | tasks done | unfinished | coverage | min sep [m] | infringement [s] | max start err [ms] | errors | clean shutdown |
|---|---|---|---|---|---|---|---|---|---|
| 1 | True | 12 | 0 | 98.1 % | 28.4 | 0.0 | 1.32 | 0 | True |
| 2 | True | 12 | 0 | 98.1 % | 30.7 | 0.0 | 0.85 | 0 | True |
| 3 | True | 12 | 0 | 98.1 % | 30.0 | 0.0 | 1.08 | 0 | True |
| 4 | True | 12 | 0 | 98.1 % | 33.0 | 0.0 | 2.06 | 0 | True |
| 5 | True | 12 | 0 | 98.1 % | 30.0 | 0.0 | 1.26 | 0 | True |
| 6 | True | 12 | 0 | 98.1 % | 30.8 | 0.0 | 1.29 | 0 | True |
| 7 | True | 12 | 0 | 98.1 % | 34.1 | 0.0 | 0.98 | 0 | True |
| 8 | True | 12 | 0 | 98.1 % | 33.0 | 0.0 | 1.56 | 0 | True |
