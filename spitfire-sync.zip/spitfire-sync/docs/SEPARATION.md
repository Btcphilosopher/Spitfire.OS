# Trajectories, separation and reservations

> Separation checks are limited to the **modelled aircraft and hazards** (other aircraft in
> this fleet, configured exclusion zones, the operational boundary, the ceiling, reserved
> volumes). They do not establish airspace safety, do not know about other airspace users,
> terrain, wires or birds, and do not replace onboard detect-and-avoid or autopilot geofences.

## Trajectories

`TrajectoryBuilder` time-parameterises straight legs with rest-to-rest trapezoidal profiles,
scaling along-leg speed so vertical rate stays within climb/descent limits, and samples every
`sample_dt_s` (0.5 s). The chord error between samples, `a dt^2 / 8`, is stored as
`interp_error_m` and added to buffers.

## Pairwise check (exact for the representation)

Both trajectories are re-sampled on the union of their sample times; on each interval the
relative motion is linear, so the set of times where *horizontal < H_req and |vertical| <
V_req* is solved in closed form (quadratic + linear). Conflicts between samples are found
(test: two aircraft crossing mid-segment with 140 m between their sampled points).

```
H_req = horizontal_m + b_a + b_b + |v_a| tau_a + |v_b| tau_b
V_req = vertical_m   + b_a + b_b + |vz_a| tau_a + |vz_b| tau_b
b   = max(nominal, reported position uncertainty) + tracking tolerance + interpolation error
tau = clock uncertainty + start tolerance + extra timing buffer
```

Aircraft on the ground (below `ground_level_m`) are excluded; pad and landing-spot spacing is
a static layout constraint. A trajectory ending with `HOLD` occupies its final point
indefinitely; `LANDED` ends are no longer airborne.

## Static checks

Exclusion zones (active window + altitude range, inflated by buffers and half a sample step),
operational boundary, ceiling, survey-band compliance for survey segments.

## Reservations

`Reservation` = holder + volume (cylinder or corridor capsule chain, z range) + time window.
Used for:

* **Shared recovery area** (capacity 1): a reservation covers the time an aircraft is inside
  the recovery cylinder below its ceiling, plus margins. Recovery plans are scheduled with
  increasing delays until free of every other reservation and trajectory - landings are
  strictly sequenced.
* **Uncertain aircraft** (see below).
* **Stopped aircraft**: an aircraft that paused or reached its reserve off-plan is an obstacle
  to plans that assumed it would move on; its position is reserved until it is replanned.

## Uncertain or disconnected aircraft

For an aircraft whose telemetry is not FRESH, the coordinator reserves:

1. **Contract region** (preferred): the planned corridor from the last confirmed observation to
   its plan-lease expiry (by contract it stops then), plus - once contact may have been lost
   for half the lost-link timeout - the volumes of its *own* pre-validated contingency: column
   to its contingency layer, transfer to its hold point, return to its pad, descent at the pad.
2. **Kinematic region** (fallback when no contract applies): a cylinder whose radius grows at
   `max_speed` from the last observation, capped at `reachable_horizon_s`. Beyond
   `max_assessable_radius_m` the snapshot flags `POSITION_UNASSESSABLE`.

Other aircraft whose committed trajectories enter such a region within 20 s are commanded to
hold, then reconciled and replanned around it.

## Conflict resolution (scheduler)

Prioritised planning in deterministic order; for each aircraft, try in order: nominal ->
alternative transit band -> alternative survey band -> reversed order/directions -> departure
delay (3 s steps, then 6 s) combined with the above -> another validated hold point
(`RESOLVED_BY_REPLAN`). The resolution used is recorded per aircraft.

## Hold points

`HoldPointChecker` accepts a hold point only if, for the whole hold window, it is separated
from every other aircraft's trajectory, from every other hold point (horizontal H + 2r or
vertical V + 2r), from reservations it does not own, exclusion zones, the boundary and the
ceiling. Two aircraft are never sent to the same hold point (tested).
