# Coordinate frames

| Frame | Axes | Used for |
|---|---|---|
| `ENU` (local) | x = east, y = north, z = up, metres, origin = mission origin | **All planning, scheduling, separation, telemetry inside the package** |
| `NED` (local) | x = north, y = east, z = down | PX4/MAVLink local positions and velocities |
| WGS84 geodetic | latitude, longitude [deg], height [m] | autopilot global positions, mission origin |

* Every `Vec3` carries a `frame` tag. Arithmetic across frames raises `FrameMismatchError`.
* `Trajectory` refuses any frame but ENU. `TelemetryIngestor` rejects observations whose
  `navigation_frame` (or the vector frames) differ from the planning frame with
  `FRAME_MISMATCH` - it never converts silently.
* The **only** functions that change frames are in `models/frames.py`:
  `geodetic_to_ecef`, `ecef_to_geodetic`, `LocalTangentFrame.to_enu/to_geodetic`,
  `enu_to_ned`, `ned_to_enu`. Adapters must call them at the boundary.

## Accuracy

* Geodetic <-> ECEF: closed form / iterative WGS84, sub-millimetre round trip (tested).
* ENU tangent plane: rigid rotation of ECEF about the origin (exact Cartesian frame). Its `z`
  is height above the tangent plane, which departs from height above the ellipsoid by
  ~d^2 / 2R (0.3 m at 2 km). `LocalTangentFrame.max_extent_m` (default 20 km) refuses
  points further away.
* Altitude datum: the mission origin height must be expressed in the same datum as the
  autopilot's altitude (MAVSDK `absolute_altitude_m` is AMSL). A constant geoid offset then
  cancels locally. Mixing ellipsoidal and AMSL heights produces a constant vertical bias of the
  geoid undulation (tens of metres in places) - check this during SITL validation.
* MAVSDK adapter: offboard position setpoints are NED relative to the autopilot's EKF origin,
  which differs from the mission origin. The adapter converts ENU(mission) -> geodetic ->
  ENU(autopilot origin) -> NED (tested). Velocity uses `enu_to_ned` directly; the rotation
  between tangent planes a few km apart is below 1e-3 rad.

## Altitudes used by the demo site (above origin plane)

| Band | Range [m] | Purpose |
|---|---|---|
| S1, S2 | 33-37, 48-52 | survey |
| T1, T2 | 62-66, 74-78 | transit |
| C1..C6 | 64, 74, 84, 94, 104, 114 (+-1) | per-aircraft contingency layer (unique, 10 m apart) |
| ceiling | 120 | mission ceiling (checked with buffers) |

Contingency layers 64 and 74 coincide with transit bands: while the coordinator is alive it
models a lost-link aircraft's possible contingency path as a reserved region and plans other
aircraft around it; when the coordinator itself is lost there is no coordinated transit.
