# Timing and synchronisation

## Time quantities (never mixed)

| Quantity | Where | Notes |
|---|---|---|
| Monotonic process time | every node (`Clock.monotonic`) | used for **all local timeouts**; values from different nodes are never compared |
| UTC | every node (`Clock.utc`) | may step (NTP/GNSS); only seeds the coordination timescale and logs |
| Coordination timescale | coordinator (`CoordinationTimescale`) | coordinator monotonic + offset fixed at start (~UTC, never steps). Plans, leases, message expiry use it. Identified by `reference_id` (coordinator boot + epoch). |
| Peer clock offset | aircraft (`ClockSyncEstimator`) | estimate of (coordination time - local monotonic) with a rigorous half-width bound |
| Message age | receiver (`MessageAge`) | receiver estimate minus `issued_at`, uncertainty = receiver + sender uncertainty |
| World time | simulator only | ground truth; evaluation only |

## Offset estimation (`clocks/sync.py`)

Each aircraft sends `TIME_SYNC_REQUEST(t1)`; the coordinator answers with `t2` (receive
timestamp taken at datagram arrival) and `t3` (send time). With `t4` the local receive time:

```
theta = ((t2 - t1) + (t3 - t4)) / 2          delay = (t4 - t1) - (t3 - t2)
true offset in [theta - delay/2 - rho*(t4-t1), theta + delay/2 + rho*(t4-t1)]
```

This bound needs only causality. Intervals widen by `rho * age` (`max_relative_drift_ppm`,
default 200 ppm) and the estimator intersects the intervals of the last 16 samples
(Marzullo-style): estimate = midpoint, uncertainty = half-width. Empty intersection means
an assumption was violated (timestamp jump, drift above bound, reference change): the
estimator restarts from the newest sample and reports `CLOCK_JUMP_DETECTED`. A new
`reference_id` (new coordinator process) restarts it with `CLOCK_REFERENCE_CHANGED`.

Receive timestamping matters: timestamping when the application loop gets round to a
message (up to one control tick later) biases the offset by tens of ms. The simulated
transport timestamps arrivals like a kernel `SO_TIMESTAMP` would.

Tested: drift (-80..+120 ppm), asymmetric delays, a +2 s reference step, reference change,
UTC steps not affecting the timescale, reboot resetting monotonic time.

## Coordinated starts

* Every `PLAN_ACK` reports the aircraft's clock uncertainty; the coordinator commits only if
  it is within `timing.start_tolerance_s` (default 250 ms), every acknowledgement is bound to
  the plan digest, mission version, coordinator epoch and the aircraft's boot id, readiness has
  not expired, and the lead time before the start is at least
  `max(min_commit_lead_s, commit_lead_latency_factor x p95 one-way latency)`.
  Otherwise `commit_when_ready` returns `INSUFFICIENT_COMMIT_LEAD`, `NOT_READY` or
  `PARTIAL_ACKNOWLEDGEMENT` and the runner reschedules with a later start (bounded by
  `max_reschedules`) or excludes non-ready aircraft that are still on the ground.
* The aircraft converts the committed start into its own monotonic time and sleeps exactly to
  it (control loop ticks are not allowed to quantise the start). At start it re-checks its
  clock uncertainty and refuses (`START_FAILED`) if it exceeds the tolerance.
* A commit that arrives after `start + tolerance` is refused as `START_DEADLINE_MISSED`; the
  aircraft does not start late.
* Simultaneous commands do **not** make aircraft arrive simultaneously: trajectories are
  time-parameterised and the separation checker adds `v x timing_uncertainty` to every
  required separation.

Measured in simulation (fault scenario, 12 seeds; fleet sizes 4-12): max |start error| 0.7-2.8 ms against a 250 ms
tolerance with ~30 ms link latency. This is a property of the simulated link and clocks.

## What a real adapter can establish

* **Companion computer clock**: discipline with chrony/PTP to a GNSS-backed reference where
  available; otherwise rely on this package's two-way exchange over the coordination link,
  whose accuracy is bounded by half the round-trip asymmetry (typically 5-50 ms on telemetry
  radios, worse on cellular). The estimator reports this bound - do not assume better.
* **Autopilot time**: MAVLink `SYSTEM_TIME`/`TIMESYNC` and MAVSDK `unix_epoch_time` /
  `timesync_status` give autopilot<->companion alignment; telemetry timestamps should be
  converted on the companion with the same bound-tracking approach before being stamped on
  the coordination timescale.
* **GNSS time** gives sub-microsecond UTC when a PPS is wired to the companion; without PPS,
  NMEA time is only good to tens/hundreds of ms.
* Treat timestamp steps (GNSS acquisition, NTP step) as events: the estimator detects them
  as interval inconsistencies; UTC steps do not move the coordination timescale.
