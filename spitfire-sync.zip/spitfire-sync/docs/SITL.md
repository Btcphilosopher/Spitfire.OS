# Software-in-the-loop and the path to hardware

Real-aircraft integration lives behind `adapters/mavsdk_adapter.py` and is **disabled by
default**. Nothing in this package has been flown. Hardware dispatch must stay disabled until
every step below has been completed and signed off by the people responsible for the aircraft.

## What was verified in the build environment

* The adapter targets **MAVSDK-Python v4** (the native binding, `pip install "mavsdk>=4,<5"`).
  Class and method names were checked against the installed `mavsdk` 4.3.0 source:
  `mavsdk.asyncio.Mavsdk`, `Configuration.create_with_component_type(ComponentType.COMPANION_COMPUTER)`,
  `add_any_connection`, `first_autopilot`, and the plugins `TelemetryAsync`
  (`subscribe_position`, `subscribe_velocity_ned`, `subscribe_battery`, `subscribe_flight_mode`,
  `subscribe_armed`, `subscribe_raw_gps`, `get_gps_global_origin`), `OffboardAsync`
  (`set_position_velocity_ned(PositionNedYaw, VelocityNedYaw)`, `start`, `stop`; the source
  documents that a setpoint must be sent before `start`), `ActionAsync` (`arm`, `hold`, `land`,
  `return_to_launch`, `goto_location(lat, lon, amsl, yaw)`), `ParamAsync`
  (`get_param_float`, `get_param_int`). MAVSDK v4 changed the API from the older gRPC-based
  `mavsdk<4` package - code written for v1-v3 will not work unchanged.
* `Battery.remaining_percent` scale is not documented in the installed source; the adapter
  accepts 0..1 or 0..100.
* The online MAVSDK and PX4 documentation sites were **not reachable** from the build
  environment. The PX4 parameter names used for validation (`RTL_RETURN_ALT`, `NAV_DLL_ACT`,
  `COM_DL_LOSS_T`, `COM_OF_LOSS_T`, `BAT_LOW_THR`, `BAT_CRIT_THR`, `COM_LOW_BAT_ACT`,
  `GF_ACTION`, `MPC_XY_VEL_MAX`, `MPC_Z_VEL_MAX_UP`, `MPC_Z_VEL_MAX_DN`, `MPC_ACC_HOR_MAX`) and
  their semantics/units **must be checked against the parameter reference of the PX4 release
  you run** before relying on `validate-config` findings.
* The adapter was **not run against a PX4 SITL instance** (no simulator in the build
  environment). Unit tests cover the dispatch gates and the frame conversion only.

## Gates

1. `enabled = true` in `MavsdkAdapterConfig` (otherwise construction raises).
2. `mode = "sitl"` accepts only loopback/UDP/TCP URLs on the local host.
3. `mode = "hardware"` is **monitor-only** (telemetry, parameters) unless
   `hardware_dispatch_enabled = true` **and** `SPITFIRE_HARDWARE_DISPATCH=I_ACCEPT_RESPONSIBILITY`
   is set in the environment; every command otherwise raises `HardwareDispatchDisabled`.

## SITL procedure (to be performed)

1. Start PX4 SITL with N vehicles (PX4 multi-vehicle Gazebo instructions for your release;
   each instance exposes an offboard UDP port, conventionally 14540 + instance - verify).
2. `spitfire-sync sitl-check --enable --url udp://:14540` - confirm telemetry, mode/armed
   mapping, frame conversion (fly a known square and compare), parameter read-back.
3. Run `validate-config` with the parameters read from each SITL vehicle and fix all ERRORs.
4. Wire `MavsdkAdapter` instead of `SimAdapter` for each agent (one companion process per
   vehicle, real `SystemClock`, a real authenticated transport) and fly the demo mission in SITL
   with the scripted faults reproduced by network emulation (`tc netem`) and battery parameter
   injection.
5. Compare SITL metrics with the simulator's distributions; investigate every divergence.

## Additional aircraft-specific validation required before any hardware use

* Airworthiness, operator approvals and the applicable regulatory framework (e.g. specific
  category operational authorisation / SORA, or local equivalent) - outside this software.
* Identification of the real energy model from flight logs; verified autopilot battery
  failsafes as the authoritative backstop.
* Measured tracking performance (deviation distribution in wind) to set
  `tracking_tolerance_m`; measured navigation accuracy to set uncertainty values.
* Measured link latency/loss distributions to set lease, freshness and commit-lead parameters.
* Time-sync validation (GNSS/PPS or measured two-way bound) against the start tolerance.
* Geofence configured in the autopilot independent of this package; RTL altitudes per aircraft
  equal to the configured contingency layers; failsafe actions reviewed per aircraft.
* Detect-and-avoid or equivalent mitigation for non-cooperative traffic; this package only
  separates its own aircraft.
* Message authentication on every link with provisioned keys (see SECURITY.md).
* Hardware-in-the-loop with the actual companion computers before flight; staged flight
  testing (single aircraft tethered/low altitude -> two aircraft -> full fleet) with a safety
  pilot able to take over each aircraft.
