# Security notes

* No cryptographic primitive is implemented in this package. `HmacAuthenticator` uses
  Python's `hmac` (HMAC-SHA256, RFC 2104) with `hmac.compare_digest`.
* HMAC keys are symmetric and per sender: any node holding a sender's key could forge that
  sender's messages. In the simulator each aircraft holds only its own key and the
  coordinator's key, so an aircraft can verify - and in principle forge - coordinator
  messages. For real deployments use asymmetric signatures (e.g. Ed25519 via a vetted library)
  or mutually authenticated TLS 1.3 / DTLS 1.3 / WireGuard tunnels between ground and
  companion computers, and MAVLink 2 message signing on the autopilot link (MAVSDK v4 exposes
  `Mavsdk.enable_signing`).
* `derive_demo_keys` produces deterministic keys for simulation only. Real keys must be
  provisioned, stored and rotated by a key-management process outside this package.
* Replay and stale traffic are rejected by expiry, `message_id` de-duplication, a sequence
  replay window and the coordinator epoch; commands are additionally bound to the target boot
  id and plans to a digest, mission version, epoch and boot id.
* Confidentiality is not provided by the message layer.
