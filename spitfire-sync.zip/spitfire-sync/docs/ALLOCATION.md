# Task allocation

## Cost function (`allocation/cost.py`)

For aircraft *d* (after its existing commitments) and lane *k*:

```
cost(d,k) = w_travel  * travel_time(d.end -> nearer end of k)      # route around exclusion zones,
          + w_dur     * duration(k)                                 #   transit speed + climb/descent
          + w_battery * (E_needed / E_available)^2
          + w_commit  * committed_time(d)                            # balances the makespan
E_needed    = (E(travel) + E(lane)) * planning_margin + E(return to recovery from lane exit)
E_available = remaining energy - reserve_fraction * capacity
```

`cost = +inf` with a reason code when: payload incompatible (`PAYLOAD_INCOMPATIBLE`), aircraft
not FRESH / not assessable / reserve breached / in a non-working status
(`AIRCRAFT_NOT_AVAILABLE`), route blocked (`ROUTE_BLOCKED`), or `E_needed > E_available`
(`BATTERY_RESERVE_INSUFFICIENT`). Lane direction is chosen per lane (reversible lanes).
Default weights: `travel_s=1.0, duration_s=0.3, battery_penalty=60, commitment_s=0.6`.

## Allocators

* `GreedyAllocator` (baseline, deterministic): repeatedly assigns the globally cheapest
  feasible pair; ties broken by `(cost, drone_id, task_id)`. When nothing can take a task,
  the most informative reason is reported.
* `OptimisingAllocator` (optional, `allocator = "optimal"`): rounds of Hungarian assignment
  (`scipy.optimize.linear_sum_assignment`, at most one task per aircraft per round), then
  deterministic move-based local search minimising `makespan + 0.2 x total travel`. Falls
  back to greedy if its result would be infeasible.

Reallocation uses the same allocators on the pending tasks, with each candidate's
commitments taken at the end of its remaining committed tasks (amendments never cut a lane
in progress).

## Energy model - a simulation assumption

```
P(v_air, w) = P_hover * (1 + c * (v_air / v_ref)^2) + max(w, 0) * m * g / eta
```

Defaults: 60 Wh, 180 W hover, c = 0.25, v_ref = 10 m/s, 2.5 kg, eta = 0.6, planning margin
1.25. This is a planning heuristic. It is **not** an endurance model of any aircraft and must
never be presented as an endurance guarantee. The simulator's "true" consumption multiplies
it by a hidden per-aircraft factor (e.g. 2.1 for the demo's faulty aircraft). Aircraft learn
a correction factor online (measured / modelled energy) and use it for their reserve check.
For real aircraft, replace it with a model identified from flight logs and keep the reserve
check in the autopilot (`BAT_LOW_THR`/`BAT_CRIT_THR`) as the authoritative backstop.

## Reallocation after suspension

Work is reallocated only after previous ownership is resolved: the lane's lease (and every
ancestor's) must be `RELEASED` by its holder or `EXPIRED` past margin and clock uncertainty.
The remainder starts `lane_overlap_m` (5 m) before the last reported progress point so that
no gap is left; duplicated coverage is therefore bounded by the overlap plus progress-report
staleness, and is measured.
