# Simulator and evaluation

## World model (`simulation/world.py`)

* Kinematic multirotor with a PD(+I) position controller emulating an autopilot: modes
  ON_GROUND, OFFBOARD (setpoint tracking), HOLD (incl. goto), LAND, RETURN_TO_LAUNCH,
  EMERGENCY. Acceleration and speed limits, climb/descent limits.
* Autopilot-owned failsafes: battery critical -> land; offboard setpoint loss
  (`COM_OF_LOSS_T`) -> hold.
* Wind: mean + Ornstein-Uhlenbeck gusts acting through air-relative drag; it also changes
  airspeed and therefore consumption.
* Battery: energy model power x hidden per-aircraft `consumption_factor`.
* Navigation error: first-order Gauss-Markov position error (sigma configurable, degradation
  windows), velocity noise; reported uncertainty = max(configured, 2.5 sigma).
* Clocks: per-node `SimulatedClock` with drift, monotonic offset, UTC offset, jumps, reboot.
* Network: `SimNetwork` - latency, exponential jitter (=> reordering), loss, duplication,
  scripted episodes (delay, outage) per node, hard node-down (coordinator crash). Arrivals are
  receive-timestamped with the receiver's clock.
* Faults: companion reboot (`reboot_at_s`), arming failure, coordinator crash, obstruction
  reports, link episodes, consumption factor, navigation degradation.

The coordinator sees only what arrives as telemetry through the network. Ground truth
(positions, true energy, true clock relations) is read only by `evaluation/`.

## Time modes

* `run_simulation` - accelerated, deterministic, inside `VirtualTimeEventLoop` (a 9-minute
  6-aircraft mission takes ~15-30 s of CPU).
* `run_realtime(speed=...)` / `spitfire-sync demo --realtime --speed X` - wall-clock paced on
  a normal asyncio loop (same code path; not bit-reproducible).
* `spitfire-sync playback results/demo/trace.json` - replays the recorded decision timeline.

## Metrics (`evaluation/metrics.py`)

| Metric | Definition |
|---|---|
| Survey coverage | fraction of 5 m cells of the survey area (minus exclusion zones) within half a swath of a true position with payload on and altitude in a survey band |
| Duplicate execution | along-lane length surveyed more than once beyond the configured overlap (+3 m), and count of concurrent surveys of the same lane by different aircraft |
| Mission duration | first take-off to last landing (truth) |
| Travel distance / energy | per aircraft, truth |
| Minimum true separation | min 3-D distance between airborne aircraft (truth, 0.25 s) |
| True separation infringement | seconds during which horizontal < `horizontal_m` and vertical < `vertical_m` |
| Predicted separation violations | conflicts in the as-committed plans (plan history stitched at each switch) with zero buffers |
| Synchronised-start error | agent start (agent clock -> world) minus committed start (coordination timescale -> world); take-off error = physical 0.5 m crossing vs plan |
| Command ack latency | first send -> acknowledgement (all commands and commits) |
| Task reassignment delay | suspension -> commit of the new owner's plan; and suspension -> first payload sample on the task |
| Recovery after communication loss | link restoration (end of scripted episode) -> resumed plan effective time |

`spitfire-sync evaluate` reports min/p5/median/p95/max across seeds plus per-seed rows.

All results are **modelled** performance of this simulator. They are not demonstrated
aircraft performance; zero simulated collisions is not evidence of safety.
