# Coordination protocol (v1.0)

## Envelope

Every message is an `Envelope` (`models/messages.py`):

`message_id, protocol_version, type, sender_id, recipient_id, boot_id, coordinator_epoch,
mission_version, sequence_number, issued_at, expires_at, payload, auth_tag`

`type` must equal `payload.kind` (validated). Times are on the coordination timescale.
Serialisation is JSON; `auth_tag` is HMAC-SHA256 over the canonical JSON without the tag.

| Type | From | Purpose |
|---|---|---|
| `STATE_UPDATE` | aircraft | one `DroneState` observation |
| `PLAN_PROPOSAL` | coordinator | `DronePlan` + digest + readiness deadline + timing tolerance |
| `PLAN_ACK` | aircraft | ready / not ready + reasons, bound to digest, plan version, epoch, boot id; readiness expiry; clock uncertainty |
| `PLAN_COMMIT` | coordinator | commit id, digest, version, effective time, leases |
| `TASK_LEASE` | coordinator | grant or revoke (revoke also confirms a completion/release report) |
| `LEASE_RENEWAL` | coordinator | extend a lease |
| `COMMAND` | coordinator | `HOLD_POSITION`, `GOTO_HOLD`, `RELEASE_TASK`, `ABANDON_TASK`, `RECONCILE` |
| `COMMAND_ACK` | aircraft | `CommandAcknowledgement` (also acknowledges commits and aborts) |
| `TASK_PROGRESS` | aircraft | started / in progress / paused / suspended (+released) / start failed / start missed |
| `TASK_COMPLETE` | aircraft | task finished, lease released |
| `COORDINATION_ABORT` | coordinator | stop coordinated work, fly own contingency |
| `TIME_SYNC_REQUEST/RESPONSE`, `HEARTBEAT` | - | clock sync and liveness (not task-bearing) |

## Admission (`MessageGuard`)

In order, first failure wins: major protocol version -> known sender -> role authorised for
the type (aircraft cannot send `PLAN_COMMIT`, a state update must describe its sender) ->
authentication tag -> recipient -> expiry (rejected if it *might* have expired given the
receiver's clock uncertainty) -> duplicate `message_id` -> sequence replay window ->
coordinator epoch (lower than the highest seen = `STALE_EPOCH`).

## Idempotency and retries

* Commands carry a stable `command_id`; the coordinator retries with new message ids until
  acknowledged or expired. The aircraft executes a command once and re-sends the cached
  acknowledgement (`duplicate=true`) for retries - so lost acknowledgements are recovered.
* Commits are acknowledged by `commit_id`. Only final outcomes are cached; a commit that
  overtook its proposal is re-evaluated when retried.
* Completion and release reports are retried by the aircraft until the coordinator confirms
  them (a `TASK_LEASE` revoke for that lease); the coordinator treats repeats idempotently.
* State updates are de-duplicated by `(boot_id, sequence_number)` in the ingestor.

## Readiness protocol

```
propose plan -> validate locally -> acknowledge readiness -> commit versioned schedule
             -> execute when permitted -> monitor outcomes
```

Local validation (`DroneAgent.validate_plan`): expected boot id, newer version, not a failed
aircraft, clock uncertainty within tolerance, sufficient lead, kinematic feasibility against
the aircraft's own limits, continuity with where the aircraft will be at the effective time,
energy (own model with an online consumption correction, reserve kept except for recovery
plans), digest matches. Readiness expires (`readiness_validity_s`).

Commit (`Coordinator.commit_when_ready`): requires every participant's acknowledgement to be
ready, unexpired, and bound to the right digest/version/epoch/boot, clock uncertainty within
tolerance, sufficient lead, and every lease grantable (ownership resolved). Otherwise it
returns a structured `CommitResult` and nothing is committed.

## Leases

* One non-terminal lease per task (`OFFERED`/`ACTIVE`/`REVOKED`); terminal = `RELEASED`
  (authoritative, by the holder) or `EXPIRED` (expiry + margin + clock uncertainty passed).
* A remainder task can only be leased when its ancestors' leases are terminal, or held by
  the same aircraft (which then supersede).
* Each committed plan also carries a **plan lease** for the aircraft as a whole. The aircraft
  follows its trajectory only while the plan lease and the current task lease are valid using
  the latest bound of its time estimate minus a safety margin; otherwise it holds and never
  resumes that plan.
* The coordinator renews leases only for aircraft whose telemetry is FRESH and whose boot id
  matches. Unreliable information therefore pauses work automatically.

## Partial-start policy

A coordinated start is an engineering tolerance, not an atomic transaction.
`coordinator.partial_start_policy`:

* `continue_and_reallocate` (default): aircraft that started continue (their trajectories
  were deconflicted against the failed aircraft's planned trajectory, and the failed aircraft
  is on its pad). The failed aircraft's leases are revoked; its lanes are reallocated by plan
  amendments once ownership is resolved. If the started fraction falls below
  `min_start_participation`, the policy escalates to `abort_all`.
* `abort_all`: `COORDINATION_ABORT` to everyone; each aircraft flies its own pre-validated
  contingency and lands; nothing is reallocated automatically.

A start counts as failed when the aircraft reports `START_FAILED` / `START_MISSED`, or no
`STARTED` report arrives by `effective_from + tolerance + 2 x p95 latency + 1.5 s`.

## Plan amendments

Reassignment, resumption and recovery are new plan versions for the affected aircraft only,
with `effective_from` in the future (`amendment_lead_s` or latency-derived). The aircraft
keeps flying its current plan until then and checks continuity at the switch. The coordinator
keeps a plan history and evaluates "who is where when" with composite trajectories (old plan
until the switch, new plan after).
