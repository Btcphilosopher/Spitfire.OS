# Test results

Actual output of `scripts/run_tests.sh` (`python -m pytest -rA --durations=15 tests`) on the delivered code.

Environment: Linux, Python 3.13.18, numpy 2.5.3, scipy 1.18.1, pydantic 2.13.5, matplotlib 3.11.2, pytest 9.1.1, pytest-asyncio 1.5.0, mavsdk 4.3.0. MAVSDK is installed but no PX4 SITL was available: only the adapter's dispatch gates and frame conversion are exercised.

**Result: `95 passed in 200.27s (0:03:20)`** (95 passed, 0 failed).

Raw output: `test_output.txt` in the repository root.

## Requested test areas

| Area | Tests |
|---|---|
| Frame conversions | test_frames.py - ENU/NED axes and round trip, WGS84 round trip, known values, extent limit, mixed-frame rejection |
| Clock drift and timestamp jumps | test_clocks.py - bounded offset under drift and asymmetry, uncertainty growth, jump detection, reference change, UTC step, reboot |
| Duplicate and reordered telemetry | test_telemetry.py - duplicates, out-of-order, gaps, reboot sequence reset, NaN/invalid, impossible motion, future timestamps, frames |
| Stale-state rejection | test_telemetry.py freshness/prediction tests; test_protocol.py message expiry |
| Lease expiry | test_leases.py; test_readiness.py::test_lease_lapse_pauses_execution |
| Stale-coordinator commands | test_protocol.py::test_stale_epoch_rejected_after_newer_coordinator_seen, ::test_stale_coordinator_command_rejected_by_agent |
| Partial-start failure | test_simulation.py::test_partial_start_failure_continues_and_reallocates, ::test_partial_start_abort_all_policy; test_readiness.py missed deadline / arming failure |
| Crossing trajectories | test_separation.py::test_crossing_detected_between_sampled_waypoints and buffer tests; scheduler head-on resolution |
| Shared recovery-area conflicts | test_separation.py::test_reservation_conflict_in_shared_recovery_area_and_slot_sequencing; test_simulation.py::test_sequenced_recovery_in_shared_area |
| Reconnection reconciliation | test_simulation.py::test_link_outage_pause_reconciliation_and_resume, ::test_companion_reboot_is_detected_and_reconciled |
| Deterministic simulation | test_simulation.py::test_simulation_is_deterministic_for_a_seed |
| Clean shutdown | test_simulation.py::test_nominal_mission_completes_with_separation_and_clean_shutdown; test_misc.py real-time mode |

## Slowest tests

```
65.36s call     tests/test_simulation.py::test_link_outage_pause_reconciliation_and_resume
58.27s call     tests/test_simulation.py::test_partial_start_abort_all_policy
38.69s call     tests/test_simulation.py::test_simulation_is_deterministic_for_a_seed
9.96s setup    tests/test_simulation.py::test_nominal_mission_completes_with_separation_and_clean_shutdown
9.95s call     tests/test_simulation.py::test_companion_reboot_is_detected_and_reconciled
5.40s call     tests/test_simulation.py::test_mission_obstruction_splits_lanes_and_replans
5.39s call     tests/test_simulation.py::test_partial_start_failure_continues_and_reallocates
3.87s call     tests/test_simulation.py::test_coordinator_failure_enters_documented_degraded_mode
2.15s call     tests/test_misc.py::test_realtime_playback_mode_runs_same_code_path
0.17s call     tests/test_separation.py::test_scheduler_resolves_head_on_conflict_by_delay_or_band
0.05s call     tests/test_allocation.py::test_optimiser_assigns_everything_with_no_worse_makespan_estimate
0.05s call     tests/test_simulation.py::test_nominal_mission_completes_with_separation_and_clean_shutdown
```

## All tests

### tests/test_allocation.py (5)
- PASSED `test_greedy_is_deterministic_and_assigns_each_task_once`
- PASSED `test_payload_compatibility_respected`
- PASSED `test_battery_reserve_makes_assignment_infeasible`
- PASSED `test_unavailable_aircraft_excluded`
- PASSED `test_optimiser_assigns_everything_with_no_worse_makespan_estimate`

### tests/test_clocks.py (8)
- PASSED `test_virtual_loop_runs_hours_instantly_and_in_order`
- PASSED `test_offset_estimate_bound_contains_truth_with_drift_and_asymmetry`
- PASSED `test_uncertainty_grows_with_age_since_last_sample`
- PASSED `test_timestamp_jump_is_detected_and_estimator_restarts`
- PASSED `test_reference_change_resets_sync`
- PASSED `test_unsynchronised_estimator_reports_infinite_uncertainty`
- PASSED `test_simulated_clock_drift_utc_jump_and_reboot`
- PASSED `test_message_age_combines_uncertainties`

### tests/test_frames.py (9)
- PASSED `test_enu_ned_axes_and_round_trip`
- PASSED `test_conversion_rejects_wrong_input_frame`
- PASSED `test_mixing_frames_is_rejected_not_silently_combined`
- PASSED `test_trajectory_must_be_enu`
- PASSED `test_ecef_geodetic_round_trip_submillimetre`
- PASSED `test_known_ecef_value_on_equator`
- PASSED `test_local_frame_axes_and_scale`
- PASSED `test_local_frame_round_trip`
- PASSED `test_local_frame_refuses_points_beyond_extent`

### tests/test_leases.py (6)
- PASSED `test_one_authoritative_owner_per_task`
- PASSED `test_lease_expiry_includes_margin_and_clock_uncertainty`
- PASSED `test_revoked_lease_blocks_reassignment_until_expiry`
- PASSED `test_remainder_requires_parent_ownership_resolution`
- PASSED `test_renewal_extends_and_release_is_terminal`
- PASSED `test_agent_side_validity_uses_latest_time_bound_boot_and_epoch`

### tests/test_misc.py (4)
- PASSED `test_kinematic_region_grows_bounded_and_flags_unassessable`
- PASSED `test_contract_region_covers_only_the_planned_corridor_until_lease_expiry`
- PASSED `test_energy_model_monotonic_in_speed_and_climb`
- PASSED `test_realtime_playback_mode_runs_same_code_path`

### tests/test_policy_and_adapters.py (13)
- PASSED `test_consistent_autopilot_settings_pass`
- PASSED `test_inconsistent_autopilot_settings_flagged[change0-RTL_RETURN_ALT]`
- PASSED `test_inconsistent_autopilot_settings_flagged[change1-BAT_LOW_THR]`
- PASSED `test_inconsistent_autopilot_settings_flagged[change2-BAT_CRIT_THR]`
- PASSED `test_inconsistent_autopilot_settings_flagged[change3-GF_ACTION]`
- PASSED `test_inconsistent_autopilot_settings_flagged[change4-MPC_XY_VEL_MAX]`
- PASSED `test_inconsistent_autopilot_settings_flagged[change5-COM_DL_LOSS_T]`
- PASSED `test_fleet_contingency_layers_must_be_unique_and_under_ceiling`
- PASSED `test_mavsdk_adapter_disabled_by_default`
- PASSED `test_sitl_mode_requires_loopback_url`
- PASSED `test_hardware_mode_is_monitor_only_unless_doubly_enabled`
- PASSED `test_hardware_monitor_mode_blocks_commands_at_the_adapter`
- PASSED `test_adapter_frame_conversion_between_mission_and_autopilot_origins`

### tests/test_protocol.py (11)
- PASSED `test_valid_message_accepted_and_duplicate_rejected`
- PASSED `test_expired_message_rejected_conservatively_with_clock_uncertainty`
- PASSED `test_unauthorised_sender_role_rejected`
- PASSED `test_tampered_or_unsigned_message_rejected`
- PASSED `test_wrong_recipient_and_unknown_sender_and_version`
- PASSED `test_stale_epoch_rejected_after_newer_coordinator_seen`
- PASSED `test_envelope_type_must_match_payload`
- PASSED `test_codec_round_trip_preserves_nan_and_auth`
- PASSED `test_command_retries_are_idempotent_and_lost_acks_recovered`
- PASSED `test_stale_coordinator_command_rejected_by_agent`
- PASSED `test_command_for_previous_boot_is_refused`

### tests/test_readiness.py (7)
- PASSED `test_valid_proposal_acknowledged_ready_and_bound`
- PASSED `test_local_validation_rejects_wrong_boot_energy_and_kinematics`
- PASSED `test_commit_bound_to_digest_and_executes_at_committed_time`
- PASSED `test_readiness_expires_before_commit`
- PASSED `test_commit_arriving_after_start_deadline_is_refused_as_missed_start`
- PASSED `test_arming_failure_reports_start_failed`
- PASSED `test_lease_lapse_pauses_execution`

### tests/test_separation.py (11)
- PASSED `test_crossing_detected_between_sampled_waypoints`
- PASSED `test_time_separated_crossing_is_not_a_conflict`
- PASSED `test_vertical_separation_resolves_crossing`
- PASSED `test_timing_uncertainty_buffer_widens_required_separation`
- PASSED `test_ground_positions_ignored_and_landed_aircraft_not_airborne`
- PASSED `test_reservation_conflict_in_shared_recovery_area_and_slot_sequencing`
- PASSED `test_hold_point_shared_by_two_aircraft_is_rejected`
- PASSED `test_hold_point_on_another_aircrafts_path_is_rejected`
- PASSED `test_trajectory_builder_respects_limits`
- PASSED `test_scheduler_resolves_head_on_conflict_by_delay_or_band`
- PASSED `test_static_exclusion_zone_check`

### tests/test_simulation.py (10)
- PASSED `test_nominal_mission_completes_with_separation_and_clean_shutdown`
- PASSED `test_coordinator_never_reads_ground_truth`
- PASSED `test_sequenced_recovery_in_shared_area`
- PASSED `test_simulation_is_deterministic_for_a_seed`
- PASSED `test_partial_start_failure_continues_and_reallocates`
- PASSED `test_partial_start_abort_all_policy`
- PASSED `test_link_outage_pause_reconciliation_and_resume`
- PASSED `test_companion_reboot_is_detected_and_reconciled`
- PASSED `test_coordinator_failure_enters_documented_degraded_mode`
- PASSED `test_mission_obstruction_splits_lanes_and_replans`

### tests/test_telemetry.py (11)
- PASSED `test_duplicate_observations_are_rejected`
- PASSED `test_out_of_order_delivery_does_not_regress_estimate`
- PASSED `test_missing_observations_are_counted`
- PASSED `test_sequence_reset_after_reboot_is_accepted_and_old_boot_rejected`
- PASSED `test_invalid_and_non_finite_positions_rejected`
- PASSED `test_incompatible_frame_rejected`
- PASSED `test_impossible_motion_rejected_then_reset_after_persistent_disagreement`
- PASSED `test_future_timestamp_rejected`
- PASSED `test_freshness_and_bounded_prediction`
- PASSED `test_uncertainty_increases_monotonically_with_age`
- PASSED `test_never_seen_aircraft_in_snapshot`

