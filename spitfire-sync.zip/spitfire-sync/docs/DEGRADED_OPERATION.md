# Degraded operation

Coordination aborts and aircraft emergency actions are different things:

* **Coordination abort / hold / suspension** - issued by the coordinator or chosen by the
  agent; the aircraft stops coordinated work and flies its own *pre-validated* contingency.
* **Aircraft emergency action** - owned by the autopilot (battery critical, geofence, RC/data
  link failsafes). The package never commands one; it detects it (`AUTOPILOT_FAILSAFE`) and
  reserves a column around the aircraft.

| Condition | Detection | Response |
|---|---|---|
| Stale telemetry | snapshot freshness (`fresh_max_age_s`, `stale_max_age_s`) | `STALE_TELEMETRY`; leases no longer renewed -> aircraft pauses at lease expiry; contract region reserved |
| Lost coordinator link (aircraft side) | no authenticated coordinator message for `lost_link_timeout_s` | pause; hold `lost_link_hold_s`; then per-aircraft `lost_link_action` |
| Link restored | snapshot FRESH again | `RECONCILE` command (status, plan version, leases, executed commands, progress); mismatch -> recovery only; else resume remaining work from reported progress |
| Battery reserve breach | agent: remaining < learned-energy(return) + reserve | stop task, release leases, hold (`RESERVE_HOLD`); coordinator: priority recovery slot, remainder reallocated; agent flies own return if no recovery plan in `reserve_wait_s` |
| Navigation uncertainty | reported uncertainty > `nav_uncertainty_threshold_m` | release task, recover the aircraft |
| Trajectory deviation | observed vs plan > threshold + uncertainty for `deviation_persist_s` | hold, reconcile, replan |
| Aircraft drop-out | LOST > `dropout_timeout_s` | leases expire; tasks reallocated after ownership resolution with the aircraft's region reserved |
| Mission obstruction | operator report (`MissionRunner.report_obstruction`) | new exclusion zone; affected lanes split; affected aircraft release and are replanned |
| Conflicting task ownership | two aircraft report the same active task | aircraft without the authoritative lease get `ABANDON_TASK` |
| Companion reboot | new `boot_id` in telemetry | old-boot leases withdrawn; reconcile; resume |
| Uncertain aircraft near others | committed trajectory enters contract/kinematic region within 20 s | hold the other aircraft, then replan around the region |
| Coordinator failure | (aircraft) lost link | degraded mode below |

## Per-aircraft contingency configuration

`ContingencyConfig`: `lost_link_timeout_s` (8), `lost_link_hold_s` (25),
`lost_link_action` (`GOTO_CONTINGENCY_HOLD` | `LAND_IN_PLACE` | `AUTOPILOT_RTL`),
`contingency_hold_timeout_s` (90), `reserve_wait_s` (25), `contingency_altitude_m`.

`GOTO_CONTINGENCY_HOLD`: climb/descend vertically to the aircraft's **own** contingency layer,
fly to its plan's validated hold point, hold, then return to its pad at that layer and land.
Layers are unique per aircraft and 10 m apart (64-114 m for six aircraft); with more aircraft
than layers, the extra aircraft use `LAND_IN_PLACE`. Not every aircraft returns along
intersecting routes at the same altitude.

`validate-config` checks these against autopilot settings (`contingencies/policy.py`): RTL
altitude equals the contingency layer, data-link-loss timeout does not pre-empt the coordination
sequence, offboard-loss timeout short, low/critical battery thresholds below the coordination
reserve, geofence enabled, autopilot speed limits not below planning limits, unique layers
under the ceiling.

## Coordinator failure (documented degraded mode)

No leader election or consensus is implemented. When the coordinator fails:

1. No more renewals: every aircraft's plan lease lapses within `lease.duration_s` and it holds
   in place (`PAUSED`).
2. After `lost_link_timeout_s` without contact it records `COORDINATOR_LINK_LOST`; after a
   further `lost_link_hold_s` it executes its own lost-link action and finally lands on its pad.
3. Aircraft never resume a suspended plan on their own.
4. Restart: an operator starts a new coordinator (new epoch). Aircraft pause on seeing the
   new epoch; the new coordinator must wait one lease duration + margin, collect state and
   reconcile each aircraft before assigning work.

Simulated (small site, crash at 90 s): every aircraft lands via its own contingency, no
autopilot failsafes, no separation infringement in that run. The hold positions at lease
lapse are taken at slightly different times per aircraft and are therefore **not** jointly
deconflicted by construction - this is a known limit; onboard detect-and-avoid is required for
real operations.
