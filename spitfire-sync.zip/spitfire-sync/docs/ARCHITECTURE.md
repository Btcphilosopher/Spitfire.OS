# Architecture

SPITFIRE.OS Drone Synchronisation Core is a **supervisory** coordination layer. It runs
on a ground coordinator and on each aircraft's companion computer. Flight stabilisation,
attitude and motor control, and aircraft-specific failsafes stay in the autopilot; the
package only ever sends position/velocity setpoints, hold, land, return-to-launch and
arm commands through an adapter.

```
            ground station                                     aircraft (x N)
 ┌─────────────────────────────────────────┐        ┌──────────────────────────────────┐
 │ MissionRunner (coordination/)           │        │ DroneAgent (coordination/agent)  │
 │  1 mission planning   simulation/scenario│        │  local plan validation           │
 │  2 task assignment    allocation/        │  msgs  │  readiness ack / commit binding  │
 │  3 trajectory sched.  scheduling/        │◄──────►│  lease-gated execution           │
 │  4 conflict checking  separation/        │ (v1.0) │  battery/link supervision        │
 │  5 command dispatch   Coordinator        │        │  own contingency (lost link)     │
 │  6 execution monitor  contingencies/     │        │        │ AircraftAdapter (ENU)   │
 │ StateStore + TelemetryIngestor (telemetry/)       │        ▼                         │
 │ LeaseManager, MessageGuard, EpochStore   │        │  SimAdapter │ MavsdkAdapter (off) │
 └─────────────────────────────────────────┘        └──────────────────────────────────┘
                 ▲ transport/ (Transport interface: SimNetwork, ... ; HMAC codec)
```

## Packages

| Package | Responsibility |
|---|---|
| `models/` | Typed records (Pydantic): `DroneState`, `EstimatedDroneState`, `FleetSnapshot`, `Mission`, `MissionTask`, `Trajectory`, `Reservation`, `Plan`/`DronePlan`, `CoordinationCommand`, `CommandAcknowledgement`, `TaskLease`, `SafetyEvent`, versioned `Envelope` + payloads; frames and geometry. |
| `clocks/` | Clock abstraction (monotonic / UTC / coordination timescale), NTP-style bounded offset estimator, virtual-time event loop, world timebase. |
| `telemetry/` | Validation, de-duplication, ordering, reboot handling (`TelemetryIngestor`); freshness and bounded prediction (`StateStore.snapshot`). Raw observations and estimates are separate types. |
| `transport/` | Replaceable `Transport` interface, `MessageCodec` (JSON + HMAC-SHA256), seeded `SimNetwork` (latency, jitter/reordering, loss, duplication, scripted episodes). |
| `allocation/` | Documented cost function, greedy baseline, Hungarian + local-search optimiser, energy model (simulation assumption). |
| `scheduling/` | Kinematic trajectory builder (speed/accel/climb/descent limits), visibility-graph router around exclusion zones, prioritised scheduler with conflict resolution. |
| `separation/` | Segment-exact 4-D conflict checking with uncertainty and timing buffers, static hazards, reservations, hold-point safety, conservative regions for uncertain aircraft. |
| `coordination/` | Message guard, leases, coordinator (proposals, readiness, commits, commands, retries, monitor), mission runner (pipeline + degraded responses), aircraft agent. |
| `contingencies/` | Execution monitor (edge-triggered `SafetyEvent`s), autopilot-settings validation. |
| `simulation/` | Ground-truth world (kinematics, wind, battery, navigation error, autopilot failsafes), scenarios, simulator (accelerated and real-time). |
| `adapters/` | `AircraftAdapter` interface, `SimAdapter`, optional `MavsdkAdapter` (disabled by default). |
| `evaluation/` | Metrics from ground truth, plots, reports, multi-seed distributions. |

## Separation of concerns (the six steps)

1. **Mission planning** - `simulation/scenario.build_mission`: survey polygon, boustrophedon lanes
   clipped to the field and split around exclusion zones (with clearance), altitude bands, launch
   pads, shared recovery area, operational boundary.
2. **Task assignment** - `allocation/`: produces an `Assignment` (per-aircraft ordered lanes with
   direction, unassigned tasks with reason codes, excluded aircraft with reason codes).
3. **Trajectory scheduling** - `scheduling/`: turns assignments into time-parameterised trajectories
   and validated hold points; resolves conflicts by delay, band change, re-ordering, re-planning.
4. **Conflict checking** - `separation/`: independent re-check of every plan against other
   committed trajectories, static hazards, reservations and uncertain regions.
5. **Command dispatch** - `Coordinator`: versioned proposals, readiness, commits bound to digests,
   expiring leases, commands with idempotent retries.
6. **Execution monitoring** - `Coordinator` + `ExecutionMonitor` + `MissionRunner`: snapshots,
   safety events and their responses.

## Coordinator failure model

Exactly one coordinator per **epoch**. Each coordinator process takes a new epoch from
`EpochStore` (file-backed when configured). Aircraft reject messages whose epoch is lower than
the highest they have seen; on seeing a higher epoch they pause (old-epoch leases stop
authorising work). There is **no leader election and no consensus**: if the coordinator fails,
aircraft follow the documented degraded mode (leases lapse -> hold in place ->
per-aircraft lost-link contingency). A replacement coordinator must be started by an operator;
it must wait at least one lease duration plus margin before assigning work, and reconcile each
aircraft (state + command history) before resuming. Automatic restart and state hand-over are
not implemented.

## Determinism

The simulator runs inside `VirtualTimeEventLoop` (single thread, virtual clock). All randomness
is drawn from seeded NumPy generators keyed by stable strings (CRC32, not Python `hash`), and no
logic iterates unordered sets. The same seed and code give bit-identical truth logs
(`tests/test_simulation.py::test_simulation_is_deterministic_for_a_seed`). Real-time playback
uses a normal event loop and is not bit-reproducible.
