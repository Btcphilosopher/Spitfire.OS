"""Aircraft state records: raw reported state and estimated (snapshot) state.

``DroneState`` is what an aircraft *reported* (a raw observation).
``EstimatedDroneState`` is what the coordinator *believes* at a given instant,
with explicit freshness, prediction validity and grown uncertainty.  The two
are deliberately different types so a last-known position cannot be passed off
as a current one.

All times are seconds on the coordination timescale (see clocks/), unless a
field name says otherwise.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field

from ..reasons import ReasonCode
from .geometry import NavigationFrame, Vec3


class FlightMode(StrEnum):
    ON_GROUND = "ON_GROUND"
    TAKEOFF = "TAKEOFF"
    OFFBOARD = "OFFBOARD"  # following supervisory setpoints
    HOLD = "HOLD"
    LAND = "LAND"
    RETURN_TO_LAUNCH = "RETURN_TO_LAUNCH"
    EMERGENCY = "EMERGENCY"  # autopilot-owned failsafe in progress
    UNKNOWN = "UNKNOWN"


class ArmedStatus(StrEnum):
    ARMED = "ARMED"
    DISARMED = "DISARMED"
    UNKNOWN = "UNKNOWN"


class AgentStatus(StrEnum):
    """Supervisory (companion-computer) status, independent of autopilot mode."""

    IDLE = "IDLE"
    READY = "READY"  # acknowledged a plan, awaiting commit/start
    COMMITTED = "COMMITTED"  # committed, waiting for start time
    EXECUTING = "EXECUTING"
    PAUSED = "PAUSED"  # lease lapsed / told to hold; holding in place
    HOLDING = "HOLDING"  # at a hold point awaiting instructions
    RESERVE_HOLD = "RESERVE_HOLD"  # battery reserve reached, waiting for recovery slot
    RECOVERING = "RECOVERING"
    LANDED = "LANDED"
    CONTINGENCY = "CONTINGENCY"  # executing its own configured contingency
    START_FAILED = "START_FAILED"


class LinkHealth(BaseModel):
    model_config = ConfigDict(frozen=True)

    quality: float = Field(ge=0.0, le=1.0, default=1.0)
    estimated_latency_s: float = Field(ge=0.0, default=0.0)
    estimated_loss_rate: float = Field(ge=0.0, le=1.0, default=0.0)
    coordinator_contact_age_s: float = Field(ge=0.0, default=0.0)


class BatteryState(BaseModel):
    """Battery as reported.  ``remaining_energy_wh`` is an energy-model estimate,
    not an endurance guarantee."""

    model_config = ConfigDict(frozen=True)

    remaining_fraction: float = Field(ge=0.0, le=1.0)
    remaining_energy_wh: float = Field(ge=0.0)
    required_to_recover_wh: float = Field(ge=0.0, default=0.0)
    reserve_fraction: float = Field(ge=0.0, le=1.0, default=0.2)
    reserve_breached: bool = False
    voltage_v: float | None = None


class DroneState(BaseModel):
    """Raw, timestamped state reported by an aircraft (one observation)."""

    model_config = ConfigDict(frozen=True, ser_json_inf_nan="constants")

    drone_id: str
    boot_id: str
    sequence_number: int = Field(ge=0)
    observation_time: float  # coordination timescale, sender's estimate
    observation_time_uncertainty: float = Field(ge=0.0, default=0.0)
    receipt_time: float | None = None  # filled by the receiver, receiver timescale
    position: Vec3
    velocity: Vec3
    position_uncertainty: float  # metres, ~95% horizontal radius (validated at ingest)
    navigation_frame: NavigationFrame
    battery_state: BatteryState
    flight_mode: FlightMode
    armed_status: ArmedStatus
    link_health: LinkHealth = LinkHealth()
    active_task_id: str | None = None
    active_lease_id: str | None = None
    plan_version: int | None = None
    agent_status: AgentStatus = AgentStatus.IDLE
    task_progress_m: float | None = None
    clock_synchronised: bool = True


class Freshness(StrEnum):
    FRESH = "FRESH"
    STALE = "STALE"
    LOST = "LOST"
    NEVER_SEEN = "NEVER_SEEN"


class EstimatedDroneState(BaseModel):
    """Coordinator belief about one aircraft at ``as_of``.

    * ``observed_position`` is the last accepted raw position (never modified).
    * ``position`` is a short-horizon prediction (constant velocity) valid only
      until ``prediction_valid_until``; afterwards it is the observed position
      with ``predicted=False`` and an uncertainty given by the kinematic
      reachable radius.
    * ``assessable`` is False once that radius exceeds the configured limit:
      the coordinator then can no longer assess the aircraft's position.
    """

    model_config = ConfigDict(frozen=True)

    drone_id: str
    boot_id: str | None
    freshness: Freshness
    as_of: float
    last_observation_time: float | None
    age_s: float | None
    observed_position: Vec3 | None
    position: Vec3 | None
    velocity: Vec3 | None
    position_uncertainty: float
    predicted: bool
    prediction_valid_until: float | None
    assessable: bool
    clock_uncertainty: float
    battery_state: BatteryState | None = None
    flight_mode: FlightMode = FlightMode.UNKNOWN
    armed_status: ArmedStatus = ArmedStatus.UNKNOWN
    agent_status: AgentStatus = AgentStatus.IDLE
    active_task_id: str | None = None
    active_lease_id: str | None = None
    plan_version: int | None = None
    task_progress_m: float | None = None
    link_health: LinkHealth | None = None
    reasons: list[ReasonCode] = Field(default_factory=list)

    @property
    def airborne(self) -> bool:
        return self.flight_mode not in (FlightMode.ON_GROUND, FlightMode.UNKNOWN) or (
            self.position is not None and self.position.z > 1.0
        )


class FleetUncertainty(BaseModel):
    model_config = ConfigDict(frozen=True)

    max_position_uncertainty: float
    max_clock_uncertainty: float
    position_uncertainty: dict[str, float]
    clock_uncertainty: dict[str, float]


class FleetSnapshot(BaseModel):
    model_config = ConfigDict(frozen=True)

    as_of: float
    drones: dict[str, EstimatedDroneState]
    uncertainty: FleetUncertainty

    def ids(self) -> list[str]:
        return sorted(self.drones)

    def fresh(self) -> list[str]:
        return [d for d in self.ids() if self.drones[d].freshness == Freshness.FRESH]

    def get(self, drone_id: str) -> EstimatedDroneState | None:
        return self.drones.get(drone_id)
