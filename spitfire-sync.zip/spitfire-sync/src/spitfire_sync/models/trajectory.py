"""Time-parameterised trajectories, reservations and plans."""

from __future__ import annotations

import hashlib
import json
import math
from enum import StrEnum
from typing import Any

import numpy as np
from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, model_validator

from ..reasons import ReasonCode
from .geometry import NavigationFrame, Vec3


class Phase(StrEnum):
    GROUND = "GROUND"
    TAKEOFF = "TAKEOFF"
    TRANSIT = "TRANSIT"
    SURVEY = "SURVEY"
    HOLD = "HOLD"
    APPROACH = "APPROACH"
    LANDING = "LANDING"
    LANDED = "LANDED"


AIRBORNE_PHASES = {Phase.TAKEOFF, Phase.TRANSIT, Phase.SURVEY, Phase.HOLD, Phase.APPROACH, Phase.LANDING}


class EndBehaviour(StrEnum):
    HOLD = "HOLD"  # aircraft remains (airborne) at the final point after end_time
    LANDED = "LANDED"  # aircraft is on the ground after end_time


class Trajectory(BaseModel):
    """Piecewise-linear (in time) ENU trajectory sampled from a kinematic profile.

    Between samples the true kinematic path deviates from the chord by at most
    ``interp_error_m`` (accounted for in separation buffers).  ``phase[i]`` and
    ``task[i]`` describe the interval [t[i], t[i+1]).
    """

    model_config = ConfigDict(frozen=True)

    drone_id: str
    frame: NavigationFrame = NavigationFrame.ENU
    t: list[float]
    x: list[float]
    y: list[float]
    z: list[float]
    phase: list[Phase]
    task: list[str | None]
    end_behaviour: EndBehaviour = EndBehaviour.HOLD
    max_speed_m_s: float = 15.0
    interp_error_m: float = 0.5

    _cache: dict[str, Any] = PrivateAttr(default_factory=dict)

    @model_validator(mode="after")
    def _check(self) -> "Trajectory":
        n = len(self.t)
        if n < 1 or not (len(self.x) == len(self.y) == len(self.z) == len(self.phase) == len(self.task) == n):
            raise ValueError("trajectory arrays must have equal, non-zero length")
        if any(b < a for a, b in zip(self.t[:-1], self.t[1:])):
            raise ValueError("trajectory times must be non-decreasing")
        if self.frame != NavigationFrame.ENU:
            raise ValueError("trajectories are planned in ENU only")
        return self

    # -- numeric access ----------------------------------------------------
    def arrays(self) -> tuple[np.ndarray, np.ndarray]:
        c = self._cache
        if "T" not in c or len(c["T"]) != len(self.t) or c.get("id") != id(self.t):
            c["T"] = np.asarray(self.t, dtype=float)
            c["P"] = np.column_stack([self.x, self.y, self.z]).astype(float)
            c["id"] = id(self.t)
        return c["T"], c["P"]

    @property
    def start_time(self) -> float:
        return self.t[0]

    @property
    def end_time(self) -> float:
        return self.t[-1]

    def position_at(self, t: float) -> np.ndarray:
        T, P = self.arrays()
        if t <= T[0]:
            return P[0].copy()
        if t >= T[-1]:
            return P[-1].copy()
        i = int(np.searchsorted(T, t, side="right") - 1)
        dt = T[i + 1] - T[i]
        f = 0.0 if dt <= 0 else (t - T[i]) / dt
        return P[i] + f * (P[i + 1] - P[i])

    def velocity_at(self, t: float) -> np.ndarray:
        T, P = self.arrays()
        if t < T[0] or t >= T[-1] or len(T) < 2:
            return np.zeros(3)
        i = int(np.searchsorted(T, t, side="right") - 1)
        dt = T[i + 1] - T[i]
        return np.zeros(3) if dt <= 0 else (P[i + 1] - P[i]) / dt

    def index_at(self, t: float) -> int:
        T, _ = self.arrays()
        if t <= T[0]:
            return 0
        return int(min(np.searchsorted(T, t, side="right") - 1, len(T) - 1))

    def phase_at(self, t: float) -> Phase:
        T, _ = self.arrays()
        if t < T[0]:
            return Phase.GROUND if self.z[0] < 0.5 else Phase.HOLD
        if t >= T[-1]:
            return Phase.LANDED if self.end_behaviour == EndBehaviour.LANDED else Phase.HOLD
        return self.phase[self.index_at(t)]

    def task_at(self, t: float) -> str | None:
        T, _ = self.arrays()
        if t < T[0] or t >= T[-1]:
            return None
        return self.task[self.index_at(t)]

    def task_window(self, task_id: str) -> tuple[float, float] | None:
        idx = [i for i, k in enumerate(self.task) if k == task_id]
        if not idx:
            return None
        return self.t[idx[0]], self.t[min(idx[-1] + 1, len(self.t) - 1)]

    def task_ids(self) -> list[str]:
        out: list[str] = []
        for k in self.task:
            if k is not None and (not out or out[-1] != k):
                if k not in out:
                    out.append(k)
        return out

    def first_airborne_time(self) -> float | None:
        for i, p in enumerate(self.phase):
            if p in AIRBORNE_PHASES and i < len(self.t) - 1:
                return self.t[i]
        return None

    def length_m(self) -> float:
        _, P = self.arrays()
        if len(P) < 2:
            return 0.0
        return float(np.linalg.norm(np.diff(P, axis=0), axis=1).sum())

    def clipped(self, t_from: float) -> "Trajectory":
        """Portion from ``t_from`` on (inserting an interpolated first sample)."""
        if t_from <= self.t[0]:
            return self
        if t_from >= self.t[-1]:
            p = self.position_at(t_from)
            return self.model_copy(
                update=dict(t=[t_from], x=[float(p[0])], y=[float(p[1])], z=[float(p[2])],
                            phase=[self.phase[-1]], task=[None])
            )
        i = self.index_at(t_from)
        p = self.position_at(t_from)
        return self.model_copy(
            update=dict(
                t=[t_from] + self.t[i + 1:],
                x=[float(p[0])] + self.x[i + 1:],
                y=[float(p[1])] + self.y[i + 1:],
                z=[float(p[2])] + self.z[i + 1:],
                phase=[self.phase[i]] + self.phase[i + 1:],
                task=[self.task[i]] + self.task[i + 1:],
            )
        )

    def airborne_mask(self) -> np.ndarray:
        """Per-interval airborne flag (length n-1)."""
        return np.array([p in AIRBORNE_PHASES for p in self.phase[:-1]], dtype=bool)


class VolumeKind(StrEnum):
    CYLINDER = "CYLINDER"
    CORRIDOR = "CORRIDOR"


class Volume(BaseModel):
    """Either a vertical cylinder or a polyline corridor (capsule chain) with a z range."""

    model_config = ConfigDict(frozen=True)

    kind: VolumeKind
    points: list[tuple[float, float]]  # cylinder: [centre]; corridor: polyline
    radius_m: float
    z_min: float
    z_max: float

    def horizontal_distance(self, x: float, y: float) -> float:
        from .geometry import point_segment_distance_2d

        if self.kind == VolumeKind.CYLINDER or len(self.points) == 1:
            c = self.points[0]
            return max(0.0, math.hypot(x - c[0], y - c[1]) - self.radius_m)
        d = min(point_segment_distance_2d((x, y), a, b) for a, b in zip(self.points[:-1], self.points[1:]))
        return max(0.0, d - self.radius_m)

    def contains(self, x: float, y: float, z: float, margin: float = 0.0) -> bool:
        return self.horizontal_distance(x, y) <= margin and (self.z_min - margin) <= z <= (self.z_max + margin)


class ReservationKind(StrEnum):
    RECOVERY_AREA = "RECOVERY_AREA"
    LANE = "LANE"
    CORRIDOR = "CORRIDOR"
    HOLD_POINT = "HOLD_POINT"
    UNCERTAIN_REGION = "UNCERTAIN_REGION"


class Reservation(BaseModel):
    """Conservative space-time reservation held by one aircraft."""

    model_config = ConfigDict(frozen=True)

    reservation_id: str
    holder: str
    kind: ReservationKind
    volume: Volume
    t_start: float
    t_end: float
    exclusive: bool = True
    shared_capacity: int = 1  # for shared resources (recovery area)
    resource: str | None = None  # name of shared resource, e.g. "recovery"

    def overlaps_time(self, t0: float, t1: float) -> bool:
        return t0 < self.t_end and t1 > self.t_start


class ConflictKind(StrEnum):
    TRAJECTORY_PAIR = "TRAJECTORY_PAIR"
    EXCLUSION_ZONE = "EXCLUSION_ZONE"
    GEOFENCE = "GEOFENCE"
    CEILING = "CEILING"
    ALTITUDE_BAND = "ALTITUDE_BAND"
    RESERVATION = "RESERVATION"
    UNCERTAIN_REGION = "UNCERTAIN_REGION"
    HOLD_POINT = "HOLD_POINT"
    SHARED_RESOURCE = "SHARED_RESOURCE"


class Conflict(BaseModel):
    model_config = ConfigDict(frozen=True)

    kind: ConflictKind
    drones: tuple[str, ...]
    t_start: float
    t_end: float
    min_horizontal_m: float | None = None
    min_vertical_m: float | None = None
    required_horizontal_m: float | None = None
    required_vertical_m: float | None = None
    location: tuple[float, float, float] | None = None
    reason: ReasonCode
    detail: str = ""


class ContingencyAssignment(BaseModel):
    """Per-aircraft pre-agreed contingency for this plan (validated by the scheduler)."""

    model_config = ConfigDict(frozen=True)

    contingency_altitude_m: float
    hold_point: Vec3
    lost_link_action: str  # see contingencies.policy.LostLinkAction
    land_position: Vec3


class PlanPurpose(StrEnum):
    INITIAL = "INITIAL"
    AMENDMENT = "AMENDMENT"
    RECOVERY = "RECOVERY"
    RESUME = "RESUME"


class DronePlan(BaseModel):
    model_config = ConfigDict(frozen=True)

    drone_id: str
    expected_boot_id: str
    plan_version: int
    purpose: PlanPurpose
    effective_from: float  # coordination time at which this plan takes over
    trajectory: Trajectory
    task_ids: list[str]
    task_windows: dict[str, tuple[float, float]] = Field(default_factory=dict)
    contingency: ContingencyAssignment
    energy_estimate_wh: float = 0.0
    lane_progress_origin: dict[str, float] = Field(default_factory=dict)

    def digest(self, mission_version: int, epoch: int) -> str:
        payload = self.model_dump(mode="json")
        blob = json.dumps({"plan": payload, "mv": mission_version, "epoch": epoch}, sort_keys=True,
                          separators=(",", ":"))
        return hashlib.sha256(blob.encode()).hexdigest()


class Plan(BaseModel):
    """A versioned schedule for a subset of the fleet."""

    model_config = ConfigDict(frozen=True)

    plan_id: str
    mission_id: str
    mission_version: int
    coordinator_epoch: int
    created_at: float
    purpose: PlanPurpose
    drone_plans: dict[str, DronePlan]
    reservations: list[Reservation] = Field(default_factory=list)
    unassigned_tasks: list[str] = Field(default_factory=list)
    resolutions: list[tuple[str, ReasonCode]] = Field(default_factory=list)
    timing_tolerance_s: float = 0.5

    def digest(self, drone_id: str) -> str:
        return self.drone_plans[drone_id].digest(self.mission_version, self.coordinator_epoch)

    @property
    def participants(self) -> list[str]:
        return sorted(self.drone_plans)

    def trajectories(self) -> dict[str, Trajectory]:
        return {d: p.trajectory for d, p in self.drone_plans.items()}
