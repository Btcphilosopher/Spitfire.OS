"""Coordinate frames, vectors and planar geometry.

Axis conventions (see docs/COORDINATES.md)
-----------------------------------------
* ``ENU`` - local East-North-Up Cartesian frame. x = east [m], y = north [m],
  z = up [m]. **All planning, scheduling and separation code uses ENU.**
* ``NED`` - local North-East-Down frame used by PX4/MAVLink local positions.
  x = north [m], y = east [m], z = down [m].
* ``WGS84`` - geodetic latitude/longitude [deg] and ellipsoidal height [m].

Vectors carry their frame.  Arithmetic between vectors in different frames
raises :class:`FrameMismatchError` instead of silently combining them.  The
only way to change frame is through the explicit functions in
:mod:`spitfire_sync.models.frames`.
"""

from __future__ import annotations

import math
from enum import StrEnum
from typing import Iterable, Sequence

import numpy as np
from pydantic import BaseModel, ConfigDict, Field


class NavigationFrame(StrEnum):
    ENU = "ENU"
    NED = "NED"


class FrameMismatchError(ValueError):
    """Raised when quantities expressed in different frames would be combined."""

    def __init__(self, expected: NavigationFrame | str, got: NavigationFrame | str) -> None:
        super().__init__(f"frame mismatch: expected {expected}, got {got}")
        self.expected = expected
        self.got = got


class Vec3(BaseModel):
    """A 3-vector tagged with the frame it is expressed in (metres or m/s)."""

    model_config = ConfigDict(frozen=True)

    x: float
    y: float
    z: float
    frame: NavigationFrame = NavigationFrame.ENU

    # -- construction -----------------------------------------------------
    @classmethod
    def enu(cls, x: float, y: float, z: float) -> "Vec3":
        return cls(x=float(x), y=float(y), z=float(z), frame=NavigationFrame.ENU)

    @classmethod
    def ned(cls, n: float, e: float, d: float) -> "Vec3":
        return cls(x=float(n), y=float(e), z=float(d), frame=NavigationFrame.NED)

    @classmethod
    def from_array(cls, a: Sequence[float], frame: NavigationFrame = NavigationFrame.ENU) -> "Vec3":
        return cls(x=float(a[0]), y=float(a[1]), z=float(a[2]), frame=frame)

    # -- helpers ----------------------------------------------------------
    def require(self, frame: NavigationFrame) -> "Vec3":
        if self.frame != frame:
            raise FrameMismatchError(frame, self.frame)
        return self

    def as_array(self) -> np.ndarray:
        return np.array([self.x, self.y, self.z], dtype=float)

    def is_finite(self) -> bool:
        return math.isfinite(self.x) and math.isfinite(self.y) and math.isfinite(self.z)

    def _check(self, other: "Vec3") -> None:
        if self.frame != other.frame:
            raise FrameMismatchError(self.frame, other.frame)

    def __add__(self, other: "Vec3") -> "Vec3":  # type: ignore[override]
        self._check(other)
        return Vec3(x=self.x + other.x, y=self.y + other.y, z=self.z + other.z, frame=self.frame)

    def __sub__(self, other: "Vec3") -> "Vec3":
        self._check(other)
        return Vec3(x=self.x - other.x, y=self.y - other.y, z=self.z - other.z, frame=self.frame)

    def scale(self, k: float) -> "Vec3":
        return Vec3(x=self.x * k, y=self.y * k, z=self.z * k, frame=self.frame)

    def norm(self) -> float:
        return math.sqrt(self.x * self.x + self.y * self.y + self.z * self.z)

    def horizontal_norm(self) -> float:
        return math.hypot(self.x, self.y)

    def distance_to(self, other: "Vec3") -> float:
        return (self - other).norm()

    def horizontal_distance_to(self, other: "Vec3") -> float:
        self._check(other)
        return math.hypot(self.x - other.x, self.y - other.y)

    def with_z(self, z: float) -> "Vec3":
        return Vec3(x=self.x, y=self.y, z=float(z), frame=self.frame)


# ---------------------------------------------------------------------------
# Planar geometry (ENU horizontal plane)
# ---------------------------------------------------------------------------


class Polygon2D(BaseModel):
    """Simple (non self-intersecting) polygon in the ENU horizontal plane."""

    model_config = ConfigDict(frozen=True)

    vertices: list[tuple[float, float]] = Field(min_length=3)

    def array(self) -> np.ndarray:
        return np.asarray(self.vertices, dtype=float)

    def contains(self, x: float, y: float) -> bool:
        """Even-odd ray casting; points on the boundary count as inside."""
        if self.distance_to_boundary(x, y) < 1e-9:
            return True
        inside = False
        v = self.vertices
        n = len(v)
        j = n - 1
        for i in range(n):
            xi, yi = v[i]
            xj, yj = v[j]
            if (yi > y) != (yj > y):
                x_cross = (xj - xi) * (y - yi) / (yj - yi) + xi
                if x < x_cross:
                    inside = not inside
            j = i
        return inside

    def edges(self) -> list[tuple[tuple[float, float], tuple[float, float]]]:
        v = self.vertices
        return [(v[i], v[(i + 1) % len(v)]) for i in range(len(v))]

    def distance_to_boundary(self, x: float, y: float) -> float:
        return min(point_segment_distance_2d((x, y), a, b) for a, b in self.edges())

    def signed_distance(self, x: float, y: float) -> float:
        """Negative inside, positive outside."""
        d = self.distance_to_boundary(x, y)
        return -d if self.contains_strict(x, y) else d

    def contains_strict(self, x: float, y: float) -> bool:
        inside = False
        v = self.vertices
        n = len(v)
        j = n - 1
        for i in range(n):
            xi, yi = v[i]
            xj, yj = v[j]
            if (yi > y) != (yj > y):
                x_cross = (xj - xi) * (y - yi) / (yj - yi) + xi
                if x < x_cross:
                    inside = not inside
            j = i
        return inside

    def segment_distance(self, a: tuple[float, float], b: tuple[float, float]) -> float:
        """Minimum distance between segment ab and the polygon (0 if it enters)."""
        if self.contains(*a) or self.contains(*b):
            return 0.0
        best = math.inf
        for p, q in self.edges():
            if segments_intersect_2d(a, b, p, q):
                return 0.0
            best = min(
                best,
                point_segment_distance_2d(a, p, q),
                point_segment_distance_2d(b, p, q),
                point_segment_distance_2d(p, a, b),
                point_segment_distance_2d(q, a, b),
            )
        return best

    def centroid(self) -> tuple[float, float]:
        a = self.array()
        x, y = a[:, 0], a[:, 1]
        x1, y1 = np.roll(x, -1), np.roll(y, -1)
        cross = x * y1 - x1 * y
        area = cross.sum() / 2.0
        if abs(area) < 1e-12:
            return float(x.mean()), float(y.mean())
        cx = ((x + x1) * cross).sum() / (6 * area)
        cy = ((y + y1) * cross).sum() / (6 * area)
        return float(cx), float(cy)

    def area(self) -> float:
        a = self.array()
        x, y = a[:, 0], a[:, 1]
        return float(abs(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1))) / 2.0)

    def bounds(self) -> tuple[float, float, float, float]:
        a = self.array()
        return float(a[:, 0].min()), float(a[:, 1].min()), float(a[:, 0].max()), float(a[:, 1].max())

    def outset_vertices(self, margin: float) -> list[tuple[float, float]]:
        """Vertices pushed outward by ``margin`` along the vertex bisector.

        Exact for convex polygons (the offset polygon contains the Minkowski sum
        of the polygon with a disc of radius ``margin``); used for routing
        waypoints around exclusion zones.  Routes are always re-validated with
        :meth:`segment_distance`, so the approximation can only cost path
        length, never safety.
        """
        v = self.array()
        n = len(v)
        # orientation: positive area => counter-clockwise
        signed = float(np.dot(v[:, 0], np.roll(v[:, 1], -1)) - np.dot(v[:, 1], np.roll(v[:, 0], -1)))
        ccw = signed > 0
        out: list[tuple[float, float]] = []
        for i in range(n):
            p_prev, p, p_next = v[i - 1], v[i], v[(i + 1) % n]
            e1 = p - p_prev
            e2 = p_next - p
            # outward normals
            n1 = np.array([e1[1], -e1[0]]) if ccw else np.array([-e1[1], e1[0]])
            n2 = np.array([e2[1], -e2[0]]) if ccw else np.array([-e2[1], e2[0]])
            n1 /= np.linalg.norm(n1) or 1.0
            n2 /= np.linalg.norm(n2) or 1.0
            bis = n1 + n2
            nb = np.linalg.norm(bis)
            if nb < 1e-9:
                bis = n1
                nb = 1.0
            bis /= nb
            cos_half = max(float(np.dot(bis, n1)), 0.25)
            q = p + bis * (margin / cos_half)
            out.append((float(q[0]), float(q[1])))
        return out


def point_segment_distance_2d(p: tuple[float, float], a: tuple[float, float], b: tuple[float, float]) -> float:
    ax, ay = a
    bx, by = b
    px, py = p
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy
    if L2 <= 0.0:
        return math.hypot(px - ax, py - ay)
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / L2))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


def _orient(a: tuple[float, float], b: tuple[float, float], c: tuple[float, float]) -> float:
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])


def segments_intersect_2d(
    a: tuple[float, float], b: tuple[float, float], c: tuple[float, float], d: tuple[float, float]
) -> bool:
    o1, o2, o3, o4 = _orient(a, b, c), _orient(a, b, d), _orient(c, d, a), _orient(c, d, b)
    if ((o1 > 0) != (o2 > 0)) and ((o3 > 0) != (o4 > 0)) and o1 != 0 and o2 != 0 and o3 != 0 and o4 != 0:
        return True
    eps = 1e-12
    if abs(o1) < eps and point_segment_distance_2d(c, a, b) < 1e-9:
        return True
    if abs(o2) < eps and point_segment_distance_2d(d, a, b) < 1e-9:
        return True
    if abs(o3) < eps and point_segment_distance_2d(a, c, d) < 1e-9:
        return True
    if abs(o4) < eps and point_segment_distance_2d(b, c, d) < 1e-9:
        return True
    return False


def clip_line_to_polygon(
    p0: tuple[float, float], p1: tuple[float, float], polygon: Polygon2D
) -> list[tuple[float, float]]:
    """Return parameter intervals [t0, t1] (flattened pairs) of segment p0->p1 inside ``polygon``."""
    ts = [0.0, 1.0]
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]
    for a, b in polygon.edges():
        ex, ey = b[0] - a[0], b[1] - a[1]
        den = dx * ey - dy * ex
        if abs(den) < 1e-12:
            continue
        t = ((a[0] - p0[0]) * ey - (a[1] - p0[1]) * ex) / den
        u = ((a[0] - p0[0]) * dy - (a[1] - p0[1]) * dx) / den
        if 0.0 <= t <= 1.0 and -1e-12 <= u <= 1.0 + 1e-12:
            ts.append(t)
    ts = sorted(set(round(t, 12) for t in ts))
    out: list[tuple[float, float]] = []
    for t0, t1 in zip(ts[:-1], ts[1:]):
        if t1 - t0 < 1e-9:
            continue
        tm = 0.5 * (t0 + t1)
        if polygon.contains(p0[0] + tm * dx, p0[1] + tm * dy):
            if out and abs(out[-1][1] - t0) < 1e-9:
                out[-1] = (out[-1][0], t1)
            else:
                out.append((t0, t1))
    return out


def subtract_intervals(
    base: Iterable[tuple[float, float]], remove: Iterable[tuple[float, float]]
) -> list[tuple[float, float]]:
    result = list(base)
    for r0, r1 in remove:
        nxt: list[tuple[float, float]] = []
        for b0, b1 in result:
            if r1 <= b0 or r0 >= b1:
                nxt.append((b0, b1))
                continue
            if r0 > b0:
                nxt.append((b0, r0))
            if r1 < b1:
                nxt.append((r1, b1))
        result = nxt
    return [(a, b) for a, b in result if b - a > 1e-9]
