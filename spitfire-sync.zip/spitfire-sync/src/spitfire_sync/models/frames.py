"""Explicit conversion boundary between geographic and local frames.

WGS84 geodetic <-> ECEF <-> local tangent plane (ENU) about a fixed origin,
plus the ENU <-> NED axis permutation.  These are the *only* functions in the
package that change the frame tag of a :class:`Vec3`.

Accuracy: the geodetic<->ECEF transforms are exact closed-form/iterative WGS84
expressions (sub-millimetre round trip).  The local ENU plane is a tangent
plane: over the few-kilometre extent of a survey site it is exact as a
Cartesian frame (it is a rigid rotation of ECEF), but "z" is height above the
tangent plane, not above the ellipsoid; at 2 km from the origin the difference
is ~0.3 m.  Survey sites are expected to stay within ``max_extent_m`` of the
origin and the conversion refuses points beyond it.
"""

from __future__ import annotations

import math

import numpy as np
from pydantic import BaseModel, ConfigDict, Field

from .geometry import NavigationFrame, Vec3

WGS84_A = 6378137.0
WGS84_F = 1.0 / 298.257223563
WGS84_E2 = WGS84_F * (2.0 - WGS84_F)


class GeodeticPosition(BaseModel):
    model_config = ConfigDict(frozen=True)

    latitude_deg: float = Field(ge=-90.0, le=90.0)
    longitude_deg: float = Field(ge=-180.0, le=180.0)
    height_m: float  # ellipsoidal height (WGS84). AMSL requires a geoid model - see docs.


def geodetic_to_ecef(p: GeodeticPosition) -> np.ndarray:
    lat = math.radians(p.latitude_deg)
    lon = math.radians(p.longitude_deg)
    s, c = math.sin(lat), math.cos(lat)
    n = WGS84_A / math.sqrt(1.0 - WGS84_E2 * s * s)
    return np.array(
        [
            (n + p.height_m) * c * math.cos(lon),
            (n + p.height_m) * c * math.sin(lon),
            (n * (1.0 - WGS84_E2) + p.height_m) * s,
        ]
    )


def ecef_to_geodetic(xyz: np.ndarray) -> GeodeticPosition:
    x, y, z = (float(v) for v in xyz)
    lon = math.atan2(y, x)
    p = math.hypot(x, y)
    lat = math.atan2(z, p * (1.0 - WGS84_E2))
    h = 0.0
    for _ in range(10):
        s = math.sin(lat)
        n = WGS84_A / math.sqrt(1.0 - WGS84_E2 * s * s)
        h = p / math.cos(lat) - n if abs(lat) < math.radians(89.9) else z / s - n * (1.0 - WGS84_E2)
        lat_new = math.atan2(z, p * (1.0 - WGS84_E2 * n / (n + h)))
        if abs(lat_new - lat) < 1e-13:
            lat = lat_new
            break
        lat = lat_new
    return GeodeticPosition(latitude_deg=math.degrees(lat), longitude_deg=math.degrees(lon), height_m=h)


class LocalTangentFrame(BaseModel):
    """ENU tangent plane anchored at ``origin``."""

    model_config = ConfigDict(frozen=True)

    origin: GeodeticPosition
    max_extent_m: float = 20_000.0

    def _rotation(self) -> np.ndarray:
        lat = math.radians(self.origin.latitude_deg)
        lon = math.radians(self.origin.longitude_deg)
        sl, cl = math.sin(lat), math.cos(lat)
        so, co = math.sin(lon), math.cos(lon)
        # rows: east, north, up expressed in ECEF
        return np.array(
            [
                [-so, co, 0.0],
                [-sl * co, -sl * so, cl],
                [cl * co, cl * so, sl],
            ]
        )

    def to_enu(self, p: GeodeticPosition) -> Vec3:
        d = geodetic_to_ecef(p) - geodetic_to_ecef(self.origin)
        enu = self._rotation() @ d
        if float(np.linalg.norm(enu[:2])) > self.max_extent_m:
            raise ValueError(
                f"point {np.linalg.norm(enu[:2]):.0f} m from origin exceeds max_extent_m={self.max_extent_m}"
            )
        return Vec3.enu(*enu)

    def to_geodetic(self, v: Vec3) -> GeodeticPosition:
        v.require(NavigationFrame.ENU)
        d = self._rotation().T @ v.as_array()
        return ecef_to_geodetic(geodetic_to_ecef(self.origin) + d)


def enu_to_ned(v: Vec3) -> Vec3:
    """ENU (east, north, up) -> NED (north, east, down).  Works for positions and velocities."""
    v.require(NavigationFrame.ENU)
    return Vec3.ned(v.y, v.x, -v.z)


def ned_to_enu(v: Vec3) -> Vec3:
    """NED (north, east, down) -> ENU (east, north, up)."""
    v.require(NavigationFrame.NED)
    return Vec3.enu(v.y, v.x, -v.z)
