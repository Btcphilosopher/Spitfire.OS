"""Coordination commands, acknowledgements, leases and safety events."""

from __future__ import annotations

from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from ..reasons import ReasonCode
from .geometry import Vec3


class CommandType(StrEnum):
    HOLD_POSITION = "HOLD_POSITION"  # stop supervisory motion and hold in place
    GOTO_HOLD = "GOTO_HOLD"  # fly to a coordinator-validated hold point and hold
    RELEASE_TASK = "RELEASE_TASK"  # stop the task, report progress, release the lease
    RECONCILE = "RECONCILE"  # report full state + command history for reconciliation
    ABANDON_TASK = "ABANDON_TASK"  # stop (ownership conflict); do not resume
    COMMIT_ACK_PROBE = "COMMIT_ACK_PROBE"  # internal: ask whether a commit was received


class CoordinationCommand(BaseModel):
    model_config = ConfigDict(frozen=True)

    command_id: str  # stable across retries => idempotent execution
    command_type: CommandType
    target_drone_id: str
    target_boot_id: str
    params: dict[str, Any] = Field(default_factory=dict)
    issued_at: float
    expires_at: float
    hold_point: Vec3 | None = None


class CommandAcknowledgement(BaseModel):
    model_config = ConfigDict(frozen=True)

    command_id: str
    drone_id: str
    boot_id: str
    accepted: bool
    reason: ReasonCode
    executed_at: float | None = None
    duplicate: bool = False
    details: dict[str, Any] = Field(default_factory=dict)


class LeaseState(StrEnum):
    OFFERED = "OFFERED"  # sent, owner has not confirmed
    ACTIVE = "ACTIVE"  # owner confirmed (by ack / progress)
    RELEASED = "RELEASED"  # owner released it (authoritative)
    REVOKED = "REVOKED"  # coordinator revoked; still counted as possibly active until expiry
    EXPIRED = "EXPIRED"  # expiry + safety margin has passed


TERMINAL_LEASE_STATES = {LeaseState.RELEASED, LeaseState.EXPIRED}


class TaskLease(BaseModel):
    model_config = ConfigDict(frozen=True)

    lease_id: str
    task_id: str
    holder: str
    holder_boot_id: str
    coordinator_epoch: int
    plan_version: int
    issued_at: float
    expires_at: float


class SafetyEventKind(StrEnum):
    STALE_TELEMETRY = "STALE_TELEMETRY"
    TELEMETRY_REJECTED = "TELEMETRY_REJECTED"
    LINK_LOST = "LINK_LOST"
    LINK_RESTORED = "LINK_RESTORED"
    POSITION_UNASSESSABLE = "POSITION_UNASSESSABLE"
    COORDINATOR_LINK_LOST = "COORDINATOR_LINK_LOST"
    BATTERY_RESERVE_BREACH = "BATTERY_RESERVE_BREACH"
    NAVIGATION_UNCERTAINTY = "NAVIGATION_UNCERTAINTY"
    TRAJECTORY_DEVIATION = "TRAJECTORY_DEVIATION"
    AIRCRAFT_DROPOUT = "AIRCRAFT_DROPOUT"
    MISSION_OBSTRUCTION = "MISSION_OBSTRUCTION"
    OWNERSHIP_CONFLICT = "OWNERSHIP_CONFLICT"
    AUTOPILOT_FAILSAFE = "AUTOPILOT_FAILSAFE"
    REBOOT_DETECTED = "REBOOT_DETECTED"
    LEASE_EXPIRED = "LEASE_EXPIRED"
    LEASE_LAPSED_ONBOARD = "LEASE_LAPSED_ONBOARD"
    PARTIAL_START = "PARTIAL_START"
    START_DEADLINE_MISSED = "START_DEADLINE_MISSED"
    COORDINATION_ABORT = "COORDINATION_ABORT"
    RECONCILED = "RECONCILED"
    TASK_SUSPENDED = "TASK_SUSPENDED"
    TASK_REASSIGNED = "TASK_REASSIGNED"
    PREDICTED_CONFLICT = "PREDICTED_CONFLICT"
    CLOCK_FAULT = "CLOCK_FAULT"


class Severity(StrEnum):
    INFO = "INFO"
    CAUTION = "CAUTION"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"


class SafetyEvent(BaseModel):
    model_config = ConfigDict(frozen=True)

    event_id: str
    time: float
    kind: SafetyEventKind
    severity: Severity
    drone_ids: list[str] = Field(default_factory=list)
    reason: ReasonCode
    action: str = ""
    details: dict[str, Any] = Field(default_factory=dict)
