"""Versioned wire protocol (protocol_version 1.x).

Every message is an :class:`Envelope` whose ``payload`` is a discriminated
union keyed on ``payload.kind``; the envelope ``type`` must equal the payload
kind.  Times are seconds on the coordination timescale.  Serialisation is JSON
(UTF-8); authentication is applied over the canonical serialisation by
:mod:`spitfire_sync.transport.auth`.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Annotated, Literal, Union

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ..reasons import ReasonCode
from .commands import CommandAcknowledgement, CoordinationCommand, TaskLease
from .state import DroneState
from .trajectory import DronePlan

PROTOCOL_VERSION = "1.0"
BROADCAST = "*"


class MessageType(StrEnum):
    STATE_UPDATE = "STATE_UPDATE"
    PLAN_PROPOSAL = "PLAN_PROPOSAL"
    PLAN_ACK = "PLAN_ACK"
    PLAN_COMMIT = "PLAN_COMMIT"
    TASK_LEASE = "TASK_LEASE"
    LEASE_RENEWAL = "LEASE_RENEWAL"
    COMMAND = "COMMAND"
    COMMAND_ACK = "COMMAND_ACK"
    TASK_PROGRESS = "TASK_PROGRESS"
    TASK_COMPLETE = "TASK_COMPLETE"
    COORDINATION_ABORT = "COORDINATION_ABORT"
    # supporting messages (not task-bearing)
    TIME_SYNC_REQUEST = "TIME_SYNC_REQUEST"
    TIME_SYNC_RESPONSE = "TIME_SYNC_RESPONSE"
    HEARTBEAT = "HEARTBEAT"


# Which roles may originate each message type (authorisation table).
COORDINATOR_ONLY = {
    MessageType.PLAN_PROPOSAL,
    MessageType.PLAN_COMMIT,
    MessageType.TASK_LEASE,
    MessageType.LEASE_RENEWAL,
    MessageType.COMMAND,
    MessageType.COORDINATION_ABORT,
    MessageType.TIME_SYNC_RESPONSE,
    MessageType.HEARTBEAT,
}
AIRCRAFT_ONLY = {
    MessageType.STATE_UPDATE,
    MessageType.PLAN_ACK,
    MessageType.COMMAND_ACK,
    MessageType.TASK_PROGRESS,
    MessageType.TASK_COMPLETE,
    MessageType.TIME_SYNC_REQUEST,
}


class StateUpdatePayload(BaseModel):
    model_config = ConfigDict(frozen=True, ser_json_inf_nan="constants")
    kind: Literal["STATE_UPDATE"] = "STATE_UPDATE"
    state: DroneState


class PlanProposalPayload(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: Literal["PLAN_PROPOSAL"] = "PLAN_PROPOSAL"
    plan_id: str
    plan_digest: str
    drone_plan: DronePlan
    readiness_deadline: float
    timing_tolerance_s: float
    participants: list[str]


class PlanAckPayload(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: Literal["PLAN_ACK"] = "PLAN_ACK"
    plan_id: str
    plan_digest: str
    plan_version: int
    ready: bool
    reasons: list[ReasonCode] = Field(default_factory=list)
    readiness_expires_at: float
    clock_uncertainty_s: float
    drone_boot_id: str


class PlanCommitPayload(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: Literal["PLAN_COMMIT"] = "PLAN_COMMIT"
    commit_id: str
    plan_id: str
    plan_digest: str
    plan_version: int
    effective_from: float
    leases: list[TaskLease] = Field(default_factory=list)


class TaskLeasePayload(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: Literal["TASK_LEASE"] = "TASK_LEASE"
    lease: TaskLease
    revoke: bool = False


class LeaseRenewalPayload(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: Literal["LEASE_RENEWAL"] = "LEASE_RENEWAL"
    lease_id: str
    task_id: str
    holder_boot_id: str
    new_expires_at: float


class CommandPayload(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: Literal["COMMAND"] = "COMMAND"
    command: CoordinationCommand


class CommandAckPayload(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: Literal["COMMAND_ACK"] = "COMMAND_ACK"
    ack: CommandAcknowledgement


class ProgressStatus(StrEnum):
    STARTED = "STARTED"
    IN_PROGRESS = "IN_PROGRESS"
    SUSPENDED = "SUSPENDED"  # stopped part way, lease released
    START_FAILED = "START_FAILED"
    START_MISSED = "START_MISSED"
    PAUSED = "PAUSED"  # lease lapsed onboard


class TaskProgressPayload(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: Literal["TASK_PROGRESS"] = "TASK_PROGRESS"
    task_id: str | None
    lease_id: str | None
    plan_version: int | None
    status: ProgressStatus
    progress_m: float = 0.0
    at_time: float
    released: bool = False
    reason: ReasonCode = ReasonCode.OK
    actual_start_time: float | None = None
    progress_xy: tuple[float, float] | None = None


class TaskCompletePayload(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: Literal["TASK_COMPLETE"] = "TASK_COMPLETE"
    task_id: str
    lease_id: str
    completed_at: float
    progress_m: float


class CoordinationAbortPayload(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: Literal["COORDINATION_ABORT"] = "COORDINATION_ABORT"
    abort_id: str
    reason: ReasonCode
    detail: str = ""


class TimeSyncRequestPayload(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: Literal["TIME_SYNC_REQUEST"] = "TIME_SYNC_REQUEST"
    request_id: str
    t1_local: float  # requester's monotonic clock


class TimeSyncResponsePayload(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: Literal["TIME_SYNC_RESPONSE"] = "TIME_SYNC_RESPONSE"
    request_id: str
    t1_local: float
    t2_reference: float  # responder (coordination timescale) at receipt
    t3_reference: float  # responder at transmission
    reference_id: str  # identifies the timescale (coordinator boot id)


class HeartbeatPayload(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: Literal["HEARTBEAT"] = "HEARTBEAT"
    reference_id: str


Payload = Annotated[
    Union[
        StateUpdatePayload,
        PlanProposalPayload,
        PlanAckPayload,
        PlanCommitPayload,
        TaskLeasePayload,
        LeaseRenewalPayload,
        CommandPayload,
        CommandAckPayload,
        TaskProgressPayload,
        TaskCompletePayload,
        CoordinationAbortPayload,
        TimeSyncRequestPayload,
        TimeSyncResponsePayload,
        HeartbeatPayload,
    ],
    Field(discriminator="kind"),
]


class Envelope(BaseModel):
    model_config = ConfigDict(frozen=True, ser_json_inf_nan="constants")

    message_id: str
    protocol_version: str = PROTOCOL_VERSION
    type: MessageType
    sender_id: str
    recipient_id: str
    boot_id: str  # sender's boot / process-instance identifier
    coordinator_epoch: int  # epoch of the coordinator the sender recognises
    mission_version: int
    sequence_number: int = Field(ge=0)
    issued_at: float
    expires_at: float
    payload: Payload
    auth_tag: str | None = None

    @model_validator(mode="after")
    def _type_matches(self) -> "Envelope":
        if self.payload.kind != self.type.value:
            raise ValueError(f"envelope type {self.type} does not match payload kind {self.payload.kind}")
        if self.expires_at < self.issued_at:
            raise ValueError("expires_at precedes issued_at")
        return self
