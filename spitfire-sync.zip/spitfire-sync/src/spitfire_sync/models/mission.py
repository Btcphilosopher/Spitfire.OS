"""Mission description: survey area, lanes (tasks), bands, launch/recovery."""

from __future__ import annotations

import math
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .frames import GeodeticPosition
from .geometry import Polygon2D, Vec3


class AltitudeBand(BaseModel):
    """Altitude band in metres above the local origin plane (ENU z)."""

    model_config = ConfigDict(frozen=True)

    name: str
    floor_m: float
    ceiling_m: float
    purpose: str = "survey"  # survey | transit | contingency

    @model_validator(mode="after")
    def _check(self) -> "AltitudeBand":
        if self.ceiling_m <= self.floor_m:
            raise ValueError(f"band {self.name}: ceiling must exceed floor")
        return self

    @property
    def centre_m(self) -> float:
        return 0.5 * (self.floor_m + self.ceiling_m)

    def contains(self, z: float) -> bool:
        return self.floor_m <= z <= self.ceiling_m


class ExclusionZone(BaseModel):
    model_config = ConfigDict(frozen=True)

    zone_id: str
    polygon: Polygon2D
    floor_m: float = -math.inf
    ceiling_m: float = math.inf
    reason: str = "configured"
    active_from: float = -math.inf
    active_until: float = math.inf

    def active_at(self, t: float) -> bool:
        return self.active_from <= t <= self.active_until

    def overlaps_altitude(self, z0: float, z1: float) -> bool:
        lo, hi = min(z0, z1), max(z0, z1)
        return hi >= self.floor_m and lo <= self.ceiling_m


class TaskKind(StrEnum):
    SURVEY_LANE = "SURVEY_LANE"


class TaskStatus(StrEnum):
    PENDING = "PENDING"
    ASSIGNED = "ASSIGNED"
    ACTIVE = "ACTIVE"
    SUSPENDED = "SUSPENDED"
    COMPLETE = "COMPLETE"
    SUPERSEDED = "SUPERSEDED"  # replaced by a remainder task
    ABANDONED = "ABANDONED"


class MissionTask(BaseModel):
    """A survey lane: fly from ``start`` to ``end`` (horizontal) at a permitted band.

    The lane may be flown in either direction; the scheduler picks the
    direction.  ``parent_task_id``/``offset_m`` describe a remainder created
    when a lane was suspended part way.
    """

    model_config = ConfigDict(frozen=True)

    task_id: str
    kind: TaskKind = TaskKind.SURVEY_LANE
    start_xy: tuple[float, float]
    end_xy: tuple[float, float]
    permitted_bands: list[str] = Field(min_length=1)
    payload_required: str = "rgb"
    swath_width_m: float = 40.0
    survey_speed_m_s: float = 8.0
    parent_task_id: str | None = None
    root_task_id: str | None = None
    offset_m: float = 0.0  # where along the root lane this task starts
    reversible: bool = True
    priority: int = 0

    @property
    def length_m(self) -> float:
        return math.hypot(self.end_xy[0] - self.start_xy[0], self.end_xy[1] - self.start_xy[1])

    @property
    def nominal_duration_s(self) -> float:
        return self.length_m / max(self.survey_speed_m_s, 0.1)

    @property
    def root_id(self) -> str:
        return self.root_task_id or self.task_id

    def point_at(self, s: float) -> tuple[float, float]:
        L = self.length_m
        f = 0.0 if L <= 0 else max(0.0, min(1.0, s / L))
        return (
            self.start_xy[0] + f * (self.end_xy[0] - self.start_xy[0]),
            self.start_xy[1] + f * (self.end_xy[1] - self.start_xy[1]),
        )


class LaunchPad(BaseModel):
    model_config = ConfigDict(frozen=True)

    drone_id: str
    position: Vec3


class RecoveryArea(BaseModel):
    """Shared recovery area: a vertical cylinder.  At most ``capacity`` aircraft
    may be inside the volume at once (default 1 => strictly sequenced)."""

    model_config = ConfigDict(frozen=True)

    centre_xy: tuple[float, float]
    radius_m: float
    ceiling_m: float = 25.0
    capacity: int = 1
    landing_spots: list[tuple[float, float]] = Field(min_length=1)
    approach_offset_m: float = 45.0  # approach fix distance from centre (outside volume)

    def contains(self, x: float, y: float, z: float) -> bool:
        return math.hypot(x - self.centre_xy[0], y - self.centre_xy[1]) <= self.radius_m and z <= self.ceiling_m


class Mission(BaseModel):
    model_config = ConfigDict(frozen=True)

    mission_id: str
    site_name: str
    origin: GeodeticPosition
    survey_area: Polygon2D
    operational_boundary: Polygon2D
    exclusion_zones: list[ExclusionZone] = Field(default_factory=list)
    altitude_bands: list[AltitudeBand]
    ceiling_m: float = 120.0
    tasks: list[MissionTask]
    launch_pads: list[LaunchPad]
    recovery_area: RecoveryArea
    lane_overlap_m: float = 5.0  # overlap applied when splitting a lane into a remainder

    def band(self, name: str) -> AltitudeBand:
        for b in self.altitude_bands:
            if b.name == name:
                return b
        raise KeyError(name)

    def bands(self, purpose: str) -> list[AltitudeBand]:
        return [b for b in self.altitude_bands if b.purpose == purpose]

    def task(self, task_id: str) -> MissionTask:
        for t in self.tasks:
            if t.task_id == task_id:
                return t
        raise KeyError(task_id)

    def pad(self, drone_id: str) -> LaunchPad:
        for p in self.launch_pads:
            if p.drone_id == drone_id:
                return p
        raise KeyError(drone_id)

    @property
    def pending_tasks(self) -> list[MissionTask]:
        return list(self.tasks)

    def with_exclusion(self, zone: ExclusionZone) -> "Mission":
        return self.model_copy(update={"exclusion_zones": [*self.exclusion_zones, zone]})
