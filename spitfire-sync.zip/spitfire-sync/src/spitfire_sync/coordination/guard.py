"""Inbound message admission control.

Order of checks (first failure wins, each with a reason code):
protocol version -> known sender -> authorisation (role may send this type)
-> authentication tag -> recipient -> expiry -> duplicate message_id ->
sequence replay -> coordinator epoch.

Expiry is conservative: a message is rejected as soon as it *might* have
expired given the receiver's clock uncertainty.
"""

from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from enum import StrEnum
from typing import Callable

from ..clocks.clock import TimeEstimate
from ..models.messages import AIRCRAFT_ONLY, BROADCAST, COORDINATOR_ONLY, PROTOCOL_VERSION, Envelope, MessageType
from ..reasons import ReasonCode
from ..transport.auth import Authenticator


class Role(StrEnum):
    COORDINATOR = "COORDINATOR"
    AIRCRAFT = "AIRCRAFT"


@dataclass(frozen=True)
class GuardResult:
    accepted: bool
    reason: ReasonCode
    new_epoch: bool = False

    def __bool__(self) -> bool:
        return self.accepted


# message types that are bound to a coordinator epoch when sent by aircraft
EPOCH_BOUND_AIRCRAFT_TYPES = {MessageType.PLAN_ACK, MessageType.COMMAND_ACK, MessageType.TASK_PROGRESS,
                              MessageType.TASK_COMPLETE}


class MessageGuard:
    def __init__(
        self,
        own_id: str,
        authenticator: Authenticator,
        roles: dict[str, Role],
        now: Callable[[], TimeEstimate],
        own_epoch: int | None = None,
        dedupe_capacity: int = 20_000,
        replay_window: int = 5_000,
    ) -> None:
        self.own_id = own_id
        self.auth = authenticator
        self.roles = dict(roles)
        self.now = now
        self.own_epoch = own_epoch  # set for the coordinator
        self.highest_epoch = own_epoch or 0
        self._seen: OrderedDict[str, None] = OrderedDict()
        self._cap = dedupe_capacity
        self._max_seq: dict[tuple[str, str], int] = {}
        self._window = replay_window
        self.rejections: dict[ReasonCode, int] = {}

    def _reject(self, r: ReasonCode) -> GuardResult:
        self.rejections[r] = self.rejections.get(r, 0) + 1
        return GuardResult(False, r)

    def check(self, env: Envelope) -> GuardResult:
        if env.protocol_version.split(".")[0] != PROTOCOL_VERSION.split(".")[0]:
            return self._reject(ReasonCode.UNSUPPORTED_PROTOCOL_VERSION)
        role = self.roles.get(env.sender_id)
        if role is None:
            return self._reject(ReasonCode.UNKNOWN_SENDER)
        if (env.type in COORDINATOR_ONLY and role != Role.COORDINATOR) or (
            env.type in AIRCRAFT_ONLY and role != Role.AIRCRAFT
        ):
            return self._reject(ReasonCode.UNAUTHORISED)
        if role == Role.AIRCRAFT and env.type == MessageType.STATE_UPDATE:
            st = env.payload.state  # type: ignore[union-attr]
            if st.drone_id != env.sender_id or st.boot_id != env.boot_id:
                return self._reject(ReasonCode.UNAUTHORISED)
        if not self.auth.verify(env):
            return self._reject(ReasonCode.BAD_SIGNATURE)
        if env.recipient_id not in (self.own_id, BROADCAST):
            return self._reject(ReasonCode.WRONG_RECIPIENT)
        now = self.now()
        if env.type != MessageType.TIME_SYNC_REQUEST and now.latest > env.expires_at:
            return self._reject(ReasonCode.MESSAGE_EXPIRED)
        if env.message_id in self._seen:
            return self._reject(ReasonCode.DUPLICATE_MESSAGE)
        key = (env.sender_id, env.boot_id)
        mx = self._max_seq.get(key)
        if mx is not None and env.sequence_number < mx - self._window:
            return self._reject(ReasonCode.REPLAYED_SEQUENCE)
        new_epoch = False
        if role == Role.COORDINATOR:
            if env.coordinator_epoch < self.highest_epoch:
                return self._reject(ReasonCode.STALE_EPOCH)
            if env.coordinator_epoch > self.highest_epoch:
                self.highest_epoch = env.coordinator_epoch
                new_epoch = True
        elif self.own_epoch is not None and env.type in EPOCH_BOUND_AIRCRAFT_TYPES:
            if env.coordinator_epoch != self.own_epoch:
                return self._reject(ReasonCode.STALE_EPOCH)
        # admit
        self._seen[env.message_id] = None
        if len(self._seen) > self._cap:
            self._seen.popitem(last=False)
        self._max_seq[key] = max(mx or 0, env.sequence_number)
        return GuardResult(True, ReasonCode.OK, new_epoch)
