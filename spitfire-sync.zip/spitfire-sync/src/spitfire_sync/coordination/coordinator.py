"""Central coordinator.

Responsibilities are separated (docs/ARCHITECTURE.md):
mission planning & task assignment & scheduling & conflict checking live in
their own modules and are orchestrated by :class:`MissionRunner`; this class
implements **command dispatch** (versioned proposals, readiness, commits,
leases, commands with idempotent retries) and **execution monitoring**
(state store, monitor, uncertain regions).

Failure model: there is exactly one coordinator per epoch.  Each process start
takes a new epoch from :class:`EpochStore`; aircraft reject messages from a
lower epoch.  No leader election or consensus is implemented: if the
coordinator fails, aircraft enter the documented degraded mode (leases lapse
=> hold; then per-aircraft lost-link contingency).
"""

from __future__ import annotations

import asyncio
import json
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from ..clocks.clock import Clock, CoordinationTimescale, TimeEstimate
from ..config import SpitfireConfig
from ..models.commands import (
    CommandAcknowledgement,
    CommandType,
    CoordinationCommand,
    LeaseState,
    SafetyEvent,
    SafetyEventKind,
    Severity,
    TaskLease,
)
from ..models.geometry import Vec3
from ..models.messages import (
    BROADCAST,
    CommandAckPayload,
    CommandPayload,
    CoordinationAbortPayload,
    Envelope,
    HeartbeatPayload,
    LeaseRenewalPayload,
    MessageType,
    PlanAckPayload,
    PlanCommitPayload,
    PlanProposalPayload,
    ProgressStatus,
    StateUpdatePayload,
    TaskCompletePayload,
    TaskLeasePayload,
    TaskProgressPayload,
    TimeSyncRequestPayload,
    TimeSyncResponsePayload,
)
from ..models.mission import Mission
from ..models.state import FleetSnapshot
from ..models.trajectory import DronePlan, Plan, PlanPurpose, Reservation, Trajectory
from ..reasons import ReasonCode
from ..separation.conflicts import Buffers, ConflictChecker
from ..telemetry.state_store import StateStore
from ..transport.base import DecodeError, MessageCodec, Transport
from ..contingencies.monitor import ExecutionMonitor
from .guard import MessageGuard, Role
from .leases import LeaseManager, plan_lease_task


class EpochStore:
    """Monotonic coordinator epoch.  File-backed when ``path`` is given."""

    def __init__(self, path: str | Path | None = None, start: int = 0) -> None:
        self.path = Path(path) if path else None
        self._value = start
        if self.path and self.path.exists():
            self._value = int(json.loads(self.path.read_text())["epoch"])

    def next_epoch(self) -> int:
        self._value += 1
        if self.path:
            self.path.write_text(json.dumps({"epoch": self._value}))
        return self._value

    @property
    def current(self) -> int:
        return self._value


@dataclass
class MissionSignal:
    kind: str
    drone_id: str | None
    time: float
    data: dict[str, Any] = field(default_factory=dict)


@dataclass
class AckRecord:
    ack: PlanAckPayload
    boot_id: str
    epoch: int
    mission_version: int
    received_at: float


@dataclass
class ProposalState:
    plan: Plan
    digests: dict[str, str]
    deadline: float
    acks: dict[str, AckRecord] = field(default_factory=dict)
    last_sent: dict[str, float] = field(default_factory=dict)
    committed: bool = False
    commit_id: str | None = None
    commit_acks: dict[str, CommandAcknowledgement] = field(default_factory=dict)
    commit_last_sent: dict[str, float] = field(default_factory=dict)
    leases: dict[str, list[TaskLease]] = field(default_factory=dict)
    committed_drones: list[str] = field(default_factory=list)


@dataclass
class ProposalResult:
    plan_id: str
    sent_to: list[str]
    readiness_deadline: float


@dataclass
class CommitResult:
    status: ReasonCode
    plan_id: str
    ready: list[str] = field(default_factory=list)
    not_ready: dict[str, list[ReasonCode]] = field(default_factory=dict)
    committed: list[str] = field(default_factory=list)
    commit_acked: list[str] = field(default_factory=list)
    commit_unacked: list[str] = field(default_factory=list)
    reasons: list[ReasonCode] = field(default_factory=list)
    committed_at: float | None = None

    @property
    def ok(self) -> bool:
        return self.status == ReasonCode.COMMITTED


@dataclass
class PendingCommand:
    command: CoordinationCommand
    first_sent: float
    last_sent: float
    attempts: int = 1
    ack: CommandAcknowledgement | None = None
    ack_time: float | None = None
    future: asyncio.Future | None = None


@dataclass
class CoordinatorRecord:
    events: list[SafetyEvent] = field(default_factory=list)
    signals: list[MissionSignal] = field(default_factory=list)
    command_latency: list[tuple[str, str, float]] = field(default_factory=list)
    commits: list[dict[str, Any]] = field(default_factory=list)
    starts: list[dict[str, Any]] = field(default_factory=list)
    leases: list[dict[str, Any]] = field(default_factory=list)
    log: list[tuple[float, str, dict[str, Any]]] = field(default_factory=list)
    rejected: dict[str, int] = field(default_factory=dict)

    def add(self, t: float, kind: str, **data: Any) -> None:
        self.log.append((t, kind, data))


class Coordinator:
    def __init__(self, node_id: str, clock: Clock, transport: Transport, codec: MessageCodec,
                 config: SpitfireConfig, mission: Mission, fleet_ids: list[str], roles: dict[str, Role],
                 epoch_store: EpochStore, checker: ConflictChecker | None = None) -> None:
        self.id = node_id
        self.clock = clock
        self.tx = transport
        self.codec = codec
        self.cfg = config
        self.mission = mission
        self.fleet_ids = sorted(fleet_ids)
        self.epoch = epoch_store.next_epoch()
        self.timescale = CoordinationTimescale(clock, self.epoch)
        self.guard = MessageGuard(node_id, codec.auth, roles, now=self.timescale.estimate, own_epoch=self.epoch)
        self.state = StateStore(self.fleet_ids, config.telemetry)
        self.leases = LeaseManager(config.leases, self.epoch)
        self.checker = checker or ConflictChecker(config.separation, mission)
        self.monitor = ExecutionMonitor(config.monitor, config.freshness, config.separation, self.checker,
                                        mission.ceiling_m)
        self.monitor.lost_link_timeout_s = {p.drone_id: p.contingency.lost_link_timeout_s for p in config.fleet}
        self.record = CoordinatorRecord()
        self.proposals: dict[str, ProposalState] = {}
        self.committed: dict[str, DronePlan] = {}  # latest committed plan per aircraft
        self.plan_history: dict[str, list[DronePlan]] = {}
        self.commands: dict[str, PendingCommand] = {}
        self.signals: asyncio.Queue[MissionSignal] = asyncio.Queue()
        self.mission_version = 0
        self.msg_seq = 0
        self._cmd_counter = 0
        self._next_heartbeat = 0.0
        self._next_monitor = 0.0
        self._next_renew: dict[str, float] = {}
        self.one_way_latency: dict[str, deque[float]] = {d: deque(maxlen=50) for d in self.fleet_ids}
        self.renewal_suspended: set[str] = set()
        self.started_plan: dict[str, int] = {}
        self._running = True
        self.stopped = asyncio.Event()

    # ------------------------------------------------------------------ basics
    def now(self) -> float:
        return self.timescale.now()

    def next_mission_version(self) -> int:
        self.mission_version += 1
        return self.mission_version

    def snapshot(self, as_of: float | None = None) -> FleetSnapshot:
        return self.state.snapshot(as_of if as_of is not None else self.now(), self.cfg.freshness)

    def latency_p95(self, drone_id: str) -> float:
        q = self.one_way_latency.get(drone_id)
        if not q:
            return 0.1
        return float(np.percentile(np.asarray(q), 95))

    def emit(self, kind: str, drone_id: str | None, **data: Any) -> None:
        s = MissionSignal(kind, drone_id, self.now(), data)
        self.record.signals.append(s)
        self.signals.put_nowait(s)

    def event(self, ev: SafetyEvent) -> None:
        self.record.events.append(ev)
        self.emit("safety_event", ev.drone_ids[0] if ev.drone_ids else None, event=ev)

    async def _send(self, recipient: str, mtype: MessageType, payload: Any, validity: float | None = None,
                    mission_version: int | None = None) -> None:
        t = self.now()
        self.msg_seq += 1
        env = Envelope(
            message_id=f"{self.id}/e{self.epoch}/{self.msg_seq}", type=mtype, sender_id=self.id,
            recipient_id=recipient, boot_id=self.clock.boot_id, coordinator_epoch=self.epoch,
            mission_version=self.mission_version if mission_version is None else mission_version,
            sequence_number=self.msg_seq, issued_at=t,
            expires_at=t + (validity if validity is not None else self.cfg.coordinator.message_validity_s),
            payload=payload,
        )
        await self.tx.send(recipient, self.codec.encode(env))

    # ------------------------------------------------------------------ loop
    def stop(self) -> None:
        self._running = False

    async def run(self) -> None:
        try:
            while self._running:
                for data, rx in self.tx.recv_nowait_timestamped():
                    await self._handle_bytes(data, rx)
                await self._tick()
                await self.clock.sleep(self.cfg.coordinator.tick_s)
        finally:
            for pc in self.commands.values():
                if pc.future is not None and not pc.future.done():
                    pc.future.set_result(None)
            await self.tx.close()
            self.stopped.set()

    async def _handle_bytes(self, data: bytes, rx_local: float | None = None) -> None:
        try:
            env = self.codec.decode(data)
        except DecodeError:
            self.record.rejected["MALFORMED"] = self.record.rejected.get("MALFORMED", 0) + 1
            return
        res = self.guard.check(env)
        if not res.accepted:
            self.record.rejected[res.reason.value] = self.record.rejected.get(res.reason.value, 0) + 1
            return
        t = self.now()
        p = env.payload
        if env.sender_id in self.one_way_latency and env.type != MessageType.TIME_SYNC_REQUEST:
            self.one_way_latency[env.sender_id].append(max(0.0, t - env.issued_at))
        if isinstance(p, TimeSyncRequestPayload):
            t2 = rx_local + self.timescale._offset if rx_local is not None else t
            await self._send(env.sender_id, MessageType.TIME_SYNC_RESPONSE, TimeSyncResponsePayload(
                request_id=p.request_id, t1_local=p.t1_local, t2_reference=t2, t3_reference=self.now(),
                reference_id=self.timescale.reference_id))
        elif isinstance(p, StateUpdatePayload):
            r = self.state.ingest(p.state, t)
            if r.new_boot:
                self.event(self.monitor._ev(t, SafetyEventKind.REBOOT_DETECTED, Severity.WARNING, [env.sender_id],
                                            ReasonCode.SEQUENCE_RESET_NEW_BOOT, boot_id=p.state.boot_id))
            if ReasonCode.FUTURE_TIMESTAMP in r.reasons:
                self.event(self.monitor._ev(t, SafetyEventKind.CLOCK_FAULT, Severity.CAUTION, [env.sender_id],
                                            ReasonCode.FUTURE_TIMESTAMP))
        elif isinstance(p, PlanAckPayload):
            self._on_plan_ack(env, p, t)
        elif isinstance(p, CommandAckPayload):
            self._on_command_ack(env, p.ack, t)
        elif isinstance(p, TaskProgressPayload):
            self._on_progress(env, p, t)
            if p.released and p.lease_id:
                await self._confirm_release(p.lease_id)
        elif isinstance(p, TaskCompletePayload):
            first = self.leases.release(p.lease_id, t)
            if first:
                self.record.leases.append({"t": t, "lease": p.lease_id, "event": "COMPLETE", "task": p.task_id})
                self.emit("task_complete", env.sender_id, task_id=p.task_id, progress_m=p.progress_m)
            await self._confirm_release(p.lease_id)

    async def _confirm_release(self, lease_id: str) -> None:
        """Confirm a completion/release report (idempotent; the aircraft retries until confirmed)."""
        rec = self.leases.get(lease_id)
        if rec is not None:
            await self._send(rec.lease.holder, MessageType.TASK_LEASE, TaskLeasePayload(lease=rec.lease, revoke=True))

    def _on_plan_ack(self, env: Envelope, p: PlanAckPayload, t: float) -> None:
        ps = self.proposals.get(p.plan_id)
        if ps is None:
            return
        ps.acks[env.sender_id] = AckRecord(p, env.boot_id, env.coordinator_epoch, env.mission_version, t)

    def _on_command_ack(self, env: Envelope, ack: CommandAcknowledgement, t: float) -> None:
        pc = self.commands.get(ack.command_id)
        if pc is not None and pc.ack is None:
            pc.ack, pc.ack_time = ack, t
            self.record.command_latency.append((pc.command.command_type.value, ack.drone_id, t - pc.first_sent))
            if pc.future is not None and not pc.future.done():
                pc.future.set_result(ack)
        for ps in self.proposals.values():
            if ps.commit_id == ack.command_id and env.sender_id not in ps.commit_acks:
                ps.commit_acks[env.sender_id] = ack
                first = ps.commit_last_sent.get("__first__", t)
                self.record.command_latency.append(("PLAN_COMMIT", env.sender_id, t - first))
                if not ack.accepted:
                    self.emit("commit_rejected", env.sender_id, plan_id=ps.plan.plan_id, reason=ack.reason)

    def _on_progress(self, env: Envelope, p: TaskProgressPayload, t: float) -> None:
        d = env.sender_id
        if p.status == ProgressStatus.STARTED:
            self.started_plan[d] = p.plan_version or 0
            dp = self.committed.get(d)
            self.record.starts.append({"drone": d, "plan_version": p.plan_version, "reported_start": p.actual_start_time,
                                       "planned": dp.effective_from if dp else None, "received": t})
            for rec in self.leases.for_holder(d):
                if rec.lease.plan_version == p.plan_version:
                    self.leases.confirm(rec.lease.lease_id, t)
            self.emit("plan_started", d, plan_version=p.plan_version)
        elif p.status in (ProgressStatus.SUSPENDED,):
            rec = self.leases.get(p.lease_id) if p.lease_id else None
            already = rec is not None and rec.state.value in ("RELEASED", "EXPIRED") and \
                any(e.get("lease") == p.lease_id and e.get("event") == "RELEASED" for e in self.record.leases[-200:])
            if already:
                return  # retried report
            if p.released and p.lease_id and self.leases.release(p.lease_id, t):
                self.record.leases.append({"t": t, "lease": p.lease_id, "event": "RELEASED", "task": p.task_id})
            self.emit("task_suspended", d, task_id=p.task_id, progress_m=p.progress_m, progress_xy=p.progress_xy,
                      reason=p.reason, lease_id=p.lease_id)
        elif p.status == ProgressStatus.PAUSED:
            self.emit("paused", d, task_id=p.task_id, progress_m=p.progress_m, progress_xy=p.progress_xy,
                      reason=p.reason)
        elif p.status in (ProgressStatus.START_FAILED, ProgressStatus.START_MISSED):
            self.emit("start_failed", d, status=p.status.value, reason=p.reason, plan_version=p.plan_version)
        elif p.status == ProgressStatus.IN_PROGRESS:
            if p.lease_id:
                self.leases.confirm(p.lease_id, t)
            self.emit("progress", d, task_id=p.task_id, progress_m=p.progress_m, progress_xy=p.progress_xy)

    # ------------------------------------------------------------------ tick
    def plan_lease_expiry(self) -> dict[str, float]:
        """Latest expiry of each aircraft's current plan lease.  An expired lease
        still bounds where the aircraft can be: by contract it stopped then."""
        out: dict[str, float] = {}
        latest: dict[str, float] = {}
        for rec in self.leases.all_records():
            if not rec.lease.task_id.startswith("__plan__"):
                continue
            h = rec.lease.holder
            if rec.lease.issued_at >= latest.get(h, -1e18):
                latest[h] = rec.lease.issued_at
                out[h] = rec.lease.expires_at
        return out

    def buffers(self, snap: FleetSnapshot) -> dict[str, Buffers]:
        out = {}
        for d in self.fleet_ids:
            e = snap.drones.get(d)
            pu = e.position_uncertainty if e and e.predicted else None
            cu = e.clock_uncertainty if e and e.clock_uncertainty < 1e3 else 0.0
            out[d] = Buffers.from_config(self.cfg.separation, pu, cu, self.cfg.timing.start_tolerance_s)
        return out

    def effective_plan(self, d: str, t: float) -> DronePlan | None:
        hist = self.plan_history.get(d, [])
        cur = None
        for dp in hist:
            if dp.effective_from <= t + 1e-9:
                cur = dp
        return cur or (hist[0] if hist else None)

    def trajectory_for(self, d: str, t_now: float | None = None) -> Trajectory | None:
        """Composite of the plan in force now and any committed amendment that
        takes over later (the aircraft flies the old plan until the switch)."""
        t_now = self.now() if t_now is None else t_now
        hist = self.plan_history.get(d, [])
        if not hist:
            return None
        latest = hist[-1]
        if latest.effective_from <= t_now or len(hist) < 2:
            return latest.trajectory
        prev = self.effective_plan(d, t_now)
        if prev is None or prev is latest:
            return latest.trajectory
        a, b = prev.trajectory, latest.trajectory
        eff = latest.effective_from
        keep = [i for i, tt in enumerate(a.t) if tt < eff]
        T = [a.t[i] for i in keep] + list(b.t)
        return b.model_copy(update=dict(
            t=T, x=[a.x[i] for i in keep] + list(b.x), y=[a.y[i] for i in keep] + list(b.y),
            z=[a.z[i] for i in keep] + list(b.z), phase=[a.phase[i] for i in keep] + list(b.phase),
            task=[a.task[i] for i in keep] + list(b.task)))

    def active_trajectories(self, t_now: float | None = None) -> dict[str, Trajectory]:
        out = {}
        for d in sorted(self.plan_history):
            tr = self.trajectory_for(d, t_now)
            if tr is not None:
                out[d] = tr
        return out

    def uncertain_regions(self, snap: FleetSnapshot | None = None, horizon_s: float = 60.0) -> list[Reservation]:
        snap = snap or self.snapshot()
        plans = {d: self.effective_plan(d, snap.as_of) for d in self.plan_history}
        return self.monitor.uncertain_regions(snap, {d: p for d, p in plans.items() if p is not None},
                                              self.plan_lease_expiry(), horizon_s)

    async def _tick(self) -> None:
        t = self.now()
        cc = self.cfg.coordinator
        if t >= self._next_heartbeat:
            self._next_heartbeat = t + cc.heartbeat_interval_s
            await self._send(BROADCAST, MessageType.HEARTBEAT, HeartbeatPayload(reference_id=self.timescale.reference_id))
        snap = self.snapshot(t)
        self.leases.max_clock_uncertainty = min(1.0, snap.uncertainty.max_clock_uncertainty)
        # lease renewals: only for aircraft whose state the coordinator can currently assess
        for rec in self.leases.renewable():
            d = rec.lease.holder
            est = snap.drones.get(d)
            if d in self.renewal_suspended or est is None or est.freshness.value != "FRESH" or \
                    est.boot_id != rec.lease.holder_boot_id:
                continue
            key = rec.lease.lease_id
            if t >= self._next_renew.get(key, rec.lease.issued_at + self.cfg.leases.renew_interval_s):
                new = self.leases.renew(key, t)
                if new is not None:
                    self._next_renew[key] = t + self.cfg.leases.renew_interval_s
                    await self._send(d, MessageType.LEASE_RENEWAL, LeaseRenewalPayload(
                        lease_id=key, task_id=new.task_id, holder_boot_id=new.holder_boot_id,
                        new_expires_at=new.expires_at), validity=self.cfg.leases.renewal_validity_s)
        for rec in self.leases.tick(t):
            self.record.leases.append({"t": t, "lease": rec.lease.lease_id, "event": "EXPIRED",
                                       "task": rec.lease.task_id})
            if not rec.lease.task_id.startswith("__plan__"):
                self.event(self.monitor._ev(t, SafetyEventKind.LEASE_EXPIRED, Severity.CAUTION, [rec.lease.holder],
                                            ReasonCode.LEASE_EXPIRED, task_id=rec.lease.task_id,
                                            lease_id=rec.lease.lease_id))
        # retries: proposals, commits, commands
        for ps in self.proposals.values():
            if not ps.committed and t < ps.deadline:
                for d in ps.plan.participants:
                    if d not in ps.acks and t - ps.last_sent.get(d, -1e9) >= cc.command_retry_interval_s:
                        await self._send_proposal(ps, d)
            if ps.committed and ps.commit_id:
                for d in ps.committed_drones:
                    eff = ps.plan.drone_plans[d].effective_from
                    if d not in ps.commit_acks and t < eff and t - ps.commit_last_sent.get(d, -1e9) >= \
                            min(cc.command_retry_interval_s, max(0.2, (eff - t) / 3)):
                        await self._send_commit(ps, d)
        for cid in sorted(self.commands):
            pc = self.commands[cid]
            if pc.ack is None and t < pc.command.expires_at and t - pc.last_sent >= cc.command_retry_interval_s:
                pc.attempts += 1
                pc.last_sent = t
                await self._send(pc.command.target_drone_id, MessageType.COMMAND, CommandPayload(command=pc.command),
                                 validity=pc.command.expires_at - t)
            elif pc.ack is None and t >= pc.command.expires_at and pc.future is not None and not pc.future.done():
                pc.future.set_result(None)
        if t >= self._next_monitor:
            self._next_monitor = t + 0.5
            active = self.active_trajectories(t)
            plans = {d: p for d in self.plan_history if (p := self.effective_plan(d, t)) is not None}
            for ev in self.monitor.evaluate(snap, plans, active, self.plan_lease_expiry(), self.buffers(snap)):
                self.event(ev)

    # ------------------------------------------------------------------ dispatch API
    async def _send_proposal(self, ps: ProposalState, d: str) -> None:
        ps.last_sent[d] = self.now()
        await self._send(d, MessageType.PLAN_PROPOSAL, PlanProposalPayload(
            plan_id=ps.plan.plan_id, plan_digest=ps.digests[d], drone_plan=ps.plan.drone_plans[d],
            readiness_deadline=ps.deadline, timing_tolerance_s=ps.plan.timing_tolerance_s,
            participants=ps.plan.participants), validity=max(1.0, ps.deadline - self.now()),
            mission_version=ps.plan.mission_version)

    async def _send_commit(self, ps: ProposalState, d: str) -> None:
        t = self.now()
        ps.commit_last_sent[d] = t
        ps.commit_last_sent.setdefault("__first__", t)
        dp = ps.plan.drone_plans[d]
        await self._send(d, MessageType.PLAN_COMMIT, PlanCommitPayload(
            commit_id=ps.commit_id or "", plan_id=ps.plan.plan_id, plan_digest=ps.digests[d],
            plan_version=dp.plan_version, effective_from=dp.effective_from, leases=ps.leases.get(d, [])),
            validity=max(0.5, dp.effective_from - t + 1.0), mission_version=ps.plan.mission_version)

    async def propose(self, plan: Plan, readiness_deadline_s: float | None = None) -> ProposalResult:
        if plan.coordinator_epoch != self.epoch:
            raise ValueError("plan built for another epoch")
        deadline = self.now() + (readiness_deadline_s or self.cfg.timing.readiness_deadline_s)
        ps = ProposalState(plan=plan, digests={d: plan.digest(d) for d in plan.participants}, deadline=deadline)
        self.proposals[plan.plan_id] = ps
        for d in plan.participants:
            await self._send_proposal(ps, d)
        self.record.add(self.now(), "proposed", plan_id=plan.plan_id, participants=plan.participants,
                        purpose=plan.purpose.value, mission_version=plan.mission_version)
        return ProposalResult(plan.plan_id, plan.participants, deadline)

    def readiness(self, ps: ProposalState) -> tuple[list[str], dict[str, list[ReasonCode]]]:
        t = self.now()
        snap = self.snapshot(t)
        ready: list[str] = []
        not_ready: dict[str, list[ReasonCode]] = {}
        for d in ps.plan.participants:
            a = ps.acks.get(d)
            dp = ps.plan.drone_plans[d]
            if a is None:
                not_ready[d] = [ReasonCode.NOT_READY]
                continue
            reasons: list[ReasonCode] = []
            if not a.ack.ready:
                reasons += a.ack.reasons
            if a.ack.plan_digest != ps.digests[d] or a.epoch != self.epoch or a.boot_id != dp.expected_boot_id \
                    or a.ack.drone_boot_id != dp.expected_boot_id or a.ack.plan_version != dp.plan_version:
                reasons.append(ReasonCode.ACK_BINDING_MISMATCH)
            if t > a.ack.readiness_expires_at:
                reasons.append(ReasonCode.READINESS_EXPIRED)
            if a.ack.clock_uncertainty_s > ps.plan.timing_tolerance_s:
                reasons.append(ReasonCode.CLOCK_UNCERTAINTY_EXCEEDS_TOLERANCE)
            est = snap.drones.get(d)
            if est is None or est.boot_id != dp.expected_boot_id:
                reasons.append(ReasonCode.WRONG_BOOT_ID)
            lead = max(self.cfg.timing.min_commit_lead_s,
                       self.cfg.timing.commit_lead_latency_factor * self.latency_p95(d))
            if dp.effective_from - t < lead:
                reasons.append(ReasonCode.INSUFFICIENT_COMMIT_LEAD)
            if reasons:
                not_ready[d] = reasons
            else:
                ready.append(d)
        return ready, not_ready

    async def commit_when_ready(self, plan: Plan, deadline: float | None = None, allow_partial: bool = False,
                                wait_for_acks: bool = True) -> CommitResult:
        """Commit once every participant is ready (or, with ``allow_partial``,
        the ready subset - only permitted for plans whose non-ready aircraft are
        on the ground).  Returns a structured result; never raises for
        protocol outcomes."""
        ps = self.proposals.get(plan.plan_id)
        if ps is None:
            await self.propose(plan)
            ps = self.proposals[plan.plan_id]
        deadline = deadline if deadline is not None else ps.deadline
        poll = self.cfg.coordinator.tick_s
        while True:
            ready, not_ready = self.readiness(ps)
            t = self.now()
            lead_problem = any(ReasonCode.INSUFFICIENT_COMMIT_LEAD in v for v in not_ready.values())
            if not not_ready:
                break
            if lead_problem or t >= deadline:
                if allow_partial and ready and not lead_problem and self._partial_safe(ps.plan, list(not_ready)):
                    break
                status = ReasonCode.INSUFFICIENT_COMMIT_LEAD if lead_problem else (
                    ReasonCode.PARTIAL_ACKNOWLEDGEMENT if ready else ReasonCode.NOT_READY)
                self.record.add(t, "commit_failed", plan_id=plan.plan_id, status=status.value,
                                not_ready={k: [r.value for r in v] for k, v in not_ready.items()})
                ps.deadline = t  # stop proposal retries
                return CommitResult(status, plan.plan_id, ready, not_ready)
            await self.clock.sleep(poll)
        # --- ownership must be resolvable for every task before anything is committed
        t = self.now()
        participants = ready if not_ready else ps.plan.participants
        refused = {}
        for d in participants:
            for task_id in [plan_lease_task(d), *ps.plan.drone_plans[d].task_ids]:
                ok, why = self.leases.can_grant(task_id, d)
                if not ok:
                    refused.setdefault(d, []).append(why)
        if refused:
            self.record.add(t, "commit_refused", plan_id=plan.plan_id,
                            refused={k: [r.value for r in v] for k, v in refused.items()})
            ps.deadline = t
            return CommitResult(ReasonCode.REJECTED, plan.plan_id, ready, refused,
                                reasons=[ReasonCode.PARENT_OWNERSHIP_UNRESOLVED])
        # --- commit
        ps.committed = True
        ps.commit_id = f"commit/{plan.plan_id}"
        ps.committed_drones = participants
        for d in participants:
            dp = ps.plan.drone_plans[d]
            boot = dp.expected_boot_id
            leases = []
            for task_id in [plan_lease_task(d), *dp.task_ids]:
                ok, why = self.leases.can_grant(task_id, d)
                if not ok:
                    self.record.add(t, "lease_refused", task=task_id, drone=d, reason=why.value)
                    continue
                lz = self.leases.grant(task_id, d, boot, dp.plan_version, t)
                leases.append(lz)
                self.record.leases.append({"t": t, "lease": lz.lease_id, "event": "GRANTED", "task": task_id,
                                           "holder": d})
            ps.leases[d] = leases
            self.committed[d] = dp
            self.plan_history.setdefault(d, []).append(dp)
            self.renewal_suspended.discard(d)
        self.record.commits.append({"t": t, "plan_id": plan.plan_id, "drones": participants,
                                    "purpose": plan.purpose.value, "mission_version": plan.mission_version,
                                    "effective_from": {d: ps.plan.drone_plans[d].effective_from for d in participants}})
        for d in participants:
            await self._send_commit(ps, d)
        result = CommitResult(ReasonCode.COMMITTED, plan.plan_id, ready, not_ready, participants, committed_at=t)
        if wait_for_acks:
            last_eff = max(ps.plan.drone_plans[d].effective_from for d in participants)
            while self.now() < last_eff and len(ps.commit_acks) < len(participants):
                await self.clock.sleep(poll)
        result.commit_acked = sorted(d for d in participants if d in ps.commit_acks and ps.commit_acks[d].accepted)
        result.commit_unacked = sorted(d for d in participants if d not in result.commit_acked)
        return result

    def _partial_safe(self, plan: Plan, missing: list[str]) -> bool:
        snap = self.snapshot()
        for d in missing:
            e = snap.drones.get(d)
            if e is None or e.position is None or e.position.z > 1.0:
                return False
        return plan.purpose == PlanPurpose.INITIAL

    def withdraw(self, drone_id: str, reason: ReasonCode) -> None:
        """Stop renewing leases of an aircraft; they lapse (aircraft holds) and
        expire at the coordinator after expiry + margin."""
        self.renewal_suspended.add(drone_id)
        t = self.now()
        for rec in self.leases.for_holder(drone_id):
            self.leases.revoke(rec.lease.lease_id, t)
        self.record.add(t, "withdraw", drone=drone_id, reason=reason.value)

    async def command(self, drone_id: str, ctype: CommandType, params: dict[str, Any] | None = None,
                      hold_point: Vec3 | None = None, wait: bool = True,
                      timeout: float | None = None) -> CommandAcknowledgement | None:
        t = self.now()
        est = self.snapshot(t).drones.get(drone_id)
        boot = est.boot_id if est and est.boot_id else ""
        self._cmd_counter += 1
        cmd = CoordinationCommand(command_id=f"e{self.epoch}-C{self._cmd_counter:05d}", command_type=ctype,
                                  target_drone_id=drone_id, target_boot_id=boot, params=params or {}, issued_at=t,
                                  expires_at=t + (timeout or self.cfg.coordinator.command_validity_s),
                                  hold_point=hold_point)
        fut: asyncio.Future = asyncio.get_running_loop().create_future()
        self.commands[cmd.command_id] = PendingCommand(cmd, t, t, future=fut)
        await self._send(drone_id, MessageType.COMMAND, CommandPayload(command=cmd), validity=cmd.expires_at - t)
        self.record.add(t, "command", drone=drone_id, type=ctype.value, command_id=cmd.command_id)
        if not wait:
            return None
        return await fut

    async def abort(self, reason: ReasonCode, drones: list[str] | None = None, detail: str = "") -> None:
        """Coordination abort: aircraft stop coordinated work and fly their own
        pre-validated contingency.  This is not an emergency command."""
        t = self.now()
        targets = drones or self.fleet_ids
        for d in targets:
            self.withdraw(d, reason)
            aid = f"abort/e{self.epoch}/{d}/{int(t * 1000)}"
            self._cmd_counter += 1
            cmd = CoordinationCommand(command_id=aid, command_type=CommandType.HOLD_POSITION, target_drone_id=d,
                                      target_boot_id="", issued_at=t, expires_at=t + 10.0)
            self.commands[aid] = PendingCommand(cmd, t, t)
            await self._send(d, MessageType.COORDINATION_ABORT,
                             CoordinationAbortPayload(abort_id=aid, reason=reason, detail=detail), validity=10.0)
        self.event(self.monitor._ev(t, SafetyEventKind.COORDINATION_ABORT, Severity.WARNING, list(targets), reason,
                                    detail=detail))

    async def revoke_lease(self, lease: TaskLease) -> None:
        self.leases.revoke(lease.lease_id, self.now())
        await self._send(lease.holder, MessageType.TASK_LEASE, TaskLeasePayload(lease=lease, revoke=True))

    async def next_signal(self, timeout: float) -> MissionSignal | None:
        if not self.signals.empty():
            return self.signals.get_nowait()
        end = self.clock.monotonic() + timeout
        while self.signals.empty() and self.clock.monotonic() < end and self._running:
            await self.clock.sleep(min(self.cfg.coordinator.tick_s, max(0.0, end - self.clock.monotonic())))
        return None if self.signals.empty() else self.signals.get_nowait()
