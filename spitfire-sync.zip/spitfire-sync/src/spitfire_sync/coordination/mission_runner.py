"""Mission runner: the coordinator-side orchestration of

    mission planning -> task assignment -> trajectory scheduling ->
    conflict checking -> command dispatch -> execution monitoring

and of the degraded-operation responses (suspension, reassignment after
ownership resolution, reconciliation, sequenced recovery, partial-start policy).

Every decision is appended to ``timeline`` with a reason code.
"""

from __future__ import annotations

import asyncio
import math
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

import numpy as np

from ..allocation.allocators import Assignment, TaskAssignment, make_allocator
from ..allocation.cost import CostModel, DroneCommitment, availability
from ..allocation.energy import EnergyModel
from ..config import SpitfireConfig
from ..models.commands import CommandType, LeaseState, SafetyEvent, SafetyEventKind, Severity
from ..models.geometry import Polygon2D, Vec3, clip_line_to_polygon, subtract_intervals
from ..models.mission import ExclusionZone, Mission, MissionTask, TaskStatus
from ..models.state import AgentStatus, FleetSnapshot, FlightMode, Freshness
from ..models.trajectory import EndBehaviour, Plan, PlanPurpose, Reservation
from ..reasons import ReasonCode
from ..scheduling.routing import Router
from ..scheduling.scheduler import DroneRequest, EndKind, EndSpec, Scheduler, StartState
from ..separation.regions import ReservationTable
from .coordinator import CommitResult, Coordinator, MissionSignal


class DroneRunState(StrEnum):
    STANDBY = "STANDBY"
    WORKING = "WORKING"
    PAUSED = "PAUSED"
    RESERVE = "RESERVE"
    RECOVERING = "RECOVERING"
    LANDED = "LANDED"
    FAILED = "FAILED"  # failed to start; on the ground
    LOST = "LOST"
    EMERGENCY = "EMERGENCY"  # autopilot failsafe owns the aircraft
    UNAVAILABLE = "UNAVAILABLE"


TERMINAL_RUN_STATES = {DroneRunState.LANDED, DroneRunState.FAILED, DroneRunState.LOST, DroneRunState.EMERGENCY}


@dataclass
class TimelineEntry:
    time: float
    kind: str
    drone_id: str | None
    reason: ReasonCode
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class MissionOutcome:
    completed_tasks: list[str]
    abandoned_tasks: dict[str, ReasonCode]
    unassigned_tasks: dict[str, ReasonCode]
    drone_states: dict[str, DroneRunState]
    timeline: list[TimelineEntry]
    initial_plan: Plan | None
    plans: list[Plan]
    reassignments: list[dict[str, Any]]
    recoveries: list[dict[str, Any]]
    reconciliations: list[dict[str, Any]]
    finished: bool
    reason: ReasonCode


class MissionRunner:
    def __init__(self, coordinator: Coordinator, mission: Mission, config: SpitfireConfig,
                 allocator: str | None = None) -> None:
        self.c = coordinator
        self.mission = mission
        self.cfg = config
        self.tasks: dict[str, MissionTask] = {t.task_id: t for t in mission.tasks}
        self.task_status: dict[str, TaskStatus] = {t: TaskStatus.PENDING for t in self.tasks}
        self.task_reason: dict[str, ReasonCode] = {}
        self.task_owner: dict[str, str] = {}
        self.progress: dict[str, tuple[float, tuple[float, float] | None]] = {}
        self.c.checker.task_registry = self.tasks
        self.profiles = {p.drone_id: p for p in config.fleet}
        self._rebuild_planners()
        self.allocator_name = allocator or config.allocator
        self.run_state: dict[str, DroneRunState] = {d: DroneRunState.STANDBY for d in coordinator.fleet_ids}
        self.timeline: list[TimelineEntry] = []
        self.plans: list[Plan] = []
        self.initial_plan: Plan | None = None
        self.pending_reassign: list[str] = []
        self.recovery_queue: list[str] = []
        self.recovery_table = ReservationTable()
        self.landing_spot: dict[str, tuple[float, float]] = {}
        self.reassignments: list[dict[str, Any]] = []
        self.recoveries: list[dict[str, Any]] = []
        self.reconciliations: list[dict[str, Any]] = []
        self.paused_info: dict[str, dict[str, Any]] = {}
        self.suspend_times: dict[str, float] = {}
        self._lock = asyncio.Lock()
        self._busy: set[str] = set()
        self._bg: set[asyncio.Task] = set()
        self._start_deadline: dict[str, float] = {}
        self._started: set[str] = set()
        self._next_house = 0.0
        self._last_reassign_try = -1e9
        self._done = False
        self.max_duration_s = 3600.0
        self.obstructions: list[ExclusionZone] = []
        self.errors: list[str] = []
        spots = list(mission.recovery_area.landing_spots)
        for i, d in enumerate(coordinator.fleet_ids):
            self.landing_spot[d] = spots[i % len(spots)]

    # ------------------------------------------------------------------ helpers
    def _rebuild_planners(self) -> None:
        self.c.checker.mission = self.mission
        self.c.mission = self.mission
        self.scheduler = Scheduler(self.mission, self.cfg, self.c.checker, tasks=self.tasks)
        self.router = Router(self.mission, self.scheduler.router.clearance)
        self.cost_model = CostModel(self.mission, self.cfg.allocation, self.cfg.constraints, self.profiles,
                                    self.router)

    def log(self, kind: str, drone: str | None, reason: ReasonCode = ReasonCode.OK, **details: Any) -> None:
        self.timeline.append(TimelineEntry(self.c.now(), kind, drone, reason, details))

    def _spawn(self, coro) -> None:  # type: ignore[no-untyped-def]
        task = asyncio.ensure_future(coro)
        self._bg.add(task)
        task.add_done_callback(self._task_done)

    def _task_done(self, task: asyncio.Task) -> None:
        self._bg.discard(task)
        if not task.cancelled() and task.exception() is not None:
            import traceback

            exc = task.exception()
            self.errors.append("".join(traceback.format_exception(exc)))
            self.log("internal_error", None, ReasonCode.REJECTED, error=repr(exc))

    def lead(self, drone_id: str | None = None) -> float:
        ids = [drone_id] if drone_id else self.c.fleet_ids
        worst = max((self.c.latency_p95(d) for d in ids), default=0.1)
        return max(self.cfg.coordinator.amendment_lead_s,
                   self.cfg.timing.readiness_deadline_s * 0.6 + self.cfg.timing.commit_lead_latency_factor * worst)

    def existing_holds(self, exclude: set[str]) -> dict[str, Vec3]:
        out = {}
        for d, dp in self.c.committed.items():
            if d in exclude or self.run_state.get(d) in TERMINAL_RUN_STATES:
                continue
            if dp.trajectory.end_behaviour == EndBehaviour.HOLD:
                p = dp.trajectory.position_at(dp.trajectory.end_time)
                out[d] = Vec3.enu(*p)
        return out

    def existing_trajectories(self, exclude: set[str]) -> dict:
        out = {}
        snap = self.c.snapshot()
        for d, tr in self.c.active_trajectories().items():
            if d in exclude:
                continue
            est = snap.drones.get(d)
            if est is not None and est.freshness == Freshness.FRESH and est.agent_status in (
                    AgentStatus.PAUSED, AgentStatus.RESERVE_HOLD, AgentStatus.CONTINGENCY):
                continue  # represented by its stopped / contingency region instead
            if self.run_state.get(d) in (DroneRunState.LANDED, DroneRunState.FAILED):
                continue
            out[d] = tr
        return out

    def reservations(self, snap: FleetSnapshot, exclude: set[str]) -> list[Reservation]:
        res = [r for r in self.recovery_table.all() if r.holder not in exclude]
        res += [r for r in self.c.uncertain_regions(snap) if r.holder not in exclude]
        return res

    # ------------------------------------------------------------------ run
    async def run(self) -> MissionOutcome:
        t0 = self.c.now()
        await self._collect_initial_state()
        ok = await self._initial_plan()
        reason = ReasonCode.OK
        if not ok:
            reason = ReasonCode.SCHEDULE_INFEASIBLE
        while not self._done and ok:
            sig = await self.c.next_signal(0.5)
            if sig is not None:
                await self._handle(sig)
            if self.c.now() >= self._next_house:
                self._next_house = self.c.now() + 1.0
                await self._housekeeping()
            if self.c.now() - t0 > self.max_duration_s:
                reason = ReasonCode.SHUTDOWN
                self.log("time_limit", None, ReasonCode.SHUTDOWN)
                break
        for task in list(self._bg):
            task.cancel()
        if self._bg:
            await asyncio.gather(*self._bg, return_exceptions=True)
        return self._outcome(reason)

    def _outcome(self, reason: ReasonCode) -> MissionOutcome:
        done = [t for t, s in self.task_status.items() if s == TaskStatus.COMPLETE]
        aband = {t: self.task_reason.get(t, ReasonCode.REJECTED) for t, s in self.task_status.items()
                 if s == TaskStatus.ABANDONED}
        unassigned = {t: self.task_reason.get(t, ReasonCode.NO_AVAILABLE_AIRCRAFT)
                      for t, s in self.task_status.items() if s in (TaskStatus.PENDING, TaskStatus.SUSPENDED)}
        return MissionOutcome(sorted(done), aband, unassigned, dict(self.run_state), self.timeline,
                              self.initial_plan, self.plans, self.reassignments, self.recoveries,
                              self.reconciliations, self._done, reason)

    async def _collect_initial_state(self) -> None:
        end = self.c.now() + self.cfg.coordinator.state_collection_timeout_s
        while self.c.now() < end:
            snap = self.c.snapshot()
            if all(snap.drones[d].freshness == Freshness.FRESH for d in self.c.fleet_ids if d in snap.drones) and \
                    len(snap.fresh()) == len(self.c.fleet_ids):
                break
            await self.c.clock.sleep(0.5)
        snap = self.c.snapshot()
        self.log("initial_state_collected", None, ReasonCode.OK, fresh=snap.fresh(),
                 missing=[d for d in self.c.fleet_ids if d not in snap.fresh()])

    # ------------------------------------------------------------------ planning primitives
    def _commitments(self, snap: FleetSnapshot, drones: list[str], at_end_of_tasks: bool) -> tuple[
            dict[str, DroneCommitment], dict[str, StartState]]:
        com: dict[str, DroneCommitment] = {}
        starts: dict[str, StartState] = {}
        now = self.c.now()
        lead = self.lead()
        for d in drones:
            est = snap.drones.get(d)
            if est is None or est.position is None or est.battery_state is None or est.boot_id is None:
                continue
            prof = self.profiles.get(d)
            if prof is None:
                continue
            cap = prof.energy.capacity_wh
            dp = self.c.committed.get(d)
            t_switch = now + self.lead(d)
            pos = (est.position.x, est.position.y, est.position.z)
            energy = est.battery_state.remaining_energy_wh
            if at_end_of_tasks and dp is not None and self.run_state.get(d) == DroneRunState.WORKING:
                windows = [w for tid, w in dp.task_windows.items() if self.task_status.get(tid) != TaskStatus.COMPLETE]
                t_end_tasks = max((w[1] for w in windows), default=0.0)
                t_switch = max(t_switch, t_end_tasks + 0.5)
                p = dp.trajectory.position_at(t_switch)
                pos = (float(p[0]), float(p[1]), float(p[2]))
                em = EnergyModel(prof.energy)
                seg = dp.trajectory.clipped(now)
                used = em.trajectory_energy_wh(seg) - em.trajectory_energy_wh(seg.clipped(t_switch))
                energy -= used * prof.energy.planning_margin
            on_ground = pos[2] < 1.0
            com[d] = DroneCommitment(d, pos, t_switch, energy - self.cfg.constraints.reserve_fraction * cap, on_ground)
            starts[d] = StartState(pos, t_switch, on_ground, est.boot_id)
        return com, starts

    async def _propose_and_commit(self, plan: Plan, allow_partial: bool = False) -> CommitResult:
        self.plans.append(plan)
        await self.c.propose(plan)
        res = await self.c.commit_when_ready(plan, allow_partial=allow_partial)
        self.log("commit_result", None, res.status, plan_id=plan.plan_id, purpose=plan.purpose.value,
                 committed=res.committed, acked=res.commit_acked, unacked=res.commit_unacked,
                 not_ready={k: [r.value for r in v] for k, v in res.not_ready.items()})
        return res

    async def _initial_plan(self) -> bool:
        tries = self.cfg.timing.max_reschedules + 1
        for attempt in range(tries):
            snap = self.c.snapshot()
            avail = [d for d in self.c.fleet_ids if availability(snap.drones.get(d)) == ReasonCode.OK]
            com, starts = self._commitments(snap, avail, at_end_of_tasks=False)
            start_time = self.c.now() + self.cfg.timing.readiness_deadline_s + 6.0 + 4.0 * attempt
            starts = {d: StartState(s.position, start_time, s.on_ground, s.boot_id) for d, s in starts.items()}
            allocator = make_allocator(self.allocator_name, self.cost_model)
            pending = [self.tasks[t] for t, s in self.task_status.items() if s == TaskStatus.PENDING]
            assignment = allocator.assign(tasks=pending, fleet=snap, constraints=self.cfg.constraints,
                                          commitments=com)
            self.log("allocation", None, ReasonCode.OK, method=assignment.method,
                     per_drone={d: [f"{a.task_id}{'(rev)' if a.reversed else ''}" for a in v]
                                for d, v in assignment.per_drone.items()},
                     unassigned={k: v.value for k, v in assignment.unassigned.items()},
                     excluded={k: v.value for k, v in assignment.excluded_drones.items()})
            res = self.scheduler.schedule(assignment, [], snap.uncertainty, starts=starts, start_time=start_time,
                                          mission_version=self.c.next_mission_version(), epoch=self.c.epoch,
                                          plan_id=f"plan-{self.c.epoch}-{self.c.mission_version}",
                                          fleet_ids=self.c.fleet_ids)
            if res.plan is None:
                self.log("schedule_failed", None, ReasonCode.SCHEDULE_INFEASIBLE,
                         failed={k: v.value for k, v in res.failed.items()})
                return False
            self.log("scheduled", None, ReasonCode.OK, conflicts=len(res.report),
                     resolutions={d: r.value for d, r in res.plan.resolutions},
                     options={d: s.options.label() for d, s in res.scheduled.items()},
                     failed={k: v.value for k, v in res.failed.items()})
            if not res.report.ok:
                self.log("conflicts_remaining", None, ReasonCode.SEPARATION_CONFLICT, n=len(res.report))
                return False
            for d, s in res.failed.items():
                for a in assignment.per_drone.get(d, []):
                    self.task_reason[a.task_id] = s
            res2 = await self._propose_and_commit(res.plan, allow_partial=True)
            if res2.ok:
                self.initial_plan = res.plan
                placed = {t for dp in res.plan.drone_plans.values() for t in dp.task_ids if dp.drone_id in res2.committed}
                for tid, st in self.task_status.items():
                    if st == TaskStatus.PENDING and tid not in placed and tid not in self.pending_reassign:
                        self.pending_reassign.append(tid)  # retried by the reallocation loop
                        self.suspend_times.setdefault(tid, self.c.now())
                for d in res2.committed:
                    self.run_state[d] = DroneRunState.WORKING
                    dp = res.plan.drone_plans[d]
                    for tid in dp.task_ids:
                        self.task_status[tid] = TaskStatus.ASSIGNED
                        self._set_owner(tid, d)
                    self._start_deadline[d] = dp.effective_from + self.cfg.timing.start_tolerance_s + \
                        2.0 * self.c.latency_p95(d) + 1.5
                for d in res.plan.participants:
                    if d not in res2.committed:
                        self.log("excluded_from_start", d, ReasonCode.NOT_READY,
                                 reasons=[r.value for r in res2.not_ready.get(d, [])])
                return True
            self.log("rescheduling", None, ReasonCode.RESCHEDULED, status=res2.status.value)
        return False

    async def amend(self, requests: list[DroneRequest], purpose: PlanPurpose, label: str) -> CommitResult | None:
        """Schedule, conflict-check, propose and commit plan amendments."""
        async with self._lock:
            for attempt in range(3):
                snap = self.c.snapshot()
                ids = {r.drone_id for r in requests}
                existing = self.existing_trajectories(ids)
                res_list = self.reservations(snap, ids)
                buffers = self.c.buffers(snap)
                if attempt:
                    bump = 4.0 * attempt
                    requests = [DroneRequest(r.drone_id, StartState(r.start.position, r.start.time + bump,
                                                                    r.start.on_ground, r.start.boot_id),
                                             r.tasks, r.end, r.contingency_altitude) for r in requests]
                if purpose == PlanPurpose.RECOVERY:
                    self.scheduler.max_delay_s = 900.0
                scheduled, failed = self.scheduler.schedule_requests(requests, existing, res_list, buffers,
                                                                     self.existing_holds(ids))
                self.scheduler.max_delay_s = 150.0
                if failed or not scheduled:
                    diag = {k: [f"{c.kind.value}:{c.detail}:{','.join(c.drones)}@{c.t_start:.0f}" if hasattr(c, "kind")
                                else str(c) for c in self.scheduler.last_failure.get(k, [])] for k in failed}
                    self.log("amend_schedule_failed", None, ReasonCode.SCHEDULE_INFEASIBLE, label=label,
                             failed={k: v.value for k, v in failed.items()}, nominal_conflicts=diag)
                    return None
                reqs = {r.drone_id: r for r in requests}
                mv = self.c.next_mission_version()
                plan = self.scheduler.make_plan(scheduled, reqs, plan_id=f"plan-{self.c.epoch}-{mv}",
                                                mission_version=mv, epoch=self.c.epoch, created_at=self.c.now(),
                                                purpose=purpose, effective_from={d: reqs[d].start.time for d in reqs},
                                                fleet_ids=self.c.fleet_ids)
                rep = self.c.checker.check(plan, existing=existing, reservations=res_list, buffers=buffers,
                                           t_from=min(r.start.time for r in requests))
                if not rep.ok:
                    self.log("amend_conflict", None, ReasonCode.SEPARATION_CONFLICT, label=label, n=len(rep))
                    return None
                self.log("amend_scheduled", None, ReasonCode.OK, label=label, purpose=purpose.value,
                         drones=sorted(reqs), resolutions={d: r.value for d, r in plan.resolutions})
                result = await self._propose_and_commit(plan)
                if result.ok:
                    for r in plan.reservations:
                        self.recovery_table.add(r)
                    return result
                if result.status != ReasonCode.INSUFFICIENT_COMMIT_LEAD:
                    return result
            return None

    # ------------------------------------------------------------------ task bookkeeping
    def _remainder(self, task_id: str, progress_xy: tuple[float, float] | None, progress_m: float,
                   drone: str) -> str | None:
        """Create a remainder task from the suspension point (minus overlap) to the lane exit."""
        task = self.tasks[task_id]
        dp = self.c.committed.get(drone)
        w = dp.trajectory.task_window(task_id) if dp else None
        if w is None:
            entry, exit_ = task.start_xy, task.end_xy
        else:
            pe = dp.trajectory.position_at(w[0])  # type: ignore[union-attr]
            px = dp.trajectory.position_at(w[1] - 1e-6)  # type: ignore[union-attr]
            entry, exit_ = (float(pe[0]), float(pe[1])), (float(px[0]), float(px[1]))
        L = math.hypot(exit_[0] - entry[0], exit_[1] - entry[1])
        s = max(0.0, min(L, progress_m) - self.mission.lane_overlap_m)
        if L - s < 15.0:
            self.task_status[task_id] = TaskStatus.COMPLETE
            self.log("task_effectively_complete", drone, ReasonCode.OK, task_id=task_id, progress_m=progress_m)
            return None
        f = s / L if L > 0 else 0.0
        start = (entry[0] + f * (exit_[0] - entry[0]), entry[1] + f * (exit_[1] - entry[1]))
        n = sum(1 for t in self.tasks if t.startswith(task_id + ".r")) + 1
        rid = f"{task_id}.r{n}"
        new = task.model_copy(update={"task_id": rid, "start_xy": start, "end_xy": exit_, "parent_task_id": task_id,
                                      "root_task_id": task.root_id, "offset_m": task.offset_m + s,
                                      "reversible": True})
        self.tasks[rid] = new
        self.task_status[rid] = TaskStatus.PENDING
        self.task_status[task_id] = TaskStatus.SUPERSEDED
        self.c.leases.register_parent(rid, task_id)
        self.log("remainder_created", drone, ReasonCode.OK, task_id=task_id, remainder=rid,
                 from_xy=[round(v, 1) for v in start], length_m=round(L - s, 1))
        return rid

    def _ownership_resolved(self, task_id: str) -> bool:
        lm = self.c.leases
        if lm.non_terminal(task_id):
            return False
        return all(not lm.non_terminal(a) for a in lm.ancestors(task_id))

    def _set_owner(self, task_id: str, d: str) -> None:
        self.task_owner.pop(task_id, None)
        self.task_owner[task_id] = d  # re-insert: dict order = order of assignment

    def _unfinished_tasks_of(self, d: str) -> list[str]:
        """All lanes currently assigned to ``d`` and not finished, across every plan
        version (an amendment's plan lists only the lanes it adds)."""
        return [t for t, o in self.task_owner.items() if o == d and
                self.task_status.get(t) in (TaskStatus.ASSIGNED, TaskStatus.ACTIVE)]

    def _revoke_tasks(self, d: str, task_ids: list[str]) -> None:
        """Take leases on ``task_ids`` away from ``d``: they stop being renewed and
        are treated as possibly active until expiry + margin (ownership resolution)."""
        wanted = set(task_ids)
        for t in list(task_ids):  # a remainder's parent lane may still be leased to the same aircraft
            wanted.update(self.c.leases.ancestors(t))
        for rec in self.c.leases.for_holder(d):
            if rec.lease.task_id in wanted and rec.state in (LeaseState.OFFERED, LeaseState.ACTIVE):
                self._spawn(self.c.revoke_lease(rec.lease))

    def _return_tasks(self, d: str, current: str | None, progress_m: float, progress_xy, reason: ReasonCode) -> None:  # type: ignore[no-untyped-def]
        t_now = self.c.now()
        self._revoke_tasks(d, self._unfinished_tasks_of(d))
        for tid in self._unfinished_tasks_of(d):
            if tid == current and progress_m > 0:
                rid = self._remainder(tid, progress_xy, progress_m, d)
                if rid:
                    self.pending_reassign.append(rid)
                    self.suspend_times[rid] = t_now
            else:
                self.task_status[tid] = TaskStatus.PENDING
                self.pending_reassign.append(tid)
                self.suspend_times[tid] = t_now
            self.task_reason[tid] = reason

    # ------------------------------------------------------------------ signal handling
    async def _handle(self, sig: MissionSignal) -> None:
        d = sig.drone_id
        k = sig.kind
        if k == "task_complete":
            tid = sig.data["task_id"]
            self.task_status[tid] = TaskStatus.COMPLETE
            self.log("task_complete", d, ReasonCode.OK, task_id=tid)
        elif k == "progress":
            tid = sig.data.get("task_id")
            if tid:
                self.progress[tid] = (sig.data.get("progress_m", 0.0), sig.data.get("progress_xy"))
                if self.task_status.get(tid) == TaskStatus.ASSIGNED:
                    self.task_status[tid] = TaskStatus.ACTIVE
        elif k == "plan_started":
            self._started.add(d)  # type: ignore[arg-type]
            for r in self.reassignments:
                if r["to"] == d and r.get("started_at") is None and r.get("committed_at") is not None:
                    r["started_at"] = sig.time
        elif k == "task_suspended" and d:
            tid = sig.data.get("task_id")
            reason = sig.data.get("reason", ReasonCode.OK)
            if tid and self.task_status.get(tid) in (TaskStatus.ASSIGNED, TaskStatus.ACTIVE):
                pm = sig.data.get("progress_m", 0.0) or 0.0
                self.log("task_suspended", d, reason, task_id=tid, progress_m=round(pm, 1))
                if pm > 0:
                    rid = self._remainder(tid, sig.data.get("progress_xy"), pm, d)
                    if rid:
                        self.pending_reassign.append(rid)
                        self.suspend_times[rid] = sig.time
                else:
                    self.task_status[tid] = TaskStatus.PENDING
                    self.pending_reassign.append(tid)
                    self.suspend_times[tid] = sig.time
            if reason == ReasonCode.BATTERY_RESERVE_BREACH:
                self._enter_reserve(d)
        elif k == "paused" and d:
            if self.run_state.get(d) in (DroneRunState.WORKING,):
                self.run_state[d] = DroneRunState.PAUSED
                self.paused_info[d] = {"t": sig.time, **sig.data}
                self.log("aircraft_paused", d, sig.data.get("reason", ReasonCode.OK), task_id=sig.data.get("task_id"))
        elif k == "start_failed" and d:
            pv = sig.data.get("plan_version")
            initial_v = self.initial_plan.mission_version if self.initial_plan else None
            if pv is not None and pv == initial_v and d not in self._started:
                await self._start_failed(d, sig.data.get("reason", ReasonCode.START_FAILED))
            else:
                # an amendment could not take over (e.g. discontinuity): the aircraft holds; replan it
                self.log("amendment_not_started", d, sig.data.get("reason", ReasonCode.START_FAILED),
                         plan_version=pv)
                if self.run_state.get(d) in (DroneRunState.RESERVE, DroneRunState.RECOVERING,
                                             DroneRunState.UNAVAILABLE):
                    self.run_state[d] = DroneRunState.RESERVE if self.run_state[d] == DroneRunState.RESERVE \
                        else DroneRunState.UNAVAILABLE
                    if d not in self.recovery_queue:
                        self.recovery_queue.insert(0, d)
                elif self.run_state.get(d) == DroneRunState.WORKING:
                    self.run_state[d] = DroneRunState.PAUSED
                    self.paused_info[d] = {"t": sig.time}
        elif k == "commit_rejected" and d:
            self.log("commit_rejected", d, sig.data.get("reason", ReasonCode.REJECTED))
        elif k == "safety_event":
            await self._on_event(sig.data["event"])

    def _enter_reserve(self, d: str) -> None:
        if self.run_state.get(d) in {DroneRunState.RESERVE, DroneRunState.RECOVERING} | TERMINAL_RUN_STATES:
            return
        self.run_state[d] = DroneRunState.RESERVE
        self.log("battery_reserve", d, ReasonCode.BATTERY_RESERVE_BREACH)
        # tasks not yet flown go back to the pool (their leases are released by the aircraft;
        # revocation covers a lost release message)
        self._revoke_tasks(d, self._unfinished_tasks_of(d))
        for tid in self._unfinished_tasks_of(d):
            if tid not in self.pending_reassign and self.task_status.get(tid) == TaskStatus.ASSIGNED:
                self.task_status[tid] = TaskStatus.PENDING
                self.pending_reassign.append(tid)
                self.suspend_times[tid] = self.c.now()
        if d not in self.recovery_queue:
            self.recovery_queue.insert(0, d)

    async def _on_event(self, ev: SafetyEvent) -> None:
        d = ev.drone_ids[0] if ev.drone_ids else None
        K = SafetyEventKind
        if ev.kind in (K.LEASE_EXPIRED, K.STALE_TELEMETRY, K.LINK_LOST, K.POSITION_UNASSESSABLE, K.CLOCK_FAULT):
            self.log(ev.kind.value.lower(), d, ev.reason, **{k: v for k, v in ev.details.items()
                                                              if isinstance(v, (int, float, str))})
        if ev.kind == K.BATTERY_RESERVE_BREACH and d:
            self._enter_reserve(d)
        elif ev.kind == K.LINK_RESTORED and d:
            self.log("link_restored", d, ReasonCode.LINK_RESTORED)
            if self.run_state.get(d) in (DroneRunState.PAUSED, DroneRunState.LOST):
                self.run_state[d] = DroneRunState.PAUSED
                self._spawn(self._reconcile_and_resume(d, link_restored_at=ev.time))
        elif ev.kind == K.AIRCRAFT_DROPOUT and d:
            if self.run_state.get(d) not in TERMINAL_RUN_STATES:
                self.log("aircraft_dropout", d, ReasonCode.AIRCRAFT_DROPOUT)
                info = self.paused_info.get(d, {})
                tid = info.get("task_id")
                pm, pxy = self.progress.get(tid, (0.0, None)) if tid else (0.0, None)
                self._return_tasks(d, tid, pm, pxy, ReasonCode.AIRCRAFT_DROPOUT)
                self.run_state[d] = DroneRunState.LOST
                self.c.withdraw(d, ReasonCode.AIRCRAFT_DROPOUT)
        elif ev.kind == K.NAVIGATION_UNCERTAINTY and d and self.run_state.get(d) == DroneRunState.WORKING:
            self.log("navigation_degraded", d, ReasonCode.NAVIGATION_UNCERTAINTY, **ev.details)
            await self.c.command(d, CommandType.RELEASE_TASK, wait=False)
            self.run_state[d] = DroneRunState.UNAVAILABLE
            if d not in self.recovery_queue:
                self.recovery_queue.append(d)
        elif ev.kind == K.TRAJECTORY_DEVIATION and d and self.run_state.get(d) == DroneRunState.WORKING:
            self.log("trajectory_deviation", d, ReasonCode.TRAJECTORY_DEVIATION, **ev.details)
            await self.c.command(d, CommandType.HOLD_POSITION, wait=False)
        elif ev.kind == K.PREDICTED_CONFLICT and len(ev.drone_ids) == 2:
            other, uncertain = ev.drone_ids
            if self.run_state.get(other) == DroneRunState.WORKING:
                self.log("hold_for_uncertain_aircraft", other, ReasonCode.UNCERTAIN_REGION_CONFLICT,
                         uncertain=uncertain)
                await self.c.command(other, CommandType.HOLD_POSITION, wait=False)
        elif ev.kind == K.OWNERSHIP_CONFLICT:
            tid = ev.details.get("task_id")
            owner = self.c.leases.owner(tid) if tid else None
            for x in ev.drone_ids:
                if x != owner:
                    self.log("ownership_conflict", x, ReasonCode.OWNERSHIP_CONFLICT, task_id=tid, owner=owner)
                    await self.c.command(x, CommandType.ABANDON_TASK, params={"task_id": tid}, wait=False)
        elif ev.kind == K.AUTOPILOT_FAILSAFE and d:
            self.log("autopilot_failsafe", d, ReasonCode.AUTOPILOT_FAILSAFE)
            self._return_tasks(d, None, 0.0, None, ReasonCode.AUTOPILOT_FAILSAFE)
            self.run_state[d] = DroneRunState.EMERGENCY
            self.c.withdraw(d, ReasonCode.AUTOPILOT_FAILSAFE)
        elif ev.kind == K.REBOOT_DETECTED and d:
            self.log("reboot_detected", d, ReasonCode.SEQUENCE_RESET_NEW_BOOT, boot_id=ev.details.get("boot_id"))
            self.c.withdraw(d, ReasonCode.SEQUENCE_RESET_NEW_BOOT)
            if self.run_state.get(d) == DroneRunState.WORKING:
                self.run_state[d] = DroneRunState.PAUSED
                self.paused_info[d] = {"t": ev.time, "reboot": True}
                self._spawn(self._reconcile_and_resume(d, link_restored_at=ev.time))

    async def _start_failed(self, d: str, reason: ReasonCode) -> None:
        if self.run_state.get(d) == DroneRunState.FAILED:
            return
        self.run_state[d] = DroneRunState.FAILED
        self.log("start_failed", d, reason)
        self.c.event(self.c.monitor._ev(self.c.now(), SafetyEventKind.PARTIAL_START, Severity.WARNING, [d], reason))
        self.c.withdraw(d, reason)
        self._return_tasks(d, None, 0.0, None, reason)
        committed = [x for x in self._start_deadline]
        failed = [x for x in committed if self.run_state.get(x) == DroneRunState.FAILED]
        frac = 1.0 - len(failed) / max(1, len(committed))
        if self.cfg.coordinator.partial_start_policy == "abort_all" or frac < self.cfg.coordinator.min_start_participation:
            self.log("partial_start_abort", None, ReasonCode.COORDINATION_ABORTED, started_fraction=frac)
            await self.c.abort(ReasonCode.START_FAILED, detail="partial start below participation threshold")
            for x in self.c.fleet_ids:
                if self.run_state.get(x) == DroneRunState.WORKING:
                    self.run_state[x] = DroneRunState.UNAVAILABLE
                    if x not in self.recovery_queue:
                        self.recovery_queue.append(x)
        else:
            self.log("partial_start_continue", None, ReasonCode.PARTIAL_ACKNOWLEDGEMENT, started_fraction=frac,
                     failed=failed)

    # ------------------------------------------------------------------ reconciliation
    async def _reconcile_and_resume(self, d: str, link_restored_at: float) -> None:
        if d in self._busy:
            return
        self._busy.add(d)
        try:
            await self.c.clock.sleep(1.0)
            ack = None
            for _ in range(5):
                ack = await self.c.command(d, CommandType.RECONCILE, timeout=6.0)
                if ack is not None:
                    break
            if ack is None:
                self.log("reconcile_failed", d, ReasonCode.COMMAND_REJECTED)
                return
            rep = ack.details
            committed = self.c.committed.get(d)
            issued = {cid for cid, pc in self.c.commands.items() if pc.command.target_drone_id == d}
            mismatch = []
            versions = {p.plan_version for p in self.c.plan_history.get(d, [])}
            if committed and rep.get("plan_version") is not None and rep.get("plan_version") not in versions:
                mismatch.append("plan_version")
            unknown = [c for c in rep.get("executed_commands", []) if c not in issued and not c.startswith("commit/")
                       and not c.startswith("abort/")]
            if unknown:
                mismatch.append("unknown_commands")
            self.reconciliations.append({"drone": d, "t": self.c.now(), "link_restored_at": link_restored_at,
                                         "report": rep, "mismatch": mismatch})
            if mismatch:
                self.log("reconciliation_mismatch", d, ReasonCode.RECONCILIATION_MISMATCH, mismatch=mismatch)
                self.run_state[d] = DroneRunState.UNAVAILABLE
                if d not in self.recovery_queue:
                    self.recovery_queue.append(d)
                return
            self.log("reconciled", d, ReasonCode.RECONCILED, status=rep.get("status"),
                     progress={k: round(v, 1) for k, v in rep.get("progress", {}).items()})
            if rep.get("reserve_breached"):
                self._enter_reserve(d)
                return
            # resume remaining work: remainder of the interrupted task + untouched tasks
            info = self.paused_info.get(d, {})
            cur = info.get("task_id")
            prog = dict(rep.get("progress", {}))
            # a rebooted companion has lost its progress: fall back to the last progress it reported
            for tid in self._unfinished_tasks_of(d):
                if tid not in prog and tid in self.progress and self.progress[tid][0] > 0:
                    prog[tid] = float(self.progress[tid][0])
            tasks: list[tuple[MissionTask, bool]] = []
            prev_tasks = info.get("resume_tasks")
            source = [t for t in prev_tasks if self.task_status.get(t) != TaskStatus.COMPLETE] if prev_tasks \
                else self._unfinished_tasks_of(d)
            for tid in source:
                if tid in rep.get("completed", []):
                    self.task_status[tid] = TaskStatus.COMPLETE
                    continue
                if prev_tasks:
                    tasks.append((self.tasks[tid], False))
                    continue
                if prog.get(tid, 0.0) > 0:
                    rid = self._remainder(tid, None, prog[tid], d)
                    if rid is None:
                        continue
                    # previous ownership must be resolved before the remainder is leased
                    tasks.append((self.tasks[rid], False))
                else:
                    tasks.append((self.tasks[tid], False))
            self.paused_info.setdefault(d, {})["resume_tasks"] = [t.task_id for t, _ in tasks]
            deadline = self.c.now() + self.cfg.leases.duration_s + 10.0
            while self.c.now() < deadline and not all(self._ownership_resolved_for(t.task_id, d) for t, _ in tasks):
                await self.c.clock.sleep(0.5)
            snap = self.c.snapshot()
            est = snap.drones.get(d)
            if est is None or est.position is None or est.boot_id is None:
                return
            start = StartState((est.position.x, est.position.y, est.position.z), self.c.now() + self.lead(d), False,
                               est.boot_id)
            # orient each task from the nearer end
            oriented = []
            cur_xy = (est.position.x, est.position.y)
            for t, _ in tasks:
                da = math.hypot(cur_xy[0] - t.start_xy[0], cur_xy[1] - t.start_xy[1])
                db = math.hypot(cur_xy[0] - t.end_xy[0], cur_xy[1] - t.end_xy[1])
                rev = db < da
                oriented.append((t, rev))
                cur_xy = t.start_xy if rev else t.end_xy
            req = DroneRequest(d, start, oriented, None, self.scheduler.contingency_altitude(d, self.c.fleet_ids))
            res = await self.amend([req], PlanPurpose.RESUME, f"resume {d}")
            if res is not None and res.ok:
                self.run_state[d] = DroneRunState.WORKING
                self.paused_info.pop(d, None)
                for t, _ in oriented:
                    self.task_status[t.task_id] = TaskStatus.ASSIGNED
                    self._set_owner(t.task_id, d)
                self.reconciliations[-1]["resumed_at"] = res.committed_at
                self.reconciliations[-1]["resume_effective_from"] = start.time
                self.log("resumed", d, ReasonCode.OK, tasks=[t.task_id for t, _ in oriented])
            else:
                n = self.paused_info.get(d, {}).get("resume_attempts", 0) + 1
                self.log("resume_failed", d, ReasonCode.SCHEDULE_INFEASIBLE, attempt=n)
                if n < 5:
                    # keep holding; housekeeping retries once the blocking condition may have cleared
                    self.paused_info[d] = {**self.paused_info.get(d, {}), "t": self.c.now(), "resume_attempts": n}
                    for t, _ in oriented:
                        if self.task_status.get(t.task_id) == TaskStatus.PENDING:
                            self.task_status[t.task_id] = TaskStatus.ASSIGNED
                    return
                self._revoke_tasks(d, [t.task_id for t, _ in oriented])
                for t, _ in oriented:
                    self.task_status[t.task_id] = TaskStatus.PENDING
                    self.pending_reassign.append(t.task_id)
                    self.suspend_times[t.task_id] = self.c.now()
                self.run_state[d] = DroneRunState.UNAVAILABLE
                if d not in self.recovery_queue:
                    self.recovery_queue.append(d)
        finally:
            self._busy.discard(d)

    def _ownership_resolved_for(self, task_id: str, holder: str) -> bool:
        lm = self.c.leases
        for tid in [task_id, *lm.ancestors(task_id)]:
            for rec in lm.non_terminal(tid):
                if rec.lease.holder != holder or rec.state == LeaseState.REVOKED:
                    return False
        return True

    # ------------------------------------------------------------------ housekeeping
    async def _housekeeping(self) -> None:
        now = self.c.now()
        snap = self.c.snapshot(now)
        # missed starts => partial-start policy
        for d, dl in list(self._start_deadline.items()):
            if d not in self._started and now > dl and self.run_state.get(d) == DroneRunState.WORKING:
                await self._start_failed(d, ReasonCode.START_DEADLINE_MISSED)
        # landed / final-hold detection
        for d in self.c.fleet_ids:
            est = snap.drones.get(d)
            if est is None or est.freshness != Freshness.FRESH:
                continue
            st = self.run_state.get(d)
            latest = self.c.committed.get(d)
            if st == DroneRunState.WORKING and est.agent_status == AgentStatus.PAUSED and d not in self._busy and \
                    latest is not None and est.plan_version == latest.plan_version and \
                    now > latest.effective_from + 2.0:
                # the PAUSED report may have been lost: the reported status is authoritative
                self.run_state[d] = DroneRunState.PAUSED
                st = DroneRunState.PAUSED
                self.paused_info[d] = {"t": now, "task_id": est.active_task_id, "inferred": True}
                self.log("aircraft_paused", d, ReasonCode.LEASE_EXPIRED, task_id=est.active_task_id,
                         inferred_from_state=True)
            if st == DroneRunState.RECOVERING and est.agent_status == AgentStatus.LANDED:
                self.run_state[d] = DroneRunState.LANDED
                self.recovery_table.remove_holder(d)
                for r in self.recoveries:
                    if r["drone"] == d and r.get("landed_at") is None:
                        r["landed_at"] = now
                self.log("landed", d, ReasonCode.OK)
            elif st == DroneRunState.WORKING and est.agent_status == AgentStatus.HOLDING and \
                    not self._unfinished_tasks_of(d) and d not in self.recovery_queue and d not in self._busy:
                self.recovery_queue.append(d)
                self.log("awaiting_recovery", d, ReasonCode.OK)
            elif st == DroneRunState.PAUSED and d not in self._busy and est.agent_status in (
                    AgentStatus.PAUSED, AgentStatus.HOLDING) and now - self.paused_info.get(d, {}).get("t", now) > 4.0:
                # paused while link healthy (e.g. commanded hold) => reconcile and resume
                self._spawn(self._reconcile_and_resume(d, link_restored_at=now))
            elif est.agent_status == AgentStatus.LANDED and st not in TERMINAL_RUN_STATES:
                self.run_state[d] = DroneRunState.LANDED
                self.log("landed", d, ReasonCode.OK, via="own_contingency")
        # reassignment of suspended work once ownership is resolved
        ready = [t for t in self.pending_reassign if self._ownership_resolved(t) and
                 self.task_status.get(t) == TaskStatus.PENDING]
        if ready and now - self._last_reassign_try > 5.0 and not self._lock.locked():
            self._last_reassign_try = now
            self._spawn(self._reassign(ready))
        # recovery sequencing
        if self.recovery_queue and not self._lock.locked():
            d = self.recovery_queue[0]
            if d not in self._busy:
                self._spawn(self._recover(d))
        # completion
        idle_ok = not any(self.task_status.get(t) == TaskStatus.PENDING and self._ownership_resolved(t)
                          for t in self.pending_reassign) or not any(
            self.run_state.get(d) in (DroneRunState.WORKING, DroneRunState.STANDBY) for d in self.c.fleet_ids)
        if all(self.run_state.get(d) in TERMINAL_RUN_STATES or
               (self.run_state.get(d) == DroneRunState.STANDBY and idle_ok) for d in self.c.fleet_ids) and \
                not self._bg:
            self._done = True
            self.log("mission_finished", None, ReasonCode.OK)

    async def _reassign(self, task_ids: list[str]) -> None:
        snap = self.c.snapshot()
        cands = [d for d in self.c.fleet_ids if self.run_state.get(d) in (DroneRunState.WORKING, DroneRunState.STANDBY)
                 and availability(snap.drones.get(d)) == ReasonCode.OK and d not in self._busy]
        if not cands:
            for t in task_ids:
                self.task_reason[t] = ReasonCode.NO_AVAILABLE_AIRCRAFT
            return
        com, starts = self._commitments(snap, cands, at_end_of_tasks=True)
        tasks = [self.tasks[t] for t in task_ids]
        allocator = make_allocator(self.allocator_name, self.cost_model)
        a = allocator.assign(tasks=tasks, fleet=snap, constraints=self.cfg.constraints, commitments=com)
        self.log("reallocation", None, ReasonCode.OK,
                 per_drone={d: [x.task_id for x in v] for d, v in a.per_drone.items() if v},
                 unassigned={k: v.value for k, v in a.unassigned.items()})
        for t, r in a.unassigned.items():
            self.task_reason[t] = r
        reqs = []
        for d in sorted(a.per_drone):
            if not a.per_drone[d]:
                continue
            reqs.append(DroneRequest(d, starts[d], [(self.tasks[x.task_id], x.reversed) for x in a.per_drone[d]],
                                     None, self.scheduler.contingency_altitude(d, self.c.fleet_ids)))
        for req in reqs:
            self._busy.add(req.drone_id)
        try:
            for req in reqs:
                res = await self.amend([req], PlanPurpose.AMENDMENT, f"reassign to {req.drone_id}")
                if res is not None and res.ok:
                    if self.run_state.get(req.drone_id) == DroneRunState.STANDBY:
                        self.run_state[req.drone_id] = DroneRunState.WORKING
                    for t, _ in req.tasks:
                        self.task_status[t.task_id] = TaskStatus.ASSIGNED
                        self._set_owner(t.task_id, req.drone_id)
                        if t.task_id in self.pending_reassign:
                            self.pending_reassign.remove(t.task_id)
                        self.reassignments.append({"task": t.task_id, "to": req.drone_id,
                                                   "suspended_at": self.suspend_times.get(t.task_id),
                                                   "committed_at": res.committed_at,
                                                   "effective_from": req.start.time, "started_at": None})
                        self.log("task_reassigned", req.drone_id, ReasonCode.OK, task_id=t.task_id,
                                 delay_s=round((res.committed_at or 0) - (self.suspend_times.get(t.task_id) or 0), 1))
                        self.c.event(self.c.monitor._ev(self.c.now(), SafetyEventKind.TASK_REASSIGNED,
                                                        Severity.INFO,
                                                        [req.drone_id], ReasonCode.OK, task_id=t.task_id))
        finally:
            for req in reqs:
                self._busy.discard(req.drone_id)

    async def _recover(self, d: str) -> None:
        if d in self._busy:
            return
        self._busy.add(d)
        try:
            snap = self.c.snapshot()
            est = snap.drones.get(d)
            if est is None or est.freshness != Freshness.FRESH or est.position is None or est.boot_id is None:
                return
            if est.agent_status == AgentStatus.LANDED:
                self.recovery_queue.remove(d)
                self.run_state[d] = DroneRunState.LANDED
                return
            if est.agent_status in (AgentStatus.EXECUTING,) and self.run_state.get(d) == DroneRunState.WORKING:
                return  # still flying its plan; wait until it holds
            spot = self.landing_spot[d]
            start = StartState((est.position.x, est.position.y, est.position.z), self.c.now() + self.lead(d), False,
                               est.boot_id)
            req = DroneRequest(d, start, [], EndSpec(EndKind.LAND, (spot[0], spot[1], 0.0)),
                               self.scheduler.contingency_altitude(d, self.c.fleet_ids))
            requested_at = self.c.now()
            res = await self.amend([req], PlanPurpose.RECOVERY, f"recover {d}")
            if res is not None and res.ok:
                if d in self.recovery_queue:
                    self.recovery_queue.remove(d)
                self.run_state[d] = DroneRunState.RECOVERING
                dp = self.c.committed[d]
                rr = [r for r in self.recovery_table.all() if r.holder == d]
                self.recoveries.append({"drone": d, "requested_at": requested_at, "committed_at": res.committed_at,
                                        "slot_start": rr[0].t_start if rr else None,
                                        "slot_end": rr[0].t_end if rr else None,
                                        "planned_landing": dp.trajectory.end_time, "landed_at": None,
                                        "priority": "reserve" if est.battery_state and
                                        est.battery_state.reserve_breached else "normal"})
                self.log("recovery_scheduled", d, ReasonCode.OK, slot_start=round(rr[0].t_start, 1) if rr else None,
                         planned_landing=round(dp.trajectory.end_time, 1))
            else:
                # move to the back of the queue and try again later
                if d in self.recovery_queue:
                    self.recovery_queue.remove(d)
                    self.recovery_queue.append(d)
        finally:
            self._busy.discard(d)

    # ------------------------------------------------------------------ obstruction
    async def report_obstruction(self, zone: ExclusionZone) -> None:
        """Operator-reported obstruction: add an exclusion zone, hold affected
        aircraft, split affected lanes and resume via replanning."""
        self.mission = self.mission.with_exclusion(zone)
        self._rebuild_planners()
        self.log("mission_obstruction", None, ReasonCode.MISSION_OBSTRUCTION, zone=zone.zone_id)
        self.c.event(self.c.monitor._ev(self.c.now(), SafetyEventKind.MISSION_OBSTRUCTION,
                                        Severity.WARNING,
                                        [], ReasonCode.MISSION_OBSTRUCTION, zone=zone.zone_id))
        clearance = self.scheduler.router.clearance
        outset = Polygon2D(vertices=zone.polygon.outset_vertices(clearance))
        # split lanes that cross the zone
        for tid in sorted(self.tasks):
            if self.task_status.get(tid) not in (TaskStatus.PENDING, TaskStatus.ASSIGNED, TaskStatus.ACTIVE):
                continue
            t = self.tasks[tid]
            iv = clip_line_to_polygon(t.start_xy, t.end_xy, outset)
            if not iv:
                continue
            keep = subtract_intervals([(0.0, 1.0)], iv)
            self.task_status[tid] = TaskStatus.SUPERSEDED
            self.task_reason[tid] = ReasonCode.MISSION_OBSTRUCTION
            for j, (a, b) in enumerate(keep):
                if (b - a) * t.length_m < 15:
                    continue
                pa = t.point_at(a * t.length_m)
                pb = t.point_at(b * t.length_m)
                nid = f"{tid}.o{j + 1}"
                self.tasks[nid] = t.model_copy(update={"task_id": nid, "start_xy": pa, "end_xy": pb,
                                                        "parent_task_id": tid, "root_task_id": t.root_id})
                self.c.leases.register_parent(nid, tid)
                self.task_status[nid] = TaskStatus.PENDING
                self.pending_reassign.append(nid)
                self.suspend_times[nid] = self.c.now()
        # hold aircraft whose remaining trajectory now conflicts
        for d, dp in sorted(self.c.committed.items()):
            if self.run_state.get(d) != DroneRunState.WORKING:
                continue
            conf = self.c.checker.static(dp.trajectory, self.c.checker.default_buffers, t_from=self.c.now())
            if any(c.detail == zone.zone_id for c in conf):
                self.log("hold_for_obstruction", d, ReasonCode.MISSION_OBSTRUCTION)
                await self.c.command(d, CommandType.RELEASE_TASK, wait=False)
                for tid in self._unfinished_tasks_of(d):
                    if self.task_status.get(tid) in (TaskStatus.ASSIGNED, TaskStatus.ACTIVE):
                        self.task_status[tid] = TaskStatus.PENDING
                        self.pending_reassign.append(tid)
                        self.suspend_times[tid] = self.c.now()
