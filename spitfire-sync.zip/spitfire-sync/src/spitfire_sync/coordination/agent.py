"""Onboard (companion-computer) coordination agent.

Contract the coordinator relies on (docs/PROTOCOL.md):

1. Execute a committed trajectory only while (a) the plan lease and (b) the
   lease of the current task are valid, using the *latest* bound of the
   coordination-time estimate.  Otherwise hold in place (PAUSED) and never
   resume the old plan; resumption requires a new committed plan.
2. Validate every proposal locally (boot id, epoch, version, continuity,
   kinematics, energy, clock uncertainty, lead time) before acknowledging
   readiness; readiness expires.
3. Start only at the committed time, only if the commit arrived in time.
4. On battery reserve breach: stop the task, release leases, hold, await a
   recovery plan for ``reserve_wait_s``; then fly its own contingency.
5. On coordinator link loss: hold in place for ``lost_link_hold_s``, then the
   configured per-aircraft lost-link action (pre-validated hold point at the
   aircraft's own contingency altitude, land in place, or autopilot RTL).
6. Commands are idempotent by ``command_id``; acknowledgements are re-sent for
   retried commands without re-executing them.
"""

from __future__ import annotations

import math
import zlib
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..adapters.base import AircraftAdapter, NavSample
from ..allocation.energy import EnergyModel
from ..clocks.clock import Clock, TimeEstimate
from ..clocks.sync import ClockSyncEstimator
from ..config import DroneProfile, LostLinkAction, SpitfireConfig
from ..models.commands import CommandAcknowledgement, CommandType, CoordinationCommand
from ..models.geometry import NavigationFrame, Vec3
from ..models.messages import (
    BROADCAST,
    CommandAckPayload,
    CommandPayload,
    CoordinationAbortPayload,
    Envelope,
    HeartbeatPayload,
    LeaseRenewalPayload,
    MessageType,
    PlanAckPayload,
    PlanCommitPayload,
    PlanProposalPayload,
    ProgressStatus,
    StateUpdatePayload,
    TaskCompletePayload,
    TaskLeasePayload,
    TaskProgressPayload,
    TimeSyncRequestPayload,
    TimeSyncResponsePayload,
)
from ..models.state import AgentStatus, BatteryState, DroneState, FlightMode, LinkHealth
from ..models.trajectory import DronePlan, EndBehaviour, Phase, PlanPurpose
from ..reasons import ReasonCode
from ..transport.base import DecodeError, MessageCodec, Transport
from .guard import MessageGuard, Role
from .leases import AgentLeaseTable, plan_lease_task

EXECUTING_STATUSES = {AgentStatus.EXECUTING, AgentStatus.RECOVERING}
UNSYNC_UNCERTAINTY = 1e6


@dataclass
class PendingProposal:
    plan_id: str
    digest: str
    plan: DronePlan
    expires_local: float
    timing_tolerance: float


@dataclass
class AgentRecord:
    """Local event log (agent monotonic time) used by evaluation."""

    events: list[tuple[float, str, dict[str, Any]]] = field(default_factory=list)

    def add(self, t_local: float, kind: str, **data: Any) -> None:
        self.events.append((t_local, kind, data))


class DroneAgent:
    def __init__(self, drone_id: str, clock: Clock, transport: Transport, codec: MessageCodec,
                 config: SpitfireConfig, profile: DroneProfile, adapter: AircraftAdapter, coordinator_id: str,
                 roles: dict[str, Role], tick_s: float = 0.1) -> None:
        self.id = drone_id
        self.clock = clock
        self.tx = transport
        self.codec = codec
        self.cfg = config
        self.profile = profile
        self.adapter = adapter
        self.coordinator_id = coordinator_id
        self.tick_s = tick_s
        self.guard = MessageGuard(drone_id, codec.auth, roles, now=self.coord_now)
        self.sync = ClockSyncEstimator(config.timing.max_relative_drift_ppm)
        self.leases = AgentLeaseTable(config.leases)
        self.energy = EnergyModel(profile.energy)
        self.record = AgentRecord()
        self.status = AgentStatus.IDLE
        self.epoch = 0
        self.plan: DronePlan | None = None
        self.next_plan: DronePlan | None = None
        self.plan_suspended = False
        self.highest_committed_version = 0
        self.pending: dict[str, PendingProposal] = {}
        self.command_results: dict[str, CommandAcknowledgement] = {}
        self.state_seq = 0
        self.msg_seq = 0
        self.last_contact_local: float | None = None
        self.progress: dict[str, float] = {}
        self.progress_xy: dict[str, tuple[float, float]] = {}
        self.completed: set[str] = set()
        self.current_task: str | None = None
        self.energy_factor = 1.0
        self._model_energy_wh = 0.0
        self._start_energy_wh: float | None = None
        self.reserve_breached = False
        self._reserve_since: float | None = None
        self._contingency_stage: str | None = None
        self._contingency_since = 0.0
        self._lost_link_since: float | None = None
        self._next_state = 0.0
        self._next_sync = 0.0
        self._next_progress = 0.0
        self._sync_requests: dict[str, float] = {}
        self._req_counter = 0
        self._running = True
        self._last_nav: NavSample | None = None
        self._last_tick_local: float | None = None
        self.rx_latency_est = 0.0
        # lease_id -> [message type, payload, next send (local), attempts]
        self._unconfirmed: dict[str, list[Any]] = {}

    # ------------------------------------------------------------------ time
    def coord_now(self) -> TimeEstimate:
        mono = self.clock.monotonic()
        e = self.sync.estimate(mono)
        if not e.synchronised:
            return TimeEstimate(mono, UNSYNC_UNCERTAINTY)
        return TimeEstimate(mono + e.offset, e.uncertainty)

    @property
    def boot_id(self) -> str:
        return self.clock.boot_id

    # ------------------------------------------------------------------ io
    async def _send(self, mtype: MessageType, payload: Any, validity: float | None = None) -> None:
        ce = self.coord_now()
        v = validity if validity is not None else self.cfg.coordinator.message_validity_s
        self.msg_seq += 1
        env = Envelope(
            message_id=f"{self.id}/{self.boot_id}/{self.msg_seq}", type=mtype, sender_id=self.id,
            recipient_id=self.coordinator_id, boot_id=self.boot_id, coordinator_epoch=self.epoch,
            mission_version=self.highest_committed_version, sequence_number=self.msg_seq, issued_at=ce.value,
            expires_at=(ce.value + v) if ce.uncertainty < UNSYNC_UNCERTAINTY else float("inf"), payload=payload,
        )
        await self.tx.send(self.coordinator_id, self.codec.encode(env))

    def stop(self) -> None:
        self._running = False

    async def run(self) -> None:
        await self.adapter.connect()
        # de-align control loops of different aircraft (deterministic per id)
        await self.clock.sleep((zlib.crc32(self.id.encode()) % 1000) / 1000.0 * self.tick_s)
        try:
            while self._running:
                for data, rx in self.tx.recv_nowait_timestamped():
                    await self._handle_bytes(data, rx)
                await self._tick()
                await self.clock.sleep(self._next_sleep())
        finally:
            await self.tx.close()

    def _next_sleep(self) -> float:
        """Normally one control tick; shorter when a committed start falls inside
        the next tick, so the start is not quantised to the tick period."""
        if self.next_plan is not None:
            ce = self.coord_now()
            dt = self.next_plan.effective_from - ce.value
            if 0.0 < dt < self.tick_s:
                return dt
        return self.tick_s

    async def _handle_bytes(self, data: bytes, rx_local: float | None = None) -> None:
        try:
            env = self.codec.decode(data)
        except DecodeError:
            self.record.add(self.clock.monotonic(), "decode_error")
            return
        res = self.guard.check(env)
        if not res.accepted:
            # a retried command/commit whose first copy we already processed: re-ack idempotently
            if res.reason == ReasonCode.DUPLICATE_MESSAGE:
                return
            self.record.add(self.clock.monotonic(), "rejected", type=env.type.value, reason=res.reason.value)
            return
        if res.new_epoch:
            await self._on_new_epoch(env.coordinator_epoch)
        self.epoch = max(self.epoch, env.coordinator_epoch)
        self.last_contact_local = self.clock.monotonic()
        p = env.payload
        if isinstance(p, TimeSyncResponsePayload):
            self._on_sync(p, rx_local)
        elif isinstance(p, HeartbeatPayload):
            pass
        elif isinstance(p, PlanProposalPayload):
            await self._on_proposal(env, p)
        elif isinstance(p, PlanCommitPayload):
            await self._on_commit(env, p)
        elif isinstance(p, TaskLeasePayload):
            if p.revoke:
                self.leases.drop(p.lease.lease_id)
                self._unconfirmed.pop(p.lease.lease_id, None)  # also confirms a completion/release report
            else:
                self.leases.add(p.lease, self.boot_id, self.epoch)
        elif isinstance(p, LeaseRenewalPayload):
            # renewals only extend validity; a suspended plan stays suspended regardless
            self.leases.renew(p.lease_id, p.new_expires_at, self.boot_id)
        elif isinstance(p, CommandPayload):
            await self._on_command(p.command)
        elif isinstance(p, CoordinationAbortPayload):
            await self._on_abort(p)

    async def _on_new_epoch(self, epoch: int) -> None:
        """A new coordinator instance.  Leases of the old epoch no longer authorise work."""
        self.record.add(self.clock.monotonic(), "new_epoch", epoch=epoch)
        self.pending.clear()
        if self.status in EXECUTING_STATUSES:
            await self._pause(ReasonCode.STALE_EPOCH)

    # ------------------------------------------------------------------ sync
    async def _send_sync(self) -> None:
        self._req_counter += 1
        rid = f"{self.boot_id}/s{self._req_counter}"
        t1 = self.clock.monotonic()
        self._sync_requests[rid] = t1
        if len(self._sync_requests) > 64:
            self._sync_requests.pop(next(iter(self._sync_requests)))
        await self._send(MessageType.TIME_SYNC_REQUEST, TimeSyncRequestPayload(request_id=rid, t1_local=t1))

    def _on_sync(self, p: TimeSyncResponsePayload, rx_local: float | None = None) -> None:
        t1 = self._sync_requests.pop(p.request_id, None)
        if t1 is None or abs(t1 - p.t1_local) > 1e-9:
            return
        t4 = rx_local if rx_local is not None else self.clock.monotonic()
        upd = self.sync.add_exchange(t1, p.t2_reference, p.t3_reference, t4, p.reference_id)
        self.rx_latency_est = 0.8 * self.rx_latency_est + 0.2 * max(0.0, (t4 - t1) / 2)
        if upd.jump_detected or ReasonCode.CLOCK_REFERENCE_CHANGED in upd.reasons:
            self.record.add(t4, "clock_event", reasons=[r.value for r in upd.reasons])

    # ------------------------------------------------------------------ proposals
    def _expected_position_at(self, t: float, nav: NavSample | None) -> np.ndarray | None:
        if self.next_plan is not None and t >= self.next_plan.effective_from:
            return self.next_plan.trajectory.position_at(t)
        if self.plan is not None and self.status in EXECUTING_STATUSES and not self.plan_suspended:
            return self.plan.trajectory.position_at(t)
        if nav is not None:
            return nav.position.as_array()
        return None

    def validate_plan(self, dp: DronePlan, tolerance: float) -> list[ReasonCode]:
        r: list[ReasonCode] = []
        ce = self.coord_now()
        nav = self.adapter.navigation()
        if dp.expected_boot_id != self.boot_id:
            r.append(ReasonCode.WRONG_BOOT_ID)
        if dp.plan_version <= self.highest_committed_version:
            r.append(ReasonCode.STALE_MISSION_VERSION)
        if dp.drone_id != self.id:
            r.append(ReasonCode.UNAUTHORISED)
        if self.status == AgentStatus.START_FAILED:
            r.append(ReasonCode.AIRCRAFT_NOT_AVAILABLE)
        if ce.uncertainty > tolerance:
            r.append(ReasonCode.CLOCK_UNCERTAINTY_EXCEEDS_TOLERANCE if ce.uncertainty < UNSYNC_UNCERTAINTY
                     else ReasonCode.CLOCK_UNSYNCHRONISED)
        if dp.effective_from - ce.latest < 0.5:
            r.append(ReasonCode.START_TOO_SOON)
        # kinematic feasibility against this aircraft's own limits
        T, P = dp.trajectory.arrays()
        if len(T) > 1:
            dt = np.diff(T)
            ok = dt > 1e-6
            v = np.diff(P, axis=0)[ok] / dt[ok][:, None]
            lim = self.profile.limits
            if (np.linalg.norm(v[:, :2], axis=1).max(initial=0) > lim.max_speed_m_s * 1.02 or
                    v[:, 2].max(initial=0) > lim.max_climb_m_s * 1.05 or
                    -v[:, 2].min(initial=0) > lim.max_descent_m_s * 1.05):
                r.append(ReasonCode.KINEMATICALLY_INFEASIBLE)
        # continuity with where the aircraft will be at effective_from
        exp = self._expected_position_at(dp.effective_from, nav)
        if exp is not None:
            start = dp.trajectory.position_at(dp.effective_from)
            unc = nav.position_uncertainty_m if nav else 5.0
            if float(np.linalg.norm(start - exp)) > self.cfg.separation.tracking_tolerance_m + 2 * unc + 4.0:
                r.append(ReasonCode.PLAN_DISCONTINUOUS if self.status != AgentStatus.IDLE
                         else ReasonCode.NOT_AT_PLAN_START)
        # energy (own model with learned correction); recovery plans need no reserve
        bat = self.adapter.battery()
        if bat is not None:
            need = self.energy.trajectory_energy_wh(dp.trajectory, t_from=dp.effective_from) * self.energy_factor
            reserve = 0.0 if dp.purpose == PlanPurpose.RECOVERY else \
                self.cfg.constraints.reserve_fraction * self.profile.energy.capacity_wh
            if need * (1.0 if dp.purpose == PlanPurpose.RECOVERY else self.profile.energy.planning_margin) + reserve \
                    > bat.remaining_energy_wh:
                r.append(ReasonCode.INSUFFICIENT_ENERGY)
        return r

    async def _on_proposal(self, env: Envelope, p: PlanProposalPayload) -> None:
        reasons = self.validate_plan(p.drone_plan, p.timing_tolerance_s)
        if p.plan_digest != p.drone_plan.digest(env.mission_version, env.coordinator_epoch):
            reasons.append(ReasonCode.ACK_BINDING_MISMATCH)
        ce = self.coord_now()
        ready = not reasons
        validity = self.cfg.timing.readiness_validity_s
        if ready:
            self.pending[p.plan_id] = PendingProposal(p.plan_id, p.plan_digest, p.drone_plan,
                                                      self.clock.monotonic() + validity, p.timing_tolerance_s)
            if self.status == AgentStatus.IDLE:
                self.status = AgentStatus.READY
        self.record.add(self.clock.monotonic(), "plan_ack", plan_id=p.plan_id, ready=ready,
                        reasons=[x.value for x in reasons])
        await self._send(MessageType.PLAN_ACK, PlanAckPayload(
            plan_id=p.plan_id, plan_digest=p.plan_digest, plan_version=p.drone_plan.plan_version, ready=ready,
            reasons=reasons or [ReasonCode.READY], readiness_expires_at=ce.value + validity - ce.uncertainty,
            clock_uncertainty_s=min(ce.uncertainty, 1e6), drone_boot_id=self.boot_id))

    async def _ack(self, command_id: str, accepted: bool, reason: ReasonCode, duplicate: bool = False,
                   details: dict[str, Any] | None = None) -> CommandAcknowledgement:
        ack = CommandAcknowledgement(command_id=command_id, drone_id=self.id, boot_id=self.boot_id,
                                     accepted=accepted, reason=reason, executed_at=self.coord_now().value,
                                     duplicate=duplicate, details=details or {})
        await self._send(MessageType.COMMAND_ACK, CommandAckPayload(ack=ack))
        return ack

    async def _on_commit(self, env: Envelope, p: PlanCommitPayload) -> None:
        prev = self.command_results.get(p.commit_id)
        if prev is not None:
            await self._send(MessageType.COMMAND_ACK, CommandAckPayload(ack=prev.model_copy(update={"duplicate": True})))
            return
        pend = self.pending.get(p.plan_id)
        ce = self.coord_now()
        reason = ReasonCode.COMMITTED
        if pend is None or pend.digest != p.plan_digest or pend.plan.plan_version != p.plan_version:
            reason = ReasonCode.ACK_BINDING_MISMATCH
        elif self.clock.monotonic() > pend.expires_local:
            reason = ReasonCode.READINESS_EXPIRED
        elif pend.plan.purpose == PlanPurpose.INITIAL and ce.earliest > p.effective_from + pend.timing_tolerance:
            reason = ReasonCode.START_DEADLINE_MISSED
        elif pend.plan.purpose != PlanPurpose.INITIAL and ce.latest > p.effective_from - 0.2:
            reason = ReasonCode.START_DEADLINE_MISSED
        else:
            for lz in p.leases:
                rc = self.leases.add(lz, self.boot_id, self.epoch)
                if rc != ReasonCode.OK:
                    reason = rc
                    break
        accepted = reason == ReasonCode.COMMITTED
        if accepted and pend is not None:
            self.next_plan = pend.plan
            self.highest_committed_version = max(self.highest_committed_version, pend.plan.plan_version)
            if self.status in (AgentStatus.IDLE, AgentStatus.READY):
                self.status = AgentStatus.COMMITTED
            self.pending.pop(p.plan_id, None)
        self.record.add(self.clock.monotonic(), "commit", plan_id=p.plan_id, accepted=accepted, reason=reason.value)
        ack = await self._ack(p.commit_id, accepted, reason)
        # cache final outcomes only: a commit that overtook its proposal (reordering) must be
        # re-evaluated when the coordinator retries it
        if accepted or reason in (ReasonCode.START_DEADLINE_MISSED, ReasonCode.READINESS_EXPIRED):
            self.command_results[p.commit_id] = ack
        if not accepted and reason == ReasonCode.START_DEADLINE_MISSED:
            await self._send(MessageType.TASK_PROGRESS, TaskProgressPayload(
                task_id=None, lease_id=None, plan_version=p.plan_version, status=ProgressStatus.START_MISSED,
                at_time=ce.value, reason=reason))

    # ------------------------------------------------------------------ commands
    def reconcile_report(self) -> dict[str, Any]:
        nav = self.adapter.navigation()
        return {
            "status": self.status.value,
            "plan_version": self.plan.plan_version if self.plan else None,
            "next_plan_version": self.next_plan.plan_version if self.next_plan else None,
            "plan_suspended": self.plan_suspended,
            "leases": [lz.lease_id for lz in self.leases.all()],
            "executed_commands": sorted(k for k, v in self.command_results.items() if v.accepted),
            "progress": dict(self.progress),
            "completed": sorted(self.completed),
            "position": list(nav.position.as_array()) if nav else None,
            "reserve_breached": self.reserve_breached,
        }

    async def _on_command(self, c: CoordinationCommand) -> None:
        prev = self.command_results.get(c.command_id)
        if prev is not None:
            await self._send(MessageType.COMMAND_ACK, CommandAckPayload(ack=prev.model_copy(update={"duplicate": True})))
            return
        if c.target_drone_id != self.id or c.target_boot_id != self.boot_id:
            ack = await self._ack(c.command_id, False, ReasonCode.WRONG_BOOT_ID)
            self.command_results[c.command_id] = ack
            return
        details: dict[str, Any] = {}
        accepted, reason = True, ReasonCode.COMMAND_EXECUTED
        if c.command_type == CommandType.HOLD_POSITION:
            await self._pause(ReasonCode.COMMAND_EXECUTED, commanded=True)
        elif c.command_type == CommandType.GOTO_HOLD:
            if c.hold_point is None or c.hold_point.frame != NavigationFrame.ENU:
                accepted, reason = False, ReasonCode.FRAME_MISMATCH
            else:
                await self._pause(ReasonCode.COMMAND_EXECUTED, commanded=True)
                await self.adapter.goto(c.hold_point, self.profile.limits.transit_speed_m_s)
                self.status = AgentStatus.HOLDING
        elif c.command_type in (CommandType.RELEASE_TASK, CommandType.ABANDON_TASK):
            tid = c.params.get("task_id")
            await self._release_tasks(ReasonCode.LEASE_RELEASED, only=tid)
            if self.status in EXECUTING_STATUSES and (tid is None or tid == self.current_task):
                await self._pause(ReasonCode.LEASE_RELEASED, commanded=True)
            details["progress"] = dict(self.progress)
        elif c.command_type == CommandType.RECONCILE:
            details = self.reconcile_report()
        else:
            accepted, reason = False, ReasonCode.COMMAND_REJECTED
        ack = await self._ack(c.command_id, accepted, reason, details=details)
        self.command_results[c.command_id] = ack
        self.record.add(self.clock.monotonic(), "command", type=c.command_type.value, accepted=accepted)

    async def _on_abort(self, p: CoordinationAbortPayload) -> None:
        if p.abort_id in self.command_results:
            return
        self.record.add(self.clock.monotonic(), "coordination_abort", reason=p.reason.value)
        await self._release_tasks(ReasonCode.COORDINATION_ABORTED)
        await self._pause(ReasonCode.COORDINATION_ABORTED, commanded=True)
        self._begin_contingency("abort")
        self.command_results[p.abort_id] = await self._ack(p.abort_id, True, ReasonCode.COORDINATION_ABORTED)

    # ------------------------------------------------------------------ execution
    async def _pause(self, reason: ReasonCode, commanded: bool = False) -> None:
        was_exec = self.status in EXECUTING_STATUSES
        self.plan_suspended = True
        self.adapter.set_payload_active(False)
        if self.status not in (AgentStatus.LANDED, AgentStatus.CONTINGENCY):
            await self.adapter.hold()
        if was_exec or self.status in (AgentStatus.COMMITTED,):
            self.status = AgentStatus.PAUSED
            self.next_plan = None
            ce = self.coord_now()
            t = self.current_task
            self.record.add(self.clock.monotonic(), "paused", reason=reason.value, task=t)
            await self._send(MessageType.TASK_PROGRESS, TaskProgressPayload(
                task_id=t, lease_id=(self.leases.for_task(t).lease_id if t and self.leases.for_task(t) else None),
                plan_version=self.plan.plan_version if self.plan else None, status=ProgressStatus.PAUSED,
                progress_m=self.progress.get(t, 0.0) if t else 0.0, at_time=ce.value, reason=reason,
                progress_xy=self.progress_xy.get(t) if t else None))

    async def _release_tasks(self, reason: ReasonCode, only: str | None = None) -> None:
        ce = self.coord_now()
        for lz in self.leases.all():
            if lz.task_id.startswith("__plan__"):
                continue
            if only is not None and lz.task_id != only:
                continue
            self.leases.drop(lz.lease_id)
            payload = TaskProgressPayload(
                task_id=lz.task_id, lease_id=lz.lease_id, plan_version=lz.plan_version,
                status=ProgressStatus.SUSPENDED, progress_m=self.progress.get(lz.task_id, 0.0), at_time=ce.value,
                released=True, reason=reason, progress_xy=self.progress_xy.get(lz.task_id))
            await self._send(MessageType.TASK_PROGRESS, payload)
            self._unconfirmed[lz.lease_id] = [MessageType.TASK_PROGRESS, payload, self.clock.monotonic() + 1.5, 1]
        self.adapter.set_payload_active(False)

    def _authorised(self, ce: TimeEstimate, task: str | None) -> tuple[bool, ReasonCode]:
        ok, r = self.leases.valid(plan_lease_task(self.id), ce.latest, self.boot_id, self.epoch)
        if not ok:
            return ok, r
        if task is not None:
            return self.leases.valid(task, ce.latest, self.boot_id, self.epoch)
        return True, ReasonCode.OK

    async def _activate(self, ce: TimeEstimate, nav: NavSample | None) -> None:
        dp = self.next_plan
        assert dp is not None
        self.next_plan = None
        if dp.purpose == PlanPurpose.INITIAL or self.status in (AgentStatus.COMMITTED, AgentStatus.READY):
            if ce.uncertainty > self.cfg.timing.start_tolerance_s:
                await self._start_failed(dp, ReasonCode.CLOCK_UNCERTAINTY_EXCEEDS_TOLERANCE)
                return
            if self.adapter.flight_mode() == FlightMode.ON_GROUND:
                ok = await self.adapter.arm()
                if not ok:
                    await self._start_failed(dp, ReasonCode.START_FAILED)
                    return
        else:
            start = dp.trajectory.position_at(ce.value)
            if nav is not None and float(np.linalg.norm(start - nav.position.as_array())) > (
                    self.cfg.separation.tracking_tolerance_m + 2 * nav.position_uncertainty_m + 6.0):
                await self._start_failed(dp, ReasonCode.PLAN_DISCONTINUOUS)
                return
        self.plan = dp
        self.plan_suspended = False
        self.current_task = None  # the previous plan's task was completed, released or superseded
        self._contingency_stage = None
        self._lost_link_since = None
        self.status = AgentStatus.RECOVERING if dp.purpose == PlanPurpose.RECOVERY else AgentStatus.EXECUTING
        self.record.add(self.clock.monotonic(), "plan_started", plan_version=dp.plan_version,
                        purpose=dp.purpose.value, effective_from=dp.effective_from, start_estimate=ce.value,
                        start_uncertainty=ce.uncertainty)
        await self._send(MessageType.TASK_PROGRESS, TaskProgressPayload(
            task_id=None, lease_id=None, plan_version=dp.plan_version, status=ProgressStatus.STARTED,
            at_time=ce.value, actual_start_time=ce.value))

    async def _start_failed(self, dp: DronePlan, reason: ReasonCode) -> None:
        self.status = AgentStatus.START_FAILED if dp.purpose == PlanPurpose.INITIAL else AgentStatus.PAUSED
        self.plan_suspended = True
        self.record.add(self.clock.monotonic(), "start_failed", reason=reason.value, plan_version=dp.plan_version)
        await self._release_tasks(reason)
        await self._send(MessageType.TASK_PROGRESS, TaskProgressPayload(
            task_id=None, lease_id=None, plan_version=dp.plan_version, status=ProgressStatus.START_FAILED,
            at_time=self.coord_now().value, reason=reason))

    def _update_progress(self, task: str, nav: NavSample) -> float:
        assert self.plan is not None
        w = self.plan.trajectory.task_window(task)
        if w is None:
            return 0.0
        a = self.plan.trajectory.position_at(w[0])[:2]
        b = self.plan.trajectory.position_at(w[1] - 1e-6)[:2]
        ab = b - a
        L = float(np.linalg.norm(ab))
        if L < 1e-6:
            return 0.0
        s = float(np.clip(np.dot(nav.position.as_array()[:2] - a, ab) / L, 0.0, L))
        if s >= self.progress.get(task, 0.0):
            self.progress[task] = s
            q = a + ab * (s / L)
            self.progress_xy[task] = (float(q[0]), float(q[1]))
        return self.progress[task]

    async def _execute(self, ce: TimeEstimate, nav: NavSample | None) -> None:
        assert self.plan is not None
        traj = self.plan.trajectory
        t = ce.value
        task = traj.task_at(t)
        ok, why = self._authorised(ce, task)
        if not ok:
            if task is not None:
                self.current_task = task
            self.record.add(self.clock.monotonic(), "lease_lapsed", reason=why.value, task=task)
            await self._pause(why)
            return
        # task bookkeeping
        if self.current_task and self.current_task != task and self.current_task not in self.completed:
            await self._complete(self.current_task, ce)
        self.current_task = task
        phase = traj.phase_at(t)
        if task is not None and nav is not None:
            self._update_progress(task, nav)
        self.adapter.set_payload_active(phase == Phase.SURVEY and task is not None, task)
        if t >= traj.end_time:
            if self.current_task and self.current_task not in self.completed:
                await self._complete(self.current_task, ce)
            self.current_task = None
            if traj.end_behaviour == EndBehaviour.LANDED:
                if self.adapter.flight_mode() == FlightMode.ON_GROUND:
                    self.status = AgentStatus.LANDED
                    self.record.add(self.clock.monotonic(), "landed")
                    self.leases.drop_all()
                else:
                    p = traj.position_at(traj.end_time)
                    await self.adapter.set_setpoint(Vec3.enu(p[0], p[1], -0.5), Vec3.enu(0, 0, -0.5))
            else:
                await self.adapter.hold()
                self.status = AgentStatus.HOLDING
                self.record.add(self.clock.monotonic(), "at_hold")
            return
        lead = self.tick_s
        p = traj.position_at(t + lead)
        v = traj.velocity_at(t + lead)
        await self.adapter.set_setpoint(Vec3.enu(*p), Vec3.enu(*v))

    async def _complete(self, task: str, ce: TimeEstimate) -> None:
        lz = self.leases.for_task(task)
        self.completed.add(task)
        if lz is None:
            return
        self.leases.drop(lz.lease_id)
        payload = TaskCompletePayload(task_id=task, lease_id=lz.lease_id, completed_at=ce.value,
                                      progress_m=self.progress.get(task, 0.0))
        await self._send(MessageType.TASK_COMPLETE, payload)
        self._unconfirmed[lz.lease_id] = [MessageType.TASK_COMPLETE, payload, self.clock.monotonic() + 1.5, 1]

    # ------------------------------------------------------------------ safety monitors
    def _energy_learning(self, nav: NavSample | None, dt: float, energy_wh: float) -> None:
        if nav is None or self.adapter.flight_mode() == FlightMode.ON_GROUND:
            return
        if self._start_energy_wh is None:
            self._start_energy_wh = energy_wh
        v = nav.velocity.as_array()
        self._model_energy_wh += self.energy.power_w(float(np.linalg.norm(v[:2])), float(v[2])) * dt / 3600.0
        used = self._start_energy_wh - energy_wh
        if self._model_energy_wh > 1.5:
            self.energy_factor = float(np.clip(used / self._model_energy_wh, 0.8, 3.0))

    def required_to_recover_wh(self, nav: NavSample) -> float:
        p = nav.position.as_array()
        target = self.plan.contingency.land_position if self.plan else Vec3.enu(p[0], p[1], 0)
        cruise = self.plan.contingency.contingency_altitude_m if self.plan else 60.0
        return self.energy.recover_energy_wh(p[0], p[1], p[2], (target.x, target.y), cruise,
                                             self.profile.limits.transit_speed_m_s) * self.energy_factor

    async def _check_battery(self, nav: NavSample | None) -> None:
        bat = self.adapter.battery()
        if bat is None or nav is None or self.adapter.flight_mode() == FlightMode.ON_GROUND:
            return
        if self.reserve_breached or self.status in (AgentStatus.LANDED, AgentStatus.RECOVERING):
            return
        need = self.required_to_recover_wh(nav)
        reserve = self.cfg.constraints.reserve_fraction * self.profile.energy.capacity_wh
        if bat.remaining_energy_wh < need + reserve:
            self.reserve_breached = True
            self._reserve_since = self.clock.monotonic()
            self.record.add(self._reserve_since, "reserve_breach", remaining_wh=bat.remaining_energy_wh,
                            needed_wh=need, factor=self.energy_factor)
            was_exec = self.status in EXECUTING_STATUSES
            await self._release_tasks(ReasonCode.BATTERY_RESERVE_BREACH)
            if was_exec:
                await self._pause(ReasonCode.BATTERY_RESERVE_BREACH)
            self.status = AgentStatus.RESERVE_HOLD

    def _begin_contingency(self, why: str) -> None:
        self._contingency_stage = "climb"
        self._contingency_since = self.clock.monotonic()
        self.status = AgentStatus.CONTINGENCY
        self.record.add(self._contingency_since, "contingency", why=why)

    async def _run_contingency(self, nav: NavSample | None) -> None:
        if nav is None:
            return
        c = self.profile.contingency
        action = c.lost_link_action
        p = nav.position.as_array()
        hold = self.plan.contingency.hold_point if self.plan else Vec3.enu(p[0], p[1], max(p[2], 30.0))
        land = self.plan.contingency.land_position if self.plan else Vec3.enu(p[0], p[1], 0.0)
        alt = self.plan.contingency.contingency_altitude_m if self.plan else max(p[2], 30.0)
        st = self._contingency_stage
        mono = self.clock.monotonic()
        if self.adapter.flight_mode() == FlightMode.ON_GROUND:
            if st != "landed":
                self._contingency_stage = "landed"
                self.status = AgentStatus.LANDED
                self.record.add(mono, "landed", via="contingency")
            return
        if action == LostLinkAction.LAND_IN_PLACE and st == "climb":
            await self.adapter.land()
            self._contingency_stage = "landing"
            return
        if action == LostLinkAction.AUTOPILOT_RTL and st == "climb":
            await self.adapter.return_to_launch()
            self._contingency_stage = "landing"
            return
        speed = self.profile.limits.transit_speed_m_s
        if st == "climb":
            await self.adapter.goto(Vec3.enu(p[0], p[1], alt), speed)
            if abs(p[2] - alt) < 1.5:
                self._contingency_stage = "return" if self.reserve_breached else "transfer"
        elif st == "transfer":
            await self.adapter.goto(hold, speed)
            if np.linalg.norm(p - hold.as_array()) < 3.0:
                self._contingency_stage, self._contingency_since = "hold", mono
        elif st == "hold":
            if mono - self._contingency_since > c.contingency_hold_timeout_s or self.reserve_breached:
                self._contingency_stage = "return"
        elif st == "return":
            tgt = Vec3.enu(land.x, land.y, alt)
            await self.adapter.goto(tgt, speed)
            if np.linalg.norm(p[:2] - tgt.as_array()[:2]) < 2.0:
                await self.adapter.land()
                self._contingency_stage = "landing"

    # ------------------------------------------------------------------ tick
    def _state(self, nav: NavSample, ce_obs: TimeEstimate) -> DroneState:
        bat = self.adapter.battery()
        need = self.required_to_recover_wh(nav)
        contact = (self.clock.monotonic() - self.last_contact_local) if self.last_contact_local is not None else 1e6
        self.state_seq += 1
        return DroneState(
            drone_id=self.id, boot_id=self.boot_id, sequence_number=self.state_seq,
            observation_time=ce_obs.value, observation_time_uncertainty=ce_obs.uncertainty,
            position=nav.position, velocity=nav.velocity, position_uncertainty=nav.position_uncertainty_m,
            navigation_frame=NavigationFrame.ENU,
            battery_state=BatteryState(
                remaining_fraction=bat.remaining_fraction if bat else 0.0,
                remaining_energy_wh=bat.remaining_energy_wh if bat else 0.0, required_to_recover_wh=need,
                reserve_fraction=self.cfg.constraints.reserve_fraction, reserve_breached=self.reserve_breached,
                voltage_v=bat.voltage_v if bat else None),
            flight_mode=self.adapter.flight_mode(), armed_status=self.adapter.armed(),
            link_health=LinkHealth(quality=1.0 if contact < 2 else max(0.0, 1.0 - contact / 20.0),
                                   estimated_latency_s=self.rx_latency_est, coordinator_contact_age_s=min(contact, 1e6)),
            active_task_id=self.current_task,
            active_lease_id=(self.leases.for_task(self.current_task).lease_id
                             if self.current_task and self.leases.for_task(self.current_task) else None),
            plan_version=self.plan.plan_version if self.plan else None, agent_status=self.status,
            task_progress_m=self.progress.get(self.current_task) if self.current_task else None,
            clock_synchronised=ce_obs.uncertainty < UNSYNC_UNCERTAINTY,
        )

    async def _tick(self) -> None:
        mono = self.clock.monotonic()
        dt = 0.0 if self._last_tick_local is None else mono - self._last_tick_local
        self._last_tick_local = mono
        ce = self.coord_now()
        nav = self.adapter.navigation()
        self._last_nav = nav
        bat = self.adapter.battery()
        if bat is not None:
            self._energy_learning(nav, dt, bat.remaining_energy_wh)
        # time sync (faster until converged)
        if mono >= self._next_sync:
            await self._send_sync()
            n = self.sync.estimate(mono).samples
            self._next_sync = mono + (0.3 if n < 4 else self.cfg.timing.sync_interval_s)
        await self._check_battery(nav)
        for lid in sorted(self._unconfirmed):
            item = self._unconfirmed[lid]
            if mono >= item[2]:
                if item[3] >= 20:
                    self._unconfirmed.pop(lid)
                    continue
                item[2], item[3] = mono + 1.5, item[3] + 1
                await self._send(item[0], item[1])
        # plan activation / execution
        if self.next_plan is not None and ce.value >= self.next_plan.effective_from:
            await self._activate(ce, nav)
        if self.status in EXECUTING_STATUSES and self.plan is not None and not self.plan_suspended:
            await self._execute(ce, nav)
        # periodic progress
        if self.status in EXECUTING_STATUSES and self.current_task and mono >= self._next_progress:
            self._next_progress = mono + 2.0
            lz = self.leases.for_task(self.current_task)
            await self._send(MessageType.TASK_PROGRESS, TaskProgressPayload(
                task_id=self.current_task, lease_id=lz.lease_id if lz else None,
                plan_version=self.plan.plan_version if self.plan else None, status=ProgressStatus.IN_PROGRESS,
                progress_m=self.progress.get(self.current_task, 0.0), at_time=ce.value,
                progress_xy=self.progress_xy.get(self.current_task)))
        # coordinator link supervision (degraded mode)
        contact_age = (mono - self.last_contact_local) if self.last_contact_local is not None else 0.0
        cc = self.profile.contingency
        airborne = self.adapter.flight_mode() not in (FlightMode.ON_GROUND,)
        if airborne and contact_age > cc.lost_link_timeout_s and self.status != AgentStatus.CONTINGENCY:
            if self._lost_link_since is None:
                self._lost_link_since = mono
                self.record.add(mono, "coordinator_link_lost")
                if self.status in EXECUTING_STATUSES:
                    await self._pause(ReasonCode.COORDINATOR_LINK_LOST)
            elif mono - self._lost_link_since > cc.lost_link_hold_s:
                self._begin_contingency("lost_link")
        elif contact_age <= cc.lost_link_timeout_s and self._lost_link_since is not None and \
                self.status != AgentStatus.CONTINGENCY:
            self._lost_link_since = None
        if self.reserve_breached and self.status == AgentStatus.RESERVE_HOLD and self._reserve_since is not None \
                and mono - self._reserve_since > cc.reserve_wait_s and self.next_plan is None:
            self._begin_contingency("reserve_wait_timeout")
        if self.status == AgentStatus.CONTINGENCY:
            await self._run_contingency(nav)
        # telemetry
        if nav is not None and mono >= self._next_state and ce.uncertainty < UNSYNC_UNCERTAINTY:
            self._next_state = mono + 1.0 / self.cfg.telemetry.rate_hz
            obs = self.sync.to_reference(nav.local_time)
            await self._send(MessageType.STATE_UPDATE, StateUpdatePayload(state=self._state(nav, obs)))
