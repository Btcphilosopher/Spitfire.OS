"""Expiring task leases.

Invariant (coordinator side): for every task at most one lease is
*non-terminal* (OFFERED, ACTIVE or REVOKED).  A task derived from another
(remainder) can only be leased once every ancestor's leases are terminal, i.e.
previous ownership has been resolved.  A REVOKED lease is still treated as
possibly active until ``expires_at + expiry_margin + clock uncertainty``,
because the holder may not have received the revocation.

Aircraft side: a lease authorises work only while it is bound to the
aircraft's current boot id and the current coordinator epoch, and only until
``expires_at - onboard_safety_margin - own clock uncertainty``.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from ..config import LeaseConfig
from ..models.commands import TERMINAL_LEASE_STATES, LeaseState, TaskLease
from ..reasons import ReasonCode

PLAN_LEASE_PREFIX = "__plan__/"


def plan_lease_task(drone_id: str) -> str:
    return f"{PLAN_LEASE_PREFIX}{drone_id}"


@dataclass
class LeaseRecord:
    lease: TaskLease
    state: LeaseState
    history: list[tuple[float, LeaseState]] = field(default_factory=list)

    def set(self, t: float, st: LeaseState) -> None:
        self.state = st
        self.history.append((t, st))


class LeaseManager:
    def __init__(self, cfg: LeaseConfig, epoch: int) -> None:
        self.cfg = cfg
        self.epoch = epoch
        self._records: dict[str, LeaseRecord] = {}
        self._by_task: dict[str, list[str]] = {}
        self._parents: dict[str, str] = {}
        self._counter = 0
        self.max_clock_uncertainty = 0.0

    def register_parent(self, task_id: str, parent_id: str) -> None:
        self._parents[task_id] = parent_id

    def ancestors(self, task_id: str) -> list[str]:
        out = []
        cur = self._parents.get(task_id)
        while cur is not None and cur not in out:
            out.append(cur)
            cur = self._parents.get(cur)
        return out

    def non_terminal(self, task_id: str) -> list[LeaseRecord]:
        return [self._records[i] for i in self._by_task.get(task_id, []) if
                self._records[i].state not in TERMINAL_LEASE_STATES]

    def can_grant(self, task_id: str, holder: str) -> tuple[bool, ReasonCode]:
        for rec in self.non_terminal(task_id):
            if rec.lease.holder != holder or rec.state == LeaseState.REVOKED:
                return False, ReasonCode.LEASE_ACTIVE_ELSEWHERE
        for anc in self.ancestors(task_id):
            for rec in self.non_terminal(anc):
                # an ancestor still (possibly) owned by someone else, or revoked and not yet expired
                if rec.lease.holder != holder or rec.state == LeaseState.REVOKED:
                    return False, ReasonCode.PARENT_OWNERSHIP_UNRESOLVED
        return True, ReasonCode.OK

    def grant(self, task_id: str, holder: str, holder_boot: str, plan_version: int, now: float) -> TaskLease:
        ok, reason = self.can_grant(task_id, holder)
        if not ok:
            raise PermissionError(f"cannot lease {task_id} to {holder}: {reason}")
        # a holder re-leasing its own task (or a remainder of its own task) supersedes its previous lease
        for tid in [task_id, *self.ancestors(task_id)]:
            for rec in self.non_terminal(tid):
                rec.set(now, LeaseState.RELEASED)
        self._counter += 1
        lease = TaskLease(lease_id=f"e{self.epoch}-L{self._counter:05d}", task_id=task_id, holder=holder,
                          holder_boot_id=holder_boot, coordinator_epoch=self.epoch, plan_version=plan_version,
                          issued_at=now, expires_at=now + self.cfg.duration_s)
        rec = LeaseRecord(lease, LeaseState.OFFERED, [(now, LeaseState.OFFERED)])
        self._records[lease.lease_id] = rec
        self._by_task.setdefault(task_id, []).append(lease.lease_id)
        return lease

    def get(self, lease_id: str) -> LeaseRecord | None:
        return self._records.get(lease_id)

    def confirm(self, lease_id: str, now: float) -> None:
        rec = self._records.get(lease_id)
        if rec and rec.state == LeaseState.OFFERED:
            rec.set(now, LeaseState.ACTIVE)

    def renew(self, lease_id: str, now: float) -> TaskLease | None:
        rec = self._records.get(lease_id)
        if rec is None or rec.state not in (LeaseState.OFFERED, LeaseState.ACTIVE):
            return None
        new = rec.lease.model_copy(update={"expires_at": now + self.cfg.duration_s})
        rec.lease = new
        return new

    def release(self, lease_id: str, now: float) -> bool:
        """Authoritative release by the holder (or task completion)."""
        rec = self._records.get(lease_id)
        if rec is None or rec.state in TERMINAL_LEASE_STATES:
            return False
        rec.set(now, LeaseState.RELEASED)
        return True

    def revoke(self, lease_id: str, now: float) -> None:
        rec = self._records.get(lease_id)
        if rec and rec.state in (LeaseState.OFFERED, LeaseState.ACTIVE):
            rec.set(now, LeaseState.REVOKED)

    def expiry_deadline(self, rec: LeaseRecord) -> float:
        return rec.lease.expires_at + self.cfg.expiry_margin_s + self.max_clock_uncertainty

    def tick(self, now: float) -> list[LeaseRecord]:
        expired = []
        for lid in sorted(self._records):
            rec = self._records[lid]
            if rec.state not in TERMINAL_LEASE_STATES and now > self.expiry_deadline(rec):
                rec.set(now, LeaseState.EXPIRED)
                expired.append(rec)
        return expired

    def for_holder(self, holder: str, include_terminal: bool = False) -> list[LeaseRecord]:
        return [r for _, r in sorted(self._records.items()) if r.lease.holder == holder and
                (include_terminal or r.state not in TERMINAL_LEASE_STATES)]

    def renewable(self) -> list[LeaseRecord]:
        return [r for _, r in sorted(self._records.items()) if r.state in (LeaseState.OFFERED, LeaseState.ACTIVE)]

    def owner(self, task_id: str) -> str | None:
        nt = [r for r in self.non_terminal(task_id) if r.state != LeaseState.REVOKED]
        return nt[-1].lease.holder if nt else None

    def all_records(self) -> list[LeaseRecord]:
        return [self._records[k] for k in sorted(self._records)]


class AgentLeaseTable:
    def __init__(self, cfg: LeaseConfig) -> None:
        self.cfg = cfg
        self._leases: dict[str, TaskLease] = {}

    def add(self, lease: TaskLease, boot_id: str, epoch: int) -> ReasonCode:
        if lease.holder_boot_id != boot_id:
            return ReasonCode.WRONG_BOOT_ID
        if lease.coordinator_epoch < epoch:
            return ReasonCode.STALE_EPOCH
        cur = self._leases.get(lease.lease_id)
        if cur is None or lease.expires_at > cur.expires_at:
            self._leases[lease.lease_id] = lease
        return ReasonCode.OK

    def renew(self, lease_id: str, new_expiry: float, boot_id: str) -> ReasonCode:
        cur = self._leases.get(lease_id)
        if cur is None:
            return ReasonCode.LEASE_UNKNOWN
        if cur.holder_boot_id != boot_id:
            return ReasonCode.WRONG_BOOT_ID
        if new_expiry > cur.expires_at:
            self._leases[lease_id] = cur.model_copy(update={"expires_at": new_expiry})
        return ReasonCode.OK

    def drop(self, lease_id: str) -> None:
        self._leases.pop(lease_id, None)

    def drop_all(self) -> list[TaskLease]:
        out = [self._leases[k] for k in sorted(self._leases)]
        self._leases.clear()
        return out

    def for_task(self, task_id: str) -> TaskLease | None:
        c = [lz for lz in self._leases.values() if lz.task_id == task_id]
        return max(c, key=lambda lz: lz.expires_at) if c else None

    def valid(self, task_id: str, now_latest: float, boot_id: str, epoch: int) -> tuple[bool, ReasonCode]:
        lz = self.for_task(task_id)
        if lz is None:
            return False, ReasonCode.LEASE_UNKNOWN
        if lz.holder_boot_id != boot_id:
            return False, ReasonCode.WRONG_BOOT_ID
        if lz.coordinator_epoch != epoch:
            return False, ReasonCode.STALE_EPOCH
        if now_latest > lz.expires_at - self.cfg.onboard_safety_margin_s:
            return False, ReasonCode.LEASE_EXPIRED
        return True, ReasonCode.OK

    def all(self) -> list[TaskLease]:
        return [self._leases[k] for k in sorted(self._leases)]
