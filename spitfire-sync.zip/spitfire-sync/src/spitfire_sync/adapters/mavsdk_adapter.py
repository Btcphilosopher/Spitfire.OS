"""Optional MAVSDK (v4, native binding) adapter for software-in-the-loop.

DISABLED BY DEFAULT.  Three independent gates must all be open before any
command reaches an autopilot:

1. ``MavsdkAdapterConfig.enabled = True`` (otherwise construction raises
   :class:`AdapterDisabledError`);
2. ``mode = "sitl"`` and a loopback/UDP SITL connection URL, *or*
   ``mode = "hardware"`` with ``hardware_dispatch_enabled = True`` **and** the
   environment variable ``SPITFIRE_HARDWARE_DISPATCH`` set to
   ``I_ACCEPT_RESPONSIBILITY``;
3. in hardware mode without both of those, the adapter is *monitor-only*:
   telemetry flows, every command raises :class:`HardwareDispatchDisabled`.

API verified against the installed ``mavsdk`` 4.3.0 package source
(``mavsdk.asyncio``: ``Mavsdk``, ``Configuration.create_with_component_type``,
``add_any_connection``, ``first_autopilot``; plugins ``TelemetryAsync``,
``OffboardAsync``, ``ActionAsync``, ``ParamAsync``).  It has NOT been run
against a PX4 SITL instance in the build environment (no simulator there) -
see docs/SITL.md for the validation procedure.

Frames: MAVSDK reports geodetic positions and NED velocities; offboard
position setpoints are NED relative to the autopilot's local (EKF) origin.
This adapter converts mission-ENU <-> geodetic <-> autopilot-local-NED
explicitly through :mod:`spitfire_sync.models.frames`.
"""

from __future__ import annotations

import asyncio
import math
import os
from typing import Any
from urllib.parse import urlparse

from pydantic import BaseModel, ConfigDict

from ..models.frames import GeodeticPosition, LocalTangentFrame, enu_to_ned, ned_to_enu
from ..models.geometry import NavigationFrame, Vec3
from ..models.state import ArmedStatus, FlightMode
from .base import AdapterDisabledError, AircraftAdapter, BatterySample, NavSample

HARDWARE_ENV = "SPITFIRE_HARDWARE_DISPATCH"
HARDWARE_TOKEN = "I_ACCEPT_RESPONSIBILITY"


class HardwareDispatchDisabled(RuntimeError):
    pass


class MavsdkAdapterConfig(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    enabled: bool = False
    mode: str = "sitl"  # "sitl" | "hardware"
    connection_url: str = "udp://:14540"
    hardware_dispatch_enabled: bool = False
    battery_capacity_wh: float = 60.0
    default_position_uncertainty_m: float = 3.0
    connect_timeout_s: float = 15.0
    param_names: list[str] = [
        "RTL_RETURN_ALT", "NAV_DLL_ACT", "COM_DL_LOSS_T", "COM_OF_LOSS_T", "BAT_LOW_THR", "BAT_CRIT_THR",
        "COM_LOW_BAT_ACT", "GF_ACTION", "MPC_XY_VEL_MAX", "MPC_Z_VEL_MAX_UP", "MPC_Z_VEL_MAX_DN", "MPC_ACC_HOR_MAX",
    ]


def _is_sitl_url(url: str) -> bool:
    u = urlparse(url)
    if u.scheme not in ("udp", "udpin", "udpout", "tcp", "tcpin", "tcpout"):
        return False
    host = u.hostname or ""
    return host in ("", "0.0.0.0", "127.0.0.1", "localhost", "::1")


class DispatchGate:
    def __init__(self, cfg: MavsdkAdapterConfig, env: dict[str, str] | None = None) -> None:
        env = dict(os.environ) if env is None else env
        if not cfg.enabled:
            raise AdapterDisabledError("MAVSDK adapter is disabled (set enabled=true explicitly)")
        if cfg.mode == "sitl":
            if not _is_sitl_url(cfg.connection_url):
                raise AdapterDisabledError(f"SITL mode requires a loopback connection URL, got {cfg.connection_url}")
            self.commands_allowed = True
        elif cfg.mode == "hardware":
            self.commands_allowed = cfg.hardware_dispatch_enabled and env.get(HARDWARE_ENV) == HARDWARE_TOKEN
        else:
            raise AdapterDisabledError(f"unknown adapter mode {cfg.mode!r}")
        self.mode = cfg.mode

    def require(self) -> None:
        if not self.commands_allowed:
            raise HardwareDispatchDisabled(
                "hardware command dispatch is disabled; adapter is monitor-only (see docs/SITL.md)")


_MODE_MAP = {
    "READY": FlightMode.ON_GROUND, "TAKEOFF": FlightMode.TAKEOFF, "HOLD": FlightMode.HOLD,
    "MISSION": FlightMode.UNKNOWN, "RETURN_TO_LAUNCH": FlightMode.RETURN_TO_LAUNCH, "LAND": FlightMode.LAND,
    "OFFBOARD": FlightMode.OFFBOARD, "MANUAL": FlightMode.UNKNOWN, "POSCTL": FlightMode.UNKNOWN,
    "ALTCTL": FlightMode.UNKNOWN,
}


class MavsdkAdapter(AircraftAdapter):
    def __init__(self, cfg: MavsdkAdapterConfig, mission_origin: GeodeticPosition, clock_monotonic,  # type: ignore[no-untyped-def]
                 env: dict[str, str] | None = None) -> None:
        self.gate = DispatchGate(cfg, env)
        self.cfg = cfg
        self.mission_frame = LocalTangentFrame(origin=mission_origin)
        self._mono = clock_monotonic
        self._ap_frame: LocalTangentFrame | None = None
        self._pos: GeodeticPosition | None = None
        self._vel_ned: Vec3 | None = None
        self._unc = cfg.default_position_uncertainty_m
        self._bat: float | None = None
        self._mode = FlightMode.UNKNOWN
        self._armed = ArmedStatus.UNKNOWN
        self._t_sample = 0.0
        self._params: dict[str, float] = {}
        self._tasks: list[asyncio.Task] = []
        self._offboard_active = False
        self._mavsdk: Any = None

    # -- lifecycle ---------------------------------------------------------
    async def connect(self) -> None:
        try:
            from mavsdk.asyncio import ComponentType, Configuration, Mavsdk  # type: ignore[import-not-found]
            from mavsdk.asyncio.plugins.action import ActionAsync  # type: ignore[import-not-found]
            from mavsdk.asyncio.plugins.offboard import OffboardAsync  # type: ignore[import-not-found]
            from mavsdk.asyncio.plugins.param import ParamAsync  # type: ignore[import-not-found]
            from mavsdk.asyncio.plugins.telemetry import TelemetryAsync  # type: ignore[import-not-found]
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise AdapterDisabledError("mavsdk>=4 is not installed (pip install 'spitfire-sync[sitl]')") from exc
        conf = Configuration.create_with_component_type(ComponentType.COMPANION_COMPUTER)
        self._mavsdk = Mavsdk(conf)
        await self._mavsdk.add_any_connection(self.cfg.connection_url)
        system = await self._mavsdk.first_autopilot(timeout_s=self.cfg.connect_timeout_s)
        if system is None:
            raise ConnectionError(f"no autopilot found on {self.cfg.connection_url}")
        self.telemetry = TelemetryAsync(system)
        self.offboard = OffboardAsync(system)
        self.action = ActionAsync(system)
        self.param = ParamAsync(system)
        origin = await self.telemetry.get_gps_global_origin()
        self._ap_frame = LocalTangentFrame(origin=GeodeticPosition(
            latitude_deg=origin.latitude_deg, longitude_deg=origin.longitude_deg, height_m=origin.altitude_m))
        for name in self.cfg.param_names:
            try:
                self._params[name] = float(await self.param.get_param_float(name))
            except Exception:  # noqa: BLE001 - int parameters / unknown names
                try:
                    self._params[name] = float(await self.param.get_param_int(name))
                except Exception:  # noqa: BLE001
                    pass
        self._tasks = [asyncio.ensure_future(c) for c in (self._watch_position(), self._watch_velocity(),
                                                          self._watch_battery(), self._watch_mode(),
                                                          self._watch_armed(), self._watch_gps())]

    async def close(self) -> None:
        for t in self._tasks:
            t.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)
        if self._mavsdk is not None and hasattr(self._mavsdk, "destroy"):
            res = self._mavsdk.destroy()
            if asyncio.iscoroutine(res):
                await res

    # -- telemetry streams ----------------------------------------------------
    async def _watch_position(self) -> None:
        async for p in self.telemetry.subscribe_position():
            # absolute_altitude_m is AMSL; the mission origin height must use the same datum
            self._pos = GeodeticPosition(latitude_deg=p.latitude_deg, longitude_deg=p.longitude_deg,
                                         height_m=p.absolute_altitude_m)
            self._t_sample = self._mono()

    async def _watch_velocity(self) -> None:
        async for v in self.telemetry.subscribe_velocity_ned():
            self._vel_ned = Vec3.ned(v.north_m_s, v.east_m_s, v.down_m_s)

    async def _watch_battery(self) -> None:
        async for b in self.telemetry.subscribe_battery():
            r = float(b.remaining_percent)
            if math.isfinite(r):
                # the scale of remaining_percent is not documented in the installed source:
                # accept either 0..1 or 0..100
                self._bat = r / 100.0 if r > 1.0 else r

    async def _watch_mode(self) -> None:
        async for m in self.telemetry.subscribe_flight_mode():
            self._mode = _MODE_MAP.get(getattr(m, "name", str(m)), FlightMode.UNKNOWN)

    async def _watch_armed(self) -> None:
        async for a in self.telemetry.subscribe_armed():
            self._armed = ArmedStatus.ARMED if a else ArmedStatus.DISARMED

    async def _watch_gps(self) -> None:
        async for g in self.telemetry.subscribe_raw_gps():
            u = getattr(g, "horizontal_uncertainty_m", float("nan"))
            if math.isfinite(u) and u > 0:
                self._unc = 2.0 * float(u)  # ~95 % from a 1-sigma estimate

    # -- AircraftAdapter ----------------------------------------------------------
    def navigation(self) -> NavSample | None:
        if self._pos is None or self._vel_ned is None:
            return None
        p = self.mission_frame.to_enu(self._pos)
        v = ned_to_enu(self._vel_ned)
        return NavSample(p, v, self._unc, self._t_sample, True)

    def battery(self) -> BatterySample | None:
        if self._bat is None:
            return None
        return BatterySample(self._bat, self._bat * self.cfg.battery_capacity_wh)

    def flight_mode(self) -> FlightMode:
        if self._mode == FlightMode.ON_GROUND and self._armed == ArmedStatus.ARMED:
            return FlightMode.HOLD
        return self._mode

    def armed(self) -> ArmedStatus:
        return self._armed

    def autopilot_params(self) -> dict[str, float]:
        return dict(self._params)

    def to_autopilot_ned(self, p: Vec3) -> Vec3:
        """Mission ENU -> autopilot local NED (via geodetic; frames differ by origin)."""
        p.require(NavigationFrame.ENU)
        assert self._ap_frame is not None
        return enu_to_ned(self._ap_frame.to_enu(self.mission_frame.to_geodetic(p)))

    async def arm(self) -> bool:
        self.gate.require()
        try:
            await self.action.arm()
            return True
        except Exception:  # noqa: BLE001 - ActionError => start failure is reported upstream
            return False

    async def set_setpoint(self, position: Vec3, velocity: Vec3) -> None:
        self.gate.require()
        from mavsdk.asyncio.plugins.offboard import PositionNedYaw, VelocityNedYaw  # type: ignore[import-not-found]

        n = self.to_autopilot_ned(position)
        v = enu_to_ned(velocity)  # tangent-plane rotation between nearby origins is negligible (<1e-4 rad/km)
        await self.offboard.set_position_velocity_ned(PositionNedYaw(n.x, n.y, n.z, 0.0),
                                                      VelocityNedYaw(v.x, v.y, v.z, 0.0))
        if not self._offboard_active:
            # PX4 requires a setpoint stream before offboard start
            await self.offboard.start()
            self._offboard_active = True

    async def _stop_offboard(self) -> None:
        if self._offboard_active:
            try:
                await self.offboard.stop()
            finally:
                self._offboard_active = False

    async def hold(self) -> None:
        self.gate.require()
        await self._stop_offboard()
        await self.action.hold()

    async def goto(self, position: Vec3, speed_m_s: float) -> None:
        self.gate.require()
        await self._stop_offboard()
        g = self.mission_frame.to_geodetic(position)
        await self.action.goto_location(g.latitude_deg, g.longitude_deg, g.height_m, 0.0)

    async def land(self) -> None:
        self.gate.require()
        await self._stop_offboard()
        await self.action.land()

    async def return_to_launch(self) -> None:
        self.gate.require()
        await self._stop_offboard()
        await self.action.return_to_launch()
