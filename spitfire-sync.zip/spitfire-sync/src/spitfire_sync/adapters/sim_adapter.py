"""Adapter connecting an agent to a simulated aircraft (navigation solution
with error, battery estimate, autopilot command interface)."""

from __future__ import annotations

import numpy as np

from ..models.geometry import Vec3
from ..models.state import ArmedStatus, FlightMode
from ..simulation.world import SimAircraft
from .base import AircraftAdapter, BatterySample, NavSample


class SimAdapter(AircraftAdapter):
    def __init__(self, aircraft: SimAircraft, world_now) -> None:  # type: ignore[no-untyped-def]
        self.ac = aircraft
        self._now = world_now  # world time is only used to timestamp setpoints inside the sim autopilot

    async def connect(self) -> None:
        return None

    async def close(self) -> None:
        return None

    def navigation(self) -> NavSample | None:
        ac = self.ac
        t = self._now()
        p = ac.pos + ac.nav_err
        v = ac.vel + ac.rng.standard_normal(3) * 0.05
        return NavSample(Vec3.enu(*p), Vec3.enu(*v), ac.reported_uncertainty(t), ac.clock.monotonic(), True)

    def battery(self) -> BatterySample | None:
        ac = self.ac
        frac = ac.energy_wh / ac.capacity_wh
        return BatterySample(remaining_fraction=float(np.clip(frac, 0, 1)), remaining_energy_wh=float(ac.energy_wh),
                             voltage_v=21.0 + 4.2 * frac)

    def flight_mode(self) -> FlightMode:
        if self.ac.failsafe_reason:
            return FlightMode.EMERGENCY if self.ac.mode != FlightMode.ON_GROUND else FlightMode.ON_GROUND
        return self.ac.mode

    def armed(self) -> ArmedStatus:
        return ArmedStatus.ARMED if self.ac.armed else ArmedStatus.DISARMED

    async def arm(self) -> bool:
        return self.ac.arm()

    async def set_setpoint(self, position: Vec3, velocity: Vec3) -> None:
        self.ac.set_setpoint(position.as_array(), velocity.as_array(), self._now())

    async def hold(self) -> None:
        self.ac.hold()

    async def goto(self, position: Vec3, speed_m_s: float) -> None:
        self.ac.goto(position.as_array(), speed_m_s)

    async def land(self) -> None:
        self.ac.land()

    async def return_to_launch(self) -> None:
        self.ac.rtl()

    def autopilot_params(self) -> dict[str, float]:
        return dict(self.ac.params)

    def set_payload_active(self, active: bool, task_id: str | None = None) -> None:
        self.ac.payload = active
        self.ac.payload_task = task_id if active else None
