"""Aircraft adapter interface (companion computer <-> autopilot).

The agent issues *supervisory* commands only: position/velocity setpoints,
hold, land, return-to-launch, arm/disarm.  Stabilisation, attitude and motor
control and aircraft-specific failsafes stay inside the autopilot.

All positions/velocities crossing this interface are ENU; adapters for
autopilots using NED (PX4/MAVLink) must convert at this boundary using
:mod:`spitfire_sync.models.frames`.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

from ..models.geometry import Vec3
from ..models.state import ArmedStatus, FlightMode


@dataclass(frozen=True)
class NavSample:
    position: Vec3
    velocity: Vec3
    position_uncertainty_m: float
    local_time: float  # companion monotonic time of the sample
    valid: bool = True


@dataclass(frozen=True)
class BatterySample:
    remaining_fraction: float
    remaining_energy_wh: float
    voltage_v: float | None = None


class AdapterDisabledError(RuntimeError):
    """Raised when a real-aircraft adapter is used without explicit enablement."""


class AircraftAdapter(ABC):
    @abstractmethod
    async def connect(self) -> None: ...

    @abstractmethod
    async def close(self) -> None: ...

    @abstractmethod
    def navigation(self) -> NavSample | None: ...

    @abstractmethod
    def battery(self) -> BatterySample | None: ...

    @abstractmethod
    def flight_mode(self) -> FlightMode: ...

    @abstractmethod
    def armed(self) -> ArmedStatus: ...

    @abstractmethod
    async def arm(self) -> bool: ...

    @abstractmethod
    async def set_setpoint(self, position: Vec3, velocity: Vec3) -> None: ...

    @abstractmethod
    async def hold(self) -> None: ...

    @abstractmethod
    async def goto(self, position: Vec3, speed_m_s: float) -> None: ...

    @abstractmethod
    async def land(self) -> None: ...

    @abstractmethod
    async def return_to_launch(self) -> None: ...

    @abstractmethod
    def autopilot_params(self) -> dict[str, float]: ...

    def set_payload_active(self, active: bool, task_id: str | None = None) -> None:  # noqa: B027 - optional
        """Turn the survey payload on/off (sim records it for coverage)."""
