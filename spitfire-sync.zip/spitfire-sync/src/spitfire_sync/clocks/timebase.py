"""World timebase (simulation ground truth / playback pacing)."""

from __future__ import annotations

import asyncio
from typing import Any, Callable


class Timebase:
    """World time.  ``speed`` > 1 runs faster than wall-clock when the loop is a
    normal (real-time) asyncio loop; under :class:`VirtualTimeEventLoop` use
    ``speed=1`` and the loop itself provides acceleration."""

    def __init__(self, speed: float = 1.0) -> None:
        if speed <= 0:
            raise ValueError("speed must be positive")
        self.speed = speed
        self._loop_t0: float | None = None

    def _loop(self) -> asyncio.AbstractEventLoop:
        return asyncio.get_running_loop()

    def start(self) -> None:
        self._loop_t0 = self._loop().time()

    def now(self) -> float:
        loop = self._loop()
        if self._loop_t0 is None:
            self._loop_t0 = loop.time()
        return (loop.time() - self._loop_t0) * self.speed

    async def sleep(self, dt: float) -> None:
        await asyncio.sleep(max(0.0, dt) / self.speed)

    def call_later(self, dt: float, cb: Callable[..., Any], *args: Any) -> asyncio.TimerHandle:
        return self._loop().call_later(max(0.0, dt) / self.speed, cb, *args)
