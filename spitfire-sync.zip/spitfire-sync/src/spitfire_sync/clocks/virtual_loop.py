"""Deterministic virtual-time asyncio event loop.

``VirtualTimeEventLoop`` is a ``SelectorEventLoop`` whose ``time()`` returns a
virtual clock.  When the loop has nothing ready to run, instead of blocking in
``select(timeout)`` it advances virtual time by ``timeout`` (i.e. jumps straight
to the next scheduled timer).  Consequently:

* ``asyncio.sleep``, ``call_later``, ``wait_for`` and timeouts all run in
  virtual time - a 10-minute mission simulates in seconds of CPU time;
* scheduling is single-threaded FIFO, so a run is reproducible given the same
  seed and the same sequence of operations (avoid iterating unordered sets).

Real file descriptors (e.g. the loop's self-pipe for thread wake-ups) are
still polled with a zero timeout, so ``run_in_executor`` keeps working.

This relies on the documented contract that the base event loop calls
``selector.select(timeout)`` with the delay to its next timer and uses
``self.time()`` for scheduling; it is exercised by tests/test_virtual_loop.py.
"""

from __future__ import annotations

import asyncio
import selectors
from typing import Any, Awaitable, Callable, TypeVar

T = TypeVar("T")


class VirtualTimeDeadlock(RuntimeError):
    """No timers are scheduled and no I/O arrived: nothing can ever happen."""


class _VirtualSelector(selectors.BaseSelector):
    def __init__(self) -> None:
        self._real = selectors.DefaultSelector()
        self.loop: "VirtualTimeEventLoop | None" = None

    def register(self, fileobj: Any, events: int, data: Any = None) -> selectors.SelectorKey:
        return self._real.register(fileobj, events, data)

    def unregister(self, fileobj: Any) -> selectors.SelectorKey:
        return self._real.unregister(fileobj)

    def modify(self, fileobj: Any, events: int, data: Any = None) -> selectors.SelectorKey:
        return self._real.modify(fileobj, events, data)

    def get_map(self) -> Any:
        return self._real.get_map()

    def close(self) -> None:
        self._real.close()

    def select(self, timeout: float | None = None) -> list[tuple[selectors.SelectorKey, int]]:
        events = self._real.select(0)
        if events:
            return events
        if timeout is None:
            # Nothing scheduled.  Only another thread could wake us; wait (really) for it.
            events = self._real.select(5.0)
            if not events:
                raise VirtualTimeDeadlock("virtual-time loop has no scheduled callbacks")
            return events
        if timeout > 0 and self.loop is not None:
            self.loop._advance(timeout)
        return []


class VirtualTimeEventLoop(asyncio.SelectorEventLoop):
    def __init__(self, start_time: float = 0.0) -> None:
        sel = _VirtualSelector()
        super().__init__(selector=sel)
        sel.loop = self
        self._virtual_time = float(start_time)

    def time(self) -> float:  # noqa: D401 - asyncio API
        return self._virtual_time

    def _advance(self, dt: float) -> None:
        self._virtual_time += dt


def run_virtual(main: Callable[[], Awaitable[T]] | Awaitable[T], start_time: float = 0.0) -> T:
    """Run ``main`` (a coroutine or a zero-arg coroutine function) in virtual time."""
    with asyncio.Runner(loop_factory=lambda: VirtualTimeEventLoop(start_time)) as runner:
        coro = main() if callable(main) else main
        return runner.run(coro)  # type: ignore[arg-type]
