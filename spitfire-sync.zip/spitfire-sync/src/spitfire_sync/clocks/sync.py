"""Peer clock-offset estimation with rigorous bounds.

Each two-way exchange (NTP-style) gives

    theta = ((t2 - t1) + (t3 - t4)) / 2      # reference - local
    delay = (t4 - t1) - (t3 - t2)

and, assuming only causality (both one-way delays >= 0), the true offset at the
time of the exchange lies in ``[theta - delay/2, theta + delay/2]``.  The
interval is widened by the relative drift bound ``rho`` for the exchange
duration and for the time elapsed since.  The estimator intersects the
intervals of all retained samples (Marzullo-style): the estimate is the
midpoint, the uncertainty the half-width.

If a new sample's interval does not intersect the current intersection, the
assumptions were violated - a timestamp jump, a reference change, or drift
beyond ``rho`` - and the estimator restarts from the new sample, reporting
``CLOCK_JUMP_DETECTED``.  A change of ``reference_id`` (new coordinator
process) also restarts it.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field

from ..reasons import ReasonCode
from .clock import TimeEstimate


@dataclass(frozen=True)
class SyncSample:
    t_local: float
    offset: float
    half_width: float


@dataclass(frozen=True)
class OffsetEstimate:
    offset: float
    uncertainty: float
    synchronised: bool
    samples: int
    last_sample_age_s: float


@dataclass
class SyncUpdate:
    accepted: bool
    reasons: list[ReasonCode] = field(default_factory=list)
    jump_detected: bool = False


class ClockSyncEstimator:
    def __init__(
        self,
        max_relative_drift_ppm: float = 200.0,
        window: int = 16,
        max_sample_age_s: float = 120.0,
        max_acceptable_delay_s: float = 10.0,
    ) -> None:
        self.rho = max_relative_drift_ppm * 1e-6
        self.window = window
        self.max_sample_age_s = max_sample_age_s
        self.max_acceptable_delay_s = max_acceptable_delay_s
        self._samples: deque[SyncSample] = deque(maxlen=window)
        self.reference_id: str | None = None
        self.jumps_detected = 0
        self.resets = 0

    def reset(self) -> None:
        self._samples.clear()
        self.resets += 1

    def _interval(self, s: SyncSample, t_local: float) -> tuple[float, float]:
        w = s.half_width + self.rho * abs(t_local - s.t_local)
        return s.offset - w, s.offset + w

    def _intersection(self, t_local: float) -> tuple[float, float] | None:
        lo, hi = -float("inf"), float("inf")
        for s in self._samples:
            a, b = self._interval(s, t_local)
            lo, hi = max(lo, a), min(hi, b)
        if lo > hi:
            return None
        return lo, hi

    def add_exchange(
        self, t1_local: float, t2_ref: float, t3_ref: float, t4_local: float, reference_id: str
    ) -> SyncUpdate:
        upd = SyncUpdate(accepted=True)
        if reference_id != self.reference_id:
            if self.reference_id is not None:
                upd.reasons.append(ReasonCode.CLOCK_REFERENCE_CHANGED)
            self.reset()
            self.reference_id = reference_id
        if t4_local < t1_local or t3_ref < t2_ref:
            return SyncUpdate(False, [ReasonCode.MALFORMED])
        round_trip = t4_local - t1_local
        delay = max(0.0, round_trip - (t3_ref - t2_ref))
        if delay > self.max_acceptable_delay_s:
            return SyncUpdate(False, [ReasonCode.TOO_OLD])
        theta = ((t2_ref - t1_local) + (t3_ref - t4_local)) / 2.0
        half = delay / 2.0 + self.rho * round_trip
        sample = SyncSample(t_local=t4_local, offset=theta, half_width=half)
        # prune old samples
        while self._samples and t4_local - self._samples[0].t_local > self.max_sample_age_s:
            self._samples.popleft()
        if self._samples:
            cur = self._intersection(t4_local)
            a, b = self._interval(sample, t4_local)
            if cur is None or b < cur[0] or a > cur[1]:
                self.jumps_detected += 1
                upd.jump_detected = True
                upd.reasons.append(ReasonCode.CLOCK_JUMP_DETECTED)
                self.reset()
        self._samples.append(sample)
        return upd

    def estimate(self, t_local: float) -> OffsetEstimate:
        if not self._samples:
            return OffsetEstimate(0.0, float("inf"), False, 0, float("inf"))
        inter = self._intersection(t_local)
        last = self._samples[-1]
        if inter is None:  # cannot happen after add_exchange's check; be safe
            a, b = self._interval(last, t_local)
        else:
            a, b = inter
        return OffsetEstimate(
            offset=(a + b) / 2.0,
            uncertainty=(b - a) / 2.0,
            synchronised=True,
            samples=len(self._samples),
            last_sample_age_s=t_local - last.t_local,
        )

    def to_reference(self, t_local: float) -> TimeEstimate:
        e = self.estimate(t_local)
        return TimeEstimate(t_local + e.offset, e.uncertainty)

    def to_local(self, t_ref: float, t_local_now: float) -> TimeEstimate:
        """Local monotonic time at which the reference clock will read ``t_ref``."""
        e = self.estimate(t_local_now)
        return TimeEstimate(t_ref - e.offset, e.uncertainty + self.rho * abs(t_ref - (t_local_now + e.offset)))
