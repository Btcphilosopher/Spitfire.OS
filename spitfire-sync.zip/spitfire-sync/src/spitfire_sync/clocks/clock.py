"""Clock abstractions.

Terminology (docs/TIMING.md):

* **monotonic time** - a node's local, never-stepping process clock.  Used for
  *all local timeouts*.  Monotonic readings from different nodes are unrelated
  and are never compared directly.
* **UTC time** - wall-clock time.  It may step (NTP/GNSS correction) and is
  only used for logging and to seed a coordination timescale.
* **coordination timescale** - the coordinator's monotonic clock plus a fixed
  offset chosen at coordinator start (so it is approximately UTC but never
  steps).  Plans, leases and message expiry are expressed on it.
* **peer clock offset** - an aircraft's estimate of (coordination time - its
  monotonic time), with a rigorous uncertainty bound (see sync.py).
* **world time** - simulator ground truth.  Only the simulator, the simulated
  network and evaluation may read it.
"""

from __future__ import annotations

import asyncio
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass

from .timebase import Timebase

SIM_UTC_EPOCH = 1_795_000_000.0  # arbitrary 2026 epoch used by simulated UTC clocks


@dataclass(frozen=True)
class TimeEstimate:
    value: float
    uncertainty: float  # half-width of the bound, seconds

    @property
    def earliest(self) -> float:
        return self.value - self.uncertainty

    @property
    def latest(self) -> float:
        return self.value + self.uncertainty


@dataclass(frozen=True)
class MessageAge:
    """Age of a message at the receiver, with its uncertainty."""

    age_s: float
    uncertainty_s: float

    @classmethod
    def compute(cls, receiver_now: TimeEstimate, issued_at: float, sender_uncertainty: float) -> "MessageAge":
        return cls(receiver_now.value - issued_at, receiver_now.uncertainty + sender_uncertainty)

    @property
    def max_age_s(self) -> float:
        return self.age_s + self.uncertainty_s


class Clock(ABC):
    """A node's local clocks."""

    boot_id: str

    @abstractmethod
    def monotonic(self) -> float: ...

    @abstractmethod
    def utc(self) -> float: ...

    @abstractmethod
    async def sleep(self, seconds: float) -> None:
        """Sleep for ``seconds`` of *local monotonic* time."""


class SystemClock(Clock):
    def __init__(self) -> None:
        self.boot_id = uuid.uuid4().hex[:12]

    def monotonic(self) -> float:
        return time.monotonic()

    def utc(self) -> float:
        return time.time()

    async def sleep(self, seconds: float) -> None:
        await asyncio.sleep(max(0.0, seconds))


class SimulatedClock(Clock):
    """Clock model for a simulated node.

    monotonic = mono_offset + (world - boot_world) * (1 + drift)
    utc       = SIM_UTC_EPOCH + world + utc_offset + sum(injected jumps)
    """

    def __init__(
        self,
        timebase: Timebase,
        name: str,
        *,
        drift_ppm: float = 0.0,
        mono_offset: float = 0.0,
        utc_offset: float = 0.0,
        boot_counter: int = 0,
    ) -> None:
        self._tb = timebase
        self.name = name
        self.drift = drift_ppm * 1e-6
        self.mono_offset = mono_offset
        self.utc_offset = utc_offset
        self._boot_world = timebase.now()
        self._boot_counter = boot_counter
        self.boot_id = self._make_boot_id()

    def _make_boot_id(self) -> str:
        return f"{self.name}-boot{self._boot_counter}"

    def monotonic(self) -> float:
        return self.mono_offset + (self._tb.now() - self._boot_world) * (1.0 + self.drift)

    def utc(self) -> float:
        return SIM_UTC_EPOCH + self._tb.now() + self.utc_offset

    def inject_utc_jump(self, delta_s: float) -> None:
        """Step the UTC clock (e.g. an NTP/GNSS correction).  Monotonic is unaffected."""
        self.utc_offset += delta_s

    def reboot(self, new_mono_offset: float = 0.0) -> str:
        self._boot_counter += 1
        self._boot_world = self._tb.now()
        self.mono_offset = new_mono_offset
        self.boot_id = self._make_boot_id()
        return self.boot_id

    def world_time_of_local(self, mono: float) -> float:
        """Ground-truth helper for evaluation only."""
        return self._boot_world + (mono - self.mono_offset) / (1.0 + self.drift)

    async def sleep(self, seconds: float) -> None:
        await self._tb.sleep(max(0.0, seconds) / (1.0 + self.drift))


class CoordinationTimescale:
    """The coordinator's timescale: monotonic + offset fixed at construction.

    A UTC step on the coordinator host after start does not move it.  A new
    coordinator process gets a new ``reference_id``; aircraft must re-sync.
    """

    def __init__(self, clock: Clock, epoch: int) -> None:
        self.clock = clock
        self._offset = clock.utc() - clock.monotonic()
        self.reference_id = f"{clock.boot_id}/e{epoch}"

    def now(self) -> float:
        return self.clock.monotonic() + self._offset

    def estimate(self) -> TimeEstimate:
        return TimeEstimate(self.now(), 0.0)
