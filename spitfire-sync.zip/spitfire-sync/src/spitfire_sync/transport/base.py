"""Replaceable transport interface.

A transport moves opaque bytes between named nodes.  Encoding, signing and
verification happen in :class:`MessageCodec` so a transport can be swapped
(simulated network, UDP, a MAVLink tunnel, ...) without touching protocol code.
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod

from pydantic import ValidationError

from ..models.messages import Envelope
from .auth import Authenticator


class Transport(ABC):
    node_id: str

    @abstractmethod
    async def send(self, recipient_id: str, data: bytes) -> None: ...

    @abstractmethod
    async def recv(self, timeout: float | None = None) -> bytes | None:
        """Next datagram, or None on timeout."""

    @abstractmethod
    def recv_nowait(self) -> list[bytes]:
        """All datagrams that have already arrived."""

    def recv_nowait_timestamped(self) -> list[tuple[bytes, float | None]]:
        """Like :meth:`recv_nowait` with the receiver's monotonic receive time
        (None if the transport cannot timestamp).  Used for clock sync."""
        return [(d, None) for d in self.recv_nowait()]

    @abstractmethod
    async def close(self) -> None: ...


class DecodeError(ValueError):
    pass


class MessageCodec:
    def __init__(self, authenticator: Authenticator) -> None:
        self.auth = authenticator

    def encode(self, env: Envelope) -> bytes:
        signed = self.auth.sign(env)
        return signed.model_dump_json().encode()

    def decode(self, data: bytes) -> Envelope:
        try:
            obj = json.loads(data.decode())
            return Envelope.model_validate(obj)
        except (ValueError, ValidationError) as exc:  # json errors are ValueErrors
            raise DecodeError(str(exc)) from exc
