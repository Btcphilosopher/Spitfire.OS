"""Message authentication using standard primitives only.

``HmacAuthenticator`` computes HMAC-SHA256 (RFC 2104, Python ``hmac``) over the
canonical JSON of the envelope without its ``auth_tag``.  Keys are per sender.
This protects integrity/authenticity against an on-path attacker who lacks the
key; it does **not** provide confidentiality or key management.

For real integration use an authenticated transport such as TLS 1.3 / DTLS 1.3
or WireGuard between ground station and companion computers, and MAVLink 2
message signing on the autopilot link (MAVSDK exposes ``enable_signing``).  See
docs/SECURITY.md.  No cryptographic primitive is implemented here.
"""

from __future__ import annotations

import hashlib
import hmac
import json
from typing import Protocol

from ..models.messages import Envelope


def canonical_bytes(env: Envelope) -> bytes:
    data = env.model_dump(mode="json", exclude={"auth_tag"})
    return json.dumps(data, sort_keys=True, separators=(",", ":"), allow_nan=True).encode()


class Authenticator(Protocol):
    def sign(self, env: Envelope) -> Envelope: ...

    def verify(self, env: Envelope) -> bool: ...


class NullAuthenticator:
    """Accepts everything.  Only for unit tests; never for real links."""

    def sign(self, env: Envelope) -> Envelope:
        return env

    def verify(self, env: Envelope) -> bool:
        return True


class HmacAuthenticator:
    def __init__(self, keys: dict[str, bytes], own_id: str | None = None) -> None:
        self._keys = dict(keys)
        self.own_id = own_id

    def knows(self, sender_id: str) -> bool:
        return sender_id in self._keys

    def sign(self, env: Envelope) -> Envelope:
        key = self._keys.get(env.sender_id)
        if key is None:
            raise KeyError(f"no key for sender {env.sender_id}")
        tag = hmac.new(key, canonical_bytes(env), hashlib.sha256).hexdigest()
        return env.model_copy(update={"auth_tag": tag})

    def verify(self, env: Envelope) -> bool:
        key = self._keys.get(env.sender_id)
        if key is None or env.auth_tag is None:
            return False
        expected = hmac.new(key, canonical_bytes(env), hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, env.auth_tag)


def derive_demo_keys(node_ids: list[str], seed: int) -> dict[str, bytes]:
    """Deterministic *demo* keys for simulation.  Real deployments provision keys."""
    return {n: hashlib.sha256(f"spitfire-demo-key/{seed}/{n}".encode()).digest() for n in node_ids}
