"""Seeded simulated network: latency, jitter (=> reordering), loss, duplication,
and scheduled link episodes (delay / outage windows)."""

from __future__ import annotations

import asyncio
import zlib
from collections import defaultdict
from dataclasses import dataclass, field

import numpy as np
from pydantic import BaseModel, ConfigDict, Field

from ..clocks.timebase import Timebase
from .base import Transport


class LinkProfile(BaseModel):
    model_config = ConfigDict(frozen=True)

    latency_s: float = Field(ge=0.0, default=0.03)
    jitter_s: float = Field(ge=0.0, default=0.01)  # mean of exponential extra delay
    loss: float = Field(ge=0.0, le=1.0, default=0.01)
    duplicate: float = Field(ge=0.0, le=1.0, default=0.005)


class LinkEpisode(BaseModel):
    """Override a node's link profile (both directions) during [start, end) world time."""

    model_config = ConfigDict(frozen=True)

    node_id: str
    start_s: float
    end_s: float
    profile: LinkProfile
    label: str = "degraded"


@dataclass
class LinkStats:
    sent: int = 0
    dropped: int = 0
    duplicated: int = 0
    delivered: int = 0
    latencies: list[float] = field(default_factory=list)


def _stable_seed(seed: int, *parts: str) -> int:
    return (seed * 1_000_003 + zlib.crc32("/".join(parts).encode())) % (2**32)


class SimNetwork:
    def __init__(
        self,
        timebase: Timebase,
        seed: int,
        default_profile: LinkProfile | None = None,
        episodes: list[LinkEpisode] | None = None,
    ) -> None:
        self.tb = timebase
        self.seed = seed
        self.default = default_profile or LinkProfile()
        self.episodes = list(episodes or [])
        self._inboxes: dict[str, asyncio.Queue[tuple[bytes, float | None]]] = {}
        self._rx_clocks: dict[str, object] = {}
        self._rngs: dict[tuple[str, str], np.random.Generator] = {}
        self.stats: dict[tuple[str, str], LinkStats] = defaultdict(LinkStats)
        self._down: set[str] = set()

    def endpoint(self, node_id: str, clock: object | None = None) -> "SimTransport":
        """``clock`` (anything with ``monotonic()``) timestamps arrivals, like a NIC/kernel RX timestamp."""
        if node_id not in self._inboxes:
            self._inboxes[node_id] = asyncio.Queue()
        if clock is not None:
            self._rx_clocks[node_id] = clock
        return SimTransport(self, node_id)

    def set_node_down(self, node_id: str, down: bool) -> None:
        """Hard-disconnect a node (e.g. coordinator crash) independent of episodes."""
        if down:
            self._down.add(node_id)
        else:
            self._down.discard(node_id)

    def _rng(self, src: str, dst: str) -> np.random.Generator:
        key = (src, dst)
        if key not in self._rngs:
            self._rngs[key] = np.random.default_rng(_stable_seed(self.seed, src, dst))
        return self._rngs[key]

    def profile_for(self, src: str, dst: str, t: float) -> LinkProfile:
        prof = self.default
        for ep in self.episodes:
            if ep.start_s <= t < ep.end_s and ep.node_id in (src, dst):
                prof = ep.profile
        return prof

    def active_episode(self, node_id: str, t: float) -> LinkEpisode | None:
        for ep in self.episodes:
            if ep.node_id == node_id and ep.start_s <= t < ep.end_s:
                return ep
        return None

    def _deliver(self, dst: str, data: bytes, sent_at: float, key: tuple[str, str]) -> None:
        if dst in self._down:
            self.stats[key].dropped += 1
            return
        q = self._inboxes.get(dst)
        if q is None:
            return
        self.stats[key].delivered += 1
        self.stats[key].latencies.append(self.tb.now() - sent_at)
        clk = self._rx_clocks.get(dst)
        q.put_nowait((data, clk.monotonic() if clk is not None else None))  # type: ignore[attr-defined]

    def transmit(self, src: str, dst: str, data: bytes) -> None:
        key = (src, dst)
        st = self.stats[key]
        st.sent += 1
        now = self.tb.now()
        if src in self._down or dst in self._down:
            st.dropped += 1
            return
        prof = self.profile_for(src, dst, now)
        rng = self._rng(src, dst)
        # draw a fixed number of variates per message so the stream stays aligned
        u_loss, u_dup, e1, e2 = rng.random(), rng.random(), rng.exponential(1.0), rng.exponential(1.0)
        if u_loss < prof.loss:
            st.dropped += 1
            return
        delay = prof.latency_s + prof.jitter_s * e1
        self.tb.call_later(delay, self._deliver, dst, data, now, key)
        if u_dup < prof.duplicate:
            st.duplicated += 1
            self.tb.call_later(delay + prof.jitter_s * e2 + 0.001, self._deliver, dst, data, now, key)

    def inbox(self, node_id: str) -> asyncio.Queue[tuple[bytes, float | None]]:
        return self._inboxes[node_id]


class SimTransport(Transport):
    def __init__(self, net: SimNetwork, node_id: str) -> None:
        self.net = net
        self.node_id = node_id
        self._closed = False

    async def send(self, recipient_id: str, data: bytes) -> None:
        if self._closed:
            return
        if recipient_id == "*":
            for other in sorted(self.net._inboxes):
                if other != self.node_id:
                    self.net.transmit(self.node_id, other, data)
        else:
            self.net.transmit(self.node_id, recipient_id, data)

    async def recv(self, timeout: float | None = None) -> bytes | None:
        q = self.net.inbox(self.node_id)
        try:
            if timeout is None:
                return (await q.get())[0]
            return (await asyncio.wait_for(q.get(), timeout / self.net.tb.speed))[0]
        except TimeoutError:
            return None

    def recv_nowait(self) -> list[bytes]:
        return [d for d, _ in self.recv_nowait_timestamped()]

    def recv_nowait_timestamped(self) -> list[tuple[bytes, float | None]]:
        q = self.net.inbox(self.node_id)
        out: list[tuple[bytes, float | None]] = []
        while not q.empty():
            out.append(q.get_nowait())
        return out

    async def close(self) -> None:
        self._closed = True
