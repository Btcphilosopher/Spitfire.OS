"""Per-aircraft contingency policy validation.

Coordination contingencies are only coherent if the autopilot's own failsafes
(which remain authoritative for emergencies) are configured consistently.
:func:`validate_fleet` checks configuration against autopilot parameters and
returns structured findings; it never edits the autopilot.

PX4 parameter names/semantics used here were not verifiable against PX4
documentation from the build environment; confirm against the parameter
reference of the PX4 release you fly (docs/SITL.md lists them).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from ..config import DroneProfile, LostLinkAction, SpitfireConfig
from ..reasons import ReasonCode


class FindingSeverity(StrEnum):
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"


@dataclass(frozen=True)
class Finding:
    severity: FindingSeverity
    drone_id: str | None
    check: str
    message: str
    reason: ReasonCode = ReasonCode.AUTOPILOT_CONFIG_MISMATCH


def validate_against_autopilot(profile: DroneProfile, params: dict[str, float], reserve_fraction: float,
                               contingency_altitude: float | None) -> list[Finding]:
    f: list[Finding] = []
    d = profile.drone_id
    c = profile.contingency

    def need(name: str) -> float | None:
        if name not in params:
            f.append(Finding(FindingSeverity.WARNING, d, name, f"{name} not reported by autopilot; cannot validate"))
            return None
        return params[name]

    rtl = need("RTL_RETURN_ALT")
    if rtl is not None and contingency_altitude is not None and c.lost_link_action in (
            LostLinkAction.AUTOPILOT_RTL, LostLinkAction.GOTO_CONTINGENCY_HOLD) and abs(rtl - contingency_altitude) > 1.0:
        f.append(Finding(FindingSeverity.ERROR, d, "RTL_RETURN_ALT",
                         f"autopilot RTL altitude {rtl:.1f} m differs from coordination contingency altitude "
                         f"{contingency_altitude:.1f} m; an autopilot RTL would not use the deconflicted layer"))
    dl = need("COM_DL_LOSS_T")
    if dl is not None and dl < c.lost_link_timeout_s + c.lost_link_hold_s:
        f.append(Finding(FindingSeverity.WARNING, d, "COM_DL_LOSS_T",
                         f"autopilot data-link-loss timeout {dl:.0f} s pre-empts the coordination lost-link "
                         f"sequence ({c.lost_link_timeout_s + c.lost_link_hold_s:.0f} s)"))
    of = need("COM_OF_LOSS_T")
    if of is not None and of > 2.0:
        f.append(Finding(FindingSeverity.WARNING, d, "COM_OF_LOSS_T",
                         f"offboard-loss timeout {of:.1f} s is long; a companion crash would leave stale setpoints"))
    low = need("BAT_LOW_THR")
    crit = need("BAT_CRIT_THR")
    if low is not None:
        if low > 1.0:
            f.append(Finding(FindingSeverity.ERROR, d, "BAT_LOW_THR", "expected a fraction (0..1)"))
        elif low >= reserve_fraction:
            f.append(Finding(FindingSeverity.ERROR, d, "BAT_LOW_THR",
                             f"autopilot low-battery threshold {low:.2f} is at/above the coordination reserve "
                             f"{reserve_fraction:.2f}; the autopilot would act before coordinated recovery"))
    if low is not None and crit is not None and crit >= low:
        f.append(Finding(FindingSeverity.ERROR, d, "BAT_CRIT_THR", "critical threshold must be below low threshold"))
    gf = need("GF_ACTION")
    if gf is not None and gf == 0:
        f.append(Finding(FindingSeverity.ERROR, d, "GF_ACTION", "geofence action disabled"))
    lim = profile.limits
    for name, val, label in (("MPC_XY_VEL_MAX", lim.max_speed_m_s, "horizontal speed"),
                             ("MPC_Z_VEL_MAX_UP", lim.max_climb_m_s, "climb rate"),
                             ("MPC_Z_VEL_MAX_DN", lim.max_descent_m_s, "descent rate")):
        v = need(name)
        if v is not None and v + 1e-6 < val:
            f.append(Finding(FindingSeverity.ERROR, d, name,
                             f"autopilot {label} limit {v} is below the planning limit {val}; plans would be "
                             f"infeasible"))
    return f


def validate_fleet(cfg: SpitfireConfig, ceiling_m: float, contingency_altitudes: dict[str, float | None],
                   vertical_sep_m: float, params: dict[str, dict[str, float]] | None = None) -> list[Finding]:
    """Fleet-level checks (unique, separated contingency layers under the
    ceiling) plus per-aircraft autopilot checks."""
    out: list[Finding] = []
    alts = {d: a for d, a in contingency_altitudes.items() if a is not None}
    ids = sorted(alts)
    for i, a in enumerate(ids):
        if alts[a] > ceiling_m:
            out.append(Finding(FindingSeverity.ERROR, a, "contingency_altitude", "above mission ceiling"))
        for b in ids[i + 1:]:
            gap = abs(alts[a] - alts[b])
            if gap < 1.0:
                out.append(Finding(FindingSeverity.ERROR, a, "contingency_altitude",
                                   f"shares its contingency altitude with {b}"))
            elif gap < vertical_sep_m:
                out.append(Finding(FindingSeverity.INFO, a, "contingency_altitude",
                                   f"layer {alts[a]:.0f} m is {gap:.0f} m from {b}'s, below planning vertical "
                                   f"separation; uncoordinated contingencies are not fully deconflicted"))
    for p in cfg.fleet:
        if p.contingency.lost_link_action != LostLinkAction.LAND_IN_PLACE and contingency_altitudes.get(p.drone_id) is None:
            out.append(Finding(FindingSeverity.ERROR, p.drone_id, "contingency_altitude",
                               "no contingency altitude assigned and action is not LAND_IN_PLACE"))
        ap = (params or {}).get(p.drone_id, p.autopilot.values)
        out += validate_against_autopilot(p, ap, cfg.constraints.reserve_fraction,
                                          contingency_altitudes.get(p.drone_id))
    return out
