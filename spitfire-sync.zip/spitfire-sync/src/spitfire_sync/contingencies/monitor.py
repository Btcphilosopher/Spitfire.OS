"""Execution monitoring: turns snapshots + committed plans into SafetyEvents.

Each condition is edge-triggered (raised once per episode) and carries a
reason code.  The monitor only *detects*; responses are chosen by the mission
runner (coordination actions) or by the aircraft/autopilot (emergency
actions).  A coordination abort is never an aircraft emergency action.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..config import FreshnessPolicy, MonitorConfig, SeparationConfig
from ..models.commands import SafetyEvent, SafetyEventKind, Severity
from ..models.state import AgentStatus, FleetSnapshot, FlightMode, Freshness
from ..models.trajectory import DronePlan, Reservation, Trajectory
from ..reasons import ReasonCode
from ..separation.conflicts import Buffers, ConflictChecker
from ..models.trajectory import ReservationKind, Volume, VolumeKind
from ..separation.regions import contingency_regions, contract_region, kinematic_region


@dataclass
class _DroneFlags:
    freshness: Freshness = Freshness.NEVER_SEEN
    lost_since: float | None = None
    dropout: bool = False
    unassessable: bool = False
    reserve: bool = False
    nav: bool = False
    deviation_since: float | None = None
    deviation: bool = False
    failsafe: bool = False
    predicted: set[str] = field(default_factory=set)


class ExecutionMonitor:
    def __init__(self, cfg: MonitorConfig, freshness: FreshnessPolicy, sep: SeparationConfig,
                 checker: ConflictChecker, ceiling_m: float) -> None:
        self.cfg = cfg
        self.freshness = freshness
        self.sep = sep
        self.checker = checker
        self.ceiling = ceiling_m
        self._flags: dict[str, _DroneFlags] = {}
        self.lost_link_timeout_s: dict[str, float] = {}
        self._counter = 0

    def _ev(self, now: float, kind: SafetyEventKind, sev: Severity, drones: list[str], reason: ReasonCode,
            **details) -> SafetyEvent:  # type: ignore[no-untyped-def]
        self._counter += 1
        return SafetyEvent(event_id=f"ev{self._counter:05d}", time=now, kind=kind, severity=sev, drone_ids=drones,
                           reason=reason, details=details)

    def uncertain_regions(self, snap: FleetSnapshot, committed: dict[str, DronePlan],
                          plan_lease_expiry: dict[str, float], horizon_s: float) -> list[Reservation]:
        """Conservative regions for aircraft whose state is not FRESH.

        * Contract-bounded (preferred): the aircraft follows its committed plan
          only until its plan lease expires, then holds; if coordinator contact
          may have been lost long enough it then flies its *own* pre-validated
          contingency (column -> transfer -> pad).  Valid until reconciled.
        * Kinematic (fallback when no contract applies, e.g. no committed plan,
          contingency/emergency in progress): reachable cylinder over a bounded
          horizon; flagged unassessable once it exceeds the configured radius.
        """
        out: list[Reservation] = []
        for d in snap.ids():
            est = snap.drones[d]
            if est.observed_position is None or est.last_observation_time is None:
                continue
            if est.freshness == Freshness.FRESH:
                # an aircraft stopped off-plan (paused, reserve hold, failed start in the air) is an
                # obstacle to plans that assumed it would move on; reserve its position until replanned
                p = est.observed_position
                if p.z > 1.0 and est.agent_status in (AgentStatus.PAUSED, AgentStatus.RESERVE_HOLD,
                                                      AgentStatus.START_FAILED):
                    r = self.sep.tracking_tolerance_m + est.position_uncertainty + 2.0
                    out.append(Reservation(reservation_id=f"stopped/{d}", holder=d,
                                           kind=ReservationKind.UNCERTAIN_REGION,
                                           volume=Volume(kind=VolumeKind.CYLINDER, points=[(p.x, p.y)], radius_m=r,
                                                         z_min=p.z - r, z_max=p.z + r),
                                           t_start=snap.as_of, t_end=float("inf")))
                elif est.agent_status == AgentStatus.CONTINGENCY and committed.get(d) is not None:
                    c = committed[d].contingency
                    base = Reservation(reservation_id=f"contingency-start/{d}", holder=d,
                                       kind=ReservationKind.UNCERTAIN_REGION,
                                       volume=Volume(kind=VolumeKind.CYLINDER, points=[(p.x, p.y)], radius_m=8.0,
                                                     z_min=p.z - 8.0, z_max=p.z + 8.0),
                                       t_start=snap.as_of, t_end=float("inf"))
                    out += [base, *contingency_regions(d, base, c.contingency_altitude_m, c.hold_point,
                                                       c.land_position, 8.0, snap.as_of)]
                continue
            if est.flight_mode == FlightMode.ON_GROUND and est.observed_position.z < 1.0:
                continue
            dp = committed.get(d)
            exp = plan_lease_expiry.get(d)
            p = est.observed_position
            inflate = self.sep.tracking_tolerance_m + self.sep.nominal_position_uncertainty_m + 3.0
            t_obs = est.last_observation_time - est.clock_uncertainty
            age = snap.as_of - est.last_observation_time
            base: Reservation | None = None
            if dp is not None and est.agent_status in (AgentStatus.EXECUTING, AgentStatus.RECOVERING) and \
                    exp is not None:
                base = contract_region(dp.trajectory, t_obs, max(exp, t_obs) + 2.0, inflate, d)
            elif dp is not None and est.agent_status in (AgentStatus.PAUSED, AgentStatus.HOLDING,
                                                         AgentStatus.RESERVE_HOLD, AgentStatus.COMMITTED,
                                                         AgentStatus.READY):
                base = Reservation(reservation_id=f"contract/{d}", holder=d, kind=ReservationKind.UNCERTAIN_REGION,
                                   volume=Volume(kind=VolumeKind.CYLINDER, points=[(p.x, p.y)],
                                                 radius_m=inflate + 2.0, z_min=p.z - inflate, z_max=p.z + inflate),
                                   t_start=t_obs, t_end=float("inf"))
            if base is not None and dp is not None:
                out.append(base)
                if age > self.lost_link_timeout_s.get(d, 8.0) * 0.5 or est.agent_status == AgentStatus.RESERVE_HOLD:
                    c = dp.contingency
                    out += contingency_regions(d, base, c.contingency_altitude_m, c.hold_point, c.land_position,
                                               inflate, t_obs)
                continue
            if est.flight_mode == FlightMode.EMERGENCY:
                out.append(Reservation(reservation_id=f"failsafe-column/{d}", holder=d,
                                       kind=ReservationKind.UNCERTAIN_REGION,
                                       volume=Volume(kind=VolumeKind.CYLINDER, points=[(p.x, p.y)],
                                                     radius_m=inflate + 5.0, z_min=0.0, z_max=p.z + inflate),
                                       t_start=t_obs, t_end=float("inf")))
                continue
            r, _ = kinematic_region(est, snap.as_of, self.freshness, horizon_s, self.ceiling)
            if r is not None:
                out.append(r)
        return out

    def evaluate(self, snap: FleetSnapshot, committed: dict[str, DronePlan], active_plans: dict[str, Trajectory],
                 plan_lease_expiry: dict[str, float], buffers: dict[str, Buffers]) -> list[SafetyEvent]:
        now = snap.as_of
        evs: list[SafetyEvent] = []
        tasks_seen: dict[str, list[str]] = {}
        for d in snap.ids():
            est = snap.drones[d]
            f = self._flags.setdefault(d, _DroneFlags())
            if est.freshness == Freshness.NEVER_SEEN:
                continue
            # --- freshness transitions
            if est.freshness != f.freshness:
                if est.freshness == Freshness.STALE and f.freshness == Freshness.FRESH:
                    evs.append(self._ev(now, SafetyEventKind.STALE_TELEMETRY, Severity.CAUTION, [d],
                                        ReasonCode.STALE_TELEMETRY, age_s=est.age_s))
                elif est.freshness == Freshness.LOST:
                    f.lost_since = now
                    evs.append(self._ev(now, SafetyEventKind.LINK_LOST, Severity.WARNING, [d],
                                        ReasonCode.STATE_LOST, age_s=est.age_s))
                elif est.freshness == Freshness.FRESH and f.freshness in (Freshness.STALE, Freshness.LOST):
                    evs.append(self._ev(now, SafetyEventKind.LINK_RESTORED, Severity.INFO, [d],
                                        ReasonCode.LINK_RESTORED, was=f.freshness.value))
                    f.lost_since = None
                    f.dropout = False
                    f.unassessable = False
                f.freshness = est.freshness
            if est.freshness == Freshness.LOST and f.lost_since is not None and not f.dropout and \
                    now - f.lost_since > self.cfg.dropout_timeout_s:
                f.dropout = True
                evs.append(self._ev(now, SafetyEventKind.AIRCRAFT_DROPOUT, Severity.WARNING, [d],
                                    ReasonCode.AIRCRAFT_DROPOUT))
            if not est.assessable and not f.unassessable and est.freshness != Freshness.FRESH:
                f.unassessable = True
                evs.append(self._ev(now, SafetyEventKind.POSITION_UNASSESSABLE, Severity.WARNING, [d],
                                    ReasonCode.POSITION_UNASSESSABLE, radius_m=est.position_uncertainty))
            # --- battery
            if est.battery_state is not None and est.battery_state.reserve_breached and not f.reserve:
                f.reserve = True
                evs.append(self._ev(now, SafetyEventKind.BATTERY_RESERVE_BREACH, Severity.WARNING, [d],
                                    ReasonCode.BATTERY_RESERVE_BREACH,
                                    remaining_wh=est.battery_state.remaining_energy_wh))
            # --- navigation uncertainty (reported, not grown-by-age)
            if est.freshness == Freshness.FRESH and est.observed_position is not None:
                raw_u = est.position_uncertainty
                if raw_u > self.cfg.nav_uncertainty_threshold_m and not f.nav:
                    f.nav = True
                    evs.append(self._ev(now, SafetyEventKind.NAVIGATION_UNCERTAINTY, Severity.WARNING, [d],
                                        ReasonCode.NAVIGATION_UNCERTAINTY, uncertainty_m=raw_u))
                elif raw_u <= self.cfg.nav_uncertainty_threshold_m * 0.7:
                    f.nav = False
            # --- autopilot failsafe (aircraft-owned emergency action)
            if est.flight_mode == FlightMode.EMERGENCY and not f.failsafe:
                f.failsafe = True
                evs.append(self._ev(now, SafetyEventKind.AUTOPILOT_FAILSAFE, Severity.CRITICAL, [d],
                                    ReasonCode.AUTOPILOT_FAILSAFE))
            # --- trajectory deviation
            traj = active_plans.get(d)
            if traj is not None and est.freshness == Freshness.FRESH and est.agent_status in (
                    AgentStatus.EXECUTING, AgentStatus.RECOVERING) and est.observed_position is not None \
                    and est.last_observation_time is not None:
                planned = traj.position_at(est.last_observation_time)
                dev = float(np.linalg.norm(planned - est.observed_position.as_array()))
                lim = self.cfg.deviation_threshold_m + est.position_uncertainty
                if dev > lim:
                    if f.deviation_since is None:
                        f.deviation_since = now
                    elif now - f.deviation_since > self.cfg.deviation_persist_s and not f.deviation:
                        f.deviation = True
                        evs.append(self._ev(now, SafetyEventKind.TRAJECTORY_DEVIATION, Severity.WARNING, [d],
                                            ReasonCode.TRAJECTORY_DEVIATION, deviation_m=dev))
                else:
                    f.deviation_since = None
                    f.deviation = False
            if est.active_task_id and not est.active_task_id.startswith("__plan__"):
                tasks_seen.setdefault(est.active_task_id, []).append(d)
        for tid in sorted(tasks_seen):
            owners = tasks_seen[tid]
            if len(owners) > 1:
                evs.append(self._ev(now, SafetyEventKind.OWNERSHIP_CONFLICT, Severity.CRITICAL, sorted(owners),
                                    ReasonCode.OWNERSHIP_CONFLICT, task_id=tid))
        # --- predicted conflicts with uncertain aircraft
        regions = self.uncertain_regions(snap, committed, plan_lease_expiry, 20.0)
        for r in regions:
            f = self._flags.setdefault(r.holder, _DroneFlags())
            for d in sorted(active_plans):
                if d == r.holder:
                    continue
                conf = self.checker.reservations(active_plans[d], [r], buffers.get(d, self.checker.default_buffers),
                                                 t_from=now)
                conf = [c for c in conf if c.t_start <= now + 20.0]
                if conf and d not in f.predicted:
                    f.predicted.add(d)
                    evs.append(self._ev(now, SafetyEventKind.PREDICTED_CONFLICT, Severity.WARNING, [d, r.holder],
                                        ReasonCode.UNCERTAIN_REGION_CONFLICT, region=r.reservation_id,
                                        t_start=conf[0].t_start))
                elif not conf:
                    f.predicted.discard(d)
        return evs
