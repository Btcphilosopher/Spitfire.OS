"""Command-line interface.

    spitfire-sync demo      [--config PATH] [--seed N] [--out DIR] [--realtime --speed X]
    spitfire-sync evaluate  [--config PATH] [--seeds 1-20] [--drones N] [--allocator greedy|optimal] [--workers N]
    spitfire-sync validate-config PATH
    spitfire-sync playback  DIR/trace.json [--speed X]
    spitfire-sync sitl-check [--url udp://:14540] [--enable]

Exit codes: 0 success, 1 run completed with findings/errors, 2 usage error.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
import time
from pathlib import Path

from .config import ScenarioFile, load_scenario

DEFAULT_CONFIG = Path(__file__).resolve().parents[2] / "configs" / "demo_agricultural.toml"


def _scenario(path: str | None) -> ScenarioFile:
    p = Path(path) if path else DEFAULT_CONFIG
    if not p.exists():
        return ScenarioFile()
    return load_scenario(p)


def _parse_seeds(s: str) -> list[int]:
    out: list[int] = []
    for part in s.split(","):
        if "-" in part:
            a, b = part.split("-")
            out += list(range(int(a), int(b) + 1))
        elif part:
            out.append(int(part))
    return out


def cmd_demo(a: argparse.Namespace) -> int:
    from .evaluation.plots import make_all
    from .evaluation.report import write_run_report
    from .simulation.simulator import run_realtime, run_simulation

    sc = _scenario(a.config)
    out = Path(a.out)
    t0 = time.perf_counter()
    res = run_realtime(sc, seed=a.seed, speed=a.speed) if a.realtime else run_simulation(sc, seed=a.seed)
    figs = make_all(res, out)
    data = write_run_report(res, out, figs)
    s = data["summary"]
    print(f"[spitfire-sync] seed {res.seed}: {data['metrics']['tasks_completed']} tasks, coverage "
          f"{s['coverage_fraction'] * 100:.1f} %, min true separation {s['min_true_separation_m']:.1f} m, "
          f"max start error {s['sync_start_abs_max_s'] * 1000:.2f} ms, wall {time.perf_counter() - t0:.1f} s")
    for c in data["checklist"]:
        print(f"  {c['step']:>2}. [{'x' if c['demonstrated'] else ' '}] {c['title']}: {c['evidence']}")
    print(f"[spitfire-sync] report: {out / 'report.md'}")
    return 0 if not res.errors else 1


def cmd_evaluate(a: argparse.Namespace) -> int:
    from .evaluation.report import evaluate_seeds

    sc = _scenario(a.config)
    if a.drones:
        sc = sc.model_copy(update={"simulation": sc.simulation.model_copy(update={"n_drones": a.drones})})
    res = evaluate_seeds(sc, _parse_seeds(a.seeds), Path(a.out), workers=a.workers, allocator=a.allocator)
    print(Path(a.out, "evaluation.md").read_text())
    return 0 if all(r["errors"] == 0 for r in res["per_seed"]) else 1


def cmd_validate(a: argparse.Namespace) -> int:
    from .contingencies.policy import FindingSeverity, validate_fleet
    from .simulation.scenario import build_mission, fleet_config
    from .scheduling.scheduler import Scheduler
    from .separation.conflicts import ConflictChecker

    sc = load_scenario(a.path)
    system = fleet_config(sc.simulation, sc.system)
    mission = build_mission(sc.simulation, system)
    sch = Scheduler(mission, system, ConflictChecker(system.separation, mission))
    ids = [p.drone_id for p in system.fleet]
    alts = {d: (sch.contingency_altitude(d, ids) if system.profile(d).contingency.lost_link_action.value !=
                "LAND_IN_PLACE" else None) for d in ids}
    findings = validate_fleet(system, mission.ceiling_m, alts, system.separation.vertical_m)
    print(f"configuration OK: {len(mission.tasks)} lanes, {len(ids)} aircraft")
    for f in findings:
        print(f"  {f.severity.value:<7} {f.drone_id or '-':<9} {f.check:<22} {f.message}")
    return 1 if any(f.severity == FindingSeverity.ERROR for f in findings) else 0


def cmd_playback(a: argparse.Namespace) -> int:
    data = json.loads(Path(a.trace).read_text())
    events = [e for e in data["timeline"] if e["t_s"] is not None]
    t_prev = 0.0
    for e in events:
        dt = (e["t_s"] - t_prev) / a.speed
        if dt > 0:
            time.sleep(min(dt, 5.0))
        t_prev = e["t_s"]
        print(f"t={e['t_s']:8.1f}s  {e['event']:<28} {e['aircraft'] or '':<9} {e['reason']}")
    return 0


def cmd_sitl(a: argparse.Namespace) -> int:
    from .adapters.base import AdapterDisabledError
    from .adapters.mavsdk_adapter import MavsdkAdapter, MavsdkAdapterConfig
    from .models.frames import GeodeticPosition

    cfg = MavsdkAdapterConfig(enabled=a.enable, mode="sitl", connection_url=a.url)
    try:
        ad = MavsdkAdapter(cfg, GeodeticPosition(latitude_deg=a.lat, longitude_deg=a.lon, height_m=a.alt),
                           time.monotonic)
    except AdapterDisabledError as exc:
        print(f"adapter not started: {exc}")
        return 1

    async def go() -> int:
        await ad.connect()
        for _ in range(10):
            await asyncio.sleep(0.5)
            print(ad.navigation(), ad.flight_mode(), ad.armed(), ad.battery())
        print("autopilot params:", ad.autopilot_params())
        await ad.close()
        return 0

    return asyncio.run(go())


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="spitfire-sync", description="SPITFIRE.OS drone synchronisation core")
    sub = p.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("demo", help="run the reproducible six-aircraft demonstration")
    d.add_argument("--config")
    d.add_argument("--seed", type=int, default=None)
    d.add_argument("--out", default="results/demo")
    d.add_argument("--realtime", action="store_true", help="wall-clock paced playback instead of virtual time")
    d.add_argument("--speed", type=float, default=1.0)
    d.set_defaults(fn=cmd_demo)
    e = sub.add_parser("evaluate", help="multi-seed evaluation")
    e.add_argument("--config")
    e.add_argument("--seeds", default="1-10")
    e.add_argument("--drones", type=int, default=None)
    e.add_argument("--allocator", choices=["greedy", "optimal"], default=None)
    e.add_argument("--workers", type=int, default=1)
    e.add_argument("--out", default="results/evaluation")
    e.set_defaults(fn=cmd_evaluate)
    v = sub.add_parser("validate-config", help="validate a scenario and contingency/autopilot settings")
    v.add_argument("path")
    v.set_defaults(fn=cmd_validate)
    pb = sub.add_parser("playback", help="replay a recorded event timeline at real-time pace")
    pb.add_argument("trace")
    pb.add_argument("--speed", type=float, default=10.0)
    pb.set_defaults(fn=cmd_playback)
    s = sub.add_parser("sitl-check", help="connect the (disabled-by-default) MAVSDK adapter to a SITL instance")
    s.add_argument("--url", default="udp://:14540")
    s.add_argument("--enable", action="store_true")
    s.add_argument("--lat", type=float, default=47.397742)
    s.add_argument("--lon", type=float, default=8.545594)
    s.add_argument("--alt", type=float, default=488.0)
    s.set_defaults(fn=cmd_sitl)
    a = p.parse_args(argv)
    return int(a.fn(a))


if __name__ == "__main__":
    sys.exit(main())
