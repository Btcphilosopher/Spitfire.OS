"""Task-assignment cost function.

For aircraft *d* (with current commitments) and lane task *k*:

    cost(d, k) = w_travel  * travel_time(d.end_position -> nearer end of k)
               + w_dur     * duration(k)
               + w_battery * (E_needed / E_available)^2
               + w_commit  * committed_time(d)

* travel_time uses route length around exclusion zones at transit speed plus
  climb/descent time;
* E_needed = energy(travel + lane + return-to-recovery) * planning margin;
  E_available = remaining energy - reserve_fraction * capacity;
* cost is +inf (with a reason code) when the payload is incompatible, the
  aircraft is unavailable, or E_needed > E_available (reserve would be breached).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from ..config import AllocationWeights, ConstraintsConfig, DroneProfile
from ..models.mission import Mission, MissionTask
from ..models.state import AgentStatus, EstimatedDroneState, FleetSnapshot, Freshness
from ..reasons import ReasonCode
from ..scheduling.routing import Router
from .energy import EnergyModel

AVAILABLE_STATUSES = {AgentStatus.IDLE, AgentStatus.READY, AgentStatus.COMMITTED, AgentStatus.EXECUTING,
                      AgentStatus.HOLDING, AgentStatus.PAUSED}


@dataclass
class DroneCommitment:
    drone_id: str
    position: tuple[float, float, float]
    available_from: float
    energy_available_wh: float  # remaining minus reserve
    on_ground: bool
    task_ids: list[str] = field(default_factory=list)
    committed_time_s: float = 0.0


@dataclass(frozen=True)
class CostEstimate:
    cost: float
    reversed: bool
    travel_s: float
    duration_s: float
    energy_wh: float
    reason: ReasonCode = ReasonCode.OK

    @property
    def feasible(self) -> bool:
        return math.isfinite(self.cost)


def availability(est: EstimatedDroneState | None) -> ReasonCode:
    if est is None:
        return ReasonCode.NEVER_SEEN
    if est.freshness != Freshness.FRESH or not est.assessable:
        return ReasonCode.AIRCRAFT_NOT_AVAILABLE
    if est.battery_state is not None and est.battery_state.reserve_breached:
        return ReasonCode.BATTERY_RESERVE_BREACH
    if est.agent_status not in AVAILABLE_STATUSES:
        return ReasonCode.AIRCRAFT_NOT_AVAILABLE
    return ReasonCode.OK


def commitments_from_snapshot(snapshot: FleetSnapshot, profiles: dict[str, DroneProfile],
                              constraints: ConstraintsConfig, start_time: float) -> dict[str, DroneCommitment]:
    out: dict[str, DroneCommitment] = {}
    for d in snapshot.ids():
        est = snapshot.drones[d]
        if d not in profiles or est.position is None or est.battery_state is None:
            continue
        cap = profiles[d].energy.capacity_wh
        out[d] = DroneCommitment(
            drone_id=d, position=(est.position.x, est.position.y, est.position.z), available_from=start_time,
            energy_available_wh=est.battery_state.remaining_energy_wh - constraints.reserve_fraction * cap,
            on_ground=est.position.z < 1.0,
        )
    return out


class CostModel:
    def __init__(self, mission: Mission, weights: AllocationWeights, constraints: ConstraintsConfig,
                 profiles: dict[str, DroneProfile], router: Router) -> None:
        self.mission = mission
        self.w = weights
        self.constraints = constraints
        self.profiles = profiles
        self.router = router
        self._route_cache: dict[tuple, float] = {}
        transit = mission.bands("transit")
        self.cruise_alt = transit[0].centre_m if transit else 60.0

    def _route_len(self, a: tuple[float, float], b: tuple[float, float]) -> float:
        key = (round(a[0]), round(a[1]), round(b[0]), round(b[1]))
        if key not in self._route_cache:
            self._route_cache[key] = self.router.route_length(a, b, self.cruise_alt)
        return self._route_cache[key]

    def estimate(self, c: DroneCommitment, task: MissionTask) -> CostEstimate:
        prof = self.profiles.get(c.drone_id)
        if prof is None:
            return CostEstimate(math.inf, False, 0, 0, 0, ReasonCode.AIRCRAFT_NOT_AVAILABLE)
        if task.payload_required not in prof.payloads:
            return CostEstimate(math.inf, False, 0, 0, 0, ReasonCode.PAYLOAD_INCOMPATIBLE)
        if len(c.task_ids) >= self.constraints.max_tasks_per_aircraft:
            return CostEstimate(math.inf, False, 0, 0, 0, ReasonCode.AIRCRAFT_NOT_AVAILABLE)
        em = EnergyModel(prof.energy)
        lim = prof.limits
        here = (c.position[0], c.position[1])
        d_fwd = self._route_len(here, task.start_xy)
        d_rev = self._route_len(here, task.end_xy) if (task.reversible and self.constraints.allow_lane_reversal) \
            else math.inf
        reversed_ = d_rev < d_fwd
        d = min(d_fwd, d_rev)
        if not math.isfinite(d):
            return CostEstimate(math.inf, False, 0, 0, 0, ReasonCode.ROUTE_BLOCKED)
        survey_alt = self.mission.band(task.permitted_bands[0]).centre_m
        climb = max(self.cruise_alt - c.position[2], 0.0)
        travel_s = d / lim.transit_speed_m_s + climb / lim.max_climb_m_s + (self.cruise_alt - survey_alt) / lim.max_descent_m_s
        duration_s = task.nominal_duration_s
        exit_xy = task.start_xy if reversed_ else task.end_xy
        rec = self.mission.recovery_area.centre_xy
        e = em.leg_energy_wh(d, climb, lim.transit_speed_m_s) + em.leg_energy_wh(task.length_m, 0.0,
                                                                                  task.survey_speed_m_s)
        e *= prof.energy.planning_margin
        e_return = em.recover_energy_wh(exit_xy[0], exit_xy[1], survey_alt, rec, self.cruise_alt,
                                        lim.transit_speed_m_s)
        needed = e + e_return
        if needed > c.energy_available_wh:
            return CostEstimate(math.inf, reversed_, travel_s, duration_s, e, ReasonCode.BATTERY_RESERVE_INSUFFICIENT)
        ratio = needed / max(c.energy_available_wh, 1e-6)
        cost = (self.w.travel_s * travel_s + self.w.duration_s * duration_s + self.w.battery_penalty * ratio**2
                + self.w.commitment_s * c.committed_time_s)
        return CostEstimate(cost, reversed_, travel_s, duration_s, e)

    def apply(self, c: DroneCommitment, task: MissionTask, est: CostEstimate) -> DroneCommitment:
        exit_xy = task.start_xy if est.reversed else task.end_xy
        alt = self.mission.band(task.permitted_bands[0]).centre_m
        return DroneCommitment(
            drone_id=c.drone_id, position=(exit_xy[0], exit_xy[1], alt),
            available_from=c.available_from + est.travel_s + est.duration_s,
            energy_available_wh=c.energy_available_wh - est.energy_wh, on_ground=False,
            task_ids=[*c.task_ids, task.task_id], committed_time_s=c.committed_time_s + est.travel_s + est.duration_s,
        )
