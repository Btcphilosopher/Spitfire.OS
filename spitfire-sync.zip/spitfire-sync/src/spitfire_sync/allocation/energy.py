"""Configurable energy-use model (a *simulation assumption*).

    P(v_air, w) = P_hover * (1 + c * (v_air / v_ref)^2) + max(w, 0) * m * g / eta

with v_air the airspeed and w the climb rate.  Descent is not regenerative.
This is a planning heuristic with an explicit margin; it is not an aircraft
endurance model and must never be presented as an endurance guarantee.
"""

from __future__ import annotations

import math

import numpy as np

from ..config import EnergyModelConfig
from ..models.trajectory import Trajectory

G = 9.80665


class EnergyModel:
    def __init__(self, cfg: EnergyModelConfig) -> None:
        self.cfg = cfg

    def power_w(self, airspeed: float, climb_rate: float) -> float:
        c = self.cfg
        return c.hover_power_w * (1.0 + c.speed_coeff * (airspeed / c.v_ref_m_s) ** 2) + max(climb_rate, 0.0) * (
            c.mass_kg * G / c.climb_efficiency
        )

    def trajectory_energy_wh(self, traj: Trajectory, t_from: float | None = None,
                             wind_xy: tuple[float, float] = (0.0, 0.0)) -> float:
        T, P = traj.arrays()
        if len(T) < 2:
            return 0.0
        dt = np.diff(T)
        dP = np.diff(P, axis=0)
        mask = traj.airborne_mask()
        if t_from is not None:
            mask &= T[1:] > t_from
        safe = np.where(dt > 0, dt, 1.0)
        v = dP / safe[:, None]
        air = v[:, :2] - np.asarray(wind_xy)[None, :]
        airspeed = np.linalg.norm(air, axis=1)
        climb = v[:, 2]
        c = self.cfg
        p = c.hover_power_w * (1 + c.speed_coeff * (airspeed / c.v_ref_m_s) ** 2) + np.maximum(climb, 0) * (
            c.mass_kg * G / c.climb_efficiency)
        return float((p * dt)[mask].sum() / 3600.0)

    def leg_energy_wh(self, horizontal_m: float, dz_m: float, speed: float, climb: float = 3.0,
                      descent: float = 2.0) -> float:
        t_h = horizontal_m / max(speed, 0.1)
        t_v = dz_m / climb if dz_m > 0 else -dz_m / descent
        e = self.power_w(speed, 0.0) * t_h + self.power_w(0.0, climb if dz_m > 0 else 0.0) * t_v
        return e / 3600.0

    def recover_energy_wh(self, x: float, y: float, z: float, target_xy: tuple[float, float],
                          cruise_alt: float, speed: float) -> float:
        """Energy to climb to cruise_alt, fly to target and descend (planning margin applied)."""
        d = math.hypot(target_xy[0] - x, target_xy[1] - y)
        e = self.leg_energy_wh(0.0, max(cruise_alt - z, 0.0), speed)
        e += self.leg_energy_wh(d, 0.0, speed)
        e += self.leg_energy_wh(0.0, -cruise_alt, speed)
        return e * self.cfg.planning_margin

    def capacity_wh(self) -> float:
        return self.cfg.capacity_wh
