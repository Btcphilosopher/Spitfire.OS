"""Task allocators: deterministic greedy baseline and an optional optimiser."""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np
from scipy.optimize import linear_sum_assignment

from ..config import ConstraintsConfig
from ..models.mission import MissionTask
from ..models.state import FleetSnapshot
from ..reasons import ReasonCode
from .cost import CostEstimate, CostModel, DroneCommitment, availability, commitments_from_snapshot


@dataclass(frozen=True)
class TaskAssignment:
    task_id: str
    reversed: bool
    cost: float


@dataclass
class Assignment:
    method: str
    per_drone: dict[str, list[TaskAssignment]] = field(default_factory=dict)
    unassigned: dict[str, ReasonCode] = field(default_factory=dict)
    excluded_drones: dict[str, ReasonCode] = field(default_factory=dict)
    total_cost: float = 0.0
    makespan_estimate_s: float = 0.0

    def owner_of(self, task_id: str) -> str | None:
        for d, lst in self.per_drone.items():
            if any(t.task_id == task_id for t in lst):
                return d
        return None

    def task_ids(self) -> list[str]:
        return [t.task_id for d in sorted(self.per_drone) for t in self.per_drone[d]]


# when no aircraft can take a task, report the most informative reason
_REASON_RANK = {ReasonCode.PAYLOAD_INCOMPATIBLE: 1, ReasonCode.AIRCRAFT_NOT_AVAILABLE: 2, ReasonCode.ROUTE_BLOCKED: 3,
                ReasonCode.BATTERY_RESERVE_INSUFFICIENT: 4}


def _eligible(fleet: FleetSnapshot, commitments: dict[str, DroneCommitment], a: Assignment) -> list[str]:
    out = []
    for d in sorted(commitments):
        reason = availability(fleet.get(d))
        if reason != ReasonCode.OK:
            a.excluded_drones[d] = reason
        else:
            out.append(d)
    return out


class GreedyAllocator:
    """Repeatedly assign the globally cheapest feasible (aircraft, task) pair.

    Deterministic: ties break on (cost, drone_id, task_id); no randomness."""

    name = "greedy"

    def __init__(self, cost_model: CostModel) -> None:
        self.cm = cost_model

    def assign(self, tasks: list[MissionTask], fleet: FleetSnapshot, constraints: ConstraintsConfig,
               commitments: dict[str, DroneCommitment] | None = None) -> Assignment:
        commitments = commitments or commitments_from_snapshot(fleet, self.cm.profiles, constraints, fleet.as_of)
        a = Assignment(method=self.name)
        drones = _eligible(fleet, commitments, a)
        com = {d: commitments[d] for d in drones}
        pending = sorted(tasks, key=lambda t: (-t.priority, t.task_id))
        a.per_drone = {d: [] for d in drones}
        last_reason: dict[str, ReasonCode] = {}
        while pending:
            best: tuple[float, str, str] | None = None
            best_est: CostEstimate | None = None
            for d in drones:
                for t in pending:
                    est = self.cm.estimate(com[d], t)
                    if not est.feasible:
                        prev = last_reason.get(t.task_id)
                        if prev is None or _REASON_RANK.get(est.reason, 0) > _REASON_RANK.get(prev, 0):
                            last_reason[t.task_id] = est.reason
                        continue
                    key = (est.cost, d, t.task_id)
                    if best is None or key < best:
                        best, best_est = key, est
            if best is None or best_est is None:
                break
            _, d, tid = best
            task = next(t for t in pending if t.task_id == tid)
            a.per_drone[d].append(TaskAssignment(tid, best_est.reversed, best_est.cost))
            a.total_cost += best_est.cost
            com[d] = self.cm.apply(com[d], task, best_est)
            pending = [t for t in pending if t.task_id != tid]
        for t in pending:
            a.unassigned[t.task_id] = last_reason.get(t.task_id, ReasonCode.NO_AVAILABLE_AIRCRAFT)
        a.makespan_estimate_s = max((c.committed_time_s for c in com.values()), default=0.0)
        return a


class OptimisingAllocator:
    """Optional optimiser: rounds of Hungarian assignment (each aircraft takes
    at most one task per round, minimising the round's total cost), followed
    by deterministic local search (move / swap) minimising
    makespan + lambda * total travel.  Falls back to greedy if no round makes
    progress."""

    name = "optimal"

    def __init__(self, cost_model: CostModel, local_search_iters: int = 200, lam: float = 0.2) -> None:
        self.cm = cost_model
        self.iters = local_search_iters
        self.lam = lam

    def _evaluate(self, order: dict[str, list[MissionTask]], base: dict[str, DroneCommitment]
                  ) -> tuple[float, dict[str, list[TaskAssignment]], float] | None:
        out: dict[str, list[TaskAssignment]] = {}
        makespan, total = 0.0, 0.0
        for d in sorted(order):
            c = base[d]
            out[d] = []
            for t in order[d]:
                est = self.cm.estimate(c, t)
                if not est.feasible:
                    return None
                out[d].append(TaskAssignment(t.task_id, est.reversed, est.cost))
                total += est.travel_s
                c = self.cm.apply(c, t, est)
            makespan = max(makespan, c.committed_time_s)
        return makespan + self.lam * total, out, makespan

    def assign(self, tasks: list[MissionTask], fleet: FleetSnapshot, constraints: ConstraintsConfig,
               commitments: dict[str, DroneCommitment] | None = None) -> Assignment:
        commitments = commitments or commitments_from_snapshot(fleet, self.cm.profiles, constraints, fleet.as_of)
        a = Assignment(method=self.name)
        drones = _eligible(fleet, commitments, a)
        com = {d: commitments[d] for d in drones}
        order: dict[str, list[MissionTask]] = {d: [] for d in drones}
        pending = sorted(tasks, key=lambda t: t.task_id)
        while pending and drones:
            C = np.full((len(drones), len(pending)), 1e12)
            ests: dict[tuple[int, int], CostEstimate] = {}
            for i, d in enumerate(drones):
                for j, t in enumerate(pending):
                    e = self.cm.estimate(com[d], t)
                    if e.feasible:
                        C[i, j] = e.cost
                        ests[(i, j)] = e
            rows, cols = linear_sum_assignment(C)
            progressed = False
            taken = set()
            for i, j in sorted(zip(rows.tolist(), cols.tolist())):
                if (i, j) not in ests:
                    continue
                d, t = drones[i], pending[j]
                order[d].append(t)
                com[d] = self.cm.apply(com[d], t, ests[(i, j)])
                taken.add(t.task_id)
                progressed = True
            pending = [t for t in pending if t.task_id not in taken]
            if not progressed:
                break
        base = {d: commitments[d] for d in drones}
        cur = self._evaluate(order, base)
        if cur is None:
            return GreedyAllocator(self.cm).assign(tasks, fleet, constraints, commitments)
        best_val, best_out, best_mk = cur
        improved = True
        it = 0
        while improved and it < self.iters:
            improved = False
            it += 1
            for d1 in drones:
                for i1 in range(len(order[d1])):
                    for d2 in drones:
                        if d2 == d1:
                            continue
                        # move task i1 of d1 to the end of d2
                        cand = {k: list(v) for k, v in order.items()}
                        t = cand[d1].pop(i1)
                        cand[d2].append(t)
                        r = self._evaluate(cand, base)
                        if r is not None and r[0] < best_val - 1e-6:
                            order, (best_val, best_out, best_mk), improved = cand, r, True
                            break
                    if improved:
                        break
                if improved:
                    break
        a.per_drone = best_out
        a.total_cost = sum(t.cost for v in best_out.values() for t in v)
        a.makespan_estimate_s = best_mk
        for t in pending:
            a.unassigned[t.task_id] = ReasonCode.NO_AVAILABLE_AIRCRAFT
        if math.isinf(a.total_cost):
            a.total_cost = float("nan")
        return a


def make_allocator(name: str, cost_model: CostModel) -> GreedyAllocator | OptimisingAllocator:
    if name == "optimal":
        return OptimisingAllocator(cost_model)
    return GreedyAllocator(cost_model)
