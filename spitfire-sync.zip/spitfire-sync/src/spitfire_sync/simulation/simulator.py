"""Seeded simulator: world truth + simulated network + aircraft agents +
coordinator.  The coordinator only sees what arrives through simulated
telemetry; ground truth is used exclusively by :mod:`spitfire_sync.evaluation`.

Two time modes:
* accelerated: run inside :class:`VirtualTimeEventLoop` (``run_simulation``)
  - deterministic for a given seed;
* real-time playback: a normal asyncio loop with ``Timebase(speed)``
  (``run_realtime``) - same code path, wall-clock paced, not bit-reproducible.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, Callable

import numpy as np

from ..adapters.sim_adapter import SimAdapter
from ..clocks.clock import SimulatedClock
from ..clocks.timebase import Timebase
from ..clocks.virtual_loop import run_virtual
from ..config import ScenarioFile, SimulationConfig, SpitfireConfig
from ..coordination.agent import AgentRecord, DroneAgent
from ..coordination.coordinator import Coordinator, CoordinatorRecord, EpochStore
from ..coordination.guard import Role
from ..coordination.mission_runner import MissionOutcome, MissionRunner
from ..models.geometry import Polygon2D
from ..models.mission import ExclusionZone, Mission
from ..transport.auth import HmacAuthenticator, derive_demo_keys
from ..transport.base import MessageCodec
from ..transport.sim_network import LinkEpisode, LinkProfile, SimNetwork
from .scenario import build_mission, drone_ids, fleet_config, sim_specs
from .world import SimAircraft, TruthSample, Wind, World

COORDINATOR_ID = "coordinator"


@dataclass
class SimulationResult:
    seed: int
    system: SpitfireConfig
    sim: SimulationConfig
    mission: Mission
    outcome: MissionOutcome | None
    truth: dict[str, list[TruthSample]]
    agent_records: dict[str, list[AgentRecord]]
    coordinator_record: CoordinatorRecord
    coordinator_epoch: int
    coord_world_of: Callable[[float], float]
    agent_world_of: dict[str, list[tuple[str, Callable[[float], float]]]]
    network_stats: dict[str, Any]
    link_episodes: list[LinkEpisode]
    sim_duration_s: float
    wall_time_s: float
    ingest_stats: dict[str, Any]
    energy_used_wh: dict[str, float]
    distance_m: dict[str, float]
    landed_events: dict[str, list[float]]
    aircraft_specs: dict[str, Any]
    guard_rejections: dict[str, dict[str, int]] = field(default_factory=dict)
    shutdown_clean: bool = True
    errors: list[str] = field(default_factory=list)
    committed_plans: dict[str, list[Any]] = field(default_factory=dict)
    task_registry: dict[str, Any] = field(default_factory=dict)
    world_coord_of: Callable[[float], float] | None = None
    coordinator_timeline: list[Any] = field(default_factory=list)


class Simulator:
    def __init__(self, scenario: ScenarioFile) -> None:
        self.scenario = scenario

    async def run(self, mission: Mission | None = None, coordinator: Any = None, seed: int | None = None,
                  speed: float = 1.0) -> SimulationResult:
        """Run one mission.  ``coordinator`` may be a callable
        ``(defaults: dict) -> Coordinator`` to substitute a custom coordinator."""
        sim = self.scenario.simulation
        if seed is not None:
            sim = sim.model_copy(update={"seed": seed})
        system = fleet_config(sim, self.scenario.system)
        mission = mission or build_mission(sim, system)
        wall0 = time.perf_counter()
        tb = Timebase(speed)
        tb.start()
        ids = drone_ids(sim.n_drones)
        specs = sim_specs(sim)
        episodes = [LinkEpisode(node_id=e["node_id"], start_s=e["start_s"], end_s=e["end_s"],
                                profile=LinkProfile(**e.get("profile", {})), label=e.get("label", "degraded"))
                    for e in sim.link_episodes]
        net = SimNetwork(tb, sim.seed, LinkProfile(**sim.network_default), episodes)
        keys = derive_demo_keys([COORDINATOR_ID, *ids], sim.seed)
        roles = {COORDINATOR_ID: Role.COORDINATOR, **{d: Role.AIRCRAFT for d in ids}}
        rng_master = np.random.default_rng(sim.seed)
        # --- coordinator
        cclock = SimulatedClock(tb, COORDINATOR_ID, drift_ppm=5.0, mono_offset=4_321.0, utc_offset=0.2)
        epoch_store = EpochStore()
        codec_c = MessageCodec(HmacAuthenticator(keys, COORDINATOR_ID))
        if callable(coordinator):
            coord = coordinator(dict(node_id=COORDINATOR_ID, clock=cclock, transport=net.endpoint(COORDINATOR_ID, cclock),
                                     codec=codec_c, config=system, mission=mission, fleet_ids=ids, roles=roles,
                                     epoch_store=epoch_store))
        else:
            coord = Coordinator(COORDINATOR_ID, cclock, net.endpoint(COORDINATOR_ID, cclock), codec_c, system, mission, ids,
                                roles, epoch_store)
        runner = MissionRunner(coord, mission, system)
        runner.max_duration_s = sim.duration_limit_s
        # --- aircraft + agents
        aircraft: dict[str, SimAircraft] = {}
        clocks: dict[str, SimulatedClock] = {}
        agents: dict[str, DroneAgent] = {}
        agent_records: dict[str, list[AgentRecord]] = {d: [] for d in ids}
        agent_world_of: dict[str, list[tuple[str, Callable[[float], float]]]] = {d: [] for d in ids}
        for i, d in enumerate(ids):
            spec = specs[d]
            clk = SimulatedClock(tb, d, drift_ppm=spec.clock_drift_ppm, mono_offset=spec.mono_offset_s,
                                 utc_offset=spec.utc_offset_s)
            clocks[d] = clk
            pad = mission.pad(d).position.as_array()
            ac = SimAircraft(d, system.profile(d), spec, pad, clk, np.random.default_rng(sim.seed * 101 + i))
            aircraft[d] = ac

        def make_agent(d: str) -> DroneAgent:
            codec = MessageCodec(HmacAuthenticator({d: keys[d], COORDINATOR_ID: keys[COORDINATOR_ID]}, d))
            ag = DroneAgent(d, clocks[d], net.endpoint(d, clocks[d]), codec, system, system.profile(d),
                            SimAdapter(aircraft[d], tb.now), COORDINATOR_ID, roles, tick_s=sim.agent_tick_s)
            agent_records[d].append(ag.record)
            c = clocks[d]
            boot_world, drift, off = c._boot_world, c.drift, c.mono_offset
            agent_world_of[d].append((c.boot_id, lambda m, bw=boot_world, dr=drift, o=off: bw + (m - o) / (1 + dr)))
            return ag

        for d in ids:
            agents[d] = make_agent(d)
        world = World(tb, aircraft, Wind(sim.wind, np.random.default_rng(sim.seed * 31 + 7)), sim.physics_dt_s)
        # --- tasks
        errors: list[str] = []
        agent_tasks: dict[str, asyncio.Task] = {d: asyncio.ensure_future(agents[d].run()) for d in ids}
        world_task = asyncio.ensure_future(world.run())
        coord_task = asyncio.ensure_future(coord.run())
        runner_task = asyncio.ensure_future(runner.run())

        async def faults() -> None:
            events: list[tuple[float, str, Any]] = []
            for d in ids:
                if specs[d].reboot_at_s is not None:
                    events.append((specs[d].reboot_at_s, "reboot", d))
            for ob in sim.obstructions:
                events.append((ob.at_s, "obstruction", ob))
            if sim.coordinator_crash_at_s is not None:
                events.append((sim.coordinator_crash_at_s, "crash", None))
            for t_ev, kind, arg in sorted(events, key=lambda e: (e[0], e[1])):
                await tb.sleep(max(0.0, t_ev - tb.now()))
                if kind == "reboot":
                    d = arg
                    agents[d].stop()
                    await agent_tasks[d]
                    clocks[d].reboot(new_mono_offset=float(rng_master.random() * 100.0))
                    agents[d] = make_agent(d)
                    agent_tasks[d] = asyncio.ensure_future(agents[d].run())
                elif kind == "obstruction":
                    zone = ExclusionZone(zone_id=arg.zone_id, polygon=Polygon2D(vertices=list(arg.vertices)),
                                         floor_m=arg.floor_m, ceiling_m=arg.ceiling_m, reason="reported obstruction")
                    await runner.report_obstruction(zone)
                elif kind == "crash":
                    coord.stop()
                    runner._done = True
                    net.set_node_down(COORDINATOR_ID, True)

        fault_task = asyncio.ensure_future(faults())
        outcome: MissionOutcome | None = None
        try:
            outcome = await asyncio.wait_for(runner_task, timeout=(sim.duration_limit_s + 60.0) / speed)
        except TimeoutError:
            errors.append("duration limit reached")
        except Exception as exc:  # surfaced in the result, never swallowed silently
            errors.append(f"runner error: {exc!r}")
            import traceback

            errors.append(traceback.format_exc())
        # allow aircraft still flying their own contingency to finish (bounded)
        t_end = tb.now()
        if sim.coordinator_crash_at_s is not None:
            while tb.now() - t_end < 240.0 and not all(a.mode.value == "ON_GROUND" for a in aircraft.values()):
                await tb.sleep(1.0)
        # --- clean shutdown
        coord.stop()
        for ag in agents.values():
            ag.stop()
        world.running = False
        fault_task.cancel()
        pending = [coord_task, world_task, fault_task, *agent_tasks.values()]
        done, not_done = await asyncio.wait(pending, timeout=10.0 / speed)
        clean = not not_done
        for t in not_done:
            t.cancel()
        for t in done:
            if not t.cancelled() and t.exception() is not None and t is not fault_task:
                errors.append(f"task error: {t.exception()!r}")
        errors.extend(runner.errors)
        sim_duration = tb.now()
        stats = {f"{a}->{b}": {"sent": s.sent, "dropped": s.dropped, "duplicated": s.duplicated,
                               "delivered": s.delivered,
                               "latency_p50": float(np.median(s.latencies)) if s.latencies else None,
                               "latency_p95": float(np.percentile(s.latencies, 95)) if s.latencies else None}
                 for (a, b), s in sorted(net.stats.items())}
        off = coord.timescale._offset
        return SimulationResult(
            seed=sim.seed, system=system, sim=sim, mission=runner.mission, outcome=outcome,
            truth={d: aircraft[d].log for d in ids}, agent_records=agent_records,
            coordinator_record=coord.record, coordinator_epoch=coord.epoch,
            coord_world_of=lambda tc: cclock.world_time_of_local(tc - off), agent_world_of=agent_world_of,
            network_stats=stats, link_episodes=episodes, sim_duration_s=sim_duration,
            wall_time_s=time.perf_counter() - wall0,
            ingest_stats={d: vars(s) for d, s in coord.state.ingestor.stats.items()},
            energy_used_wh={d: aircraft[d].energy_used_wh for d in ids},
            distance_m={d: aircraft[d].distance_m for d in ids},
            landed_events={d: aircraft[d].landed_events for d in ids},
            aircraft_specs={d: specs[d].model_dump() for d in ids},
            guard_rejections={"coordinator": {k.value: v for k, v in coord.guard.rejections.items()},
                              **{d: {k.value: v for k, v in agents[d].guard.rejections.items()} for d in ids}},
            shutdown_clean=clean, errors=errors, committed_plans={d: list(h) for d, h in coord.plan_history.items()},
            task_registry=dict(runner.tasks), coordinator_timeline=list(runner.timeline),
            world_coord_of=lambda tw: cclock.mono_offset + (tw - cclock._boot_world) * (1 + cclock.drift) + off,
        )


def run_simulation(scenario: ScenarioFile, seed: int | None = None) -> SimulationResult:
    """Accelerated, deterministic run in virtual time."""
    return run_virtual(lambda: Simulator(scenario).run(seed=seed))


def run_realtime(scenario: ScenarioFile, seed: int | None = None, speed: float = 1.0) -> SimulationResult:
    """Real-time (optionally sped-up) playback on a normal asyncio loop."""
    return asyncio.run(Simulator(scenario).run(seed=seed, speed=speed))
