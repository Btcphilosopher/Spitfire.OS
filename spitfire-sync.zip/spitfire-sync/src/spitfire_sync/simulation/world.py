"""Ground-truth world: kinematic multirotors with a simple autopilot model,
wind, battery drain and navigation error.  Nothing here is visible to the
coordinator except through simulated telemetry; evaluation reads the truth log.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from ..allocation.energy import EnergyModel
from ..clocks.clock import SimulatedClock
from ..clocks.timebase import Timebase
from ..config import DroneProfile, DroneSimSpec, WindConfig
from ..models.state import ArmedStatus, FlightMode


@dataclass
class TruthSample:
    t: float
    pos: tuple[float, float, float]
    vel: tuple[float, float, float]
    mode: FlightMode
    payload: bool
    task: str | None
    energy_wh: float


class Wind:
    """Mean wind plus Ornstein-Uhlenbeck gusts (seeded)."""

    def __init__(self, cfg: WindConfig, rng: np.random.Generator) -> None:
        self.cfg = cfg
        self.rng = rng
        self.gust = np.zeros(2)

    def step(self, dt: float) -> np.ndarray:
        c = self.cfg
        if c.gust_tau_s > 0:
            a = math.exp(-dt / c.gust_tau_s)
            self.gust = a * self.gust + math.sqrt(1 - a * a) * c.gust_sigma_m_s * self.rng.standard_normal(2)
        return np.array([c.mean_east_m_s, c.mean_north_m_s]) + self.gust


class SimAircraft:
    KP, KD, KI = 1.1, 2.0, 0.08
    DRAG = 0.25  # 1/s : wind acts through air-relative drag

    def __init__(self, drone_id: str, profile: DroneProfile, spec: DroneSimSpec, home: np.ndarray,
                 clock: SimulatedClock, rng: np.random.Generator) -> None:
        self.id = drone_id
        self.profile = profile
        self.spec = spec
        self.home = home.astype(float).copy()
        self.clock = clock
        self.rng = rng
        self.pos = home.astype(float).copy()
        self.vel = np.zeros(3)
        self.mode = FlightMode.ON_GROUND
        self.armed = False
        self.energy_model = EnergyModel(profile.energy)
        self.capacity_wh = profile.energy.capacity_wh
        self.energy_wh = self.capacity_wh * spec.initial_charge
        self.sp_pos = self.pos.copy()
        self.sp_vel = np.zeros(3)
        self.last_setpoint_t = -1e9
        self.goto_target: np.ndarray | None = None
        self.goto_speed = 8.0
        self.integral = np.zeros(3)
        self.nav_err = np.zeros(3)
        self.payload = False
        self.payload_task: str | None = None
        self.failsafe_reason: str | None = None
        self.log: list[TruthSample] = []
        self.distance_m = 0.0
        self.energy_used_wh = 0.0
        self.landed_events: list[float] = []
        self.takeoff_events: list[float] = []
        self.motion_start_events: list[float] = []  # first offboard motion after a commanded start
        self._rtl_stage = 0
        self.params = dict(profile.autopilot.values)
        self.companion_alive = True
        self.was_airborne = False

    # --- autopilot command interface (used by SimAdapter) -----------------
    def arm(self) -> bool:
        if self.spec.arm_failure:
            return False
        self.armed = True
        return True

    def set_setpoint(self, p: np.ndarray, v: np.ndarray, t: float) -> None:
        if self.mode in (FlightMode.EMERGENCY, FlightMode.LAND, FlightMode.RETURN_TO_LAUNCH) and self.failsafe_reason:
            return  # autopilot failsafe owns the aircraft
        if not self.armed:
            return
        self.sp_pos, self.sp_vel = p.astype(float), v.astype(float)
        self.last_setpoint_t = t
        if self.mode != FlightMode.OFFBOARD:
            self.integral[:] = 0
        self.mode = FlightMode.OFFBOARD
        self.goto_target = None

    def hold(self) -> None:
        if self.failsafe_reason:
            return
        if self.mode == FlightMode.ON_GROUND:
            return
        self.mode = FlightMode.HOLD
        self.sp_pos = self.pos.copy()
        self.sp_vel = np.zeros(3)
        self.goto_target = None

    def goto(self, p: np.ndarray, speed: float) -> None:
        if self.failsafe_reason or self.mode == FlightMode.ON_GROUND:
            return
        self.mode = FlightMode.HOLD
        self.goto_target = p.astype(float)
        self.goto_speed = speed

    def land(self) -> None:
        if self.mode == FlightMode.ON_GROUND:
            return
        self.mode = FlightMode.LAND
        self.goto_target = None

    def rtl(self) -> None:
        if self.mode == FlightMode.ON_GROUND:
            return
        self.mode = FlightMode.RETURN_TO_LAUNCH
        self._rtl_stage = 0

    # --- physics -----------------------------------------------------------
    def _track(self, p_sp: np.ndarray, v_sp: np.ndarray, dt: float, wind: np.ndarray) -> np.ndarray:
        lim = self.profile.limits
        e = p_sp - self.pos
        self.integral = np.clip(self.integral + e * dt, -20, 20)
        a = self.KP * e + self.KD * (v_sp - self.vel) + self.KI * self.integral
        a[:2] += self.DRAG * (wind - self.vel[:2])
        ah = np.linalg.norm(a[:2])
        amax = lim.max_accel_m_s2 * 1.6
        if ah > amax:
            a[:2] *= amax / ah
        a[2] = float(np.clip(a[2], -3.0, 3.0))
        return a

    def step(self, t: float, dt: float, wind: np.ndarray) -> None:
        lim = self.profile.limits
        airborne = self.mode != FlightMode.ON_GROUND
        # autopilot failsafes (aircraft-owned; the coordinator never commands these)
        frac = self.energy_wh / self.capacity_wh
        if airborne and frac < self.params.get("BAT_CRIT_THR", 0.07) and self.failsafe_reason is None:
            self.failsafe_reason = "battery_critical"
            self.mode = FlightMode.LAND
        if airborne and self.mode == FlightMode.OFFBOARD and t - self.last_setpoint_t > self.params.get("COM_OF_LOSS_T", 1.0):
            self.mode = FlightMode.HOLD  # offboard setpoint loss => hold
            self.sp_pos = self.pos.copy()
            self.sp_vel = np.zeros(3)
        if self.mode == FlightMode.ON_GROUND:
            self.vel[:] = 0
            self.pos[2] = 0.0
        else:
            if self.mode == FlightMode.OFFBOARD:
                a = self._track(self.sp_pos, self.sp_vel, dt, wind)
            elif self.mode == FlightMode.HOLD:
                if self.goto_target is not None:
                    d = self.goto_target - self.pos
                    dist = np.linalg.norm(d)
                    v_sp = d / dist * min(self.goto_speed, 0.6 * dist) if dist > 0.1 else np.zeros(3)
                    v_sp[2] = np.clip(v_sp[2], -lim.max_descent_m_s, lim.max_climb_m_s)
                    a = self._track(self.pos + v_sp * 0.5, v_sp, dt, wind)
                else:
                    a = self._track(self.sp_pos, np.zeros(3), dt, wind)
            elif self.mode in (FlightMode.LAND, FlightMode.EMERGENCY):
                v_sp = np.array([0.0, 0.0, -lim.landing_descent_m_s if self.pos[2] < 8 else -lim.max_descent_m_s])
                a = self._track(np.array([self.pos[0], self.pos[1], self.pos[2]]), v_sp, dt, wind)
                a[2] = 2.0 * (v_sp[2] - self.vel[2])
            elif self.mode == FlightMode.RETURN_TO_LAUNCH:
                alt = self.params.get("RTL_RETURN_ALT", 60.0)
                if self._rtl_stage == 0:
                    tgt = np.array([self.pos[0], self.pos[1], alt])
                    if abs(self.pos[2] - alt) < 1.0:
                        self._rtl_stage = 1
                elif self._rtl_stage == 1:
                    tgt = np.array([self.home[0], self.home[1], alt])
                    if np.linalg.norm(self.pos[:2] - self.home[:2]) < 1.5:
                        self._rtl_stage = 2
                else:
                    self.mode = FlightMode.LAND
                    tgt = self.pos.copy()
                d = tgt - self.pos
                dist = float(np.linalg.norm(d))
                v_sp = d / dist * min(10.0, 0.6 * dist) if dist > 0.1 else np.zeros(3)
                a = self._track(self.pos + v_sp * 0.5, v_sp, dt, wind)
            else:
                a = np.zeros(3)
            self.vel += a * dt
            vh = np.linalg.norm(self.vel[:2])
            vmax = lim.max_speed_m_s * 1.1
            if vh > vmax:
                self.vel[:2] *= vmax / vh
            self.vel[2] = float(np.clip(self.vel[2], -lim.max_descent_m_s * 1.3, lim.max_climb_m_s * 1.3))
            step = self.vel * dt
            self.pos += step
            self.distance_m += float(np.linalg.norm(step))
            if self.pos[2] > 0.5:
                self.was_airborne = True
            if self.pos[2] <= 0.0 and self.vel[2] <= 0.0:
                self.pos[2] = 0.0
                self.vel[:] = 0.0
                if self.was_airborne and (
                        self.mode in (FlightMode.LAND, FlightMode.EMERGENCY, FlightMode.RETURN_TO_LAUNCH) or
                        (self.mode == FlightMode.OFFBOARD and self.sp_pos[2] <= 0.3)):
                    self.mode = FlightMode.ON_GROUND
                    self.armed = False
                    self.landed_events.append(t)
                    self.was_airborne = False
        # energy (true consumption = nominal model x hidden factor)
        if self.mode != FlightMode.ON_GROUND:
            air = self.vel[:2] - wind
            p = self.energy_model.power_w(float(np.linalg.norm(air)), float(self.vel[2])) * self.spec.consumption_factor
        else:
            p = 8.0 if self.armed else 0.0
        de = p * dt / 3600.0
        self.energy_wh = max(0.0, self.energy_wh - de)
        self.energy_used_wh += de
        # navigation error: first-order Gauss-Markov
        sigma = self.nav_sigma(t)
        a_gm = math.exp(-dt / 20.0)
        self.nav_err = a_gm * self.nav_err + math.sqrt(1 - a_gm * a_gm) * sigma * self.rng.standard_normal(3) * \
            np.array([1.0, 1.0, 0.6])

    def nav_sigma(self, t: float) -> float:
        for (s, e, sig) in self.spec.nav_degradation:
            if s <= t < e:
                return sig
        return self.spec.nav_noise_sigma_m

    def reported_uncertainty(self, t: float) -> float:
        sig = self.nav_sigma(t)
        return max(self.spec.reported_uncertainty_m, 2.5 * sig)

    def record(self, t: float) -> None:
        self.log.append(TruthSample(t, tuple(self.pos), tuple(self.vel), self.mode,  # type: ignore[arg-type]
                                    self.payload, self.payload_task, self.energy_wh))


class World:
    def __init__(self, timebase: Timebase, aircraft: dict[str, SimAircraft], wind: Wind, dt: float,
                 log_dt: float = 0.25) -> None:
        self.tb = timebase
        self.aircraft = aircraft
        self.wind = wind
        self.dt = dt
        self.log_dt = log_dt
        self.wind_log: list[tuple[float, float, float]] = []
        self.running = True

    async def run(self) -> None:
        t_next_log = 0.0
        last = self.tb.now()
        while self.running:
            await self.tb.sleep(self.dt)
            t = self.tb.now()
            dt = t - last
            last = t
            if dt <= 0:
                continue
            w = self.wind.step(dt)
            for d in sorted(self.aircraft):
                self.aircraft[d].step(t, dt, w)
            if t >= t_next_log:
                for d in sorted(self.aircraft):
                    self.aircraft[d].record(t)
                self.wind_log.append((t, float(w[0]), float(w[1])))
                t_next_log = t + self.log_dt


@dataclass
class SimAdapterState:
    payload_log: list[tuple[float, bool, str | None]] = field(default_factory=list)
