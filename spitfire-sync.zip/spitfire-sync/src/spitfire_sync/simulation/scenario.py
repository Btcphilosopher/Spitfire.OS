"""Scenario construction: mission geometry (lanes, zones, pads, recovery) and
fleet profiles from a :class:`SimulationConfig`."""

from __future__ import annotations

import math

import numpy as np

from ..config import (
    ContingencyConfig,
    DroneProfile,
    DroneSimSpec,
    EnergyModelConfig,
    KinematicLimits,
    SimulationConfig,
    SpitfireConfig,
)
from ..models.frames import GeodeticPosition
from ..models.geometry import Polygon2D, Vec3, clip_line_to_polygon, subtract_intervals
from ..models.mission import AltitudeBand, ExclusionZone, LaunchPad, Mission, MissionTask, RecoveryArea


def drone_ids(n: int) -> list[str]:
    return [f"drone-{i + 1:02d}" for i in range(n)]


DEFAULT_EXCLUSIONS = [
    {"zone_id": "farmhouse", "vertices": [(200.0, 150.0), (290.0, 150.0), (290.0, 212.0), (200.0, 212.0)],
     "reason": "farmhouse and livestock yard (no overflight)"},
]


def build_mission(sim: SimulationConfig, system: SpitfireConfig) -> Mission:
    site = sim.site
    field = Polygon2D(vertices=list(site.field_vertices))
    zones_cfg = site.exclusion_zones or DEFAULT_EXCLUSIONS
    zones = [
        ExclusionZone(zone_id=z["zone_id"], polygon=Polygon2D(vertices=[tuple(v) for v in z["vertices"]]),
                      floor_m=float(z.get("floor_m", -math.inf)), ceiling_m=float(z.get("ceiling_m", math.inf)),
                      reason=str(z.get("reason", "configured")))
        for z in zones_cfg
    ]
    bands = [AltitudeBand(name=n, floor_m=lo, ceiling_m=hi, purpose="survey") for n, lo, hi in site.survey_bands]
    bands += [AltitudeBand(name=n, floor_m=lo, ceiling_m=hi, purpose="transit") for n, lo, hi in site.transit_bands]
    bands += [AltitudeBand(name=f"C{i + 1}", floor_m=a - 1.0, ceiling_m=a + 1.0, purpose="contingency")
              for i, a in enumerate(site.contingency_altitudes_m)]
    clearance = system.separation.horizontal_m * 0.5 + system.separation.nominal_position_uncertainty_m + \
        system.separation.tracking_tolerance_m
    xmin, ymin, xmax, ymax = field.bounds()
    tasks: list[MissionTask] = []
    y = ymin + site.lane_spacing_m / 2.0
    k = 0
    survey_band_names = [b.name for b in bands if b.purpose == "survey"]
    while y < ymax:
        k += 1
        p0, p1 = (xmin - 50.0, y), (xmax + 50.0, y)
        ivals = clip_line_to_polygon(p0, p1, field)
        L = math.hypot(p1[0] - p0[0], p1[1] - p0[1])
        # remove exclusion zones inflated by clearance
        rem = []
        for z in zones:
            outset = Polygon2D(vertices=z.polygon.outset_vertices(clearance + 1.0))
            rem += clip_line_to_polygon(p0, p1, outset)
        ivals = subtract_intervals(ivals, rem)
        parts = [(a, b) for a, b in ivals if (b - a) * L >= 30.0]
        for j, (a, b) in enumerate(parts):
            suffix = "" if len(parts) == 1 else "abcdefgh"[j]
            tid = f"L{k:02d}{suffix}"
            sx, ex = p0[0] + a * (p1[0] - p0[0]), p0[0] + b * (p1[0] - p0[0])
            payload = site.payload_by_lane.get(tid, "multispectral" if y > (ymin + ymax) / 2 else "rgb")
            tasks.append(MissionTask(task_id=tid, start_xy=(sx, y), end_xy=(ex, y),
                                     permitted_bands=list(survey_band_names), payload_required=payload,
                                     swath_width_m=site.lane_spacing_m + 8.0, survey_speed_m_s=8.0))
        y += site.lane_spacing_m
    ids = drone_ids(sim.n_drones)
    lo = site.launch_origin
    pads = [LaunchPad(drone_id=d, position=Vec3.enu(lo[0] + i * site.launch_spacing_m, lo[1], 0.0))
            for i, d in enumerate(ids)]
    rc = site.recovery_centre
    n_spots = max(sim.n_drones, 6)
    ring = site.recovery_radius_m * 0.7
    spots = [(rc[0] + ring * math.cos(2 * math.pi * i / n_spots), rc[1] + ring * math.sin(2 * math.pi * i / n_spots))
             for i in range(n_spots)]
    recovery = RecoveryArea(centre_xy=rc, radius_m=site.recovery_radius_m, ceiling_m=site.recovery_ceiling_m,
                            capacity=1, landing_spots=spots)
    m = site.boundary_margin_m
    all_x = [p.position.x for p in pads] + [xmin, xmax, rc[0]]
    all_y = [p.position.y for p in pads] + [ymin, ymax, rc[1]]
    bx0, by0, bx1, by1 = min(all_x) - m, min(all_y) - m, max(all_x) + m, max(all_y) + m
    boundary = Polygon2D(vertices=[(bx0, by0), (bx1, by0), (bx1, by1), (bx0, by1)])
    return Mission(
        mission_id=f"survey-{site.name.split()[0].lower()}", site_name=site.name,
        origin=GeodeticPosition(latitude_deg=site.origin_lat_deg, longitude_deg=site.origin_lon_deg,
                                height_m=site.origin_height_m),
        survey_area=field, operational_boundary=boundary, exclusion_zones=zones, altitude_bands=bands,
        ceiling_m=site.ceiling_m, tasks=tasks, launch_pads=pads, recovery_area=recovery,
    )


def default_fleet(sim: SimulationConfig, system: SpitfireConfig) -> list[DroneProfile]:
    """Fleet profiles: explicit ones from the system config win; otherwise defaults.

    Payloads: aircraft with an odd index carry rgb+multispectral, even ones rgb only,
    except that at least two multispectral aircraft always exist."""
    explicit = {p.drone_id: p for p in system.fleet}
    out = []
    alts = sim.site.contingency_altitudes_m
    for i, d in enumerate(drone_ids(sim.n_drones)):
        if d in explicit:
            out.append(explicit[d])
            continue
        payloads = ["rgb", "multispectral"] if (i % 2 == 0 or i < 2) else ["rgb"]
        cont = ContingencyConfig(contingency_altitude_m=alts[i] if i < len(alts) else None)
        if i >= len(alts):
            # not enough unique contingency layers under the ceiling: land in place
            cont = ContingencyConfig(lost_link_action="LAND_IN_PLACE")  # type: ignore[arg-type]
        out.append(DroneProfile(drone_id=d, payloads=payloads, limits=KinematicLimits(), energy=EnergyModelConfig(),
                                contingency=cont, autopilot=_default_autopilot(alts[i] if i < len(alts) else 60.0)))
    return out


def _default_autopilot(rtl_alt: float):  # type: ignore[no-untyped-def]
    from ..config import AutopilotParams

    # PX4-style failsafe settings consistent with the coordination contingencies.
    return AutopilotParams(values={
        "RTL_RETURN_ALT": rtl_alt, "NAV_DLL_ACT": 0.0, "COM_DL_LOSS_T": 45.0, "COM_OF_LOSS_T": 1.0,
        "BAT_LOW_THR": 0.15, "BAT_CRIT_THR": 0.07, "COM_LOW_BAT_ACT": 3.0, "GF_ACTION": 1.0,
        "MPC_XY_VEL_MAX": 15.0, "MPC_Z_VEL_MAX_UP": 3.0, "MPC_Z_VEL_MAX_DN": 2.0, "MPC_ACC_HOR_MAX": 3.0,
    })


def sim_specs(sim: SimulationConfig) -> dict[str, DroneSimSpec]:
    """Per-aircraft hidden truth.  Explicit specs override; when ``randomise`` is
    set, clock drift/offset and consumption are perturbed per seed."""
    rng = np.random.default_rng(sim.seed * 7919 + 17)
    explicit = {s.drone_id: s for s in sim.drones}
    out = {}
    for d in drone_ids(sim.n_drones):
        base = explicit.get(d, DroneSimSpec(drone_id=d))
        upd: dict[str, float] = {}
        if sim.randomise:
            r = rng.random(4)
            if d not in explicit or base.clock_drift_ppm == 0.0:
                upd["clock_drift_ppm"] = float((r[0] - 0.5) * 100.0)
            if d not in explicit or base.mono_offset_s == 0.0:
                upd["mono_offset_s"] = float(1000.0 + r[1] * 50_000.0)
            if d not in explicit or base.utc_offset_s == 0.0:
                upd["utc_offset_s"] = float((r[2] - 0.5) * 4.0)
            if d not in explicit:
                upd["consumption_factor"] = float(0.95 + r[3] * 0.12)
        else:
            rng.random(4)
        out[d] = base.model_copy(update=upd)
    return out


def fleet_config(sim: SimulationConfig, system: SpitfireConfig) -> SpitfireConfig:
    return system.model_copy(update={"fleet": default_fleet(sim, system)})
