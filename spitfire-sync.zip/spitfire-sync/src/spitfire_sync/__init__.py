"""SPITFIRE.OS - Drone Synchronisation Core.

Supervisory coordination for civilian survey fleets: timestamped state
sharing, task allocation with expiring leases, conflict-checked trajectory
scheduling, readiness-gated coordinated starts and degraded-mode handling.
Flight stabilisation and aircraft failsafes remain in the autopilot.
"""

__version__ = "0.1.0"
