"""Matplotlib figures: plan view, altitude, separation over time, event timeline,
multi-seed distributions.  Colours follow a fixed categorical order (aircraft
1..8 always get the same hue); beyond eight aircraft tracks are drawn in
neutral grey with direct labels rather than generating new hues."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.patches import Circle, Polygon  # noqa: E402

from ..simulation.simulator import SimulationResult  # noqa: E402
from .metrics import Metrics, separation_series  # noqa: E402

SERIES = ["#257de0", "#f47230", "#00b894", "#f2a600", "#ee7fac", "#008a17", "#6a4ce2", "#ec4647"]
TEXT = "#191919"
TEXT2 = "#666666"
GRID = "#e6e6e6"
NEUTRAL = "#9a9a9a"
SURFACE = "#ffffff"

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "axes.edgecolor": "#cccccc",
    "axes.labelcolor": TEXT2, "xtick.color": TEXT2, "ytick.color": TEXT2, "text.color": TEXT,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.8, "axes.spines.top": False,
    "axes.spines.right": False, "font.size": 9, "axes.titlesize": 11, "axes.titleweight": "bold",
    "legend.frameon": False,
})


def colour(i: int) -> str:
    return SERIES[i] if i < len(SERIES) else NEUTRAL


def _world(res: SimulationResult, t_coord: float) -> float:
    return float(res.coord_world_of(t_coord))


def plot_plan_view(res: SimulationResult, path: Path) -> None:
    m = res.mission
    fig, ax = plt.subplots(figsize=(10, 7.2))
    ax.add_patch(Polygon(m.survey_area.vertices, closed=True, fill=False, ec=TEXT2, lw=1.2, ls="-"))
    for z in m.exclusion_zones:
        ax.add_patch(Polygon(z.polygon.vertices, closed=True, fc="#f0f0f0", ec=TEXT2, hatch="///", lw=0.8))
        cx, cy = z.polygon.centroid()
        ax.text(cx, cy, z.zone_id, ha="center", va="center", fontsize=8, color=TEXT2)
    for t in res.task_registry.values():
        if t.parent_task_id is None:
            ax.plot([t.start_xy[0], t.end_xy[0]], [t.start_xy[1], t.end_xy[1]], color=GRID, lw=6, zorder=0,
                    solid_capstyle="butt")
            ax.text(t.start_xy[0] - 8, t.start_xy[1], t.task_id, ha="right", va="center", fontsize=7, color=TEXT2)
    ra = m.recovery_area
    ax.add_patch(Circle(ra.centre_xy, ra.radius_m, fill=False, ec=TEXT, lw=1.2, ls="--"))
    ax.text(ra.centre_xy[0], ra.centre_xy[1] - ra.radius_m - 10, "shared recovery area", ha="center",
            fontsize=8, color=TEXT2)
    ids = sorted(res.truth)
    for i, d in enumerate(ids):
        log = res.truth[d]
        if not log:
            continue
        P = np.array([s.pos for s in log])
        pay = np.array([s.payload for s in log])
        c = colour(i)
        ax.plot(P[:, 0], P[:, 1], color=c, lw=0.9, alpha=0.55)
        Ps = np.where(pay[:, None], P, np.nan)
        ax.plot(Ps[:, 0], Ps[:, 1], color=c, lw=2.2, label=d)
        pad = m.pad(d).position
        ax.plot(pad.x, pad.y, marker="s", ms=6, color=c, mec=SURFACE, mew=1.5)
        ax.text(pad.x, pad.y - 9, d.replace("drone-", "D"), ha="center", fontsize=7, color=TEXT)
    # hold points of the initial plan
    o = res.outcome
    if o and o.initial_plan:
        for i, d in enumerate(ids):
            dp = o.initial_plan.drone_plans.get(d)
            if dp:
                h = dp.contingency.hold_point
                ax.plot(h.x, h.y, marker="o", ms=8, mfc=SURFACE, mec=colour(i), mew=2)
    # notable events located from truth
    marked: set[tuple[str, str]] = set()
    for e in (o.timeline if o else []):
        if e.kind in ("battery_reserve", "aircraft_paused") and e.drone_id in res.truth:
            if (e.drone_id, e.kind) in marked or (e.kind == "aircraft_paused" and
                                                  str(e.reason) == "BATTERY_RESERVE_BREACH"):
                continue
            marked.add((e.drone_id, e.kind))
            tw = _world(res, e.time)
            log = res.truth[e.drone_id]
            k = int(np.argmin([abs(s.t - tw) for s in log]))
            p = log[k].pos
            mk = "X" if e.kind == "battery_reserve" else "P"
            ax.plot(p[0], p[1], marker=mk, ms=11, color=TEXT, mec=SURFACE, mew=1.5, zorder=5)
            lab = "reserve reached" if e.kind == "battery_reserve" else "paused"
            ax.annotate(f"{e.drone_id.replace('drone-', 'D')} {lab}", (p[0], p[1]), xytext=(8, 8),
                        textcoords="offset points", fontsize=8, color=TEXT)
    ax.set_aspect("equal")
    ax.set_xlabel("east [m] (local ENU)")
    ax.set_ylabel("north [m]")
    ax.set_title(f"{m.site_name}: flown tracks (thick = payload on), seed {res.seed}")
    ax.legend(loc="upper left", bbox_to_anchor=(1.0, 1.0), fontsize=8)
    fig.tight_layout(rect=(0, 0.04, 1, 1))
    fig.text(0.99, 0.01, "markers: ring = assigned hold point, square = launch pad, X = battery reserve reached, "
             "+ = paused (lease lapse / commanded hold)", ha="right", fontsize=7, color=TEXT2)
    fig.savefig(path, dpi=150)
    plt.close(fig)


def plot_altitude(res: SimulationResult, path: Path) -> None:
    m = res.mission
    fig, ax = plt.subplots(figsize=(10, 4.2))
    for b in m.altitude_bands:
        if b.purpose in ("survey", "transit"):
            ax.axhspan(b.floor_m, b.ceiling_m, color="#f2f2f2", zorder=0)
            ax.text(0, b.ceiling_m + 0.5, f"{b.name} ({b.purpose})", fontsize=7, color=TEXT2)
    for i, d in enumerate(sorted(res.truth)):
        log = res.truth[d]
        t = [s.t for s in log]
        z = [s.pos[2] for s in log]
        ax.plot(t, z, color=colour(i), lw=1.4, label=d)
    ax.axhline(m.ceiling_m, color=TEXT2, lw=0.8, ls="--")
    ax.text(0, m.ceiling_m + 1, "mission ceiling", fontsize=7, color=TEXT2)
    ax.set_xlabel("simulation time [s]")
    ax.set_ylabel("height above origin [m]")
    ax.set_title("Altitude profiles (true)")
    ax.legend(loc="upper left", bbox_to_anchor=(1.0, 1.0), fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def plot_separation(res: SimulationResult, path: Path) -> None:
    T, min3, minh, _ = separation_series(res)
    sep = res.system.separation
    fig, ax = plt.subplots(figsize=(10, 3.8))
    groups: dict[str, list] = {}
    for ep in res.link_episodes:
        ax.axvspan(ep.start_s, ep.end_s, color="#f2f2f2", zorder=0)
        groups.setdefault(ep.node_id, []).append(ep)
    for node, eps in groups.items():
        a, b = min(e.start_s for e in eps), max(e.end_s for e in eps)
        ax.text((a + b) / 2, 0.98, f"{node} link: " + " -> ".join(e.label for e in eps),
                transform=ax.get_xaxis_transform(), ha="center", va="top", fontsize=7, color=TEXT2)
    y = np.where(np.isfinite(min3), min3, np.nan)
    ax.plot(T, y, color=SERIES[0], lw=1.6)
    ax.axhline(sep.horizontal_m, color=TEXT, lw=1.0, ls="--")
    ax.text(T[0] if len(T) else 0, sep.horizontal_m + 2, f"configured horizontal separation {sep.horizontal_m:.0f} m",
            fontsize=8, color=TEXT)
    k = np.nanargmin(y) if np.isfinite(y).any() else None
    if k is not None:
        ax.plot(T[k], y[k], "o", ms=8, color=SERIES[0], mec=SURFACE, mew=2)
        ax.annotate(f"minimum {y[k]:.1f} m at t={T[k]:.0f} s", (T[k], y[k]), xytext=(10, -14),
                    textcoords="offset points", fontsize=8)
    ax.set_ylim(0, min(250, np.nanmax(y) * 1.05) if np.isfinite(y).any() else 100)
    ax.set_xlabel("simulation time [s]")
    ax.set_ylabel("closest airborne pair [m]")
    ax.set_title("Minimum true 3-D separation between airborne aircraft (modelled aircraft only)")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


PHASE_COLOURS = {"survey": SERIES[0], "transit": SERIES[2], "hold": SERIES[3], "landing": SERIES[6]}


def _phase(s) -> str | None:  # type: ignore[no-untyped-def]
    """Classify a truth sample: survey (payload on), landing (descending below
    25 m), hold (airborne, < 0.7 m/s) or transit."""
    mv = s.mode.value
    if mv == "ON_GROUND":
        return None
    if s.payload:
        return "survey"
    vz = s.vel[2]
    if mv in ("LAND", "EMERGENCY", "RETURN_TO_LAUNCH") or (s.pos[2] < 25.0 and vz < -0.3):
        return "landing"
    if (s.vel[0] ** 2 + s.vel[1] ** 2 + vz ** 2) ** 0.5 < 0.7:
        return "hold"
    return "transit"


KEY_EVENTS = {
    "commit_result": "commit", "stale_telemetry": "stale", "aircraft_paused": "paused",
    "link_restored": "link back", "reconciled": "reconciled", "resumed": "resumed",
    "battery_reserve": "reserve", "task_reassigned": "reassigned", "recovery_scheduled": "recovery slot",
    "landed": "landed", "start_failed": "start failed", "aircraft_dropout": "dropout",
    "mission_obstruction": "obstruction", "lease_expired": "lease expired",
}


def plot_timeline(res: SimulationResult, path: Path) -> None:
    ids = sorted(res.truth)
    fig, ax = plt.subplots(figsize=(11, 1.0 * len(ids) + 1.8))
    for row, d in enumerate(ids):
        log = res.truth[d]
        if not log:
            continue
        segs: list[list] = []  # [phase, start, end]
        for s in log:
            ph = _phase(s)
            if segs and segs[-1][0] == ph:
                segs[-1][2] = s.t
            else:
                segs.append([ph, s.t, s.t])
        merged: list[list] = []
        for sg in segs:  # absorb sub-1.5 s flickers into the preceding phase
            if merged and (sg[2] - sg[1] < 1.5 or merged[-1][0] == sg[0]) and merged[-1][0] is not None \
                    and sg[0] is not None:
                merged[-1][2] = sg[2]
            else:
                merged.append(list(sg))
        for ph, a, b in merged:
            if ph is not None and b > a:
                ax.barh(row, b - a, left=a, height=0.42, color=PHASE_COLOURS[ph], edgecolor=SURFACE, linewidth=1.0)
    o = res.outcome
    label_count: dict[int, int] = {}
    label_level: dict[int, int] = {}
    last_label_t: dict[int, float] = {}
    for e in (o.timeline if o else []):
        lab = KEY_EVENTS.get(e.kind)
        if lab is None or e.drone_id not in ids:
            if e.kind == "commit_result" and e.details.get("purpose") == "INITIAL":
                ax.axvline(_world(res, e.time), color=TEXT2, lw=0.8, ls=":")
                ax.text(_world(res, e.time), len(ids) - 0.4, "initial commit", fontsize=7, color=TEXT2)
            continue
        row = ids.index(e.drone_id)
        tw = _world(res, e.time)
        ax.plot(tw, row + 0.32, marker="v", ms=5, color=TEXT)
        if lab not in ("landed",):
            k = label_count.get(row, 0)
            label_count[row] = k + 1
            last = last_label_t.get(row, -1e9)
            level = label_level.get(row, 0) + 1 if tw - last < 25 else 0
            label_level[row], last_label_t[row] = level, tw
            ax.annotate(lab, (tw, row + 0.32), xytext=(2, -9 - 8 * (level % 4)), textcoords="offset points",
                        fontsize=6.5, color=TEXT, ha="left", va="top")
    for ep in res.link_episodes:
        if ep.node_id in ids:
            r = ids.index(ep.node_id)
            ax.add_patch(plt.Rectangle((ep.start_s, r - 0.32), ep.end_s - ep.start_s, 0.64, fill=False,
                                       ec=TEXT, lw=1.0, ls="--"))
    ax.set_yticks(range(len(ids)))
    ax.set_yticklabels(ids)
    ax.set_ylim(-0.6, len(ids) + 0.2)
    ax.invert_yaxis()
    ax.set_xlabel("simulation time [s]")
    ax.set_title("Event timeline (bars: true flight phase; triangles: coordinator decisions; dashed box: link episode)")
    handles = [plt.Rectangle((0, 0), 1, 1, color=c) for c in PHASE_COLOURS.values()]
    ax.legend(handles, list(PHASE_COLOURS), loc="upper left", bbox_to_anchor=(1.0, 1.0), fontsize=8)
    ax.grid(axis="y", visible=False)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def plot_distributions(metrics: list[Metrics], path: Path) -> None:
    keys = [
        ("coverage_fraction", "survey coverage [fraction]"),
        ("mission_duration_s", "mission duration [s]"),
        ("min_true_separation_m", "min true separation [m]"),
        ("sync_start_abs_max_s", "max |sync-start error| [s]"),
        ("command_ack_latency_p95_s", "command ack latency p95 [s]"),
        ("reassignment_delay_max_s", "reassignment delay [s]"),
        ("recovery_after_comm_loss_max_s", "resume after link restored [s]"),
        ("total_energy_wh", "fleet energy (model) [Wh]"),
    ]
    fig, axes = plt.subplots(2, 4, figsize=(13, 5.6))
    rng = np.random.default_rng(0)
    for ax, (k, label) in zip(axes.ravel(), keys):
        vals = np.array([m.scalar_summary()[k] for m in metrics], dtype=float)
        vals = vals[np.isfinite(vals)]
        ax.set_title(label, fontsize=9)
        if len(vals) == 0:
            ax.text(0.5, 0.5, "n/a", transform=ax.transAxes, ha="center")
            continue
        ax.boxplot(vals, widths=0.5, showfliers=False, medianprops={"color": TEXT, "lw": 1.5},
                   boxprops={"color": TEXT2}, whiskerprops={"color": TEXT2}, capprops={"color": TEXT2})
        ax.plot(1 + rng.uniform(-0.12, 0.12, len(vals)), vals, "o", ms=5, color=SERIES[0], mec=SURFACE, mew=1, alpha=0.9)
        ax.set_xticks([])
        ax.text(1.32, float(np.median(vals)), f"median {np.median(vals):.3g}", fontsize=7.5, va="center")
    fig.suptitle(f"Distributions across {len(metrics)} seeds (simulation model only)", fontweight="bold")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def make_all(res: SimulationResult, out: Path) -> dict[str, str]:
    out.mkdir(parents=True, exist_ok=True)
    files = {
        "plan_view": out / "trajectories.png",
        "altitude": out / "altitude.png",
        "separation": out / "separation.png",
        "timeline": out / "timeline.png",
    }
    plot_plan_view(res, files["plan_view"])
    plot_altitude(res, files["altitude"])
    plot_separation(res, files["separation"])
    plot_timeline(res, files["timeline"])
    return {k: str(v) for k, v in files.items()}


def _unused(_: Any) -> None:  # keep linters quiet about optional imports
    return None
