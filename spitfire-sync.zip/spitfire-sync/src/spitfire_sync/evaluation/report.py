"""Structured run report (JSON + Markdown) and multi-seed evaluation."""

from __future__ import annotations

import json
import math
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from typing import Any

import numpy as np

from ..config import ScenarioFile
from ..simulation.simulator import SimulationResult, run_simulation
from .metrics import Metrics, compute_metrics

CAVEAT = (
    "All figures are properties of the simulation model (kinematic aircraft, simple energy model, simulated "
    "network). They are modelled performance, not demonstrated aircraft performance. A simulation without "
    "collisions is not evidence of safety; separation checks cover only the modelled aircraft and hazards and "
    "do not replace onboard detect-and-avoid or autopilot failsafes."
)


def _json_default(o: Any) -> Any:
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, tuple):
        return list(o)
    if hasattr(o, "model_dump"):
        return o.model_dump(mode="json")
    if hasattr(o, "value"):
        return o.value
    return str(o)


def _w(res: SimulationResult, t: float | None) -> float | None:
    return None if t is None else round(float(res.coord_world_of(t)), 2)


def timeline_rows(res: SimulationResult) -> list[dict[str, Any]]:
    rows = []
    for e in (res.outcome.timeline if res.outcome else []):
        if e.kind in ("progress",):
            continue
        rows.append({"t_s": _w(res, e.time), "event": e.kind, "aircraft": e.drone_id, "reason": e.reason.value,
                     "details": e.details})
    return rows


def _onboard_pause(res: SimulationResult) -> str:
    """Ground-truth time at which an aircraft with a scripted link episode paused onboard."""
    for ep in res.link_episodes:
        for rec, (_, conv) in zip(res.agent_records.get(ep.node_id, []), res.agent_world_of.get(ep.node_id, [])):
            for t_local, kind, data in rec.events:
                if kind == "paused" and conv(t_local) >= ep.start_s - 1.0:
                    return f"{conv(t_local):.1f}"
    return "-"


def demonstration_checklist(res: SimulationResult, m: Metrics) -> list[dict[str, Any]]:
    tl = timeline_rows(res)

    def first(kind: str, pred=lambda r: True) -> dict[str, Any] | None:  # type: ignore[no-untyped-def]
        for r in tl:
            if r["event"] == kind and pred(r):
                return r
        return None

    def item(n: int, title: str, row: dict[str, Any] | None, evidence: str) -> dict[str, Any]:
        return {"step": n, "title": title, "demonstrated": row is not None or evidence.startswith("metric"),
                "t_s": row["t_s"] if row else None, "evidence": evidence}

    init = first("initial_state_collected")
    alloc = first("allocation")
    sched = first("scheduled")
    commit = first("commit_result", lambda r: r["details"].get("purpose") == "INITIAL")
    stale = first("stale_telemetry")
    paused = first("aircraft_paused", lambda r: r["reason"] in ("LEASE_EXPIRED", "COORDINATOR_LINK_LOST"))
    reserve = first("battery_reserve")
    reassigned = first("task_reassigned")
    recovery = first("recovery_scheduled")
    finished = first("mission_finished")
    return [
        item(1, "Initial state collection", init, f"fresh aircraft: {init['details'].get('fresh') if init else '-'}"),
        item(2, "Survey-lane allocation", alloc, f"{alloc['details'].get('method') if alloc else '-'}: "
             f"{alloc['details'].get('per_drone') if alloc else '-'}"),
        item(3, "Conflict-checked scheduling", sched,
             f"conflicts after resolution: {sched['details'].get('conflicts') if sched else '-'}; resolutions "
             f"{sched['details'].get('resolutions') if sched else '-'}"),
        item(4, "Coordinated departure", commit,
             f"commit acked by {commit['details'].get('acked') if commit else '-'}; max abs start error "
             f"{m.sync_start_abs_max_s * 1000:.1f} ms (tolerance {res.system.timing.start_tolerance_s * 1000:.0f} ms)"),
        item(5, "Task execution", first("task_complete"), f"{m.tasks_completed} tasks completed; coverage "
             f"{m.coverage_fraction * 100:.1f} %"),
        item(6, "One delayed communication link", stale or paused,
             f"stale telemetry at {stale['t_s'] if stale else '-'} s; aircraft paused onboard (lease lapse) at "
             f"{_onboard_pause(res)} s; coordinator registered the pause at {paused['t_s'] if paused else '-'} s; "
             f"work resumed {', '.join(f'{x:.1f}' for x in m.recovery_after_comm_loss_s) or '-'} s after the link "
             f"was restored"),
        item(7, "One aircraft reaching its battery reserve", reserve,
             f"{reserve['aircraft'] if reserve else '-'} at {reserve['t_s'] if reserve else '-'} s"),
        item(8, "Safe suspension and reassignment", reassigned,
             f"reassignment committed {', '.join('%.1f' % x for x in m.reassignment_delay_s)} s after suspension; "
             f"duplicate survey length {m.duplicate_length_m:.1f} m"),
        item(9, "Sequenced recovery", recovery,
             "landing order: " + ", ".join(f"{r['drone']}@{_w(res, r.get('landed_at'))}s" for r in
                                           sorted(m.recovery_landings, key=lambda r: r.get("landed_at") or 1e18))),
        item(10, "Final coverage and timing report", finished, "metric: see summary below"),
    ]


def write_run_report(res: SimulationResult, out: Path, figures: dict[str, str] | None = None) -> dict[str, Any]:
    out.mkdir(parents=True, exist_ok=True)
    m = compute_metrics(res)
    checklist = demonstration_checklist(res, m)
    tl = timeline_rows(res)
    data = {
        "caveat": CAVEAT, "seed": res.seed, "mission": res.mission.mission_id, "site": res.mission.site_name,
        "n_aircraft": len(res.truth), "summary": m.scalar_summary(), "metrics": m.as_dict(),
        "checklist": checklist, "timeline": tl, "figures": figures or {},
        "injected_faults": {"link_episodes": [e.model_dump() for e in res.link_episodes],
                            "aircraft": {d: s for d, s in res.aircraft_specs.items()
                                         if s.get("consumption_factor", 1.0) > 1.3 or s.get("reboot_at_s")
                                         or s.get("arm_failure")}},
    }
    (out / "report.json").write_text(json.dumps(data, indent=1, default=_json_default))
    (out / "trace.json").write_text(json.dumps({
        "timeline": tl,
        "tracks": {d: [[round(s.t, 2), *[round(v, 2) for v in s.pos], s.mode.value, s.payload] for s in log[::4]]
                   for d, log in res.truth.items()},
    }, default=_json_default))
    lines = [f"# SPITFIRE.OS demonstration report - {res.mission.site_name}", "",
             f"Seed {res.seed}, {len(res.truth)} aircraft, simulated duration {res.sim_duration_s:.0f} s "
             f"(wall {res.wall_time_s:.1f} s). Clean shutdown: {res.shutdown_clean}. Errors: {len(res.errors)}.", "",
             f"> {CAVEAT}", "", "## Demonstration checklist", "", "| # | Step | Shown | t [s] | Evidence |",
             "|---|---|---|---|---|"]
    for c in checklist:
        lines.append(f"| {c['step']} | {c['title']} | {'yes' if c['demonstrated'] else 'no'} | "
                     f"{c['t_s'] if c['t_s'] is not None else ''} | {c['evidence']} |")
    s = m.scalar_summary()
    lines += ["", "## Summary metrics", "", "| Metric | Value |", "|---|---|"]
    fmt = {
        "coverage_fraction": lambda v: f"{v * 100:.1f} %",
        "sync_start_abs_max_s": lambda v: f"{v * 1000:.2f} ms",
        "command_ack_latency_p95_s": lambda v: f"{v * 1000:.0f} ms",
    }
    for k, v in s.items():
        lines.append(f"| {k} | {fmt.get(k, lambda x: f'{x:.2f}')(v) if isinstance(v, float) and math.isfinite(v) else v} |")
    lines += ["", "## Synchronised start (initial plan)", "",
              "Error = true start of execution (agent clock mapped to world time) minus the committed start "
              "(coordination timescale mapped to world time). Take-off error is the physical response "
              "(first crossing of 0.5 m) relative to the plan.", "",
              "| Aircraft | Start error [ms] | Take-off error [s] |", "|---|---|---|"]
    for d in sorted(m.sync_start_error_s):
        lines.append(f"| {d} | {m.sync_start_error_s[d] * 1000:.2f} | {m.takeoff_error_s.get(d, float('nan')):.2f} |")
    lines += ["", "## Per-aircraft (truth)", "", "| Aircraft | Distance [m] | Energy (model) [Wh] |", "|---|---|---|"]
    for d in sorted(m.travel_distance_m):
        lines.append(f"| {d} | {m.travel_distance_m[d]:.0f} | {m.energy_used_wh[d]:.1f} |")
    lines += ["", "## Recovery sequence", "", "| Aircraft | Priority | Slot start [s] | Landed [s] |", "|---|---|---|---|"]
    for r in sorted(m.recovery_landings, key=lambda r: r.get("landed_at") or 1e18):
        lines.append(f"| {r['drone']} | {r['priority']} | {_w(res, r.get('slot_start'))} | {_w(res, r.get('landed_at'))} |")
    lines += ["", "## Key coordination events", "", "| t [s] | Event | Aircraft | Reason |", "|---|---|---|---|"]
    keep = {"commit_result", "stale_telemetry", "aircraft_paused", "lease_expired", "link_lost", "link_restored",
            "position_unassessable", "reconciled", "resumed", "battery_reserve", "task_suspended",
            "remainder_created", "reallocation", "task_reassigned", "recovery_scheduled", "landed",
            "hold_for_uncertain_aircraft", "start_failed", "partial_start_continue", "partial_start_abort",
            "aircraft_dropout", "mission_obstruction", "reboot_detected", "mission_finished"}
    for r in tl:
        if r["event"] in keep:
            lines.append(f"| {r['t_s']} | {r['event']} | {r['aircraft'] or ''} | {r['reason']} |")
    if figures:
        lines += ["", "## Figures", ""] + [f"![{k}]({Path(v).name})" for k, v in figures.items()]
    (out / "report.md").write_text("\n".join(lines) + "\n")
    return data


def _run_one(args: tuple[str, int, str | None]) -> dict[str, Any]:
    scenario_json, seed, allocator = args
    sc = ScenarioFile.model_validate_json(scenario_json)
    if allocator:
        sc = sc.model_copy(update={"system": sc.system.model_copy(update={"allocator": allocator})})
    res = run_simulation(sc, seed=seed)
    return compute_metrics(res).as_dict()


def evaluate_seeds(scenario: ScenarioFile, seeds: list[int], out: Path, workers: int = 1,
                   allocator: str | None = None) -> dict[str, Any]:
    out.mkdir(parents=True, exist_ok=True)
    payload = scenario.model_dump_json()
    jobs = [(payload, s, allocator) for s in seeds]
    if workers > 1:
        with ProcessPoolExecutor(max_workers=workers) as ex:
            rows = list(ex.map(_run_one, jobs))
    else:
        rows = [_run_one(j) for j in jobs]
    metrics = [Metrics(**r) for r in rows]
    summaries = [m.scalar_summary() for m in metrics]
    keys = list(summaries[0]) if summaries else []
    dist: dict[str, dict[str, float]] = {}
    for k in keys:
        v = np.array([s[k] for s in summaries], dtype=float)
        v = v[np.isfinite(v)]
        dist[k] = ({"n": int(len(v)), "min": float(v.min()), "p5": float(np.percentile(v, 5)),
                    "median": float(np.median(v)), "mean": float(v.mean()), "p95": float(np.percentile(v, 95)),
                    "max": float(v.max())} if len(v) else {"n": 0})
    result = {"caveat": CAVEAT, "seeds": seeds, "allocator": allocator or scenario.system.allocator,
              "n_aircraft": scenario.simulation.n_drones, "distributions": dist,
              "per_seed": [{"seed": m.seed, **s, "finished": m.finished, "tasks_completed": m.tasks_completed,
                            "tasks_unfinished": m.tasks_unfinished, "errors": len(m.errors),
                            "shutdown_clean": m.shutdown_clean} for m, s in zip(metrics, summaries)]}
    (out / "evaluation.json").write_text(json.dumps(result, indent=1, default=_json_default))
    lines = [f"# Multi-seed evaluation ({len(seeds)} seeds, {scenario.simulation.n_drones} aircraft, "
             f"allocator {result['allocator']})", "", f"> {CAVEAT}", "",
             "| Metric | n | min | p5 | median | p95 | max |", "|---|---|---|---|---|---|---|"]
    for k, d in dist.items():
        if d.get("n"):
            lines.append(f"| {k} | {d['n']} | {d['min']:.4g} | {d['p5']:.4g} | {d['median']:.4g} | {d['p95']:.4g} | "
                         f"{d['max']:.4g} |")
        else:
            lines.append(f"| {k} | 0 | - | - | - | - | - |")
    lines += ["", "## Per seed", "", "| seed | finished | tasks done | unfinished | coverage | min sep [m] | "
              "infringement [s] | max start err [ms] | errors | clean shutdown |", "|---|---|---|---|---|---|---|---|---|---|"]
    for r in result["per_seed"]:
        lines.append(f"| {r['seed']} | {r['finished']} | {r['tasks_completed']} | {r['tasks_unfinished']} | "
                     f"{r['coverage_fraction'] * 100:.1f} % | {r['min_true_separation_m']:.1f} | "
                     f"{r['true_separation_infringements_s']:.1f} | {r['sync_start_abs_max_s'] * 1000:.2f} | "
                     f"{r['errors']} | {r['shutdown_clean']} |")
    (out / "evaluation.md").write_text("\n".join(lines) + "\n")
    from .plots import plot_distributions

    plot_distributions(metrics, out / "distributions.png")
    return result
