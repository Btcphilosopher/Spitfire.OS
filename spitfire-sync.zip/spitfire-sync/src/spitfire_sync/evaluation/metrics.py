"""Evaluation metrics.

Ground truth (simulator state) is used *only here*, after the run.  Every
metric is a property of the simulation model: modelled performance, not
demonstrated aircraft performance.  "No collision in simulation" is not
evidence of safety.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field
from typing import Any

import numpy as np
from scipy.spatial import cKDTree

from ..models.mission import Mission
from ..models.state import FlightMode
from ..simulation.simulator import SimulationResult

GROUND = 1.0


@dataclass
class Metrics:
    seed: int
    finished: bool
    coverage_fraction: float
    coverage_cells: int
    covered_cells: int
    duplicate_length_m: float
    concurrent_duplicate_execution: int
    tasks_completed: int
    tasks_unfinished: int
    mission_duration_s: float
    travel_distance_m: dict[str, float]
    total_travel_distance_m: float
    energy_used_wh: dict[str, float]
    total_energy_wh: float
    min_true_separation_m: float
    min_true_horizontal_when_vertical_lt_sep_m: float
    true_separation_infringements_s: float
    predicted_separation_violations: int
    sync_start_error_s: dict[str, float]
    sync_start_abs_max_s: float
    sync_start_spread_s: float
    takeoff_error_s: dict[str, float]
    command_ack_latency_s: list[float]
    reassignment_delay_s: list[float]
    reassignment_to_execution_s: list[float]
    recovery_after_comm_loss_s: list[float]
    recovery_landings: list[dict[str, Any]]
    autopilot_failsafes: int
    safety_events: dict[str, int]
    network: dict[str, Any] = field(default_factory=dict)
    telemetry_ingest: dict[str, Any] = field(default_factory=dict)
    guard_rejections: dict[str, Any] = field(default_factory=dict)
    shutdown_clean: bool = True
    errors: list[str] = field(default_factory=list)
    sim_duration_s: float = 0.0
    wall_time_s: float = 0.0

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)

    def scalar_summary(self) -> dict[str, float]:
        def pct(xs: list[float], q: float) -> float:
            return float(np.percentile(xs, q)) if xs else float("nan")

        return {
            "coverage_fraction": self.coverage_fraction,
            "duplicate_length_m": self.duplicate_length_m,
            "concurrent_duplicate_execution": float(self.concurrent_duplicate_execution),
            "mission_duration_s": self.mission_duration_s,
            "total_travel_distance_m": self.total_travel_distance_m,
            "total_energy_wh": self.total_energy_wh,
            "min_true_separation_m": self.min_true_separation_m,
            "true_separation_infringements_s": self.true_separation_infringements_s,
            "predicted_separation_violations": float(self.predicted_separation_violations),
            "sync_start_abs_max_s": self.sync_start_abs_max_s,
            "command_ack_latency_p95_s": pct(self.command_ack_latency_s, 95),
            "reassignment_delay_max_s": max(self.reassignment_delay_s) if self.reassignment_delay_s else float("nan"),
            "recovery_after_comm_loss_max_s": max(self.recovery_after_comm_loss_s)
            if self.recovery_after_comm_loss_s else float("nan"),
            "autopilot_failsafes": float(self.autopilot_failsafes),
        }


def _truth_arrays(res: SimulationResult) -> dict[str, dict[str, np.ndarray]]:
    out = {}
    for d, log in res.truth.items():
        if not log:
            continue
        out[d] = {
            "t": np.array([s.t for s in log]),
            "p": np.array([s.pos for s in log]),
            "payload": np.array([s.payload for s in log]),
            "task": np.array([s.task or "" for s in log], dtype=object),
            "mode": np.array([s.mode.value for s in log], dtype=object),
        }
    return out


def coverage(res: SimulationResult, cell_m: float = 5.0) -> tuple[float, int, int, np.ndarray, np.ndarray]:
    m: Mission = res.mission
    xmin, ymin, xmax, ymax = m.survey_area.bounds()
    xs = np.arange(xmin + cell_m / 2, xmax, cell_m)
    ys = np.arange(ymin + cell_m / 2, ymax, cell_m)
    X, Y = np.meshgrid(xs, ys)
    pts = np.column_stack([X.ravel(), Y.ravel()])
    inside = np.array([m.survey_area.contains(x, y) for x, y in pts])
    for z in m.exclusion_zones:
        inside &= ~np.array([z.polygon.contains(x, y) for x, y in pts])
    targets = pts[inside]
    tree = cKDTree(targets)
    covered = np.zeros(len(targets), dtype=bool)
    tasks = {t.task_id: t for t in m.tasks}
    swath = max((t.swath_width_m for t in tasks.values()), default=40.0)
    band_ok = [b for b in m.altitude_bands if b.purpose == "survey"]
    zmin = min(b.floor_m for b in band_ok) - 5 if band_ok else 0
    zmax = max(b.ceiling_m for b in band_ok) + 5 if band_ok else 1e9
    for d, a in _truth_arrays(res).items():
        sel = a["payload"] & (a["p"][:, 2] >= zmin) & (a["p"][:, 2] <= zmax)
        if not sel.any():
            continue
        for idx in tree.query_ball_point(a["p"][sel][:, :2], r=swath / 2.0):
            covered[idx] = True
    return float(covered.mean()) if len(covered) else 0.0, int(len(covered)), int(covered.sum()), targets, covered


def duplicates(res: SimulationResult, task_registry: dict[str, Any]) -> tuple[float, int]:
    """Along-lane duplicated length (beyond the configured split overlap) and the
    number of instances where two aircraft surveyed the same root lane at the
    same time (should be zero)."""
    per_lane: dict[str, list[tuple[str, float, float, float, float]]] = {}
    roots = {tid: (t.root_task_id or tid) for tid, t in task_registry.items()}
    for d, a in _truth_arrays(res).items():
        T, P, tasks = a["t"], a["p"], a["task"]
        on = a["payload"]
        i = 0
        n = len(T)
        while i < n:
            if not on[i] or not tasks[i]:
                i += 1
                continue
            j = i
            while j + 1 < n and on[j + 1] and tasks[j + 1] == tasks[i]:
                j += 1
            tid = str(tasks[i])
            root = roots.get(tid, tid)
            rt = task_registry.get(root)
            if rt is not None:
                ax = np.asarray(rt.start_xy)
                u = np.asarray(rt.end_xy) - ax
                L = float(np.linalg.norm(u))
                u = u / L if L > 0 else u
                s = (P[i:j + 1, :2] - ax) @ u
                per_lane.setdefault(root, []).append((d, float(s.min()), float(s.max()), float(T[i]), float(T[j])))
            i = j + 1
    dup = 0.0
    concurrent = 0
    overlap_allow = res.mission.lane_overlap_m + 3.0
    for root, segs in per_lane.items():
        for k in range(len(segs)):
            for l in range(k + 1, len(segs)):
                a, b = segs[k], segs[l]
                ov = min(a[2], b[2]) - max(a[1], b[1])
                if ov > 0:
                    dup += max(0.0, ov - overlap_allow)
                    if a[0] != b[0] and min(a[4], b[4]) > max(a[3], b[3]):
                        concurrent += 1
    return dup, concurrent


def separation_series(res: SimulationResult, dt: float = 0.25) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict[tuple[str, str], float]]:
    arr = _truth_arrays(res)
    ids = sorted(arr)
    t0 = max(min(a["t"][0] for a in arr.values()), 0.0)
    t1 = max(a["t"][-1] for a in arr.values())
    T = np.arange(t0, t1, dt)
    P = {d: np.column_stack([np.interp(T, arr[d]["t"], arr[d]["p"][:, k]) for k in range(3)]) for d in ids}
    min3 = np.full(len(T), np.inf)
    minh_v = np.full(len(T), np.inf)
    pair_min: dict[tuple[str, str], float] = {}
    for i, a in enumerate(ids):
        for b in ids[i + 1:]:
            air = (P[a][:, 2] > GROUND) & (P[b][:, 2] > GROUND)
            dd = np.linalg.norm(P[a] - P[b], axis=1)
            dh = np.linalg.norm(P[a][:, :2] - P[b][:, :2], axis=1)
            dv = np.abs(P[a][:, 2] - P[b][:, 2])
            d3 = np.where(air, dd, np.inf)
            min3 = np.minimum(min3, d3)
            vs = res.system.separation.vertical_m
            minh_v = np.minimum(minh_v, np.where(air & (dv < vs), dh, np.inf))
            pair_min[(a, b)] = float(d3.min()) if np.isfinite(d3).any() else float("inf")
    return T, min3, minh_v, pair_min


def _pause_times_coord(res: SimulationResult, d: str) -> list[float]:
    """Coordination times at which aircraft ``d`` stopped following its plan
    (pause, lease lapse, reserve hold, contingency, start failure)."""
    if res.world_coord_of is None:
        return []
    out = []
    for rec, (_, conv) in zip(res.agent_records.get(d, []), res.agent_world_of.get(d, [])):
        for t_local, kind, _ in rec.events:
            if kind in ("paused", "contingency", "start_failed", "coordination_abort"):
                out.append(float(res.world_coord_of(conv(t_local))))
    return sorted(out)


def _predicted_violations(res: SimulationResult) -> int:
    """Conflicts between the *as-commanded* trajectories with zero buffers: each
    committed plan is followed from its effective time until the next plan takes
    over or the aircraft stopped following it (it then holds where the plan had
    it at that moment).  Should be zero by construction."""
    from ..separation.conflicts import Buffers, ConflictChecker

    plans = res.committed_plans
    if not plans:
        return 0
    trajs = {}
    for d, hist in plans.items():
        hist = sorted(hist, key=lambda p: p.effective_from)
        pauses = _pause_times_coord(res, d)
        T, X, Y, Z, PH, TK = [], [], [], [], [], []
        for k, dp in enumerate(hist):
            end = hist[k + 1].effective_from if k + 1 < len(hist) else math.inf
            stop = min([p for p in pauses if dp.effective_from <= p < end], default=math.inf)
            tr = dp.trajectory
            for i in range(len(tr.t)):
                if dp.effective_from - 1e-9 <= tr.t[i] < min(end, stop) and (not T or tr.t[i] > T[-1]):
                    T.append(tr.t[i]); X.append(tr.x[i]); Y.append(tr.y[i]); Z.append(tr.z[i])
                    PH.append(tr.phase[i]); TK.append(tr.task[i])
            if math.isfinite(stop):
                p = tr.position_at(stop)
                for tt in (stop, end if math.isfinite(end) else stop + 1.0):
                    if not T or tt > T[-1]:
                        T.append(tt); X.append(float(p[0])); Y.append(float(p[1])); Z.append(float(p[2]))
                        PH.append(PH[-1] if PH else tr.phase[0]); TK.append(None)
        if len(T) >= 2:
            trajs[d] = hist[-1].trajectory.model_copy(update=dict(t=T, x=X, y=Y, z=Z, phase=PH, task=TK))
    chk = ConflictChecker(res.system.separation, None, Buffers(0.0, 0.0))
    rep = chk.check(trajs, include_static=False)
    return len(rep)


def compute_metrics(res: SimulationResult) -> Metrics:
    o = res.outcome
    cov, n_cells, n_cov, _, _ = coverage(res)
    registry = res.task_registry or {t.task_id: t for t in res.mission.tasks}
    dup, conc = duplicates(res, registry)
    arr = _truth_arrays(res)
    # mission duration: first take-off to last landing (truth)
    t_air = [a["t"][a["p"][:, 2] > GROUND] for a in arr.values()]
    t_air = [x for x in t_air if len(x)]
    duration = float(max(x[-1] for x in t_air) - min(x[0] for x in t_air)) if t_air else 0.0
    T, min3, minh, _ = separation_series(res)
    finite = np.isfinite(min3)
    infr = float(np.sum(np.isfinite(minh) & (minh < res.system.separation.horizontal_m)) * 0.25)
    # synchronised start: agent start (agent clock -> world) vs planned effective_from (coord -> world)
    sync: dict[str, float] = {}
    takeoff: dict[str, float] = {}
    plan0 = o.initial_plan if o else None
    if plan0 is not None:
        for d, dp in plan0.drone_plans.items():
            planned_world = res.coord_world_of(dp.effective_from)
            for rec, (boot, conv) in zip(res.agent_records[d], res.agent_world_of[d]):
                ev = [e for e in rec.events if e[1] == "plan_started" and e[2].get("plan_version") == dp.plan_version]
                if ev:
                    sync[d] = conv(ev[0][0]) - planned_world
                    break
            fa = dp.trajectory.first_airborne_time()
            if fa is not None and d in arr:
                a = arr[d]
                up = np.nonzero(a["p"][:, 2] > 0.5)[0]
                if len(up):
                    # actual crossing of 0.5 m vs planned crossing of 0.5 m
                    tr = dp.trajectory
                    Tt, Pt = tr.arrays()
                    k = np.nonzero(Pt[:, 2] > 0.5)[0]
                    if len(k):
                        takeoff[d] = float(a["t"][up[0]] - res.coord_world_of(Tt[k[0]]))
    lat = [x[2] for x in res.coordinator_record.command_latency]
    reassign = [r["committed_at"] - r["suspended_at"] for r in (o.reassignments if o else [])
                if r.get("committed_at") and r.get("suspended_at")]
    reassign_exec: list[float] = []
    for r in (o.reassignments if o else []):
        a = arr.get(r["to"])
        if a is None or r.get("suspended_at") is None:
            continue
        hit = np.nonzero(a["payload"] & (a["task"] == r["task"]))[0]
        if len(hit):
            reassign_exec.append(float(a["t"][hit[0]] - res.coord_world_of(r["suspended_at"])))
    comm: list[float] = []
    for rc in (o.reconciliations if o else []):
        if rc.get("resume_effective_from") is None:
            continue
        ep_end = [e.end_s for e in res.link_episodes if e.node_id == rc["drone"] and
                  e.end_s <= res.coord_world_of(rc["t"]) + 1.0]
        if ep_end:
            comm.append(float(res.coord_world_of(rc["resume_effective_from"]) - max(ep_end)))
    events: dict[str, int] = {}
    for ev in res.coordinator_record.events:
        events[ev.kind.value] = events.get(ev.kind.value, 0) + 1
    failsafes = sum(1 for a in arr.values() if (a["mode"] == FlightMode.EMERGENCY.value).any())
    landings = [{k: v for k, v in r.items()} for r in (o.recoveries if o else [])]
    spread = (max(sync.values()) - min(sync.values())) if sync else float("nan")
    return Metrics(
        seed=res.seed, finished=bool(o and o.finished), coverage_fraction=cov, coverage_cells=n_cells,
        covered_cells=n_cov, duplicate_length_m=dup, concurrent_duplicate_execution=conc,
        tasks_completed=len(o.completed_tasks) if o else 0,
        tasks_unfinished=len(o.unassigned_tasks) if o else 0, mission_duration_s=duration,
        travel_distance_m=res.distance_m, total_travel_distance_m=float(sum(res.distance_m.values())),
        energy_used_wh=res.energy_used_wh, total_energy_wh=float(sum(res.energy_used_wh.values())),
        min_true_separation_m=float(min3[finite].min()) if finite.any() else float("inf"),
        min_true_horizontal_when_vertical_lt_sep_m=float(minh[np.isfinite(minh)].min())
        if np.isfinite(minh).any() else float("inf"),
        true_separation_infringements_s=infr, predicted_separation_violations=_predicted_violations(res),
        sync_start_error_s=sync, sync_start_abs_max_s=max((abs(v) for v in sync.values()), default=float("nan")),
        sync_start_spread_s=spread, takeoff_error_s=takeoff, command_ack_latency_s=lat,
        reassignment_delay_s=reassign, reassignment_to_execution_s=reassign_exec, recovery_after_comm_loss_s=comm,
        recovery_landings=landings, autopilot_failsafes=failsafes, safety_events=events,
        network=res.network_stats, telemetry_ingest=res.ingest_stats, guard_rejections=res.guard_rejections,
        shutdown_clean=res.shutdown_clean, errors=res.errors, sim_duration_s=res.sim_duration_s,
        wall_time_s=res.wall_time_s,
    )
