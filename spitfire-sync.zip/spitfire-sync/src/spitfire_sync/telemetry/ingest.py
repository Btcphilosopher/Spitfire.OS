"""Telemetry ingestion: validation, de-duplication, ordering, reboot handling.

Raw observations are appended to an immutable log (accepted or not, with
reason codes).  Only accepted observations update the per-aircraft "latest
accepted observation" used by :class:`StateStore` for estimation.
"""

from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass, field
from typing import Callable

from ..config import TelemetryConfig
from ..models.geometry import NavigationFrame
from ..models.state import DroneState
from ..reasons import ReasonCode

VELOCITY_NOISE_ALLOWANCE_M_S = 1.5


@dataclass(frozen=True)
class RawObservation:
    state: DroneState
    receipt_time: float
    accepted: bool
    reasons: tuple[ReasonCode, ...]


@dataclass
class IngestResult:
    accepted: bool
    reasons: list[ReasonCode] = field(default_factory=list)
    new_boot: bool = False
    gap: int = 0
    reset_after_rejects: bool = False


@dataclass
class _Track:
    boot_id: str
    last_seq: int
    current: DroneState
    seen: deque[int] = field(default_factory=lambda: deque(maxlen=512))
    seen_set: set[int] = field(default_factory=set)
    consecutive_rejects: int = 0
    retired_boots: list[str] = field(default_factory=list)

    def remember(self, seq: int) -> None:
        if len(self.seen) == self.seen.maxlen:
            self.seen_set.discard(self.seen[0])
        self.seen.append(seq)
        self.seen_set.add(seq)


@dataclass
class IngestStats:
    received: int = 0
    accepted: int = 0
    duplicates: int = 0
    out_of_order: int = 0
    gaps: int = 0
    missing_observations: int = 0
    rejected_invalid: int = 0
    rejected_kinematic: int = 0
    rejected_time: int = 0
    reboots: int = 0


class TelemetryIngestor:
    def __init__(
        self,
        config: TelemetryConfig,
        planning_frame: NavigationFrame = NavigationFrame.ENU,
        operating_volume: Callable[[float, float, float], bool] | None = None,
    ) -> None:
        self.cfg = config
        self.frame = planning_frame
        self.operating_volume = operating_volume
        self._tracks: dict[str, _Track] = {}
        self.raw_log: deque[RawObservation] = deque(maxlen=config.raw_log_limit)
        self.stats: dict[str, IngestStats] = {}

    # ------------------------------------------------------------------
    def latest(self, drone_id: str) -> DroneState | None:
        tr = self._tracks.get(drone_id)
        return tr.current if tr else None

    def known(self) -> list[str]:
        return sorted(self._tracks)

    def current_boot(self, drone_id: str) -> str | None:
        tr = self._tracks.get(drone_id)
        return tr.boot_id if tr else None

    # ------------------------------------------------------------------
    def _log(self, state: DroneState, receipt: float, ok: bool, reasons: list[ReasonCode]) -> None:
        self.raw_log.append(RawObservation(state, receipt, ok, tuple(reasons)))

    def _validate_static(self, s: DroneState) -> list[ReasonCode]:
        r: list[ReasonCode] = []
        if s.navigation_frame != self.frame or s.position.frame != self.frame or s.velocity.frame != self.frame:
            r.append(ReasonCode.FRAME_MISMATCH)
            return r
        if not (s.position.is_finite() and s.velocity.is_finite()):
            r.append(ReasonCode.INVALID_POSITION)
            return r
        if not math.isfinite(s.position_uncertainty) or s.position_uncertainty <= 0 or (
            s.position_uncertainty > self.cfg.max_accepted_position_uncertainty_m
        ):
            r.append(ReasonCode.INVALID_UNCERTAINTY)
        if s.velocity.norm() > self.cfg.max_plausible_speed_m_s:
            r.append(ReasonCode.IMPLAUSIBLE_SPEED)
        if self.operating_volume is not None and not self.operating_volume(s.position.x, s.position.y, s.position.z):
            r.append(ReasonCode.OUTSIDE_OPERATING_VOLUME)
        if not math.isfinite(s.observation_time):
            r.append(ReasonCode.INVALID_POSITION)
        return r

    def _kinematic_check(self, prev: DroneState, s: DroneState) -> list[ReasonCode]:
        dt = s.observation_time - prev.observation_time
        if dt <= 0:
            return []
        slack = prev.position_uncertainty + s.position_uncertainty
        dp = (s.position - prev.position).norm()
        r: list[ReasonCode] = []
        if max(0.0, dp - slack) / dt > self.cfg.max_plausible_speed_m_s:
            r.append(ReasonCode.IMPLAUSIBLE_SPEED)
        dv = (s.velocity - prev.velocity).norm()
        if max(0.0, dv - 2 * VELOCITY_NOISE_ALLOWANCE_M_S) / dt > self.cfg.max_plausible_accel_m_s2:
            r.append(ReasonCode.IMPOSSIBLE_ACCELERATION)
        return r

    def ingest(self, state: DroneState, receipt_time: float) -> IngestResult:
        st = self.stats.setdefault(state.drone_id, IngestStats())
        st.received += 1
        state = state.model_copy(update={"receipt_time": receipt_time})

        reasons = self._validate_static(state)
        if reasons:
            st.rejected_invalid += 1
            self._log(state, receipt_time, False, reasons)
            return IngestResult(False, reasons)

        # timestamps: never accept observations claimed to be from the future
        skew = state.observation_time - receipt_time
        if skew > self.cfg.max_future_skew_s + state.observation_time_uncertainty:
            st.rejected_time += 1
            self._log(state, receipt_time, False, [ReasonCode.FUTURE_TIMESTAMP])
            return IngestResult(False, [ReasonCode.FUTURE_TIMESTAMP])

        tr = self._tracks.get(state.drone_id)
        if tr is None:
            tr = _Track(boot_id=state.boot_id, last_seq=state.sequence_number, current=state)
            tr.remember(state.sequence_number)
            self._tracks[state.drone_id] = tr
            st.accepted += 1
            self._log(state, receipt_time, True, [ReasonCode.OK])
            return IngestResult(True, [ReasonCode.OK])

        if receipt_time - state.observation_time > self.cfg.max_observation_age_s:
            st.rejected_time += 1
            self._log(state, receipt_time, False, [ReasonCode.TOO_OLD])
            return IngestResult(False, [ReasonCode.TOO_OLD])

        result = IngestResult(True)
        if state.boot_id != tr.boot_id:
            if state.boot_id in tr.retired_boots or state.observation_time <= tr.current.observation_time:
                st.rejected_time += 1
                self._log(state, receipt_time, False, [ReasonCode.STALE_BOOT])
                return IngestResult(False, [ReasonCode.STALE_BOOT])
            # a genuine reboot: sequence numbers restart
            st.reboots += 1
            tr.retired_boots.append(tr.boot_id)
            tr.boot_id = state.boot_id
            tr.seen.clear()
            tr.seen_set.clear()
            tr.last_seq = state.sequence_number - 1
            result.new_boot = True
            result.reasons.append(ReasonCode.SEQUENCE_RESET_NEW_BOOT)
        else:
            seq = state.sequence_number
            if seq in tr.seen_set:
                st.duplicates += 1
                self._log(state, receipt_time, False, [ReasonCode.DUPLICATE_OBSERVATION])
                return IngestResult(False, [ReasonCode.DUPLICATE_OBSERVATION])
            if seq < tr.last_seq:
                # older observation delivered late: keep raw, do not regress the estimate
                st.out_of_order += 1
                tr.remember(seq)
                st.missing_observations = max(0, st.missing_observations - 1)
                self._log(state, receipt_time, False, [ReasonCode.OUT_OF_ORDER])
                return IngestResult(False, [ReasonCode.OUT_OF_ORDER])
            if seq > tr.last_seq + 1:
                result.gap = seq - tr.last_seq - 1
                st.gaps += 1
                st.missing_observations += result.gap
                result.reasons.append(ReasonCode.SEQUENCE_GAP)

        kin = self._kinematic_check(tr.current, state)
        if kin:
            tr.consecutive_rejects += 1
            if tr.consecutive_rejects < self.cfg.consecutive_rejects_before_reset:
                st.rejected_kinematic += 1
                tr.remember(state.sequence_number)
                self._log(state, receipt_time, False, kin)
                return IngestResult(False, kin)
            # persistent disagreement: the previous accepted fix is the suspect one
            result.reset_after_rejects = True
            result.reasons.extend(kin)
        tr.consecutive_rejects = 0
        tr.current = state
        tr.last_seq = max(tr.last_seq, state.sequence_number)
        tr.remember(state.sequence_number)
        st.accepted += 1
        if not result.reasons:
            result.reasons.append(ReasonCode.OK)
        self._log(state, receipt_time, True, result.reasons)
        return result
