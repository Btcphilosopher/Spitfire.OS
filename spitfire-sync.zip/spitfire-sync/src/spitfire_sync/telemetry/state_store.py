"""Fleet state estimation with explicit freshness and uncertainty growth."""

from __future__ import annotations

from typing import Iterable

from ..config import FreshnessPolicy, TelemetryConfig
from ..models.geometry import Vec3
from ..models.state import EstimatedDroneState, FleetSnapshot, FleetUncertainty, Freshness
from ..reasons import ReasonCode
from .ingest import IngestResult, TelemetryIngestor


class StateStore:
    def __init__(self, fleet_ids: Iterable[str], telemetry: TelemetryConfig, ingestor: TelemetryIngestor | None = None):
        self.fleet_ids = sorted(fleet_ids)
        self.ingestor = ingestor or TelemetryIngestor(telemetry)

    def ingest(self, state, receipt_time: float) -> IngestResult:  # type: ignore[no-untyped-def]
        return self.ingestor.ingest(state, receipt_time)

    def estimate(self, drone_id: str, as_of: float, policy: FreshnessPolicy) -> EstimatedDroneState:
        s = self.ingestor.latest(drone_id)
        if s is None:
            return EstimatedDroneState(
                drone_id=drone_id, boot_id=None, freshness=Freshness.NEVER_SEEN, as_of=as_of,
                last_observation_time=None, age_s=None, observed_position=None, position=None, velocity=None,
                position_uncertainty=float("inf"), predicted=False, prediction_valid_until=None,
                assessable=False, clock_uncertainty=float("inf"), reasons=[ReasonCode.NEVER_SEEN],
            )
        age = as_of - s.observation_time
        clock_u = s.observation_time_uncertainty
        age_hi = max(0.0, age + clock_u)
        if age_hi <= policy.fresh_max_age_s:
            fresh, reason = Freshness.FRESH, ReasonCode.STATE_FRESH
        elif age_hi <= policy.stale_max_age_s:
            fresh, reason = Freshness.STALE, ReasonCode.STATE_STALE
        else:
            fresh, reason = Freshness.LOST, ReasonCode.STATE_LOST
        reasons = [reason]
        speed = s.velocity.norm()
        valid_until = s.observation_time + policy.prediction_horizon_s
        if age_hi <= policy.prediction_horizon_s:
            a = max(0.0, age)
            pos = s.position + s.velocity.scale(a)
            unc = s.position_uncertainty + speed * clock_u + 0.5 * policy.assumed_max_accel_m_s2 * age_hi**2
            predicted = True
        else:
            # prediction no longer valid: last-known position, kinematic reachable radius
            pos = s.position
            horizon = min(age_hi, policy.reachable_horizon_s)
            unc = s.position_uncertainty + policy.max_speed_m_s * horizon
            predicted = False
        assessable = unc <= policy.max_assessable_radius_m and age_hi <= policy.reachable_horizon_s
        if not assessable:
            reasons.append(ReasonCode.POSITION_UNASSESSABLE)
        vel = s.velocity if predicted else Vec3.enu(0.0, 0.0, 0.0)
        return EstimatedDroneState(
            drone_id=drone_id, boot_id=s.boot_id, freshness=fresh, as_of=as_of,
            last_observation_time=s.observation_time, age_s=age, observed_position=s.position, position=pos,
            velocity=vel, position_uncertainty=unc, predicted=predicted,
            prediction_valid_until=valid_until if predicted else None, assessable=assessable,
            clock_uncertainty=clock_u, battery_state=s.battery_state, flight_mode=s.flight_mode,
            armed_status=s.armed_status, agent_status=s.agent_status, active_task_id=s.active_task_id,
            active_lease_id=s.active_lease_id, plan_version=s.plan_version, task_progress_m=s.task_progress_m,
            link_health=s.link_health, reasons=reasons,
        )

    def snapshot(self, as_of: float, freshness_policy: FreshnessPolicy) -> FleetSnapshot:
        ids = sorted(set(self.fleet_ids) | set(self.ingestor.known()))
        drones = {d: self.estimate(d, as_of, freshness_policy) for d in ids}
        pos_u = {d: e.position_uncertainty for d, e in drones.items()}
        clk_u = {d: e.clock_uncertainty for d, e in drones.items()}
        finite_pos = [v for v in pos_u.values() if v != float("inf")]
        finite_clk = [v for v in clk_u.values() if v != float("inf")]
        unc = FleetUncertainty(
            max_position_uncertainty=max(finite_pos, default=0.0),
            max_clock_uncertainty=max(finite_clk, default=0.0),
            position_uncertainty=pos_u,
            clock_uncertainty=clk_u,
        )
        return FleetSnapshot(as_of=as_of, drones=drones, uncertainty=unc)
