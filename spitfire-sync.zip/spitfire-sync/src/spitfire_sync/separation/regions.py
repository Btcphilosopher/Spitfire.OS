"""Conservative regions for uncertain aircraft, reservation tables, hold-point safety."""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from ..config import FreshnessPolicy, SeparationConfig
from ..models.geometry import Vec3
from ..models.state import EstimatedDroneState
from ..models.trajectory import (
    EndBehaviour,
    Phase,
    Reservation,
    ReservationKind,
    Trajectory,
    Volume,
    VolumeKind,
)
from ..reasons import ReasonCode
from .conflicts import Buffers, ConflictChecker, ConflictReport


def kinematic_region(est: EstimatedDroneState, now: float, policy: FreshnessPolicy, horizon_s: float,
                     ceiling_m: float) -> tuple[Reservation | None, bool]:
    """Ball-like cylinder the aircraft could reach by ``now + horizon_s`` from its
    last accepted observation.  Returns (reservation, assessable).  Once the
    radius exceeds the policy limit, the aircraft is flagged unassessable and
    the (capped) region is still returned so planners avoid it."""
    if est.observed_position is None or est.last_observation_time is None:
        return None, False
    elapsed = max(0.0, now + horizon_s - est.last_observation_time + est.clock_uncertainty)
    capped = min(elapsed, policy.reachable_horizon_s)
    radius = (est.position_uncertainty if est.predicted else 0.0) + policy.max_speed_m_s * capped + 2.0
    assessable = radius <= policy.max_assessable_radius_m and elapsed <= policy.reachable_horizon_s
    p = est.observed_position
    vol = Volume(kind=VolumeKind.CYLINDER, points=[(p.x, p.y)], radius_m=radius,
                 z_min=max(0.0, p.z - policy.max_speed_m_s * capped), z_max=min(ceiling_m + 10, p.z + policy.max_speed_m_s * capped))
    return Reservation(reservation_id=f"uncertain/{est.drone_id}", holder=est.drone_id,
                       kind=ReservationKind.UNCERTAIN_REGION, volume=vol, t_start=now,
                       t_end=now + horizon_s), assessable


def contract_region(traj: Trajectory, t_known: float, t_until: float, inflate_m: float,
                    holder: str) -> Reservation:
    """Corridor covering the planned path between ``t_known`` (last confirmed
    conformance) and ``t_until`` (e.g. lease expiry after which the aircraft is
    contractually holding).  Valid while the aircraft obeys the agent contract:
    follow the committed plan only while its lease is valid, otherwise hold."""
    T, P = traj.arrays()
    sel = (T >= t_known) & (T <= t_until)
    pts = [traj.position_at(t_known)] + [P[i] for i in np.nonzero(sel)[0]] + [traj.position_at(t_until)]
    arr = np.asarray(pts)
    # thin the polyline
    keep = [arr[0]]
    for q in arr[1:]:
        if np.linalg.norm(q[:2] - keep[-1][:2]) > 10.0:
            keep.append(q)
    keep.append(arr[-1])
    xy = [(float(q[0]), float(q[1])) for q in keep]
    zs = arr[:, 2]
    vol = Volume(kind=VolumeKind.CORRIDOR if len(xy) > 1 else VolumeKind.CYLINDER, points=xy,
                 radius_m=inflate_m, z_min=float(zs.min()) - inflate_m, z_max=float(zs.max()) + inflate_m)
    return Reservation(reservation_id=f"contract/{holder}", holder=holder, kind=ReservationKind.UNCERTAIN_REGION,
                       volume=vol, t_start=t_known, t_end=float("inf"))


def contingency_regions(holder: str, base: Reservation, calt: float, hold_point: Vec3, pad: Vec3,
                        inflate_m: float, t_start: float) -> list[Reservation]:
    """Volumes the aircraft may occupy if it executes its *own* contingency
    from anywhere inside ``base``: vertical column to its contingency altitude,
    transfer to its hold point, return to its pad (also the autopilot RTL path
    when RTL altitude equals the contingency altitude) and descent at the pad."""
    pts = np.asarray(base.volume.points, dtype=float)
    mid = pts.mean(axis=0)
    spread = float(np.max(np.linalg.norm(pts - mid, axis=1))) if len(pts) > 1 else 0.0
    zr = (calt - inflate_m, calt + inflate_m)
    out = [
        Reservation(reservation_id=f"contingency-column/{holder}", holder=holder,
                    kind=ReservationKind.UNCERTAIN_REGION,
                    volume=Volume(kind=base.volume.kind, points=base.volume.points, radius_m=base.volume.radius_m,
                                  z_min=base.volume.z_min, z_max=calt + inflate_m),
                    t_start=t_start, t_end=float("inf")),
        Reservation(reservation_id=f"contingency-transfer/{holder}", holder=holder,
                    kind=ReservationKind.UNCERTAIN_REGION,
                    volume=Volume(kind=VolumeKind.CORRIDOR, points=[(float(mid[0]), float(mid[1])),
                                                                     (hold_point.x, hold_point.y),
                                                                     (pad.x, pad.y)],
                                  radius_m=inflate_m + spread, z_min=zr[0], z_max=zr[1]),
                    t_start=t_start, t_end=float("inf")),
        Reservation(reservation_id=f"contingency-rtl/{holder}", holder=holder, kind=ReservationKind.UNCERTAIN_REGION,
                    volume=Volume(kind=VolumeKind.CORRIDOR, points=[(float(mid[0]), float(mid[1])), (pad.x, pad.y)],
                                  radius_m=inflate_m + spread, z_min=zr[0], z_max=zr[1]),
                    t_start=t_start, t_end=float("inf")),
        Reservation(reservation_id=f"contingency-pad/{holder}", holder=holder, kind=ReservationKind.UNCERTAIN_REGION,
                    volume=Volume(kind=VolumeKind.CYLINDER, points=[(pad.x, pad.y)], radius_m=inflate_m,
                                  z_min=0.0, z_max=calt + inflate_m),
                    t_start=t_start, t_end=float("inf")),
    ]
    return out


def stationary_trajectory(drone_id: str, p: Vec3, t0: float, t1: float) -> Trajectory:
    return Trajectory(drone_id=drone_id, t=[t0, t1], x=[p.x, p.x], y=[p.y, p.y], z=[p.z, p.z],
                      phase=[Phase.HOLD, Phase.HOLD], task=[None, None], end_behaviour=EndBehaviour.HOLD,
                      max_speed_m_s=0.0, interp_error_m=0.0)


@dataclass
class HoldCheck:
    safe: bool
    reason: ReasonCode
    report: ConflictReport | None = None


class HoldPointChecker:
    """A hold point is safe only if, for the whole hold window, it is separated
    from every other aircraft's trajectory, every other hold point, all
    reservations it does not own, exclusion zones, the boundary and ceiling."""

    def __init__(self, checker: ConflictChecker, sep: SeparationConfig) -> None:
        self.checker = checker
        self.sep = sep

    def check(self, drone_id: str, point: Vec3, t0: float, t1: float, others: dict[str, Trajectory],
              other_holds: dict[str, Vec3], reservations: list[Reservation],
              buffers: dict[str, Buffers] | None = None) -> HoldCheck:
        H = self.sep.horizontal_m + 2 * self.sep.hold_point_radius_m
        V = self.sep.vertical_m + 2 * self.sep.hold_point_radius_m
        for d in sorted(other_holds):
            if d == drone_id:
                continue
            q = other_holds[d]
            if math.hypot(point.x - q.x, point.y - q.y) < H and abs(point.z - q.z) < V:
                return HoldCheck(False, ReasonCode.NO_SAFE_HOLD_POINT)
        st = stationary_trajectory(drone_id, point, t0, t1)
        rep = self.checker.check({drone_id: st}, existing={k: v for k, v in others.items() if k != drone_id},
                                 reservations=reservations, buffers=buffers, t_from=t0)
        if not rep.ok:
            return HoldCheck(False, ReasonCode.NO_SAFE_HOLD_POINT, rep)
        return HoldCheck(True, ReasonCode.OK, rep)


class ReservationTable:
    """Conservative reservation book for shared resources (recovery area,
    corridors).  Intervals are half-open [t_start, t_end)."""

    def __init__(self) -> None:
        self._items: dict[str, Reservation] = {}

    def all(self) -> list[Reservation]:
        return [self._items[k] for k in sorted(self._items)]

    def add(self, r: Reservation) -> None:
        self._items[r.reservation_id] = r

    def remove(self, reservation_id: str) -> None:
        self._items.pop(reservation_id, None)

    def remove_holder(self, holder: str, kind: ReservationKind | None = None) -> None:
        for k in sorted(self._items):
            r = self._items[k]
            if r.holder == holder and (kind is None or r.kind == kind):
                del self._items[k]

    def for_resource(self, resource: str) -> list[Reservation]:
        return sorted((r for r in self._items.values() if r.resource == resource), key=lambda r: r.t_start)

    def free_slot(self, resource: str, earliest: float, duration: float, capacity: int = 1,
                  exclude_holder: str | None = None) -> float:
        """Earliest start >= ``earliest`` such that occupancy of ``resource`` stays below capacity."""
        rs = [r for r in self.for_resource(resource) if r.holder != exclude_holder]
        t = earliest
        for _ in range(1000):
            overlapping = [r for r in rs if r.overlaps_time(t, t + duration)]
            if len(overlapping) < capacity:
                # check capacity at every boundary inside the window
                pts = sorted({t} | {r.t_start for r in overlapping if t < r.t_start < t + duration})
                if all(sum(1 for r in rs if r.t_start <= p < r.t_end) < capacity for p in pts):
                    return t
            t = min(r.t_end for r in overlapping)
        raise RuntimeError("no free slot found")
