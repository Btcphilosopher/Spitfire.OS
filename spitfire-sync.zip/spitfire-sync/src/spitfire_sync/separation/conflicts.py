"""Space-time conflict detection between time-parameterised trajectories.

Pairwise check (exact for the piecewise-linear representation)
--------------------------------------------------------------
Both trajectories are evaluated on the union of their sample times, so over
each resulting interval both aircraft move linearly and their *relative*
motion is linear.  On an interval the squared horizontal distance is a
quadratic in the interval parameter s in [0, 1] and the vertical offset is
linear, so the set of s where horizontal < H_req **and** |vertical| < V_req is
computed in closed form.  This catches conflicts *between* samples (e.g. two
aircraft crossing mid-segment), not just at sample instants.

Buffers
-------
H_req = horizontal_sep + b_a + b_b + v_a*tau_a + v_b*tau_b
V_req = vertical_sep   + b_a + b_b + |vz_a|*tau_a + |vz_b|*tau_b

where b = position uncertainty + tracking tolerance + interpolation error and
tau = timing uncertainty (clock uncertainty + start tolerance + extra buffer).
Separation is only evaluated while at least one of the pair is airborne and
both are above ``ground_level_m`` (ground positions are validated statically
by pad/spot spacing).

Scope: these checks cover only the modelled aircraft and modelled hazards
(exclusion zones, boundary, ceiling, reservations).  They do not establish
airspace safety and do not replace onboard detect-and-avoid.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from ..config import SeparationConfig
from ..models.mission import Mission
from ..models.trajectory import (
    Conflict,
    ConflictKind,
    Phase,
    Reservation,
    ReservationKind,
    Trajectory,
    VolumeKind,
)
from ..reasons import ReasonCode


@dataclass(frozen=True)
class Buffers:
    """Per-aircraft buffers used by the checker."""

    spatial_m: float
    timing_s: float

    @classmethod
    def from_config(cls, sep: SeparationConfig, position_uncertainty: float | None = None,
                    clock_uncertainty: float = 0.0, start_tolerance: float = 0.0,
                    interp_error: float = 0.5) -> "Buffers":
        pu = max(sep.nominal_position_uncertainty_m, position_uncertainty or 0.0)
        return cls(
            spatial_m=pu + sep.tracking_tolerance_m + interp_error,
            timing_s=clock_uncertainty + start_tolerance + sep.extra_timing_buffer_s,
        )


@dataclass
class ConflictReport:
    conflicts: list[Conflict] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.conflicts

    def involving(self, drone_id: str) -> list[Conflict]:
        return [c for c in self.conflicts if drone_id in c.drones]

    def __len__(self) -> int:
        return len(self.conflicts)


# ---------------------------------------------------------------------------
# vectorised polygon helpers
# ---------------------------------------------------------------------------


def _points_polygon_distance(pts: np.ndarray, poly: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Return (distance to boundary, inside flag) for points (N,2) vs polygon (M,2)."""
    a = poly
    b = np.roll(poly, -1, axis=0)
    ab = b - a  # (M,2)
    ap = pts[:, None, :] - a[None, :, :]  # (N,M,2)
    L2 = np.maximum((ab**2).sum(axis=1), 1e-12)
    t = np.clip((ap * ab[None]).sum(axis=2) / L2[None], 0.0, 1.0)
    proj = a[None] + t[..., None] * ab[None]
    d = np.sqrt(((pts[:, None, :] - proj) ** 2).sum(axis=2)).min(axis=1)
    # even-odd ray casting
    y = pts[:, 1][:, None]
    x = pts[:, 0][:, None]
    yi, yj = a[:, 1][None], b[:, 1][None]
    xi, xj = a[:, 0][None], b[:, 0][None]
    cond = (yi > y) != (yj > y)
    with np.errstate(divide="ignore", invalid="ignore"):
        xc = (xj - xi) * (y - yi) / (yj - yi) + xi
    crossing = cond & (x < xc)
    inside = (crossing.sum(axis=1) % 2) == 1
    return d, inside


def _interval_set_quadratic(a: np.ndarray, b: np.ndarray, c: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """For q(s) = a s^2 + b s + c (a >= 0) return (lo, hi, nonempty) of {s in [0,1] : q(s) < 0}."""
    lo = np.ones_like(a)
    hi = np.zeros_like(a)
    deg = a < 1e-12
    # linear / constant case
    with np.errstate(divide="ignore", invalid="ignore"):
        root = -c / b
    lin_lo = np.where(b > 0, 0.0, np.where(b < 0, root, np.where(c < 0, 0.0, 1.0)))
    lin_hi = np.where(b > 0, root, np.where(b < 0, 1.0, np.where(c < 0, 1.0, 0.0)))
    disc = b * b - 4 * a * c
    sq = np.sqrt(np.maximum(disc, 0.0))
    with np.errstate(divide="ignore", invalid="ignore"):
        r1 = (-b - sq) / (2 * a)
        r2 = (-b + sq) / (2 * a)
    quad_lo = np.where(disc > 0, r1, 1.0)
    quad_hi = np.where(disc > 0, r2, 0.0)
    lo = np.where(deg, lin_lo, quad_lo)
    hi = np.where(deg, lin_hi, quad_hi)
    lo = np.clip(lo, 0.0, 1.0)
    hi = np.clip(hi, 0.0, 1.0)
    return lo, hi, hi > lo


def _interval_set_linear_abs(z0: np.ndarray, z1: np.ndarray, V: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """{s in [0,1] : |z0 + s (z1 - z0)| < V}."""
    dz = z1 - z0
    with np.errstate(divide="ignore", invalid="ignore"):
        sa = (-V - z0) / dz
        sb = (V - z0) / dz
    lo = np.where(np.abs(dz) < 1e-12, np.where(np.abs(z0) < V, 0.0, 1.0), np.minimum(sa, sb))
    hi = np.where(np.abs(dz) < 1e-12, np.where(np.abs(z0) < V, 1.0, 0.0), np.maximum(sa, sb))
    lo = np.clip(lo, 0.0, 1.0)
    hi = np.clip(hi, 0.0, 1.0)
    return lo, hi, hi > lo


class ConflictChecker:
    def __init__(self, separation: SeparationConfig, mission: Mission | None = None,
                 default_buffers: Buffers | None = None) -> None:
        self.sep = separation
        self.mission = mission
        self.default_buffers = default_buffers or Buffers.from_config(separation)
        self.task_registry: dict | None = None  # task_id -> MissionTask (incl. remainder tasks)

    # ------------------------------------------------------------------
    def _buf(self, buffers: dict[str, Buffers] | None, drone: str, traj: Trajectory) -> Buffers:
        b = (buffers or {}).get(drone, self.default_buffers)
        if traj.interp_error_m > 0.5:
            b = Buffers(b.spatial_m + traj.interp_error_m - 0.5, b.timing_s)
        return b

    def pair(self, ta: Trajectory, tb: Trajectory, ba: Buffers, bb: Buffers,
             t_from: float | None = None, t_until: float | None = None) -> list[Conflict]:
        Ta, Pa = ta.arrays()
        Tb, Pb = tb.arrays()
        lo = min(Ta[0], Tb[0])
        hi = max(Ta[-1], Tb[-1])
        if t_from is not None:
            lo = max(lo, t_from)
        if t_until is not None:
            hi = min(hi, t_until)
        if hi <= lo:
            return []
        T = np.union1d(Ta[(Ta > lo) & (Ta < hi)], Tb[(Tb > lo) & (Tb < hi)])
        T = np.concatenate([[lo], T, [hi]])
        T = np.unique(T)
        if len(T) < 2:
            return []
        A = np.column_stack([np.interp(T, Ta, Pa[:, k]) for k in range(3)])
        B = np.column_stack([np.interp(T, Tb, Pb[:, k]) for k in range(3)])
        # after end: LANDED aircraft are not airborne
        gl = self.sep.ground_level_m
        air_a = np.maximum(A[:-1, 2], A[1:, 2]) > gl
        air_b = np.maximum(B[:-1, 2], B[1:, 2]) > gl
        if ta.end_behaviour.value == "LANDED":
            air_a &= T[:-1] < Ta[-1]
        if tb.end_behaviour.value == "LANDED":
            air_b &= T[:-1] < Tb[-1]
        both = air_a & air_b
        if not both.any():
            return []
        dt = np.diff(T)
        dt_safe = np.where(dt > 0, dt, 1.0)
        va = np.linalg.norm(A[1:] - A[:-1], axis=1) / dt_safe
        vb = np.linalg.norm(B[1:] - B[:-1], axis=1) / dt_safe
        vza = np.abs(A[1:, 2] - A[:-1, 2]) / dt_safe
        vzb = np.abs(B[1:, 2] - B[:-1, 2]) / dt_safe
        H = self.sep.horizontal_m + ba.spatial_m + bb.spatial_m + va * ba.timing_s + vb * bb.timing_s
        V = self.sep.vertical_m + ba.spatial_m + bb.spatial_m + vza * ba.timing_s + vzb * bb.timing_s
        D0 = A[:-1] - B[:-1]
        D1 = A[1:] - B[1:]
        dd = D1 - D0
        qa = dd[:, 0] ** 2 + dd[:, 1] ** 2
        qb = 2 * (D0[:, 0] * dd[:, 0] + D0[:, 1] * dd[:, 1])
        qc = D0[:, 0] ** 2 + D0[:, 1] ** 2 - H**2
        hlo, hhi, hne = _interval_set_quadratic(qa, qb, qc)
        vlo, vhi, vne = _interval_set_linear_abs(D0[:, 2], D1[:, 2], V)
        slo = np.maximum(hlo, vlo)
        shi = np.minimum(hhi, vhi)
        bad = both & hne & vne & (shi > slo)
        if not bad.any():
            return []
        # minimum horizontal distance on each interval (for reporting)
        with np.errstate(divide="ignore", invalid="ignore"):
            smin = np.clip(np.where(qa > 1e-12, -qb / (2 * qa), 0.0), 0.0, 1.0)
        hmin = np.sqrt(np.maximum(qa * smin**2 + qb * smin + qc + H**2, 0.0))
        idx = np.nonzero(bad)[0]
        out: list[Conflict] = []
        start = idx[0]
        prev = idx[0]
        for i in list(idx[1:]) + [None]:  # type: ignore[list-item]
            if i is not None and i == prev + 1:
                prev = i
                continue
            seg = np.arange(start, prev + 1)
            k = seg[np.argmin(hmin[seg])]
            ts = T[start] + slo[start] * dt[start]
            te = T[prev] + shi[prev] * dt[prev]
            loc = A[k] + smin[k] * (A[k + 1] - A[k])
            vmin = float(np.min(np.minimum(np.abs(D0[seg, 2]), np.abs(D1[seg, 2]))))
            out.append(Conflict(
                kind=ConflictKind.TRAJECTORY_PAIR, drones=tuple(sorted((ta.drone_id, tb.drone_id))),
                t_start=float(ts), t_end=float(te), min_horizontal_m=float(hmin[seg].min()),
                min_vertical_m=vmin, required_horizontal_m=float(H[seg].max()),
                required_vertical_m=float(V[seg].max()), location=(float(loc[0]), float(loc[1]), float(loc[2])),
                reason=ReasonCode.SEPARATION_CONFLICT,
            ))
            if i is not None:
                start = prev = i
        return out

    # ------------------------------------------------------------------
    def static(self, traj: Trajectory, buf: Buffers, t_from: float | None = None) -> list[Conflict]:
        m = self.mission
        if m is None:
            return []
        T, P = traj.arrays()
        if t_from is not None:
            keep = T >= t_from - 1e-9
            if not keep.any():
                return []
            T, P = T[keep], P[keep]
        air = P[:, 2] > self.sep.ground_level_m
        if not air.any():
            return []
        steps = np.linalg.norm(np.diff(P, axis=0), axis=1) if len(P) > 1 else np.zeros(1)
        half_step = 0.5 * float(steps.max()) if len(steps) else 0.0
        margin = buf.spatial_m + half_step
        out: list[Conflict] = []
        xy = P[:, :2]
        # exclusion zones (with altitude overlap), active at the sample time
        for z in m.exclusion_zones:
            poly = np.asarray(z.polygon.vertices, dtype=float)
            d, inside = _points_polygon_distance(xy, poly)
            alt_ok = (P[:, 2] + buf.spatial_m >= z.floor_m) & (P[:, 2] - buf.spatial_m <= z.ceiling_m)
            active = np.array([z.active_at(float(t)) for t in T])
            hit = air & alt_ok & active & (inside | (d < margin))
            if hit.any():
                i = np.nonzero(hit)[0]
                out.append(Conflict(kind=ConflictKind.EXCLUSION_ZONE, drones=(traj.drone_id,),
                                    t_start=float(T[i[0]]), t_end=float(T[i[-1]]),
                                    location=tuple(float(v) for v in P[i[0]]),  # type: ignore[arg-type]
                                    reason=ReasonCode.EXCLUSION_ZONE_INCURSION, detail=z.zone_id))
        # operational boundary (geofence): stay inside by margin
        poly = np.asarray(m.operational_boundary.vertices, dtype=float)
        d, inside = _points_polygon_distance(xy, poly)
        hit = air & (~inside | (d < buf.spatial_m))
        if hit.any():
            i = np.nonzero(hit)[0]
            out.append(Conflict(kind=ConflictKind.GEOFENCE, drones=(traj.drone_id,), t_start=float(T[i[0]]),
                                t_end=float(T[i[-1]]), location=tuple(float(v) for v in P[i[0]]),  # type: ignore[arg-type]
                                reason=ReasonCode.GEOFENCE_EXIT))
        hit = P[:, 2] + buf.spatial_m > m.ceiling_m
        if hit.any():
            i = np.nonzero(hit)[0]
            out.append(Conflict(kind=ConflictKind.CEILING, drones=(traj.drone_id,), t_start=float(T[i[0]]),
                                t_end=float(T[i[-1]]), reason=ReasonCode.CEILING_EXCEEDED))
        return out

    def reservations(self, traj: Trajectory, reservations: list[Reservation], buf: Buffers,
                     t_from: float | None = None) -> list[Conflict]:
        """Samples of ``traj`` inside another holder's reserved volume during
        its window (inflated by buffers).  A HOLD end behaviour occupies the
        final point for ever after; reported times are those of the hits."""
        if not reservations:
            return []
        T0, P0 = traj.arrays()
        hold_tail = traj.end_behaviour.value == "HOLD"
        out: list[Conflict] = []
        for r in reservations:
            if r.holder == traj.drone_id:
                continue
            lo = r.t_start - buf.timing_s
            hi = r.t_end + buf.timing_s
            if t_from is not None:
                lo = max(lo, t_from)
            if hi < lo:
                continue
            T, P = T0, P0
            if hold_tail and hi > T0[-1]:
                tail_t = max(T0[-1], lo)
                T = np.concatenate([T0, [tail_t]])
                P = np.vstack([P0, P0[-1:]])
            sel = (T >= lo) & (T <= hi)
            if not sel.any():
                continue
            ts, pts = T[sel], P[sel]
            air = pts[:, 2] > self.sep.ground_level_m
            vol = r.volume
            margin = buf.spatial_m + 0.5 * self.sep.horizontal_m
            if vol.kind == VolumeKind.CYLINDER or len(vol.points) == 1:
                c = np.asarray(vol.points[0])
                dh = np.linalg.norm(pts[:, :2] - c, axis=1) - vol.radius_m
            else:
                poly_pts = np.asarray(vol.points, dtype=float)
                a, b = poly_pts[:-1], poly_pts[1:]
                ab = b - a
                ap = pts[:, None, :2] - a[None]
                L2 = np.maximum((ab**2).sum(axis=1), 1e-12)
                t = np.clip((ap * ab[None]).sum(axis=2) / L2[None], 0, 1)
                proj = a[None] + t[..., None] * ab[None]
                dh = np.sqrt(((pts[:, None, :2] - proj) ** 2).sum(axis=2)).min(axis=1) - vol.radius_m
            vmargin = buf.spatial_m + self.sep.vertical_m * 0.5
            inz = (pts[:, 2] >= vol.z_min - vmargin) & (pts[:, 2] <= vol.z_max + vmargin)
            hit = air & inz & (dh < margin)
            if hit.any():
                th = ts[hit]
                kind = (ConflictKind.UNCERTAIN_REGION if r.kind == ReservationKind.UNCERTAIN_REGION
                        else ConflictKind.RESERVATION)
                reason = (ReasonCode.UNCERTAIN_REGION_CONFLICT if r.kind == ReservationKind.UNCERTAIN_REGION
                          else ReasonCode.RESERVATION_CONFLICT)
                k = int(np.nonzero(hit)[0][0])
                out.append(Conflict(kind=kind, drones=tuple(sorted((traj.drone_id, r.holder))),
                                    t_start=float(th.min()), t_end=float(th.max()),
                                    min_horizontal_m=float(max(0.0, dh[hit].min())),
                                    location=(float(pts[k, 0]), float(pts[k, 1]), float(pts[k, 2])),
                                    reason=reason, detail=r.reservation_id))
        return out

    def survey_bands(self, traj: Trajectory, tolerance_m: float = 3.0) -> list[Conflict]:
        if self.mission is None:
            return []
        out: list[Conflict] = []
        tasks = self.task_registry or {t.task_id: t for t in self.mission.tasks}
        for i, (ph, tid) in enumerate(zip(traj.phase[:-1], traj.task[:-1])):
            if ph != Phase.SURVEY or tid is None:
                continue
            task = tasks.get(tid)
            if task is None:
                continue
            z = traj.z[i]
            ok = any(self.mission.band(b).floor_m - tolerance_m <= z <= self.mission.band(b).ceiling_m + tolerance_m
                     for b in task.permitted_bands)
            if not ok:
                out.append(Conflict(kind=ConflictKind.ALTITUDE_BAND, drones=(traj.drone_id,), t_start=traj.t[i],
                                    t_end=traj.t[i + 1], reason=ReasonCode.SEPARATION_CONFLICT,
                                    detail=f"task {tid} flown outside permitted bands"))
                break
        return out

    # ------------------------------------------------------------------
    def check(
        self,
        plan_or_trajectories: "dict[str, Trajectory] | object",
        existing: dict[str, Trajectory] | None = None,
        reservations: list[Reservation] | None = None,
        buffers: dict[str, Buffers] | None = None,
        t_from: float | None = None,
        include_static: bool = True,
    ) -> ConflictReport:
        """Check new trajectories against each other, against ``existing``
        trajectories (other aircraft's committed plans), static hazards and
        reservations.  ``plan_or_trajectories`` may be a Plan."""
        if hasattr(plan_or_trajectories, "trajectories"):
            new = plan_or_trajectories.trajectories()  # type: ignore[union-attr]
            res = list(reservations or []) + list(getattr(plan_or_trajectories, "reservations", []))
        else:
            new = dict(plan_or_trajectories)  # type: ignore[arg-type]
            res = list(reservations or [])
        existing = {k: v for k, v in (existing or {}).items() if k not in new}
        report = ConflictReport()
        ids = sorted(new)
        for i, a in enumerate(ids):
            ba = self._buf(buffers, a, new[a])
            for b in ids[i + 1:]:
                report.conflicts += self.pair(new[a], new[b], ba, self._buf(buffers, b, new[b]), t_from=t_from)
            for b in sorted(existing):
                report.conflicts += self.pair(new[a], existing[b], ba, self._buf(buffers, b, existing[b]),
                                              t_from=t_from)
            if include_static:
                report.conflicts += self.static(new[a], ba, t_from=t_from)
                report.conflicts += self.survey_bands(new[a])
            report.conflicts += self.reservations(new[a], res, ba, t_from=t_from)
        return report


def min_pairwise_distance(trajs: dict[str, Trajectory], ground_level: float = 1.0) -> float:
    """Minimum 3-D distance between airborne aircraft (evaluation helper)."""
    ids = sorted(trajs)
    best = math.inf
    for i, a in enumerate(ids):
        Ta, Pa = trajs[a].arrays()
        for b in ids[i + 1:]:
            Tb, Pb = trajs[b].arrays()
            T = np.union1d(Ta, Tb)
            A = np.column_stack([np.interp(T, Ta, Pa[:, k]) for k in range(3)])
            B = np.column_stack([np.interp(T, Tb, Pb[:, k]) for k in range(3)])
            air = (A[:, 2] > ground_level) & (B[:, 2] > ground_level)
            if air.any():
                best = min(best, float(np.linalg.norm(A[air] - B[air], axis=1).min()))
    return best
