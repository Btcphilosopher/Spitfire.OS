"""Horizontal routing around exclusion zones (visibility graph + Dijkstra)."""

from __future__ import annotations

import heapq
import math

from ..models.mission import ExclusionZone, Mission


class Router:
    def __init__(self, mission: Mission, clearance_m: float) -> None:
        self.mission = mission
        self.clearance = clearance_m

    def _zones(self, t: float | None, z_range: tuple[float, float]) -> list[ExclusionZone]:
        out = []
        for zone in self.mission.exclusion_zones:
            if t is not None and zone.active_until < t:
                continue
            if zone.overlaps_altitude(z_range[0] - self.clearance, z_range[1] + self.clearance):
                out.append(zone)
        return out

    def _clear(self, a: tuple[float, float], b: tuple[float, float], zones: list[ExclusionZone]) -> bool:
        if not self.mission.operational_boundary.contains(*a) or not self.mission.operational_boundary.contains(*b):
            return False
        for z in zones:
            # an end point already closer than the clearance (e.g. an aircraft that stopped at a
            # lane end) may leave, but no segment may come closer than its closer end point
            lim = min(self.clearance, z.polygon.distance_to_boundary(*a) if not z.polygon.contains(*a) else 0.0,
                      z.polygon.distance_to_boundary(*b) if not z.polygon.contains(*b) else 0.0)
            if lim <= 0.0 or z.polygon.segment_distance(a, b) < lim - 0.5:
                return False
        # stay inside the boundary along the segment (sample)
        n = max(2, int(math.hypot(b[0] - a[0], b[1] - a[1]) / 20.0))
        for k in range(1, n):
            f = k / n
            p = (a[0] + f * (b[0] - a[0]), a[1] + f * (b[1] - a[1]))
            if not self.mission.operational_boundary.contains(*p):
                return False
        return True

    def route(self, a: tuple[float, float], b: tuple[float, float], altitude: float,
              t: float | None = None) -> list[tuple[float, float]] | None:
        """Shortest clear polyline from a to b (excluding a, including b); None if blocked."""
        zones = self._zones(t, (altitude, altitude))
        if self._clear(a, b, zones):
            return [b]
        nodes: list[tuple[float, float]] = [a, b]
        for z in zones:
            nodes += z.polygon.outset_vertices(self.clearance * 1.2 + 1.0)
        n = len(nodes)
        dist = [math.inf] * n
        prev = [-1] * n
        dist[0] = 0.0
        pq = [(0.0, 0)]
        while pq:
            d, i = heapq.heappop(pq)
            if d > dist[i]:
                continue
            if i == 1:
                break
            for j in range(n):
                if j == i:
                    continue
                if not self._clear(nodes[i], nodes[j], zones):
                    continue
                nd = d + math.hypot(nodes[j][0] - nodes[i][0], nodes[j][1] - nodes[i][1])
                if nd < dist[j] - 1e-9:
                    dist[j] = nd
                    prev[j] = i
                    heapq.heappush(pq, (nd, j))
        if dist[1] == math.inf:
            return None
        path = []
        k = 1
        while k != 0:
            path.append(nodes[k])
            k = prev[k]
        return list(reversed(path))

    def route_length(self, a: tuple[float, float], b: tuple[float, float], altitude: float) -> float:
        r = self.route(a, b, altitude)
        if r is None:
            return math.inf
        L, cur = 0.0, a
        for p in r:
            L += math.hypot(p[0] - cur[0], p[1] - cur[1])
            cur = p
        return L
