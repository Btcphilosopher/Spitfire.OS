"""Time-parameterise waypoint sequences under speed/acceleration/climb limits.

Each straight leg uses a trapezoidal (or triangular) speed profile that starts
and ends at rest.  The along-leg speed and acceleration are scaled so that
the vertical component never exceeds the climb or descent limit.  The profile
is sampled every ``sample_dt_s`` plus exact leg end points; the maximum chord
error of the piecewise-linear samples, a*dt^2/8, is recorded as
``interp_error_m`` and added to separation buffers.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from ..config import KinematicLimits
from ..models.trajectory import EndBehaviour, Phase, Trajectory


@dataclass(frozen=True)
class Leg:
    target: tuple[float, float, float]
    speed: float
    phase: Phase
    task: str | None = None


@dataclass(frozen=True)
class Wait:
    duration: float
    phase: Phase
    task: str | None = None


def leg_profile(L: float, v_max: float, a: float) -> tuple[float, float, float]:
    """Return (duration, t_accel, v_peak) for a rest-to-rest leg of length L."""
    if L <= 1e-9:
        return 0.0, 0.0, 0.0
    t_acc = v_max / a
    d_acc = 0.5 * a * t_acc**2
    if 2 * d_acc >= L:
        v_peak = math.sqrt(a * L)
        t_acc = v_peak / a
        return 2 * t_acc, t_acc, v_peak
    t_cruise = (L - 2 * d_acc) / v_max
    return 2 * t_acc + t_cruise, t_acc, v_max


def _s_of_t(t: float, dur: float, t_acc: float, v: float, a: float, L: float) -> float:
    if t <= 0:
        return 0.0
    if t >= dur:
        return L
    if t < t_acc:
        return 0.5 * a * t * t
    if t <= dur - t_acc:
        return 0.5 * a * t_acc**2 + v * (t - t_acc)
    tr = dur - t
    return L - 0.5 * a * tr * tr


class TrajectoryBuilder:
    def __init__(self, limits: KinematicLimits) -> None:
        self.lim = limits

    def leg_limits(self, d: np.ndarray, speed: float) -> tuple[float, float]:
        L = float(np.linalg.norm(d))
        if L <= 1e-9:
            return speed, self.lim.max_accel_m_s2
        frac_v = abs(d[2]) / L
        v = min(speed, self.lim.max_speed_m_s)
        if frac_v > 1e-9:
            vz_lim = self.lim.max_climb_m_s if d[2] > 0 else self.lim.max_descent_m_s
            v = min(v, vz_lim / frac_v)
        return v, self.lim.max_accel_m_s2

    def leg_duration(self, a: np.ndarray, b: np.ndarray, speed: float) -> float:
        d = b - a
        v, acc = self.leg_limits(d, speed)
        return leg_profile(float(np.linalg.norm(d)), v, acc)[0]

    def build(self, drone_id: str, start: tuple[float, float, float], t0: float,
              steps: list[Leg | Wait], end_behaviour: EndBehaviour = EndBehaviour.HOLD) -> Trajectory:
        dt_s = self.lim.sample_dt_s
        T = [t0]
        X = [np.asarray(start, dtype=float)]
        PH: list[Phase] = []
        TK: list[str | None] = []
        cur = np.asarray(start, dtype=float)
        t = t0
        for st in steps:
            if isinstance(st, Wait):
                if st.duration <= 1e-9:
                    continue
                n = max(1, int(math.ceil(st.duration / max(dt_s * 8, 1.0))))
                for k in range(1, n + 1):
                    T.append(t + st.duration * k / n)
                    X.append(cur.copy())
                    PH.append(st.phase)
                    TK.append(st.task)
                t += st.duration
                continue
            tgt = np.asarray(st.target, dtype=float)
            d = tgt - cur
            L = float(np.linalg.norm(d))
            if L < 1e-6:
                continue
            v, a = self.leg_limits(d, st.speed)
            dur, t_acc, vpk = leg_profile(L, v, a)
            u = d / L
            n = max(1, int(math.ceil(dur / dt_s)))
            for k in range(1, n + 1):
                tk = dur * k / n
                s = _s_of_t(tk, dur, t_acc, vpk, a, L)
                T.append(t + tk)
                X.append(cur + u * s)
                PH.append(st.phase)
                TK.append(st.task)
            t += dur
            cur = tgt
        # phase/task arrays describe intervals; final sample repeats the last label
        last_phase = PH[-1] if PH else (Phase.GROUND if start[2] < 0.5 else Phase.HOLD)
        PH.append(Phase.LANDED if end_behaviour == EndBehaviour.LANDED else last_phase)
        TK.append(None)
        P = np.asarray(X)
        return Trajectory(
            drone_id=drone_id, t=[float(v) for v in T], x=P[:, 0].tolist(), y=P[:, 1].tolist(),
            z=P[:, 2].tolist(), phase=PH, task=TK, end_behaviour=end_behaviour,
            max_speed_m_s=self.lim.max_speed_m_s,
            interp_error_m=max(0.05, self.lim.max_accel_m_s2 * dt_s**2 / 8.0),
        )
