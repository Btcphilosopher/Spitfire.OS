"""Trajectory scheduling with conflict resolution.

Approach: *prioritised planning*.  Aircraft are scheduled one at a time in a
deterministic order; each candidate trajectory is checked against the
trajectories already scheduled in this plan, against existing committed
trajectories of other aircraft, against reservations/uncertain regions and
against static hazards.  For each aircraft the following resolutions are tried
in order and the first conflict-free one is kept:

1. nominal (no delay, default transit and survey band, assigned order);
2. alternative transit altitude band;
3. alternative permitted survey band;
4. adjusted task order (reverse lane order and lane directions);
5. departure delay in increasing steps, combined with 2-4;
6. replanning the end of the plan with another validated hold point.

Hold points are checked by :class:`HoldPointChecker` before selection; two
aircraft are never sent to the same (or an unseparated) hold point.
"""

from __future__ import annotations

import itertools
import math
from dataclasses import dataclass, field
from enum import StrEnum

from ..config import DroneProfile, LostLinkAction, SpitfireConfig
from ..models.geometry import Vec3
from ..models.mission import Mission, MissionTask
from ..models.state import FleetUncertainty
from ..models.trajectory import (
    ContingencyAssignment,
    DronePlan,
    EndBehaviour,
    Phase,
    Plan,
    PlanPurpose,
    Reservation,
    ReservationKind,
    Trajectory,
    Volume,
    VolumeKind,
)
from ..reasons import ReasonCode
from ..allocation.energy import EnergyModel
from ..separation.conflicts import Buffers, ConflictChecker, ConflictReport
from ..separation.regions import HoldPointChecker
from .routing import Router
from .trajectory_builder import Leg, TrajectoryBuilder, Wait


class EndKind(StrEnum):
    HOLD = "HOLD"
    LAND = "LAND"


@dataclass(frozen=True)
class StartState:
    position: tuple[float, float, float]
    time: float
    on_ground: bool
    boot_id: str


@dataclass(frozen=True)
class EndSpec:
    kind: EndKind
    point: tuple[float, float, float]  # hold point (HOLD) or landing spot with z=0 (LAND)


@dataclass(frozen=True)
class RouteOptions:
    delay_s: float = 0.0
    transit_band: str | None = None
    survey_band: str | None = None
    reverse_order: bool = False
    cruise_altitude: float | None = None  # for LAND ends

    def label(self) -> str:
        return (f"delay={self.delay_s:.0f}s transit={self.transit_band} survey={self.survey_band} "
                f"reverse={self.reverse_order} cruise={self.cruise_altitude}")


@dataclass
class DroneRequest:
    drone_id: str
    start: StartState
    tasks: list[tuple[MissionTask, bool]]
    end: EndSpec | None = None  # None => choose a validated hold point
    contingency_altitude: float | None = None


@dataclass
class ScheduledDrone:
    drone_id: str
    trajectory: Trajectory
    options: RouteOptions
    resolution: ReasonCode
    end: EndSpec
    energy_wh: float


@dataclass
class ScheduleResult:
    plan: Plan | None
    scheduled: dict[str, ScheduledDrone] = field(default_factory=dict)
    failed: dict[str, ReasonCode] = field(default_factory=dict)
    report: ConflictReport = field(default_factory=ConflictReport)

    @property
    def ok(self) -> bool:
        return self.plan is not None and not self.failed and self.report.ok


class Scheduler:
    def __init__(self, mission: Mission, config: SpitfireConfig, checker: ConflictChecker,
                 tasks: dict[str, MissionTask] | None = None, max_delay_s: float = 150.0,
                 delay_step_s: float = 3.0) -> None:
        self.mission = mission
        self.cfg = config
        self.checker = checker
        self.tasks = tasks if tasks is not None else {t.task_id: t for t in mission.tasks}
        self.router = Router(mission, clearance_m=config.separation.horizontal_m * 0.5 +
                             config.separation.nominal_position_uncertainty_m + config.separation.tracking_tolerance_m)
        self.hold_checker = HoldPointChecker(checker, config.separation)
        self.max_delay_s = max_delay_s
        self.delay_step_s = delay_step_s
        self.transit_bands = [b.name for b in mission.bands("transit")]
        self._hold_candidates = self._make_hold_candidates()
        self.last_failure: dict[str, list] = {}

    # ------------------------------------------------------------------
    def profile(self, drone_id: str) -> DroneProfile:
        try:
            return self.cfg.profile(drone_id)
        except KeyError:
            return DroneProfile(drone_id=drone_id)

    def contingency_altitude(self, drone_id: str, fleet_ids: list[str]) -> float:
        p = self.profile(drone_id)
        if p.contingency.contingency_altitude_m is not None:
            return p.contingency.contingency_altitude_m
        cont = self.mission.bands("contingency")
        alts = [b.centre_m for b in cont] or [self.mission.ceiling_m - 10]
        i = sorted(fleet_ids).index(drone_id) if drone_id in fleet_ids else 0
        return alts[i % len(alts)]

    def _make_hold_candidates(self) -> list[tuple[float, float]]:
        """Candidate hold positions: a ring just outside the survey area,
        inside the operational boundary, away from the recovery area."""
        xmin, ymin, xmax, ymax = self.mission.survey_area.bounds()
        out: list[tuple[float, float]] = []
        off = 45.0
        step = self.cfg.separation.horizontal_m + 2 * self.cfg.separation.hold_point_radius_m + 6.0
        rec = self.mission.recovery_area
        for y in (ymin - off, ymax + off):
            x = xmin
            while x <= xmax + 1e-6:
                out.append((x, y))
                x += step
        for x in (xmin - off, xmax + off):
            y = ymin
            while y <= ymax + 1e-6:
                out.append((x, y))
                y += step
        bnd = self.mission.operational_boundary
        keep = []
        for p in out:
            if not bnd.contains(*p) or bnd.distance_to_boundary(*p) < 15.0:
                continue
            if math.hypot(p[0] - rec.centre_xy[0], p[1] - rec.centre_xy[1]) < rec.radius_m + 40.0:
                continue
            if any(z.polygon.contains(*p) or z.polygon.distance_to_boundary(*p) < 20 for z in self.mission.exclusion_zones):
                continue
            keep.append(p)
        return keep

    # ------------------------------------------------------------------
    def build_route(self, drone_id: str, start: StartState, tasks: list[tuple[MissionTask, bool]], end: EndSpec,
                    opts: RouteOptions) -> Trajectory | None:
        prof = self.profile(drone_id)
        lim = prof.limits
        b = TrajectoryBuilder(lim)
        steps: list[Leg | Wait] = []
        cur = start.position
        on_ground = start.on_ground
        if opts.delay_s > 0:
            steps.append(Wait(opts.delay_s, Phase.GROUND if on_ground else Phase.HOLD))
        tb = opts.transit_band or (self.transit_bands[0] if self.transit_bands else None)
        transit_alt = self.mission.band(tb).centre_m if tb else 60.0
        order = list(reversed(tasks)) if opts.reverse_order else list(tasks)
        if opts.reverse_order:
            order = [(t, not r) for t, r in order]
        short_hop = 2.2 * 40.0

        def go_vertical(z: float, phase: Phase) -> None:
            nonlocal cur
            if abs(cur[2] - z) > 0.2:
                steps.append(Leg((cur[0], cur[1], z), lim.max_climb_m_s, phase))
                cur = (cur[0], cur[1], z)

        def go_route(xy: tuple[float, float], z: float, phase: Phase) -> bool:
            nonlocal cur
            r = self.router.route((cur[0], cur[1]), xy, z, start.time)
            if r is None:
                return False
            for p in r:
                steps.append(Leg((p[0], p[1], z), lim.transit_speed_m_s, phase))
            cur = (xy[0], xy[1], z)
            return True

        for task, rev in order:
            a, bb = (task.end_xy, task.start_xy) if rev else (task.start_xy, task.end_xy)
            band = opts.survey_band if (opts.survey_band and opts.survey_band in task.permitted_bands) \
                else task.permitted_bands[0]
            s_alt = self.mission.band(band).centre_m
            dxy = math.hypot(cur[0] - a[0], cur[1] - a[1])
            if dxy < 5.0 and abs(cur[2] - s_alt) < 3.0:
                pass
            elif (not on_ground) and dxy <= short_hop and abs(cur[2] - s_alt) < 20.0 and \
                    self.router._clear((cur[0], cur[1]), a, self.router._zones(start.time, (s_alt, s_alt))):
                steps.append(Leg((a[0], a[1], s_alt), lim.transit_speed_m_s, Phase.TRANSIT))
                cur = (a[0], a[1], s_alt)
            else:
                go_vertical(transit_alt, Phase.TAKEOFF if on_ground else Phase.TRANSIT)
                on_ground = False
                if not go_route(a, transit_alt, Phase.TRANSIT):
                    return None
                go_vertical(s_alt, Phase.TRANSIT)
            on_ground = False
            steps.append(Leg((bb[0], bb[1], s_alt), task.survey_speed_m_s, Phase.SURVEY, task.task_id))
            cur = (bb[0], bb[1], s_alt)

        if end.kind == EndKind.HOLD:
            hz = end.point[2]
            go_vertical(hz, Phase.TAKEOFF if on_ground else Phase.TRANSIT)
            if not go_route((end.point[0], end.point[1]), hz, Phase.TRANSIT):
                return None
            behaviour = EndBehaviour.HOLD
        else:
            cz = opts.cruise_altitude or transit_alt
            go_vertical(cz, Phase.TAKEOFF if on_ground else Phase.APPROACH)
            if not go_route((end.point[0], end.point[1]), cz, Phase.APPROACH):
                return None
            flare = 8.0
            if cur[2] > flare:
                steps.append(Leg((cur[0], cur[1], flare), lim.max_descent_m_s, Phase.LANDING))
            steps.append(Leg((cur[0], cur[1], 0.0), lim.landing_descent_m_s, Phase.LANDING))
            behaviour = EndBehaviour.LANDED
        return b.build(drone_id, start.position, start.time, steps, behaviour)

    # ------------------------------------------------------------------
    def _option_space(self, req: DroneRequest, end_kind: EndKind) -> list[RouteOptions]:
        tbs = self.transit_bands or [None]
        survey_sets = sorted({b for t, _ in req.tasks for b in t.permitted_bands})
        sbs: list[str | None] = [None] + [s for s in survey_sets if s != (req.tasks[0][0].permitted_bands[0]
                                                                          if req.tasks else None)]
        reorder = [False, True] if len(req.tasks) > 0 else [False]
        cruise: list[float | None] = [None]
        if end_kind == EndKind.LAND:
            alts = [self.mission.band(t).centre_m for t in self.transit_bands]
            if req.contingency_altitude is not None:
                alts.append(req.contingency_altitude)
            cruise = sorted(set(alts))
        delays = [0.0]
        d = self.delay_step_s
        while d <= self.max_delay_s + 1e-9:
            delays.append(d)
            d += self.delay_step_s if d < 30 else 2 * self.delay_step_s
        out: list[RouteOptions] = []
        seen = set()
        # nominal and single-change resolutions first, then delays
        for delay in delays:
            for tb, sb, rev, cz in itertools.product(tbs, sbs, reorder, cruise):
                o = RouteOptions(delay, tb, sb, rev, cz)
                if o in seen:
                    continue
                seen.add(o)
                out.append(o)
        return out

    @staticmethod
    def _classify(o: RouteOptions, nominal: RouteOptions) -> ReasonCode:
        if o == nominal:
            return ReasonCode.OK
        if o.delay_s > 0:
            return ReasonCode.RESOLVED_BY_DELAY
        if o.reverse_order != nominal.reverse_order:
            return ReasonCode.RESOLVED_BY_REORDER
        return ReasonCode.RESOLVED_BY_ALTITUDE_BAND

    def _hold_options(self, req: DroneRequest, used: dict[str, Vec3], others: dict[str, Trajectory],
                      reservations: list[Reservation], buffers: dict[str, Buffers], t_ref: float) -> list[EndSpec]:
        alt = req.contingency_altitude if req.contingency_altitude is not None else 90.0
        if req.tasks:
            t, rev = req.tasks[-1]
            ref = t.start_xy if rev else t.end_xy
        else:
            ref = (req.start.position[0], req.start.position[1])
        cands = sorted(self._hold_candidates, key=lambda p: (math.hypot(p[0] - ref[0], p[1] - ref[1]), p))
        out = []
        for p in cands:
            pt = Vec3.enu(p[0], p[1], alt)
            chk = self.hold_checker.check(req.drone_id, pt, t_ref, t_ref + 3600.0, {}, used, reservations, buffers)
            if chk.safe:
                out.append(EndSpec(EndKind.HOLD, (p[0], p[1], alt)))
            if len(out) >= 10:
                break
        return out

    def schedule_requests(
        self,
        requests: list[DroneRequest],
        existing: dict[str, Trajectory],
        reservations: list[Reservation],
        buffers: dict[str, Buffers],
        existing_holds: dict[str, Vec3] | None = None,
    ) -> tuple[dict[str, ScheduledDrone], dict[str, ReasonCode]]:
        scheduled: dict[str, ScheduledDrone] = {}
        failed: dict[str, ReasonCode] = {}
        holds: dict[str, Vec3] = dict(existing_holds or {})
        for req in requests:
            others = {**{k: v for k, v in existing.items() if k != req.drone_id},
                      **{k: s.trajectory for k, s in scheduled.items()}}
            holds.pop(req.drone_id, None)
            self.last_failure.pop(req.drone_id, None)
            ends = [req.end] if req.end is not None else self._hold_options(req, holds, others, reservations,
                                                                             buffers, req.start.time)
            if not ends:
                failed[req.drone_id] = ReasonCode.NO_SAFE_HOLD_POINT
                continue
            end_kind = ends[0].kind
            opts = self._option_space(req, end_kind)
            nominal = opts[0]
            found: ScheduledDrone | None = None
            last_reason = ReasonCode.SCHEDULE_INFEASIBLE
            for ei, end in enumerate(ends):
                for o in opts:
                    traj = self.build_route(req.drone_id, req.start, req.tasks, end, o)
                    if traj is None:
                        last_reason = ReasonCode.ROUTE_BLOCKED
                        continue
                    rep = self.checker.check({req.drone_id: traj}, existing=others, reservations=reservations,
                                             buffers=buffers, t_from=req.start.time)
                    if o == nominal and not rep.ok:
                        self.last_failure[req.drone_id] = rep.conflicts[:3]
                    if rep.ok:
                        if end.kind == EndKind.HOLD:
                            hp = Vec3.enu(*end.point)
                            hc = self.hold_checker.check(req.drone_id, hp, traj.end_time, traj.end_time + 3600,
                                                         others, holds, reservations, buffers)
                            if not hc.safe:
                                last_reason = ReasonCode.NO_SAFE_HOLD_POINT
                                self.last_failure[req.drone_id] = (hc.report.conflicts[:2] if hc.report else []) or \
                                    [f"hold {end.point} too close to another hold"]
                                break
                        res = self._classify(o, nominal) if ei == 0 else ReasonCode.RESOLVED_BY_REPLAN
                        em = EnergyModel(self.profile(req.drone_id).energy)
                        found = ScheduledDrone(req.drone_id, traj, o, res, end,
                                               em.trajectory_energy_wh(traj) * em.cfg.planning_margin)
                        break
                    last_reason = ReasonCode.SCHEDULE_INFEASIBLE
                if found:
                    break
            if found is None:
                failed[req.drone_id] = last_reason
                continue
            scheduled[req.drone_id] = found
            if found.end.kind == EndKind.HOLD:
                holds[req.drone_id] = Vec3.enu(*found.end.point)
        return scheduled, failed

    # ------------------------------------------------------------------
    def buffers_for(self, uncertainty: FleetUncertainty | None, drone_ids: list[str]) -> dict[str, Buffers]:
        out: dict[str, Buffers] = {}
        tol = self.cfg.timing.start_tolerance_s
        for d in drone_ids:
            pu = uncertainty.position_uncertainty.get(d) if uncertainty else None
            cu = uncertainty.clock_uncertainty.get(d, 0.0) if uncertainty else 0.0
            if pu is not None and not math.isfinite(pu):
                pu = None
            if not math.isfinite(cu):
                cu = 0.0
            out[d] = Buffers.from_config(self.cfg.separation, pu, cu, tol)
        return out

    def make_plan(self, scheduled: dict[str, ScheduledDrone], requests: dict[str, DroneRequest], *,
                  plan_id: str, mission_version: int, epoch: int, created_at: float, purpose: PlanPurpose,
                  effective_from: dict[str, float], fleet_ids: list[str],
                  unassigned: list[str] | None = None) -> Plan:
        dps: dict[str, DronePlan] = {}
        resv: list[Reservation] = []
        for d in sorted(scheduled):
            s = scheduled[d]
            req = requests[d]
            prof = self.profile(d)
            pad = self.mission.pad(d).position if any(p.drone_id == d for p in self.mission.launch_pads) \
                else Vec3.enu(req.start.position[0], req.start.position[1], 0.0)
            calt = req.contingency_altitude if req.contingency_altitude is not None else \
                self.contingency_altitude(d, fleet_ids)
            hold = Vec3.enu(*s.end.point) if s.end.kind == EndKind.HOLD else Vec3.enu(s.end.point[0], s.end.point[1], calt)
            windows = {}
            for tid in s.trajectory.task_ids():
                w = s.trajectory.task_window(tid)
                if w:
                    windows[tid] = w
            dps[d] = DronePlan(
                drone_id=d, expected_boot_id=req.start.boot_id, plan_version=mission_version, purpose=purpose,
                effective_from=effective_from.get(d, req.start.time), trajectory=s.trajectory,
                task_ids=s.trajectory.task_ids(), task_windows=windows,
                contingency=ContingencyAssignment(
                    contingency_altitude_m=calt, hold_point=hold,
                    lost_link_action=prof.contingency.lost_link_action.value
                    if isinstance(prof.contingency.lost_link_action, LostLinkAction) else str(prof.contingency.lost_link_action),
                    land_position=pad),
                energy_estimate_wh=s.energy_wh,
                lane_progress_origin={t.task_id: t.offset_m for t, _ in req.tasks},
            )
            if s.end.kind == EndKind.LAND:
                resv.append(self.recovery_reservation(d, s.trajectory))
        return Plan(plan_id=plan_id, mission_id=self.mission.mission_id, mission_version=mission_version,
                    coordinator_epoch=epoch, created_at=created_at, purpose=purpose, drone_plans=dps,
                    reservations=resv, unassigned_tasks=list(unassigned or []),
                    resolutions=[(d, scheduled[d].resolution) for d in sorted(scheduled)],
                    timing_tolerance_s=self.cfg.timing.start_tolerance_s)

    def recovery_reservation(self, drone_id: str, traj: Trajectory, margin_s: float = 4.0) -> Reservation:
        ra = self.mission.recovery_area
        T, P = traj.arrays()
        inside = [i for i in range(len(T)) if ra.contains(P[i, 0], P[i, 1], P[i, 2] - 1e-6)
                  and P[i, 2] <= ra.ceiling_m + 0.5]
        t0 = T[inside[0]] if inside else T[-1]
        return Reservation(
            reservation_id=f"recovery/{drone_id}/{int(t0 * 10)}", holder=drone_id, kind=ReservationKind.RECOVERY_AREA,
            volume=Volume(kind=VolumeKind.CYLINDER, points=[ra.centre_xy], radius_m=ra.radius_m, z_min=0.0,
                          z_max=ra.ceiling_m),
            t_start=float(t0) - margin_s, t_end=float(T[-1]) + margin_s, resource="recovery",
            shared_capacity=ra.capacity)

    # ------------------------------------------------------------------
    def schedule(self, assignment, existing_reservations: list[Reservation], uncertainty: FleetUncertainty, *,
                 starts: dict[str, StartState] | None = None, snapshot=None, start_time: float | None = None,  # type: ignore[no-untyped-def]
                 mission_version: int = 1, epoch: int = 1, plan_id: str = "plan",
                 existing_trajectories: dict[str, Trajectory] | None = None,
                 purpose: PlanPurpose = PlanPurpose.INITIAL, fleet_ids: list[str] | None = None) -> ScheduleResult:
        """Schedule an :class:`Assignment` into a conflict-checked :class:`Plan`.

        Start states come from ``starts`` or, if omitted, from ``snapshot``
        (current estimated positions); ``start_time`` defaults to the snapshot time."""
        if starts is None:
            if snapshot is None:
                raise ValueError("schedule() needs either starts or snapshot")
            starts = {}
            for d, e in snapshot.drones.items():
                if e.position is not None and e.boot_id is not None:
                    starts[d] = StartState((e.position.x, e.position.y, e.position.z), snapshot.as_of,
                                           e.position.z < 1.0, e.boot_id)
        if start_time is None:
            start_time = max((s.time for s in starts.values()), default=0.0)
        fleet_ids = fleet_ids or sorted(starts)
        reqs: dict[str, DroneRequest] = {}
        for d in sorted(assignment.per_drone):
            if d not in starts:
                continue
            tasks = [(self.tasks[a.task_id], a.reversed) for a in assignment.per_drone[d]]
            st = starts[d]
            st = StartState(st.position, max(st.time, start_time), st.on_ground, st.boot_id)
            reqs[d] = DroneRequest(d, st, tasks, None, self.contingency_altitude(d, fleet_ids))
        buffers = self.buffers_for(uncertainty, sorted(set(fleet_ids) | set(reqs)))
        # drones with work first (deterministic), then idle ones
        order = sorted(reqs.values(), key=lambda r: (len(r.tasks) == 0, r.drone_id))
        scheduled, failed = self.schedule_requests(order, existing_trajectories or {}, existing_reservations, buffers)
        if not scheduled:
            return ScheduleResult(None, {}, failed)
        plan = self.make_plan(scheduled, reqs, plan_id=plan_id, mission_version=mission_version, epoch=epoch,
                              created_at=start_time, purpose=purpose,
                              effective_from={d: reqs[d].start.time for d in scheduled}, fleet_ids=fleet_ids,
                              unassigned=sorted(assignment.unassigned) +
                              [a.task_id for d in failed for a in assignment.per_drone.get(d, [])])
        report = self.checker.check(plan, existing=existing_trajectories or {}, reservations=existing_reservations,
                                    buffers=buffers, t_from=start_time)
        return ScheduleResult(plan, scheduled, failed, report)
