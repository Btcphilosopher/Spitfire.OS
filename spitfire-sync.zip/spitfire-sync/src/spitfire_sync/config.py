"""Validated configuration (loaded from TOML; see configs/)."""

from __future__ import annotations

import tomllib
from enum import StrEnum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator


class _Cfg(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")


class FreshnessPolicy(_Cfg):
    fresh_max_age_s: float = 1.5
    stale_max_age_s: float = 6.0
    prediction_horizon_s: float = 2.0  # constant-velocity prediction validity
    assumed_max_accel_m_s2: float = 3.0  # uncertainty growth during prediction
    max_speed_m_s: float = 15.0  # reachable-set growth once prediction is invalid
    max_assessable_radius_m: float = 150.0  # beyond this the position is "unassessable"
    reachable_horizon_s: float = 60.0  # reachable regions are not extrapolated further


class TelemetryConfig(_Cfg):
    rate_hz: float = 2.0
    max_plausible_speed_m_s: float = 22.0
    max_plausible_accel_m_s2: float = 10.0
    max_accepted_position_uncertainty_m: float = 60.0
    max_future_skew_s: float = 0.5  # beyond reported clock uncertainty
    max_observation_age_s: float = 30.0
    consecutive_rejects_before_reset: int = 4
    raw_log_limit: int = 200_000


class KinematicLimits(_Cfg):
    max_speed_m_s: float = 15.0
    transit_speed_m_s: float = 10.0
    max_accel_m_s2: float = 2.5
    max_climb_m_s: float = 3.0
    max_descent_m_s: float = 2.0
    landing_descent_m_s: float = 1.0
    sample_dt_s: float = 0.5


class SeparationConfig(_Cfg):
    horizontal_m: float = 15.0
    vertical_m: float = 8.0
    nominal_position_uncertainty_m: float = 2.0
    tracking_tolerance_m: float = 3.0
    extra_timing_buffer_s: float = 0.3
    hold_point_radius_m: float = 6.0
    ground_level_m: float = 1.0  # below this an aircraft on a pad/spot is "on ground"


class TimingConfig(_Cfg):
    start_tolerance_s: float = 0.25  # synchronised-start engineering tolerance
    readiness_validity_s: float = 20.0
    readiness_deadline_s: float = 8.0
    min_commit_lead_s: float = 2.0
    commit_lead_latency_factor: float = 4.0  # lead >= factor * observed p95 one-way latency
    sync_interval_s: float = 2.0
    max_relative_drift_ppm: float = 200.0
    max_reschedules: int = 3


class LeaseConfig(_Cfg):
    duration_s: float = 10.0
    renew_interval_s: float = 3.0
    renewal_validity_s: float = 4.0
    expiry_margin_s: float = 1.5  # coordinator waits expires_at + margin + clock unc
    onboard_safety_margin_s: float = 0.5  # aircraft stops this early (plus its clock unc)


class EnergyModelConfig(_Cfg):
    """Simple *simulation assumption*, not an endurance model of any aircraft."""

    capacity_wh: float = 60.0
    hover_power_w: float = 180.0
    speed_coeff: float = 0.25  # P = hover * (1 + c * (v_air / v_ref)^2) + climb term
    v_ref_m_s: float = 10.0
    mass_kg: float = 2.5
    climb_efficiency: float = 0.6
    planning_margin: float = 1.25  # multiply estimates when planning


class ConstraintsConfig(_Cfg):
    reserve_fraction: float = 0.25
    max_tasks_per_aircraft: int = 6
    allow_lane_reversal: bool = True


class AllocationWeights(_Cfg):
    travel_s: float = 1.0
    duration_s: float = 0.3
    battery_penalty: float = 60.0
    commitment_s: float = 0.6


class LostLinkAction(StrEnum):
    GOTO_CONTINGENCY_HOLD = "GOTO_CONTINGENCY_HOLD"  # climb/descend to own altitude, fly to own hold point
    LAND_IN_PLACE = "LAND_IN_PLACE"
    AUTOPILOT_RTL = "AUTOPILOT_RTL"  # hand over to the autopilot's configured RTL


class ContingencyConfig(_Cfg):
    lost_link_timeout_s: float = 8.0  # no coordinator contact => degraded mode
    lost_link_hold_s: float = 25.0  # hold in place before executing lost_link_action
    lost_link_action: LostLinkAction = LostLinkAction.GOTO_CONTINGENCY_HOLD
    contingency_hold_timeout_s: float = 90.0  # then land at launch pad
    reserve_wait_s: float = 25.0  # wait for a recovery plan after reserve breach
    contingency_altitude_m: float | None = None  # assigned per aircraft if None


class MonitorConfig(_Cfg):
    deviation_threshold_m: float = 12.0
    deviation_persist_s: float = 3.0
    nav_uncertainty_threshold_m: float = 10.0
    dropout_timeout_s: float = 20.0
    reconnect_wait_s: float = 90.0


class CoordinatorConfig(_Cfg):
    tick_s: float = 0.2
    heartbeat_interval_s: float = 1.0
    command_retry_interval_s: float = 1.0
    command_validity_s: float = 8.0
    message_validity_s: float = 6.0
    partial_start_policy: str = "continue_and_reallocate"  # or "abort_all"
    min_start_participation: float = 0.5
    amendment_lead_s: float = 6.0
    state_collection_timeout_s: float = 20.0


class AutopilotParams(_Cfg):
    """Autopilot failsafe settings the coordination contingencies depend on.

    Names follow PX4 conventions (RTL_RETURN_ALT, NAV_DLL_ACT, COM_DL_LOSS_T,
    BAT_LOW_THR, BAT_CRIT_THR, COM_LOW_BAT_ACT, GF_ACTION).  They were *not*
    verifiable against PX4 documentation from the build environment - check
    them against the parameter reference of your PX4 release (docs/SITL.md).
    """

    model_config = ConfigDict(frozen=True, extra="allow")
    autopilot: str = "PX4"
    values: dict[str, float] = Field(default_factory=dict)


class DroneProfile(_Cfg):
    drone_id: str
    payloads: list[str] = Field(default_factory=lambda: ["rgb"])
    limits: KinematicLimits = KinematicLimits()
    energy: EnergyModelConfig = EnergyModelConfig()
    contingency: ContingencyConfig = ContingencyConfig()
    autopilot: AutopilotParams = AutopilotParams()


class SpitfireConfig(_Cfg):
    """System configuration shared by coordinator and aircraft agents."""

    freshness: FreshnessPolicy = FreshnessPolicy()
    telemetry: TelemetryConfig = TelemetryConfig()
    separation: SeparationConfig = SeparationConfig()
    timing: TimingConfig = TimingConfig()
    leases: LeaseConfig = LeaseConfig()
    constraints: ConstraintsConfig = ConstraintsConfig()
    allocation: AllocationWeights = AllocationWeights()
    monitor: MonitorConfig = MonitorConfig()
    coordinator: CoordinatorConfig = CoordinatorConfig()
    allocator: str = "greedy"  # greedy | optimal
    fleet: list[DroneProfile] = Field(default_factory=list)

    def profile(self, drone_id: str) -> DroneProfile:
        for p in self.fleet:
            if p.drone_id == drone_id:
                return p
        raise KeyError(drone_id)

    @model_validator(mode="after")
    def _check(self) -> "SpitfireConfig":
        ids = [p.drone_id for p in self.fleet]
        if len(ids) != len(set(ids)):
            raise ValueError("duplicate drone_id in fleet")
        f = self.freshness
        if not (0 < f.fresh_max_age_s < f.stale_max_age_s):
            raise ValueError("freshness: require 0 < fresh_max_age_s < stale_max_age_s")
        L = self.leases
        if not (L.renew_interval_s < L.duration_s and L.renewal_validity_s <= L.duration_s):
            raise ValueError("leases: renew_interval_s and renewal_validity_s must be below duration_s")
        return self


# ---------------------------------------------------------------------------
# Simulation scenario configuration
# ---------------------------------------------------------------------------


class WindConfig(_Cfg):
    mean_east_m_s: float = 2.0
    mean_north_m_s: float = -1.0
    gust_sigma_m_s: float = 1.0
    gust_tau_s: float = 8.0


class DroneSimSpec(_Cfg):
    """Ground-truth properties hidden from the coordinator."""

    drone_id: str
    consumption_factor: float = 1.0  # true power / nominal model power
    nav_noise_sigma_m: float = 0.8
    reported_uncertainty_m: float = 2.0
    clock_drift_ppm: float = 0.0
    mono_offset_s: float = 0.0
    utc_offset_s: float = 0.0
    initial_charge: float = 1.0
    reboot_at_s: float | None = None
    arm_failure: bool = False
    nav_degradation: list[tuple[float, float, float]] = Field(default_factory=list)  # (start, end, sigma)


class ObstructionEvent(_Cfg):
    at_s: float
    zone_id: str
    vertices: list[tuple[float, float]]
    floor_m: float = 0.0
    ceiling_m: float = 200.0


class SiteConfig(_Cfg):
    name: str = "Larkspur Farm (fictional)"
    origin_lat_deg: float = 52.2050
    origin_lon_deg: float = -0.1200
    origin_height_m: float = 45.0
    field_vertices: list[tuple[float, float]] = Field(
        default_factory=lambda: [(0.0, 0.0), (520.0, 0.0), (540.0, 360.0), (-10.0, 350.0)]
    )
    boundary_margin_m: float = 140.0
    exclusion_zones: list[dict[str, Any]] = Field(default_factory=list)
    lane_spacing_m: float = 40.0
    lane_angle_deg: float = 0.0  # lanes parallel to +x (east)
    survey_bands: list[tuple[str, float, float]] = Field(
        default_factory=lambda: [("S1", 33.0, 37.0), ("S2", 48.0, 52.0)]
    )
    transit_bands: list[tuple[str, float, float]] = Field(
        default_factory=lambda: [("T1", 62.0, 66.0), ("T2", 74.0, 78.0)]
    )
    contingency_altitudes_m: list[float] = Field(default_factory=lambda: [62.0, 72.0, 82.0, 92.0, 102.0, 112.0])
    ceiling_m: float = 120.0
    launch_origin: tuple[float, float] = (-60.0, -70.0)
    launch_spacing_m: float = 22.0
    recovery_centre: tuple[float, float] = (230.0, -80.0)
    recovery_radius_m: float = 18.0
    recovery_ceiling_m: float = 25.0
    payload_by_lane: dict[str, str] = Field(default_factory=dict)


class SimulationConfig(_Cfg):
    seed: int = 42
    n_drones: int = Field(default=6, ge=4, le=12)
    duration_limit_s: float = 1500.0
    physics_dt_s: float = 0.05
    agent_tick_s: float = 0.1
    realtime: bool = False
    realtime_speed: float = 1.0
    site: SiteConfig = SiteConfig()
    wind: WindConfig = WindConfig()
    network_default: dict[str, float] = Field(default_factory=lambda: {
        "latency_s": 0.03, "jitter_s": 0.01, "loss": 0.01, "duplicate": 0.01})
    link_episodes: list[dict[str, Any]] = Field(default_factory=list)
    drones: list[DroneSimSpec] = Field(default_factory=list)
    obstructions: list[ObstructionEvent] = Field(default_factory=list)
    coordinator_crash_at_s: float | None = None
    randomise: bool = True  # draw per-seed perturbations (clock drift, consumption) on top of specs


class ScenarioFile(_Cfg):
    system: SpitfireConfig = SpitfireConfig()
    simulation: SimulationConfig = SimulationConfig()


def load_scenario(path: str | Path) -> ScenarioFile:
    with open(path, "rb") as fh:
        data = tomllib.load(fh)
    return ScenarioFile.model_validate(data)
