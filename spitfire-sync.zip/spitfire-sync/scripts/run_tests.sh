#!/usr/bin/env bash
# Run the full test suite and write docs/TEST_RESULTS.md
set -euo pipefail
cd "$(dirname "$0")/.."
python -m pytest -p no:cacheprovider -rA --durations=15 tests 2>&1 | tee test_output.txt
python "$(dirname "$0")/write_test_report.py"
