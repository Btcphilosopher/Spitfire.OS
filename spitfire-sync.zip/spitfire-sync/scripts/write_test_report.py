"""Turn test_output.txt (from scripts/run_tests.sh) into docs/TEST_RESULTS.md."""
import platform
import re
from importlib.metadata import version
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
out = (ROOT / "test_output.txt").read_text()
passed = re.findall(r"^PASSED (\S+)", out, re.M)
failed = re.findall(r"^FAILED (\S+)", out, re.M)
summary = [l for l in out.splitlines() if re.search(r"\d+ (passed|failed)", l)][-1].strip(" =")
groups: dict[str, list[str]] = {}
for t in passed:
    f, n = t.split("::", 1)
    groups.setdefault(f, []).append(n)


def v(p: str) -> str:
    try:
        return version(p)
    except Exception:  # noqa: BLE001
        return "not installed"


env = ", ".join(f"{p} {v(p)}" for p in ("numpy", "scipy", "pydantic", "matplotlib", "pytest", "pytest-asyncio", "mavsdk"))
areas = [
    ("Frame conversions", "test_frames.py - ENU/NED axes and round trip, WGS84 round trip, known values, extent limit, mixed-frame rejection"),
    ("Clock drift and timestamp jumps", "test_clocks.py - bounded offset under drift and asymmetry, uncertainty growth, jump detection, reference change, UTC step, reboot"),
    ("Duplicate and reordered telemetry", "test_telemetry.py - duplicates, out-of-order, gaps, reboot sequence reset, NaN/invalid, impossible motion, future timestamps, frames"),
    ("Stale-state rejection", "test_telemetry.py freshness/prediction tests; test_protocol.py message expiry"),
    ("Lease expiry", "test_leases.py; test_readiness.py::test_lease_lapse_pauses_execution"),
    ("Stale-coordinator commands", "test_protocol.py::test_stale_epoch_rejected_after_newer_coordinator_seen, ::test_stale_coordinator_command_rejected_by_agent"),
    ("Partial-start failure", "test_simulation.py::test_partial_start_failure_continues_and_reallocates, ::test_partial_start_abort_all_policy; test_readiness.py missed deadline / arming failure"),
    ("Crossing trajectories", "test_separation.py::test_crossing_detected_between_sampled_waypoints and buffer tests; scheduler head-on resolution"),
    ("Shared recovery-area conflicts", "test_separation.py::test_reservation_conflict_in_shared_recovery_area_and_slot_sequencing; test_simulation.py::test_sequenced_recovery_in_shared_area"),
    ("Reconnection reconciliation", "test_simulation.py::test_link_outage_pause_reconciliation_and_resume, ::test_companion_reboot_is_detected_and_reconciled"),
    ("Deterministic simulation", "test_simulation.py::test_simulation_is_deterministic_for_a_seed"),
    ("Clean shutdown", "test_simulation.py::test_nominal_mission_completes_with_separation_and_clean_shutdown; test_misc.py real-time mode"),
]
lines = ["# Test results", "",
         "Actual output of `scripts/run_tests.sh` (`python -m pytest -rA --durations=15 tests`) on the delivered code.", "",
         f"Environment: {platform.system()}, Python {platform.python_version()}, {env}. MAVSDK is installed but no "
         "PX4 SITL was available: only the adapter's dispatch gates and frame conversion are exercised.", "",
         f"**Result: `{summary}`** ({len(passed)} passed, {len(failed)} failed).", "",
         "Raw output: `test_output.txt` in the repository root.", "",
         "## Requested test areas", "", "| Area | Tests |", "|---|---|"]
lines += [f"| {a} | {t} |" for a, t in areas]
lines += ["", "## Slowest tests", "", "```"]
lines += [l for l in out.splitlines() if re.match(r"^[0-9.]+s (call|setup)", l)][:12]
lines += ["```", "", "## All tests", ""]
for f in sorted(groups):
    lines.append(f"### {f} ({len(groups[f])})")
    lines += [f"- PASSED `{n}`" for n in groups[f]]
    lines.append("")
if failed:
    lines += ["## Failures", ""] + [f"- FAILED `{t}`" for t in failed]
(ROOT / "docs" / "TEST_RESULTS.md").write_text("\n".join(lines) + "\n")
print(summary)
