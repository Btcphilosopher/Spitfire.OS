#!/usr/bin/env bash
# Regenerate every result shipped in results/ (deterministic in virtual time).
set -euo pipefail
cd "$(dirname "$0")/.."
export PYTHONPATH=src
W=${WORKERS:-4}
python -m spitfire_sync demo --config configs/demo_agricultural.toml --seed 42 --out results/demo
python -m spitfire_sync evaluate --config configs/demo_agricultural.toml --seeds 1-12 --workers "$W" --out results/evaluation_demo_faults
python -m spitfire_sync evaluate --config configs/nominal_agricultural.toml --seeds 1-8 --workers "$W" --allocator greedy --out results/allocator_greedy
python -m spitfire_sync evaluate --config configs/nominal_agricultural.toml --seeds 1-8 --workers "$W" --allocator optimal --out results/allocator_optimal
for n in 4 8 12; do
  python -m spitfire_sync evaluate --config configs/nominal_agricultural.toml --drones "$n" --seeds 1-4 --workers "$W" --out "results/fleet_${n}"
done
