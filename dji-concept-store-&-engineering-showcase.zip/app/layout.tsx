import type {Metadata} from 'next';
import { Plus_Jakarta_Sans } from 'next/font/google';
import './globals.css';

const plusJakartaSans = Plus_Jakarta_Sans({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-sans',
});

export const metadata: Metadata = {
  title: 'DJI Concept Store & Engineering Showcase',
  description: 'An independent, precision-crafted editorial website concept for DJI camera drones, handheld imaging, and professional filmmaking systems.',
  openGraph: {
    title: 'DJI Concept Store & Engineering Showcase',
    description: 'An independent, precision-crafted editorial website concept for DJI camera drones, handheld imaging, and professional filmmaking systems.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'DJI Concept Store & Engineering Showcase',
    description: 'An independent, precision-crafted editorial website concept for DJI camera drones, handheld imaging, and professional filmmaking systems.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={plusJakartaSans.variable}>
      <body className="bg-white text-zinc-900 antialiased selection:bg-zinc-900 selection:text-white" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
