'use client';

import React from 'react';
import { AppProvider, useApp } from '@/context/AppContext';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import CategoryGrid from '@/components/CategoryGrid';
import FeaturedProducts from '@/components/FeaturedProducts';
import GuidedSelector from '@/components/GuidedSelector';
import ProductDetail from '@/components/ProductDetail';
import ProductComparison from '@/components/ProductComparison';
import RealWorldStories from '@/components/RealWorldStories';
import SupportSection from '@/components/SupportSection';
import CartDrawer from '@/components/CartDrawer';
import CheckoutModal from '@/components/CheckoutModal';
import SearchModal from '@/components/SearchModal';
import VideoModal from '@/components/VideoModal';
import Footer from '@/components/Footer';

function MainContent() {
  const { activeView, selectedProductId } = useApp();

  return (
    <main className="min-h-screen flex flex-col bg-white">
      <Header />

      {/* Dynamic View Router */}
      <div className="flex-1">
        {activeView === 'home' && (
          <>
            {/* Primary Hero Section replicating mockup */}
            <Hero />

            {/* "Find your next perspective." 3 Category Cards replicating mockup */}
            <CategoryGrid />

            {/* Featured Engineered Fleet with quick buy & filter */}
            <FeaturedProducts />

            {/* Guided Product Recommendation Flow */}
            <GuidedSelector />

            {/* "Shot on DJI" Real-World Field Expeditions */}
            <div id="shot-on-dji">
              <RealWorldStories />
            </div>

            {/* Comprehensive Support & Documentation Hub */}
            <SupportSection />
          </>
        )}

        {activeView === 'pdp' && (
          <ProductDetail key={selectedProductId} productId={selectedProductId} />
        )}

        {activeView === 'category' && <CategoryViewWrapper />}

        {activeView === 'selector' && (
          <div className="pt-4">
            <GuidedSelector />
          </div>
        )}

        {activeView === 'compare' && <ProductComparison />}

        {activeView === 'support' && (
          <div className="pt-4">
            <SupportSection />
          </div>
        )}
      </div>

      <Footer />

      {/* Global Interactive Overlays */}
      <CartDrawer />
      <CheckoutModal />
      <SearchModal />
      <VideoModal />
    </main>
  );
}

// Lazy/direct CategoryView import
import CategoryView from '@/components/CategoryView';
function CategoryViewWrapper() {
  return <CategoryView />;
}

export default function Page() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
