'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import {
  Download,
  FileText,
  Shield,
  Wrench,
  Search,
  ExternalLink,
  MapPin,
  CheckCircle,
  HelpCircle,
  AlertCircle,
} from 'lucide-react';
import { PRODUCTS } from '@/data/products';

export default function SupportSection() {
  const [activeTab, setActiveTab] = useState<'downloads' | 'repair' | 'regulations' | 'care'>('downloads');
  const [serialQuery, setSerialQuery] = useState('');
  const [checkedStatus, setCheckedStatus] = useState<string | null>(null);

  const handleCheckSerial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!serialQuery.trim()) return;
    setCheckedStatus(`Serial #${serialQuery.toUpperCase()}: DJI Care Refresh Active. 2 replacements remaining until December 2026. Factory calibration verified.`);
  };

  return (
    <section className="w-full bg-[#f9f9fa] text-zinc-900 py-16 lg:py-24 border-b border-zinc-200">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        {/* Header */}
        <div className="max-w-2xl mb-12">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-4 h-[2px] bg-red-600 inline-block" />
            <span className="text-xs font-bold uppercase tracking-widest text-zinc-500">
              Operations & Technical Care
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-zinc-900">
            Support & Documentation
          </h2>
          <p className="text-xs sm:text-sm text-zinc-500 mt-2">
            Access official flight manuals, download desktop and mobile software, verify your warranty status, and review global airspace compliance.
          </p>
        </div>

        {/* Support Tabs */}
        <div className="flex flex-wrap gap-2 border-b border-zinc-200 mb-8">
          {[
            { id: 'downloads', label: 'Manuals & Downloads', icon: Download },
            { id: 'care', label: 'DJI Care Refresh', icon: Shield },
            { id: 'repair', label: 'Service & Repair Status', icon: Wrench },
            { id: 'regulations', label: 'Flight Safety & GEO Zones', icon: MapPin },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 py-3 px-4 text-xs font-semibold border-b-2 transition-all ${
                  isActive
                    ? 'border-zinc-900 text-zinc-900 bg-white'
                    : 'border-transparent text-zinc-500 hover:text-zinc-800'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content 1: Manuals & Downloads */}
        {activeTab === 'downloads' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-6 bg-white border border-zinc-200 rounded-lg">
                <span className="text-xs font-bold text-red-600 uppercase tracking-wider block mb-1">
                  Mobile App
                </span>
                <h3 className="text-base font-bold text-zinc-900 mb-1">DJI Fly (v1.14.2)</h3>
                <p className="text-xs text-zinc-500 mb-4">
                  Intuitive flight interface, MasterShots creation, and live 1080p preview for Mini and Mavic series.
                </p>
                <div className="flex gap-2 text-xs">
                  <button
                    onClick={() => alert('Download link generated for iOS App Store')}
                    className="px-3 py-1.5 bg-zinc-900 text-white font-medium rounded hover:bg-black"
                  >
                    iOS App
                  </button>
                  <button
                    onClick={() => alert('Download link generated for Android APK')}
                    className="px-3 py-1.5 bg-zinc-100 text-zinc-800 font-medium rounded hover:bg-zinc-200"
                  >
                    Android APK
                  </button>
                </div>
              </div>

              <div className="p-6 bg-white border border-zinc-200 rounded-lg">
                <span className="text-xs font-bold text-red-600 uppercase tracking-wider block mb-1">
                  Handheld App
                </span>
                <h3 className="text-base font-bold text-zinc-900 mb-1">DJI Mimo (v2.0.4)</h3>
                <p className="text-xs text-zinc-500 mb-4">
                  Precision color control, Story Mode video templates, and wireless firmware sync for Osmo Pocket and Action.
                </p>
                <div className="flex gap-2 text-xs">
                  <button
                    onClick={() => alert('Download link generated for iOS')}
                    className="px-3 py-1.5 bg-zinc-900 text-white font-medium rounded hover:bg-black"
                  >
                    iOS App
                  </button>
                  <button
                    onClick={() => alert('Download link generated for Android')}
                    className="px-3 py-1.5 bg-zinc-100 text-zinc-800 font-medium rounded hover:bg-zinc-200"
                  >
                    Android APK
                  </button>
                </div>
              </div>

              <div className="p-6 bg-white border border-zinc-200 rounded-lg">
                <span className="text-xs font-bold text-red-600 uppercase tracking-wider block mb-1">
                  Desktop Utility
                </span>
                <h3 className="text-base font-bold text-zinc-900 mb-1">DJI Assistant 2</h3>
                <p className="text-xs text-zinc-500 mb-4">
                  Diagnostic flight data export, IMU vision calibration, and recovery firmware flashing for Mac and Windows.
                </p>
                <div className="flex gap-2 text-xs">
                  <button
                    onClick={() => alert('Download link for macOS (Apple Silicon)')}
                    className="px-3 py-1.5 bg-zinc-900 text-white font-medium rounded hover:bg-black"
                  >
                    macOS
                  </button>
                  <button
                    onClick={() => alert('Download link for Windows (64-bit)')}
                    className="px-3 py-1.5 bg-zinc-100 text-zinc-800 font-medium rounded hover:bg-zinc-200"
                  >
                    Windows
                  </button>
                </div>
              </div>
            </div>

            {/* Official Product Manuals Table */}
            <div className="bg-white border border-zinc-200 rounded-lg p-6">
              <h3 className="text-sm font-bold text-zinc-900 mb-4">
                Official User Manuals & Quickstart Guides
              </h3>
              <div className="divide-y divide-zinc-100">
                {PRODUCTS.map((prod) => (
                  <div
                    key={prod.id}
                    className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <FileText className="w-4 h-4 text-zinc-400" />
                      <div>
                        <span className="font-bold text-zinc-900">{prod.name} User Manual</span>
                        <span className="text-zinc-400 ml-2">PDF (v1.6) · English</span>
                      </div>
                    </div>
                    <button
                      onClick={() => alert(`Downloading manual PDF for ${prod.name}`)}
                      className="inline-flex items-center gap-1.5 text-zinc-700 hover:text-black font-semibold"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download PDF</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab Content 2: Care Refresh */}
        {activeTab === 'care' && (
          <div className="bg-white border border-zinc-200 rounded-lg p-6 sm:p-10 max-w-2xl animate-in fade-in duration-200">
            <h3 className="text-lg font-bold text-zinc-900 mb-2">
              DJI Care Refresh Warranty & Coverage Lookup
            </h3>
            <p className="text-xs text-zinc-500 mb-6">
              Enter your 14-digit serial number located in the battery compartment or on your original packaging box.
            </p>

            <form onSubmit={handleCheckSerial} className="flex gap-3 mb-6">
              <input
                type="text"
                placeholder="e.g. 1581F4QPB240019"
                value={serialQuery}
                onChange={(e) => setSerialQuery(e.target.value)}
                className="flex-1 p-3 text-xs border border-zinc-300 rounded focus:outline-none focus:ring-2 focus:ring-zinc-900 uppercase font-mono"
              />
              <button
                type="submit"
                className="px-5 py-3 bg-zinc-900 hover:bg-black text-white text-xs font-semibold rounded whitespace-nowrap"
              >
                Verify Status
              </button>
            </form>

            {checkedStatus && (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded text-xs text-emerald-800 flex items-start gap-3">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>{checkedStatus}</span>
              </div>
            )}
          </div>
        )}

        {/* Tab Content 3: Repair Status */}
        {activeTab === 'repair' && (
          <div className="bg-white border border-zinc-200 rounded-lg p-6 sm:p-10 max-w-2xl animate-in fade-in duration-200">
            <h3 className="text-lg font-bold text-zinc-900 mb-2">
              Track Repair Order
            </h3>
            <p className="text-xs text-zinc-500 mb-6">
              Enter your DJI Service Case number (e.g. CAS-2026-9921) to check inspection, technician quotation, and return shipping.
            </p>

            <div className="p-4 bg-zinc-50 rounded border border-zinc-200 text-xs text-zinc-600 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-zinc-800">Average Turnaround:</span>
                <span className="font-mono">4–5 Business Days</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-semibold text-zinc-800">Global Service Centers:</span>
                <span>Los Angeles · Frankfurt · Shenzhen · Tokyo</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-semibold text-zinc-800">Return Logistics:</span>
                <span>Free two-way express courier via UPS / DHL</span>
              </div>
            </div>
          </div>
        )}

        {/* Tab Content 4: Flight Regulations & GEO Zones */}
        {activeTab === 'regulations' && (
          <div className="bg-white border border-zinc-200 rounded-lg p-6 sm:p-10 max-w-3xl animate-in fade-in duration-200 space-y-6">
            <div>
              <h3 className="text-lg font-bold text-zinc-900 mb-2">
                Airspace Compliance & Regulatory Guidelines
              </h3>
              <p className="text-xs text-zinc-500">
                Airspace regulations vary by national aviation administration. The details below are published for guidance.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-[#f8f8fa] border border-zinc-200 rounded">
                <span className="font-bold text-zinc-900 block mb-1">
                  United States (FAA Part 107 & TRUST)
                </span>
                <p className="text-zinc-600 leading-relaxed">
                  Aircraft under 249g (e.g. DJI Mini 4 Pro) flown recreationally do not require FAA registration. Commercial flights require Part 107 certification and Remote ID broadcast compliance.
                </p>
              </div>

              <div className="p-4 bg-[#f8f8fa] border border-zinc-200 rounded">
                <span className="font-bold text-zinc-900 block mb-1">
                  European Union (EASA Open Category A1/A3)
                </span>
                <p className="text-zinc-600 leading-relaxed">
                  DJI Mini 4 Pro holds official C0 certification, allowing flight over people (excluding crowds). Mavic 3 Pro holds C2 certification for A2/A3 operations with remote pilot competence.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
