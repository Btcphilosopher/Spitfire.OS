'use client';

import React, { useState, useEffect, useRef } from 'react';
import { PRODUCTS, Product } from '@/data/products';
import { ACCESSORIES, Accessory } from '@/data/accessories';
import { useApp } from '@/context/AppContext';
import {
  Check,
  ChevronDown,
  ChevronUp,
  Download,
  FileText,
  HelpCircle,
  Package,
  Plus,
  Shield,
  ShieldCheck,
  Truck,
  Wrench,
  ArrowLeft,
  SlidersHorizontal,
} from 'lucide-react';

interface ProductDetailProps {
  productId?: string;
}

export default function ProductDetail({ productId }: ProductDetailProps) {
  const {
    selectedProductId,
    addToCart,
    formatPrice,
    addToCompare,
    isInCompare,
    setActiveView,
    navigateToProduct,
  } = useApp();

  const activeId = productId || selectedProductId || 'mavic-3-pro';
  const product: Product = PRODUCTS.find((p) => p.id === activeId) || PRODUCTS[0];

  const [selectedComboId, setSelectedComboId] = useState<string>(product.combos[0]?.id || '');
  const [selectedAccessoryIds, setSelectedAccessoryIds] = useState<string[]>([]);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [expandedSpecs, setExpandedSpecs] = useState<Record<string, boolean>>({
    'Optics & Gimbal': true,
    'Camera System': true,
    'Flight Performance': true,
    'Flight Dynamics': true,
  });

  const [showStickyBar, setShowStickyBar] = useState(false);
  const buyPanelRef = useRef<HTMLDivElement>(null);

  // Track scroll position to reveal sticky buy bar when purchase panel leaves view
  useEffect(() => {
    const handleScroll = () => {
      if (!buyPanelRef.current) return;
      const rect = buyPanelRef.current.getBoundingClientRect();
      if (rect.bottom < 80) {
        setShowStickyBar(true);
      } else {
        setShowStickyBar(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const selectedCombo = product.combos.find((c) => c.id === selectedComboId) || product.combos[0];
  const comboPrice = product.basePrice + (selectedCombo ? selectedCombo.priceDelta : 0);

  // Filter compatible accessories explicitly
  const compatibleAccessories = ACCESSORIES.filter((acc) =>
    acc.compatibleProductIds.includes(product.id)
  );

  const accessoriesTotal = selectedAccessoryIds.reduce((sum, id) => {
    const acc = ACCESSORIES.find((a) => a.id === id);
    return sum + (acc ? acc.price : 0);
  }, 0);

  const totalPrice = comboPrice + accessoriesTotal;

  const toggleAccessory = (accId: string) => {
    setSelectedAccessoryIds((prev) =>
      prev.includes(accId) ? prev.filter((id) => id !== accId) : [...prev, accId]
    );
  };

  const toggleSpecSection = (category: string) => {
    setExpandedSpecs((prev) => ({ ...prev, [category]: !prev[category] }));
  };

  const galleryImages = [
    product.images.hero,
    product.images.studio,
    ...(product.images.details || []),
  ].filter(Boolean);

  const handleAddToCart = () => {
    addToCart(product.id, selectedCombo.id, selectedAccessoryIds);
  };

  return (
    <div className="w-full bg-white text-zinc-900 pb-24">
      {/* Breadcrumb Navigation */}
      <div className="border-b border-zinc-200 bg-[#fbfbfb]">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12 py-3 flex items-center justify-between text-xs text-zinc-500">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveView('home')}
              className="hover:text-zinc-900 transition-colors"
            >
              Home
            </button>
            <span>/</span>
            <button
              onClick={() => setActiveView('category')}
              className="capitalize hover:text-zinc-900 transition-colors"
            >
              {product.category.replace('-', ' ')}
            </button>
            <span>/</span>
            <span className="font-semibold text-zinc-900">{product.name}</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => addToCompare(product.id)}
              className="hover:text-zinc-900 flex items-center gap-1"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>{isInCompare(product.id) ? 'In Comparison' : 'Add to Compare'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main PDP Section: Gallery + Purchase Module */}
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12 pt-8 lg:pt-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left Column: Interactive Product Gallery */}
          <div className="lg:col-span-7 sticky top-24 space-y-4">
            {/* Primary Display Viewport */}
            <div className="aspect-[4/3] w-full bg-[#f4f4f6] rounded-lg overflow-hidden border border-zinc-200/80 p-8 flex items-center justify-center relative">
              {product.badge && (
                <div className="absolute top-4 left-4 z-10">
                  <span className="text-xs font-semibold text-zinc-800 bg-white/95 border border-zinc-200 px-2.5 py-1 rounded shadow-sm">
                    {product.badge}
                  </span>
                </div>
              )}

              <img
                src={galleryImages[activeImageIndex] || product.images.studio}
                alt={`${product.name} detail view ${activeImageIndex + 1}`}
                referrerPolicy="no-referrer"
                className="max-h-full w-auto object-contain transition-all duration-300"
              />
            </div>

            {/* Thumbnail Strip */}
            {galleryImages.length > 1 && (
              <div className="flex items-center gap-3 overflow-x-auto pb-2">
                {galleryImages.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`w-20 h-20 rounded border bg-[#f7f7f8] p-1.5 shrink-0 overflow-hidden transition-all ${
                      activeImageIndex === idx
                        ? 'border-zinc-900 ring-2 ring-zinc-900/10'
                        : 'border-zinc-200 hover:border-zinc-400 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={img}
                      alt={`Thumbnail ${idx + 1}`}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-contain"
                    />
                  </button>
                ))}
              </div>
            )}

            {/* Key Engineering Callout Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6 border-t border-zinc-200">
              {product.keyHighlights.map((hl, i) => (
                <div key={i} className="p-3 bg-zinc-50 rounded border border-zinc-200/60">
                  <span className="text-lg font-bold font-mono text-zinc-900 block">
                    {hl.stat}
                  </span>
                  <span className="text-xs font-semibold text-zinc-700 block mt-0.5">
                    {hl.label}
                  </span>
                  <span className="text-[11px] text-zinc-500 block mt-1 leading-snug">
                    {hl.description}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column: Contiguous Purchase Module */}
          <div ref={buyPanelRef} className="lg:col-span-5 space-y-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs font-bold text-red-600 uppercase tracking-wider">
                  {product.series} Series
                </span>
                <span className="text-zinc-300">·</span>
                <div className="flex items-center gap-1 text-xs text-zinc-500">
                  <span className="font-semibold text-zinc-800">★ {product.rating}</span>
                  <span>({product.reviewCount} pilot reviews)</span>
                </div>
              </div>

              <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-zinc-900 mb-2">
                {product.name}
              </h1>

              <p className="text-sm text-zinc-600 leading-relaxed mb-4">
                {product.description}
              </p>

              {/* Price display with currency */}
              <div className="flex items-baseline gap-3 mb-2">
                <span className="text-3xl font-extrabold font-mono text-zinc-900">
                  {formatPrice(totalPrice)}
                </span>
                {accessoriesTotal > 0 && (
                  <span className="text-xs text-zinc-500">
                    (Includes {formatPrice(accessoriesTotal)} in selected accessories)
                  </span>
                )}
              </div>

              {/* Delivery state */}
              <div className="flex items-center gap-2 text-xs text-emerald-700 bg-emerald-50/70 border border-emerald-200/60 p-2.5 rounded mb-6">
                <Truck className="w-4 h-4 shrink-0 text-emerald-600" />
                <span>
                  <strong>In Stock.</strong> Complimentary Express Global Delivery (2–4 business days).
                </span>
              </div>
            </div>

            {/* Configuration / Combo Selector */}
            <div className="space-y-3 pt-4 border-t border-zinc-200">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-zinc-700">
                  1. Select Package Configuration
                </span>
                <span className="text-xs text-zinc-400">
                  {product.combos.length} options available
                </span>
              </div>

              <div className="space-y-2.5">
                {product.combos.map((combo) => {
                  const isSelected = selectedComboId === combo.id;
                  const itemPrice = product.basePrice + combo.priceDelta;

                  return (
                    <div
                      key={combo.id}
                      onClick={() => setSelectedComboId(combo.id)}
                      className={`p-3.5 rounded border cursor-pointer transition-all ${
                        isSelected
                          ? 'border-zinc-900 bg-zinc-900 text-white shadow-sm'
                          : 'border-zinc-200 bg-white text-zinc-900 hover:border-zinc-400'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-bold">{combo.name}</span>
                        <span className="font-mono text-sm font-semibold">
                          {formatPrice(itemPrice)}
                        </span>
                      </div>
                      <p
                        className={`text-xs leading-relaxed mb-2 ${
                          isSelected ? 'text-zinc-300' : 'text-zinc-500'
                        }`}
                      >
                        {combo.description}
                      </p>

                      {/* Combo included list */}
                      <div
                        className={`text-[11px] pt-2 border-t ${
                          isSelected ? 'border-zinc-700 text-zinc-300' : 'border-zinc-100 text-zinc-600'
                        }`}
                      >
                        <span className="font-semibold block mb-0.5">Package Contents:</span>
                        <span>{combo.includes.join(' · ')}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Compatible Accessories Checklist */}
            {compatibleAccessories.length > 0 && (
              <div className="space-y-3 pt-6 border-t border-zinc-200">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-zinc-700">
                    2. Recommended Bundled Accessories
                  </span>
                  <span className="text-xs text-zinc-400">Verified compatibility</span>
                </div>

                <div className="space-y-2">
                  {compatibleAccessories.map((acc) => {
                    const isChecked = selectedAccessoryIds.includes(acc.id);

                    return (
                      <label
                        key={acc.id}
                        className={`flex items-start gap-3 p-3 rounded border cursor-pointer transition-colors ${
                          isChecked
                            ? 'border-zinc-800 bg-zinc-50'
                            : 'border-zinc-200 bg-white hover:border-zinc-300'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => toggleAccessory(acc.id)}
                          className="mt-1 h-4 w-4 rounded border-zinc-300 text-zinc-900 focus:ring-zinc-900"
                        />
                        <div className="flex-1 text-xs">
                          <div className="flex items-center justify-between font-semibold text-zinc-900 mb-0.5">
                            <span>{acc.name}</span>
                            <span className="font-mono">{formatPrice(acc.price)}</span>
                          </div>
                          <p className="text-zinc-500 leading-normal text-[11px]">
                            {acc.description}
                          </p>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Buy CTA & Actions */}
            <div className="pt-6 border-t border-zinc-200 space-y-3">
              <button
                onClick={handleAddToCart}
                className="w-full py-4 px-6 bg-zinc-900 hover:bg-black text-white text-sm font-bold rounded transition-colors shadow-lg flex items-center justify-center gap-2"
              >
                <span>Add to Shopping Bag</span>
                <span>·</span>
                <span className="font-mono">{formatPrice(totalPrice)}</span>
              </button>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  onClick={() => addToCompare(product.id)}
                  className="py-2.5 px-3 border border-zinc-200 hover:border-zinc-400 rounded text-zinc-700 text-center font-medium"
                >
                  {isInCompare(product.id) ? '✓ In Comparison List' : '+ Add to Comparison'}
                </button>
                <button
                  onClick={() => setActiveView('selector')}
                  className="py-2.5 px-3 border border-zinc-200 hover:border-zinc-400 rounded text-zinc-700 text-center font-medium"
                >
                  Find Other Models
                </button>
              </div>

              {/* Trust markers */}
              <div className="pt-4 flex items-center justify-around text-[11px] text-zinc-500 border-t border-zinc-100">
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-zinc-400" />
                  <span>2-Year Manufacturer Warranty</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Truck className="w-4 h-4 text-zinc-400" />
                  <span>14-Day Free Returns</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* What's In The Box Visual Breakdown */}
        <div className="mt-20 pt-12 border-t border-zinc-200">
          <div className="max-w-3xl mb-8">
            <span className="text-xs font-bold uppercase tracking-widest text-zinc-400 block mb-1">
              Unboxing
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-zinc-900">
              What’s in the Box
            </h2>
            <p className="text-xs text-zinc-500 mt-1">
              Standard equipment shipped factory-sealed with your {product.name}.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-4">
            {product.boxItems.map((item, idx) => (
              <div
                key={idx}
                className="p-4 bg-[#f9f9fa] border border-zinc-200 rounded text-center flex flex-col items-center justify-center"
              >
                <Package className="w-6 h-6 text-zinc-400 mb-2" />
                <span className="text-xs font-semibold text-zinc-900 block leading-tight">
                  {item.name}
                </span>
                <span className="text-[11px] font-mono text-zinc-500 mt-1">
                  Qty: {item.quantity}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Technical Specifications Accordion */}
        <div className="mt-20 pt-12 border-t border-zinc-200">
          <div className="max-w-3xl mb-8">
            <span className="text-xs font-bold uppercase tracking-widest text-zinc-400 block mb-1">
              Engineering Architecture
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-zinc-900">
              Verified Technical Specifications
            </h2>
            <p className="text-xs text-zinc-500 mt-1">
              Authoritative performance metrics measured under standard atmospheric conditions.
            </p>
          </div>

          <div className="space-y-4">
            {product.specs.map((specGroup) => {
              const isOpen = !!expandedSpecs[specGroup.category];

              return (
                <div
                  key={specGroup.category}
                  className="border border-zinc-200 rounded-lg overflow-hidden bg-white"
                >
                  <button
                    onClick={() => toggleSpecSection(specGroup.category)}
                    className="w-full p-4 sm:p-5 flex items-center justify-between bg-zinc-50/70 hover:bg-zinc-100/70 transition-colors text-left"
                  >
                    <span className="text-sm sm:text-base font-bold text-zinc-900">
                      {specGroup.category}
                    </span>
                    {isOpen ? (
                      <ChevronUp className="w-5 h-5 text-zinc-500" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-zinc-500" />
                    )}
                  </button>

                  {isOpen && (
                    <div className="p-4 sm:p-6 divide-y divide-zinc-100 text-xs">
                      {specGroup.items.map((item, i) => (
                        <div
                          key={i}
                          className="py-3 grid grid-cols-1 md:grid-cols-12 gap-2 items-baseline"
                        >
                          <div className="md:col-span-4 font-semibold text-zinc-800">
                            {item.label}
                          </div>
                          <div className="md:col-span-8 font-mono text-zinc-900 font-medium">
                            {item.value}
                            {item.plainExplanation && (
                              <p className="font-sans text-[11px] text-zinc-500 font-normal mt-0.5">
                                Note: {item.plainExplanation}
                              </p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Support, Documentation & Manuals */}
        <div className="mt-20 pt-12 border-t border-zinc-200">
          <div className="max-w-3xl mb-8">
            <span className="text-xs font-bold uppercase tracking-widest text-zinc-400 block mb-1">
              Flight Support
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-zinc-900">
              Manuals, Firmware & Support
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 bg-zinc-50 border border-zinc-200 rounded-lg">
              <FileText className="w-5 h-5 text-zinc-700 mb-3" />
              <h3 className="text-sm font-bold text-zinc-900 mb-1">
                Official User Manual (v2.0)
              </h3>
              <p className="text-xs text-zinc-500 mb-4">
                Full 94-page operations manual including flight safety calibration, battery maintenance, and APAS guidelines.
              </p>
              <button
                onClick={() => alert(`Downloading official PDF manual for ${product.name}`)}
                className="text-xs font-semibold text-zinc-900 hover:underline flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download PDF (18.4 MB)</span>
              </button>
            </div>

            <div className="p-6 bg-zinc-50 border border-zinc-200 rounded-lg">
              <Wrench className="w-5 h-5 text-zinc-700 mb-3" />
              <h3 className="text-sm font-bold text-zinc-900 mb-1">
                Firmware Updates
              </h3>
              <p className="text-xs text-zinc-500 mb-4">
                Latest release v01.00.0600. Includes enhanced obstacle avoidance response in low-light environments.
              </p>
              <button
                onClick={() => setActiveView('support')}
                className="text-xs font-semibold text-zinc-900 hover:underline flex items-center gap-1.5"
              >
                <span>View Release Notes →</span>
              </button>
            </div>

            <div className="p-6 bg-zinc-50 border border-zinc-200 rounded-lg">
              <Shield className="w-5 h-5 text-zinc-700 mb-3" />
              <h3 className="text-sm font-bold text-zinc-900 mb-1">
                DJI Care Refresh Claims
              </h3>
              <p className="text-xs text-zinc-500 mb-4">
                Express replacement service for water damage, flyaways, or collisions with free two-way shipping.
              </p>
              <button
                onClick={() => setActiveView('support')}
                className="text-xs font-semibold text-zinc-900 hover:underline flex items-center gap-1.5"
              >
                <span>Check Coverage Status →</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Restrained Sticky Bottom Purchase Bar */}
      {showStickyBar && (
        <div className="fixed bottom-0 left-0 right-0 z-40 bg-black/95 backdrop-blur-md text-white border-t border-zinc-800 py-3 px-6 animate-in slide-in-from-bottom duration-200 shadow-2xl">
          <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <img
                src={product.images.studio}
                alt={product.name}
                referrerPolicy="no-referrer"
                className="w-10 h-10 object-contain hidden sm:block bg-zinc-900 rounded p-1"
              />
              <div>
                <span className="text-sm font-bold block">{product.name}</span>
                <span className="text-xs text-zinc-400 hidden sm:block">
                  {selectedCombo.name}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="text-right">
                <span className="text-xs text-zinc-400 uppercase tracking-wider block text-[10px]">
                  Total
                </span>
                <span className="text-lg font-bold font-mono">
                  {formatPrice(totalPrice)}
                </span>
              </div>

              <button
                onClick={handleAddToCart}
                className="py-2.5 px-6 bg-white hover:bg-zinc-200 text-black text-xs font-bold rounded transition-colors whitespace-nowrap"
              >
                Add to Bag
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
