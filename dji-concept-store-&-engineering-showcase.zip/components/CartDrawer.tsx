'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { PRODUCTS } from '@/data/products';
import { ACCESSORIES } from '@/data/accessories';
import { X, Plus, Minus, Trash2, ArrowRight, ShoppingBag, ShieldCheck } from 'lucide-react';

export default function CartDrawer() {
  const {
    cart,
    isCartOpen,
    setIsCartOpen,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    cartSubtotal,
    formatPrice,
    setIsCheckoutOpen,
    navigateToProduct,
    setActiveView,
  } = useApp();

  if (!isCartOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={() => setIsCartOpen(false)}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity animate-in fade-in duration-200"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between animate-in slide-in-from-right duration-300 border-l border-zinc-200">
          {/* Header */}
          <div className="p-6 border-b border-zinc-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-zinc-900" />
              <h2 className="text-base font-bold text-zinc-900">
                Shopping Bag ({cart.reduce((n, i) => n + i.quantity, 0)})
              </h2>
            </div>
            <button
              onClick={() => setIsCartOpen(false)}
              className="p-1 rounded text-zinc-400 hover:text-zinc-900 transition-colors"
              aria-label="Close cart"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Items List */}
          <div className="p-6 overflow-y-auto flex-1 divide-y divide-zinc-200">
            {cart.length === 0 ? (
              <div className="py-16 text-center">
                <ShoppingBag className="w-12 h-12 text-zinc-300 mx-auto mb-3" />
                <p className="text-sm font-semibold text-zinc-800 mb-1">
                  Your shopping bag is empty.
                </p>
                <p className="text-xs text-zinc-500 max-w-xs mx-auto mb-6">
                  Explore our flagship camera drones, handheld gimbals, and cinema accessories.
                </p>
                <button
                  onClick={() => {
                    setIsCartOpen(false);
                    setActiveView('category');
                  }}
                  className="px-5 py-2.5 bg-zinc-900 text-white text-xs font-semibold rounded hover:bg-black transition-colors"
                >
                  Explore Products
                </button>
              </div>
            ) : (
              cart.map((item) => {
                const product = PRODUCTS.find((p) => p.id === item.productId);
                if (!product) return null;

                const combo =
                  product.combos.find((c) => c.id === item.comboId) || product.combos[0];
                const baseComboPrice = product.basePrice + (combo ? combo.priceDelta : 0);

                const itemAccessories = (item.addedAccessoryIds || [])
                  .map((accId) => ACCESSORIES.find((a) => a.id === accId))
                  .filter(Boolean);

                const accessoriesPrice = itemAccessories.reduce(
                  (sum, acc) => sum + (acc ? acc.price : 0),
                  0
                );

                const itemUnitPrice = baseComboPrice + accessoriesPrice;

                return (
                  <div key={item.id} className="py-4 first:pt-0 last:pb-0">
                    <div className="flex gap-4">
                      {/* Product Thumbnail */}
                      <div
                        onClick={() => {
                          setIsCartOpen(false);
                          navigateToProduct(product.id);
                        }}
                        className="w-20 h-20 bg-[#f4f4f6] rounded border border-zinc-200 p-1 flex items-center justify-center shrink-0 cursor-pointer"
                      >
                        <img
                          src={product.images.studio}
                          alt={product.name}
                          referrerPolicy="no-referrer"
                          className="max-h-full object-contain"
                        />
                      </div>

                      {/* Info & Quantity */}
                      <div className="flex-1">
                        <div className="flex items-start justify-between">
                          <div>
                            <span className="text-[10px] font-bold text-red-600 uppercase">
                              {product.series}
                            </span>
                            <h3
                              onClick={() => {
                                setIsCartOpen(false);
                                navigateToProduct(product.id);
                              }}
                              className="text-sm font-bold text-zinc-900 cursor-pointer hover:underline"
                            >
                              {product.name}
                            </h3>
                          </div>
                          <button
                            onClick={() => removeFromCart(item.id)}
                            className="text-zinc-400 hover:text-red-600 transition-colors p-1"
                            title="Remove item"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>

                        <span className="text-xs text-zinc-500 block mb-2">
                          Package: {combo?.name}
                        </span>

                        {/* Bundled Accessories */}
                        {itemAccessories.length > 0 && (
                          <div className="text-[11px] text-zinc-600 bg-zinc-50 p-2 rounded border border-zinc-200/80 mb-2">
                            <span className="font-semibold block mb-0.5 text-zinc-800">
                              Included Accessories:
                            </span>
                            {itemAccessories.map((acc) => (
                              <div key={acc?.id} className="flex justify-between text-zinc-600">
                                <span>+ {acc?.name}</span>
                                <span className="font-mono">{formatPrice(acc?.price || 0)}</span>
                              </div>
                            ))}
                          </div>
                        )}

                        <div className="flex items-center justify-between pt-1">
                          {/* Quantity stepper */}
                          <div className="flex items-center border border-zinc-300 rounded">
                            <button
                              onClick={() => updateCartQuantity(item.id, -1)}
                              className="p-1 hover:bg-zinc-100 text-zinc-600"
                              aria-label="Decrease quantity"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="px-2.5 text-xs font-mono font-semibold text-zinc-900">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => updateCartQuantity(item.id, 1)}
                              className="p-1 hover:bg-zinc-100 text-zinc-600"
                              aria-label="Increase quantity"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          {/* Line total */}
                          <div className="text-sm font-bold font-mono text-zinc-900">
                            {formatPrice(itemUnitPrice * item.quantity)}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Cart Footer */}
          {cart.length > 0 && (
            <div className="p-6 border-t border-zinc-200 bg-[#fbfbfb] space-y-4">
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-zinc-600">
                  <span>Subtotal</span>
                  <span className="font-mono font-medium">{formatPrice(cartSubtotal)}</span>
                </div>
                <div className="flex justify-between text-zinc-600">
                  <span>Global Express Courier</span>
                  <span className="font-semibold text-emerald-700">Free</span>
                </div>
                <div className="flex justify-between text-zinc-600">
                  <span>Estimated Import / Taxes</span>
                  <span className="font-mono text-zinc-500">Calculated at checkout</span>
                </div>
                <div className="flex justify-between text-sm font-bold text-zinc-900 pt-2 border-t border-zinc-200">
                  <span>Estimated Total</span>
                  <span className="font-mono">{formatPrice(cartSubtotal)}</span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 text-[11px] text-zinc-500">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Simulated concept checkout · No real payment charged.</span>
              </div>

              <div className="space-y-2">
                <button
                  onClick={() => {
                    setIsCartOpen(false);
                    setIsCheckoutOpen(true);
                  }}
                  className="w-full py-3.5 px-4 bg-zinc-900 hover:bg-black text-white text-xs font-bold rounded transition-colors flex items-center justify-center gap-2 shadow"
                >
                  <span>Proceed to Simulated Checkout</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={clearCart}
                  className="w-full text-center text-xs text-zinc-400 hover:text-red-600 pt-1"
                >
                  Clear Bag
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
