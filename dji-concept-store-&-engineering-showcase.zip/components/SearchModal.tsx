'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '@/context/AppContext';
import { PRODUCTS, Product } from '@/data/products';
import { Search, X, ArrowRight, CornerDownLeft, Sparkles } from 'lucide-react';

export default function SearchModal() {
  const {
    isSearchOpen,
    setIsSearchOpen,
    searchQuery,
    setSearchQuery,
    navigateToProduct,
    formatPrice,
  } = useApp();

  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isSearchOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isSearchOpen]);

  // Handle ESC key to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isSearchOpen) {
        setIsSearchOpen(false);
      }
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isSearchOpen, setIsSearchOpen]);

  if (!isSearchOpen) return null;

  const quickPicks = ['Under 249g', 'Hasselblad', 'Pocket 3', '8K Cinema', 'FPV Acro', 'Action 5'];

  const results = searchQuery.trim() === ''
    ? []
    : PRODUCTS.filter((p) => {
        const query = searchQuery.toLowerCase();
        return (
          p.name.toLowerCase().includes(query) ||
          p.series.toLowerCase().includes(query) ||
          p.tagline.toLowerCase().includes(query) ||
          p.description.toLowerCase().includes(query) ||
          p.sensorSize.toLowerCase().includes(query) ||
          (p.badge && p.badge.toLowerCase().includes(query)) ||
          p.recommendedUse.some((u) => u.toLowerCase().includes(query))
        );
      });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-sm flex items-start justify-center pt-20 px-4">
      {/* Backdrop */}
      <div
        onClick={() => setIsSearchOpen(false)}
        className="fixed inset-0 -z-10"
      />

      <div className="bg-white border border-zinc-200 rounded-xl max-w-2xl w-full shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 text-zinc-900">
        {/* Search Input Bar */}
        <div className="p-4 border-b border-zinc-200 flex items-center gap-3">
          <Search className="w-5 h-5 text-zinc-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Search camera drones, handheld gimbals, sensors, or specs..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1 text-sm bg-transparent border-none focus:outline-none placeholder:text-zinc-400"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="p-1 text-zinc-400 hover:text-zinc-700"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <kbd className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-mono text-zinc-400 bg-zinc-100 rounded border border-zinc-200">
            ESC
          </kbd>
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-5 py-3 bg-zinc-50 border-b border-zinc-200/80 flex items-center gap-2 overflow-x-auto text-xs text-zinc-500">
          <span className="font-medium shrink-0">Popular:</span>
          {quickPicks.map((pick) => (
            <button
              key={pick}
              onClick={() => setSearchQuery(pick)}
              className="px-2.5 py-1 bg-white border border-zinc-200 rounded-md hover:border-zinc-400 hover:text-zinc-900 transition-colors shrink-0"
            >
              {pick}
            </button>
          ))}
        </div>

        {/* Results Area */}
        <div className="max-h-[380px] overflow-y-auto p-4 divide-y divide-zinc-100">
          {searchQuery.trim() === '' ? (
            <div className="py-8 text-center text-xs text-zinc-500 space-y-1">
              <Sparkles className="w-6 h-6 text-zinc-300 mx-auto mb-2" />
              <p className="font-semibold text-zinc-800">
                Explore the complete DJI fleet
              </p>
              <p>Search by product name, sensor size, video resolution, or flight criteria.</p>
            </div>
          ) : results.length === 0 ? (
            <div className="py-8 text-center text-xs text-zinc-500">
              <p className="font-semibold text-zinc-800 mb-1">
                No systems found matching &ldquo;{searchQuery}&rdquo;
              </p>
              <p>Try searching for &ldquo;Mavic&rdquo;, &ldquo;Mini 4&rdquo;, &ldquo;Pocket&rdquo;, &ldquo;Hasselblad&rdquo;, or &ldquo;FPV&rdquo;.</p>
            </div>
          ) : (
            results.map((product) => (
              <div
                key={product.id}
                onClick={() => {
                  setIsSearchOpen(false);
                  navigateToProduct(product.id);
                }}
                className="py-3 px-3 hover:bg-zinc-50 rounded-lg cursor-pointer flex items-center justify-between gap-4 transition-colors group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-zinc-100 rounded border border-zinc-200 p-1 flex items-center justify-center shrink-0">
                    <img
                      src={product.images.studio}
                      alt={product.name}
                      referrerPolicy="no-referrer"
                      className="max-h-full object-contain"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-red-600 uppercase">
                      {product.series}
                    </span>
                    <h4 className="text-sm font-bold text-zinc-900 group-hover:text-black">
                      {product.name}
                    </h4>
                    <p className="text-xs text-zinc-500 line-clamp-1">
                      {product.tagline}
                    </p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-sm font-bold font-mono text-zinc-900 block">
                    {formatPrice(product.basePrice)}
                  </span>
                  <span className="text-xs text-zinc-400 group-hover:text-zinc-900 inline-flex items-center gap-1">
                    <span>View</span>
                    <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
