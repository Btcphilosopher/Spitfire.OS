'use client';

import React from 'react';
import { STORIES } from '@/data/stories';
import { useApp } from '@/context/AppContext';
import { Play, ArrowRight, Camera } from 'lucide-react';

export default function RealWorldStories() {
  const { setActiveVideo, navigateToProduct } = useApp();

  return (
    <section className="w-full bg-zinc-950 text-white py-20 lg:py-28 border-b border-zinc-800">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        {/* Section Header */}
        <div className="max-w-2xl mb-12 lg:mb-16">
          <div className="flex items-center gap-2 mb-3">
            <span className="w-4 h-[2px] bg-red-600 inline-block" />
            <span className="text-xs font-bold uppercase tracking-widest text-zinc-400">
              Field Expeditions
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white mb-3">
            Shot on DJI
          </h2>
          <p className="text-sm sm:text-base text-zinc-400 leading-relaxed">
            From the freezing basalt shores of Iceland to the neon avenues of Shinjuku, discover how world-class cinematographers push the envelope with DJI optical systems.
          </p>
        </div>

        {/* Stories Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {STORIES.map((story) => (
            <div
              key={story.id}
              className="group bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden flex flex-col justify-between hover:border-zinc-600 transition-all duration-300"
            >
              {/* Media Container */}
              <div className="relative aspect-[16/9] w-full overflow-hidden bg-zinc-800">
                <img
                  src={story.image}
                  alt={story.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 filter brightness-90 group-hover:brightness-100"
                />

                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                <button
                  onClick={() =>
                    setActiveVideo({
                      title: story.title,
                      subtitle: `${story.creator} · ${story.location}`,
                    })
                  }
                  className="absolute bottom-4 left-4 inline-flex items-center gap-2 px-3 py-1.5 bg-black/60 backdrop-blur-md rounded-full text-xs font-medium text-white hover:bg-white hover:text-black transition-colors"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Watch Story ({story.videoDuration})</span>
                </button>
              </div>

              {/* Story Content */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-xs text-zinc-400 mb-2">
                    <span className="font-semibold text-zinc-200">{story.creator}</span>
                    <span>·</span>
                    <span>{story.location}</span>
                  </div>

                  <h3 className="text-lg font-bold text-white mb-3 leading-snug group-hover:text-zinc-200">
                    {story.title}
                  </h3>

                  <blockquote className="text-xs text-zinc-300 italic border-l-2 border-red-600 pl-3 py-1 mb-4 leading-relaxed bg-zinc-950/40 rounded-r">
                    &ldquo;{story.quote}&rdquo;
                  </blockquote>

                  <p className="text-xs text-zinc-400 leading-relaxed mb-6">
                    {story.synopsis}
                  </p>
                </div>

                {/* Gear Used List */}
                <div className="pt-4 border-t border-zinc-800/80">
                  <span className="text-[10px] uppercase tracking-wider text-zinc-500 font-bold block mb-1.5">
                    Production Gear Loadout:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {story.gearUsed.map((gear, idx) => (
                      <span
                        key={idx}
                        className="text-[11px] text-zinc-300 bg-zinc-800/80 px-2 py-0.5 rounded border border-zinc-700/60 font-mono"
                      >
                        {gear}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
