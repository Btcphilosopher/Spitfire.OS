'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { Globe, Compass, SlidersHorizontal, ShieldCheck, HelpCircle } from 'lucide-react';

export default function Footer() {
  const {
    setActiveView,
    navigateToCategory,
    currency,
    region,
  } = useApp();

  return (
    <footer className="w-full bg-[#111113] text-zinc-400 border-t border-zinc-800 text-xs">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12 py-16">
        {/* Main Columns Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 mb-16">
          {/* Column 1: Product Categories */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-white mb-4">
              Product Categories
            </h4>
            <ul className="space-y-2.5">
              <li>
                <button
                  onClick={() => navigateToCategory('camera-drones')}
                  className="hover:text-white transition-colors"
                >
                  Camera Drones
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateToCategory('handheld')}
                  className="hover:text-white transition-colors"
                >
                  Handheld & Action
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateToCategory('professional')}
                  className="hover:text-white transition-colors"
                >
                  Professional Cinema
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateToCategory('enterprise')}
                  className="hover:text-white transition-colors"
                >
                  Enterprise Industrial
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateToCategory('accessories')}
                  className="hover:text-white transition-colors"
                >
                  Genuine Accessories
                </button>
              </li>
            </ul>
          </div>

          {/* Column 2: Guided Exploration */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-white mb-4">
              Product Discovery
            </h4>
            <ul className="space-y-2.5">
              <li>
                <button
                  onClick={() => setActiveView('selector')}
                  className="hover:text-white transition-colors flex items-center gap-1.5"
                >
                  <Compass className="w-3.5 h-3.5 text-zinc-400" />
                  <span>Find Your DJI (Guided)</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveView('compare')}
                  className="hover:text-white transition-colors flex items-center gap-1.5"
                >
                  <SlidersHorizontal className="w-3.5 h-3.5 text-zinc-400" />
                  <span>Product Comparison</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveView('category')}
                  className="hover:text-white transition-colors"
                >
                  Full Fleet Catalog
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    const el = document.getElementById('shot-on-dji');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="hover:text-white transition-colors"
                >
                  Real-World Stories
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Flight Support & Service */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-white mb-4">
              Support & Service
            </h4>
            <ul className="space-y-2.5">
              <li>
                <button
                  onClick={() => setActiveView('support')}
                  className="hover:text-white transition-colors"
                >
                  Official User Manuals
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveView('support')}
                  className="hover:text-white transition-colors"
                >
                  DJI Care Refresh Claims
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveView('support')}
                  className="hover:text-white transition-colors"
                >
                  Software & App Downloads
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveView('support')}
                  className="hover:text-white transition-colors"
                >
                  Repair Status Tracking
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveView('support')}
                  className="hover:text-white transition-colors"
                >
                  GEO Airspace Zones
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Engineering & Innovation */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-white mb-4">
              Aerospace Precision
            </h4>
            <p className="text-zinc-500 leading-relaxed mb-3">
              Pioneering commercial aerial stabilization, multi-sensor obstacle sensing, and intelligent flight control algorithms since 2006.
            </p>
            <div className="flex items-center gap-2 text-zinc-300 font-mono text-[11px]">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>Certified ISO 9001 Systems</span>
            </div>
          </div>

          {/* Column 5: Storefront Preferences */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-white mb-4">
              Global Preferences
            </h4>
            <div className="p-3 bg-zinc-900 border border-zinc-800 rounded space-y-2">
              <div className="flex items-center justify-between">
                <span>Active Region:</span>
                <span className="font-semibold text-white">{region}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Store Currency:</span>
                <span className="font-mono font-semibold text-white">{currency}</span>
              </div>
              <div className="text-[11px] text-zinc-500 pt-1 border-t border-zinc-800">
                VAT / Sales taxes dynamically adjusted per region.
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar matching Mockup */}
        <div className="pt-8 border-t border-zinc-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-zinc-500">
          {/* Subtle notice matching the mockup's bottom left notice */}
          <div className="flex items-center gap-3">
            <span className="text-zinc-400 font-medium">Unofficial design concept</span>
            <span>·</span>
            <span>Independent editorial study & product exploration experience</span>
          </div>

          <div className="flex items-center gap-6">
            <a href="#privacy" className="hover:text-zinc-300">Privacy Policy</a>
            <a href="#terms" className="hover:text-zinc-300">Terms of Service</a>
            <a href="#cookies" className="hover:text-zinc-300">Cookie Preferences</a>
            <span>© 2026 DJI Concept Store</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
