'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { ArrowRight } from 'lucide-react';

interface CategoryCard {
  title: string;
  categoryKey: string;
  productId: string;
  image: string;
  alt: string;
  description: string;
}

const CATEGORIES: CategoryCard[] = [
  {
    title: 'Camera Drones',
    categoryKey: 'camera-drones',
    productId: 'mavic-3-pro',
    image: '/assets/images/card_camera_drones.png',
    alt: 'Folded DJI Mavic 3 Pro camera drone in studio setting',
    description: 'Flagship aerial imaging, foldable travel drones, and intuitive first-person flight systems.',
  },
  {
    title: 'Handheld',
    categoryKey: 'handheld',
    productId: 'osmo-pocket-3',
    image: '/assets/images/card_handheld.png',
    alt: 'DJI Osmo Pocket 3 handheld camera with rotating OLED touchscreen',
    description: 'Pocket gimbals, rugged action cameras, and wireless broadcast microphones.',
  },
  {
    title: 'Professional',
    categoryKey: 'professional',
    productId: 'inspire-3',
    image: '/assets/images/card_professional.png',
    alt: 'DJI Inspire 3 heavy-lift 8K cinema drone system',
    description: 'Integrated cinema platforms, Ronin 3-axis camera stabilizers, and wireless video transmission.',
  },
];

export default function CategoryGrid() {
  const { navigateToCategory, navigateToProduct, setActiveView } = useApp();

  return (
    <section className="w-full bg-white text-zinc-900 py-16 lg:py-24 border-b border-zinc-200">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        {/* Header row matching mockup */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8 lg:mb-12">
          <div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-zinc-900">
              Find your next perspective.
            </h2>
            <p className="text-zinc-500 text-sm mt-2 max-w-lg">
              Explore purpose-built creative instruments engineered for cinema directors, globetrotting creators, and bold visual storytellers.
            </p>
          </div>

          <button
            onClick={() => {
              setActiveView('category');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="text-sm font-semibold text-zinc-900 hover:text-red-600 transition-colors inline-flex items-center gap-1.5 shrink-0 group self-start sm:self-auto"
          >
            <span>Explore all products</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* 3 Large Showcase Cards matching mockup */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {CATEGORIES.map((card) => (
            <div
              key={card.categoryKey}
              onClick={() => navigateToCategory(card.categoryKey)}
              className="group cursor-pointer rounded-none border border-zinc-200/90 hover:border-zinc-400 bg-[#f7f7f8] overflow-hidden transition-all duration-300 hover:shadow-lg flex flex-col justify-between"
            >
              {/* Card Header matching mockup */}
              <div className="p-6 lg:p-8 pb-0">
                <h3 className="text-xl sm:text-2xl font-bold tracking-tight text-zinc-900 mb-1 group-hover:text-black">
                  {card.title}
                </h3>
                <span className="text-sm font-medium text-zinc-600 group-hover:text-zinc-900 inline-flex items-center gap-1 transition-colors">
                  <span>Explore</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </span>
              </div>

              {/* Card Studio Image matching mockup */}
              <div className="w-full aspect-[4/3] relative overflow-hidden flex items-end justify-center p-4 pt-0">
                <img
                  src={card.image}
                  alt={card.alt}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain object-bottom group-hover:scale-[1.03] transition-transform duration-500"
                />
              </div>

              {/* Sub-caption on hover or focus */}
              <div className="px-6 pb-6 pt-2 text-xs text-zinc-500 border-t border-zinc-200/60 flex items-center justify-between">
                <span>Precision Engineering</span>
                <span className="text-zinc-400 group-hover:text-zinc-900 font-mono">
                  View Series →
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
