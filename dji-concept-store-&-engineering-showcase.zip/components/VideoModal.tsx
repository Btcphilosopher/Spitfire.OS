'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { X, Play, Film, Sparkles } from 'lucide-react';

export default function VideoModal() {
  const { activeVideo, setActiveVideo } = useApp();

  if (!activeVideo) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div
        onClick={() => setActiveVideo(null)}
        className="fixed inset-0 -z-10"
      />

      <div className="bg-zinc-950 border border-zinc-800 rounded-xl max-w-4xl w-full overflow-hidden shadow-2xl text-white">
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Film className="w-5 h-5 text-red-500" />
            <h3 className="text-sm sm:text-base font-bold text-white">
              {activeVideo.title}
            </h3>
          </div>
          <button
            onClick={() => setActiveVideo(null)}
            className="p-1 text-zinc-400 hover:text-white rounded"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Cinematic Screen Player Simulation */}
        <div className="relative aspect-[16/9] w-full bg-black flex items-center justify-center overflow-hidden group">
          <img
            src="/assets/images/story_cinematographer_iceland_1794403423081.jpg"
            alt={activeVideo.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover filter brightness-75"
          />

          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-black/30" />

          {/* Central Play Button */}
          <div className="relative z-10 text-center space-y-3">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full border-2 border-white/80 flex items-center justify-center mx-auto hover:scale-110 transition-transform cursor-pointer bg-black/40 backdrop-blur-sm">
              <Play className="w-7 h-7 sm:w-8 sm:h-8 fill-current ml-1" />
            </div>
            <span className="text-xs font-mono tracking-widest uppercase text-zinc-300 block">
              Stream in 4K ProRes 60fps
            </span>
          </div>

          <div className="absolute bottom-4 left-6 right-6 flex items-center justify-between text-xs text-zinc-400">
            <span>00:00 / 03:42</span>
            <span>Hasselblad Natural Colour Solution (HNCS)</span>
          </div>
        </div>

        {/* Film Description */}
        <div className="p-6 bg-zinc-900/60 border-t border-zinc-800/80">
          <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed">
            {activeVideo.subtitle}
          </p>
          <div className="mt-4 pt-4 border-t border-zinc-800 flex items-center justify-between text-[11px] text-zinc-500 font-mono">
            <span>Captured with DJI Cinema Color Science</span>
            <span>10-Bit D-Log M · 12.8 Stops DR</span>
          </div>
        </div>
      </div>
    </div>
  );
}
