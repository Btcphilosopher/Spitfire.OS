'use client';

import React, { useState, useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import { Play, ArrowRight } from 'lucide-react';

interface HeroSlide {
  kicker: string;
  headline: string;
  subhead: string;
  productId: string;
  exploreText: string;
  videoTitle: string;
  videoSubtitle: string;
  image: string;
  alt: string;
}

const HERO_SLIDES: HeroSlide[] = [
  {
    kicker: 'DJI CAMERA DRONES',
    headline: 'A new\nperspective.',
    subhead: 'See further. Create without limits.',
    productId: 'mavic-3-pro',
    exploreText: 'Explore drones',
    videoTitle: 'DJI Mavic 3 Pro: The Art of the Tri-Camera',
    videoSubtitle: 'Director Henrik Lindqvist captures the Arctic frontiers of Iceland with Hasselblad optical depth.',
    image: '/assets/images/mockup_hero_slice.png',
    alt: 'DJI Mavic 3 Pro flying over scenic coastal cliffs',
  },
  {
    kicker: 'DJI HANDHELD IMAGING',
    headline: 'For moving\nmoments.',
    subhead: '1-inch CMOS sensor, pocket-sized mechanical stabilization.',
    productId: 'osmo-pocket-3',
    exploreText: 'Explore Osmo',
    videoTitle: 'DJI Osmo Pocket 3: Midnight in Shinjuku',
    videoSubtitle: 'Full-pixel fast focusing and 4K/120fps slow motion in low-light metropolitan alleys.',
    image: '/assets/images/card_handheld.png',
    alt: 'DJI Osmo Pocket 3 handheld camera with rotatable OLED screen',
  },
  {
    kicker: 'DJI CINEMA SYSTEMS',
    headline: 'Master\nthe unseen.',
    subhead: 'Full-frame 8K cinema aerial platform with RTK repeatability.',
    productId: 'inspire-3',
    exploreText: 'Explore Inspire 3',
    videoTitle: 'DJI Inspire 3: Hollywood Aerial Production',
    videoSubtitle: 'Dual operator precision, 360-degree pan & tilt boost for feature film cinematography.',
    image: '/assets/images/card_professional.png',
    alt: 'DJI Inspire 3 professional cinema aerial platform',
  },
];

export default function Hero() {
  const { navigateToProduct, setActiveVideo, setActiveView } = useApp();
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);

  // Auto-advance slides every 8 seconds (can be paused or manually toggled)
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlideIndex((prev) => (prev + 1) % HERO_SLIDES.length);
    }, 9000);
    return () => clearInterval(timer);
  }, []);

  const slide = HERO_SLIDES[currentSlideIndex];

  return (
    <section className="relative w-full bg-black text-white overflow-hidden min-h-[580px] lg:min-h-[640px] flex items-center">
      {/* Background Graphic / Mockup Scene */}
      <div className="absolute inset-0 z-0">
        {/* Render the exact hero slice from the mockup for slide 0, and styled backdrop for other slides */}
        {currentSlideIndex === 0 ? (
          <div className="relative w-full h-full">
            <img
              src="/assets/images/mockup_hero_slice.png"
              alt="DJI Camera Drones Aerial Scene"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center lg:object-right filter brightness-95"
            />
            {/* Dark gradient scrim on left to guarantee 5:1+ text contrast on all devices */}
            <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/50 to-transparent w-full lg:w-2/3" />
          </div>
        ) : (
          <div className="relative w-full h-full bg-gradient-to-b from-zinc-950 via-zinc-900 to-black flex items-center justify-end pr-12 lg:pr-32">
            <div className="w-full max-w-xl aspect-[4/3] rounded-2xl overflow-hidden bg-zinc-900/40 p-8 flex items-center justify-center">
              <img
                src={slide.image}
                alt={slide.alt}
                referrerPolicy="no-referrer"
                className="max-h-[420px] w-auto object-contain animate-in fade-in zoom-in-95 duration-500"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-r from-black via-black/75 to-transparent w-full lg:w-3/5" />
          </div>
        )}
      </div>

      {/* Hero Content Layer */}
      <div className="relative z-10 max-w-[1440px] mx-auto px-6 lg:px-12 w-full py-16 lg:py-24">
        <div className="max-w-2xl">
          {/* Red line kicker matching mockup */}
          <div className="flex items-center gap-2 mb-4 animate-in fade-in duration-300">
            <span className="w-5 h-[2px] bg-red-600 inline-block" />
            <span className="text-xs font-bold tracking-widest text-zinc-300 uppercase">
              {slide.kicker}
            </span>
          </div>

          {/* Large, Confident Headline */}
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white mb-4 whitespace-pre-line leading-[1.08] text-balance">
            {slide.headline}
          </h1>

          {/* Subtitle */}
          <p className="text-base sm:text-lg text-zinc-300 max-w-lg mb-8 font-normal leading-relaxed">
            {slide.subhead}
          </p>

          {/* CTA Buttons matching mockup */}
          <div className="flex flex-wrap items-center gap-4 sm:gap-6">
            {/* Primary Button: Solid White */}
            <button
              onClick={() => navigateToProduct(slide.productId)}
              className="px-6 py-3.5 bg-white text-black font-semibold text-sm rounded hover:bg-zinc-200 transition-colors flex items-center gap-2 group shadow-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
            >
              <span>{slide.exploreText}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            {/* Secondary Button: Watch the film */}
            <button
              onClick={() =>
                setActiveVideo({
                  title: slide.videoTitle,
                  subtitle: slide.videoSubtitle,
                })
              }
              className="inline-flex items-center gap-3 text-sm font-medium text-white hover:text-zinc-200 transition-colors py-2 px-1 focus:outline-none focus-visible:ring-2 focus-visible:ring-white group"
            >
              <span className="w-8 h-8 rounded-full border border-white/80 flex items-center justify-center group-hover:bg-white/20 transition-all">
                <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
              </span>
              <span>Watch the film</span>
            </button>
          </div>
        </div>

        {/* Slide Progress Indicator matching mockup: '01 / 03' + Segmented Dashes */}
        <div className="mt-16 lg:mt-24 flex items-center gap-4">
          <span className="text-xs font-mono font-medium tracking-wider text-zinc-300">
            0{currentSlideIndex + 1} <span className="text-zinc-500">/ 0{HERO_SLIDES.length}</span>
          </span>

          <div className="flex items-center gap-2" role="tablist" aria-label="Hero slides">
            {HERO_SLIDES.map((_, idx) => (
              <button
                key={idx}
                role="tab"
                aria-selected={currentSlideIndex === idx}
                aria-label={`Go to slide ${idx + 1}`}
                onClick={() => setCurrentSlideIndex(idx)}
                className={`h-[2px] transition-all duration-300 focus:outline-none ${
                  currentSlideIndex === idx
                    ? 'w-10 bg-white'
                    : 'w-6 bg-zinc-600 hover:bg-zinc-400'
                }`}
              />
            ))}
          </div>

          <div className="hidden sm:flex items-center gap-2 ml-4">
            <button
              onClick={() => setActiveView('selector')}
              className="text-xs text-zinc-400 hover:text-white underline underline-offset-4"
            >
              Need help deciding? Use Guided Selector
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
