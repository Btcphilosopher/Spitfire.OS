'use client';

import React, { useState } from 'react';
import { PRODUCTS, Product } from '@/data/products';
import { useApp } from '@/context/AppContext';
import { Check, Compass, RotateCcw, ArrowRight, ShieldCheck, Zap, Sparkles } from 'lucide-react';

interface QuestionOption {
  label: string;
  sublabel: string;
  value: string;
}

interface Question {
  id: string;
  title: string;
  subtitle: string;
  options: QuestionOption[];
}

const QUESTIONS: Question[] = [
  {
    id: 'primaryUse',
    title: 'What is your primary creative focus?',
    subtitle: 'Choose the medium and environment you create in most frequently.',
    options: [
      { label: 'Aerial Cinematography & Landscape', sublabel: 'High dynamic range, multi-focal lenses, and sweeping cinematic shots.', value: 'cinema' },
      { label: 'Travel & Everyday Vlogging', sublabel: 'Ultra-portable, quick setup, effortless vertical framing for mobile.', value: 'travel' },
      { label: 'Extreme Sports & Action', sublabel: 'Waterproof, crash-resistant, high-g shock stabilization, extreme temps.', value: 'action' },
      { label: 'First-Person Immersive FPV', sublabel: 'Cockpit goggles perspective, tight gaps, acrobatic flight maneuvers.', value: 'fpv' },
    ],
  },
  {
    id: 'portability',
    title: 'How critical is weight and portability?',
    subtitle: 'Regulations and pack size dictate where and how easily you can operate.',
    options: [
      { label: 'Pocket-sized or Under 249g', sublabel: 'No FAA registration in most regions, fits in jacket pocket.', value: 'ultralight' },
      { label: 'Compact Folding Backpack Fit', sublabel: 'Fits inside standard photography backpack with spare batteries.', value: 'compact' },
      { label: 'Studio & Cinema Payload', sublabel: 'Performance is king; vehicle transport with pelican rolling case.', value: 'heavy' },
    ],
  },
  {
    id: 'experience',
    title: 'What is your pilot and camera experience?',
    subtitle: 'Helps balance automated safety assistance with manual pro-grade controls.',
    options: [
      { label: 'Beginner / First Drone', sublabel: 'Need omnidirectional obstacle avoidance, auto-return, and intuitive controls.', value: 'beginner' },
      { label: 'Enthusiast Creator', sublabel: 'Comfortable with manual exposure, D-Log M color grading, and flight modes.', value: 'enthusiast' },
      { label: 'Licensed Cinema Operator', sublabel: 'Require ProRes RAW, dual-operator remotes, and centimeter RTK.', value: 'professional' },
    ],
  },
  {
    id: 'budget',
    title: 'What is your target investment?',
    subtitle: 'Includes the primary unit and standard controller.',
    options: [
      { label: 'Under $600 USD', sublabel: 'High-value pocket cameras and entry-level travel setups.', value: 'under-600' },
      { label: '$600 – $1,200 USD', sublabel: 'Advanced sub-249g drones and comprehensive creator combos.', value: '600-1200' },
      { label: '$1,200 – $3,000 USD', sublabel: 'Flagship multi-camera cinema systems and heavy-duty sensors.', value: '1200-3000' },
      { label: '$3,000+ USD', sublabel: 'Commercial cinema rigs with 8K full-frame cinema bodies.', value: 'over-3000' },
    ],
  },
];

interface MatchResult {
  product: Product;
  score: number;
  matchReasons: string[];
}

export default function GuidedSelector() {
  const { navigateToProduct, addToCart, formatPrice, addToCompare } = useApp();

  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [hasCompleted, setHasCompleted] = useState(false);

  const handleSelectOption = (questionId: string, value: string) => {
    const nextAnswers = { ...answers, [questionId]: value };
    setAnswers(nextAnswers);

    if (currentStep < QUESTIONS.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setHasCompleted(true);
    }
  };

  const handleReset = () => {
    setAnswers({});
    setCurrentStep(0);
    setHasCompleted(false);
  };

  // Evaluate matching products with transparent rules
  const evaluateMatches = (): MatchResult[] => {
    const results: MatchResult[] = [];

    const primaryUse = answers['primaryUse'];
    const portability = answers['portability'];
    const experience = answers['experience'];
    const budget = answers['budget'];

    PRODUCTS.forEach((product) => {
      let score = 0;
      const matchReasons: string[] = [];

      // 1. Primary Use Matching
      if (primaryUse === 'cinema') {
        if (product.id === 'mavic-3-pro') {
          score += 40;
          matchReasons.push('Tri-camera system with 4/3 Hasselblad sensor allows telephoto framing and cinematic focal compression.');
        } else if (product.id === 'inspire-3') {
          score += 45;
          matchReasons.push('Full-frame 8K ProRes RAW with interchangeable DL primes meets commercial cinema requirements.');
        } else if (product.id === 'mini-4-pro') {
          score += 25;
          matchReasons.push('Supports 4K/60fps HDR and 10-bit D-Log M for easy color grading in a compact package.');
        }
      } else if (primaryUse === 'travel') {
        if (product.id === 'mini-4-pro') {
          score += 45;
          matchReasons.push('Sub-249g ultra-lightweight design is exempt from registration in many regions and packs into any daypack.');
        } else if (product.id === 'osmo-pocket-3') {
          score += 45;
          matchReasons.push('Pocketable 1-inch CMOS gimbal powers on instantly with rotatable screen for spontaneous travel documentation.');
        } else if (product.id === 'osmo-action-5-pro') {
          score += 35;
          matchReasons.push('Rugged waterproof design and 4-hour battery life make it hassle-free for all-day excursions.');
        }
      } else if (primaryUse === 'action') {
        if (product.id === 'osmo-action-5-pro') {
          score += 50;
          matchReasons.push('Engineered for action: 20m waterproof without housing, cold-resistant down to -20°C, and 13.5 stops dynamic range.');
        } else if (product.id === 'avata-2') {
          score += 45;
          matchReasons.push('Integrated propeller guards withstand collisions while tracking high-speed downhill sports.');
        }
      } else if (primaryUse === 'fpv') {
        if (product.id === 'avata-2') {
          score += 55;
          matchReasons.push('Built specifically for FPV flight with Goggles 3 and single-hand Motion 3 controller for intuitive ACRO maneuvers.');
        }
      }

      // 2. Portability Matching
      if (portability === 'ultralight') {
        if (product.weightGrams < 250) {
          score += 25;
          matchReasons.push(`Weighs only ${product.weightGrams}g, well under standard regulatory thresholds.`);
        } else if (product.id === 'osmo-action-5-pro') {
          score += 25;
          matchReasons.push('Weighs just 146g and mounts directly to helmets, handlebars, or chest harnesses.');
        }
      } else if (portability === 'compact') {
        if (product.weightGrams < 1000 && product.weightGrams >= 250) {
          score += 25;
          matchReasons.push(`Foldable airframe (${product.weightGrams}g) balances heavy camera specs with portable backpack transport.`);
        }
      } else if (portability === 'heavy') {
        if (product.id === 'inspire-3') {
          score += 30;
          matchReasons.push('Engineered for heavy-duty flight dynamics and dual-operator cinema workflows.');
        }
      }

      // 3. Experience Matching
      if (experience === 'beginner') {
        if (product.experienceLevel === 'beginner') {
          score += 20;
          matchReasons.push('Designed with comprehensive obstacle sensing, automatic return-to-home, and beginner tutorial flight modes.');
        } else if (product.id === 'avata-2') {
          score += 15;
          matchReasons.push('Intuitive Motion 3 controller makes flight as simple as pointing where you want to fly.');
        }
      } else if (experience === 'professional') {
        if (product.experienceLevel === 'professional' || product.id === 'mavic-3-pro') {
          score += 25;
          matchReasons.push('Offers full manual aperture control, timecode sync, D-Log color profiles, and high-bitrate recording.');
        }
      }

      // 4. Budget Matching
      if (budget === 'under-600') {
        if (product.basePrice <= 600) {
          score += 30;
          matchReasons.push(`Base price of $${product.basePrice} aligns cleanly with your budget under $600.`);
        } else {
          score -= 30;
        }
      } else if (budget === '600-1200') {
        if (product.basePrice >= 600 && product.basePrice <= 1200) {
          score += 30;
          matchReasons.push(`Base price of $${product.basePrice} fits your $600 - $1,200 tier.`);
        } else if (product.basePrice < 600) {
          score += 10;
        } else {
          score -= 25;
        }
      } else if (budget === '1200-3000') {
        if (product.basePrice >= 1200 && product.basePrice <= 3000) {
          score += 30;
          matchReasons.push(`Priced at $${product.basePrice}, delivering maximum pro capability for under $3,000.`);
        } else {
          score -= 15;
        }
      } else if (budget === 'over-3000') {
        if (product.basePrice > 3000) {
          score += 35;
          matchReasons.push('Priced for studio production and enterprise film budgets.');
        }
      }

      if (score > 30) {
        results.push({ product, score, matchReasons });
      }
    });

    results.sort((a, b) => b.score - a.score);
    return results;
  };

  const matches = evaluateMatches();
  const topMatch = matches[0];
  const secondMatch = matches[1];

  return (
    <section className="w-full bg-[#fafafa] text-zinc-900 py-16 lg:py-24 border-b border-zinc-200">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-12">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-zinc-200/80 rounded-full text-xs font-semibold uppercase tracking-wider text-zinc-700 mb-3">
            <Compass className="w-3.5 h-3.5" />
            <span>Find Your DJI</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-zinc-900">
            Guided Product Selector
          </h2>
          <p className="text-zinc-600 text-sm mt-3">
            Answer four straightforward questions to receive an objective recommendation based on your workflow, technical needs, and regulatory comfort.
          </p>
        </div>

        {!hasCompleted ? (
          /* Question Card */
          <div className="bg-white border border-zinc-200 shadow-sm rounded-xl p-6 sm:p-10 max-w-2xl mx-auto">
            {/* Step progress bar */}
            <div className="flex items-center justify-between text-xs text-zinc-500 mb-6 font-medium">
              <span>Question {currentStep + 1} of {QUESTIONS.length}</span>
              <span>{Math.round(((currentStep + 1) / QUESTIONS.length) * 100)}% Complete</span>
            </div>

            <div className="w-full h-1 bg-zinc-100 rounded-full mb-8 overflow-hidden">
              <div
                className="h-full bg-zinc-900 transition-all duration-300"
                style={{ width: `${((currentStep + 1) / QUESTIONS.length) * 100}%` }}
              />
            </div>

            <div className="mb-6">
              <h3 className="text-xl sm:text-2xl font-bold tracking-tight text-zinc-900">
                {QUESTIONS[currentStep].title}
              </h3>
              <p className="text-xs sm:text-sm text-zinc-500 mt-1">
                {QUESTIONS[currentStep].subtitle}
              </p>
            </div>

            {/* Options */}
            <div className="space-y-3">
              {QUESTIONS[currentStep].options.map((opt) => {
                const isSelected = answers[QUESTIONS[currentStep].id] === opt.value;
                return (
                  <button
                    key={opt.value}
                    onClick={() => handleSelectOption(QUESTIONS[currentStep].id, opt.value)}
                    className={`w-full p-4 rounded-lg border text-left transition-all flex items-start justify-between group ${
                      isSelected
                        ? 'border-zinc-900 bg-zinc-900 text-white shadow-sm'
                        : 'border-zinc-200 hover:border-zinc-400 bg-white text-zinc-900 hover:bg-zinc-50/50'
                    }`}
                  >
                    <div className="pr-4">
                      <span className={`block text-sm font-semibold mb-0.5 ${isSelected ? 'text-white' : 'text-zinc-900'}`}>
                        {opt.label}
                      </span>
                      <span className={`block text-xs leading-relaxed ${isSelected ? 'text-zinc-300' : 'text-zinc-500'}`}>
                        {opt.sublabel}
                      </span>
                    </div>
                    <div
                      className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 mt-0.5 ${
                        isSelected
                          ? 'border-white bg-white text-black'
                          : 'border-zinc-300 group-hover:border-zinc-400'
                      }`}
                    >
                      {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Back button */}
            {currentStep > 0 && (
              <div className="mt-6 pt-4 border-t border-zinc-100 flex justify-between">
                <button
                  onClick={() => setCurrentStep(currentStep - 1)}
                  className="text-xs text-zinc-500 hover:text-zinc-900 font-medium"
                >
                  ← Back to previous question
                </button>
              </div>
            )}
          </div>
        ) : (
          /* Recommendation Result Screen */
          <div className="max-w-3xl mx-auto bg-white border border-zinc-200 rounded-xl p-6 sm:p-10 shadow-sm animate-in fade-in zoom-in-95 duration-300">
            <div className="flex items-center justify-between mb-8 pb-4 border-b border-zinc-200">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-red-600" />
                <h3 className="text-lg font-bold text-zinc-900">
                  Recommended For Your Needs
                </h3>
              </div>
              <button
                onClick={handleReset}
                className="inline-flex items-center gap-1.5 text-xs text-zinc-500 hover:text-zinc-900 font-medium"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Retake Assessment</span>
              </button>
            </div>

            {topMatch ? (
              <div className="space-y-8">
                {/* Primary Card */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center bg-[#f8f8fa] p-6 rounded-lg border border-zinc-200/80">
                  <div className="md:col-span-5 aspect-[4/3] rounded bg-white p-4 flex items-center justify-center border border-zinc-200/50">
                    <img
                      src={topMatch.product.images.studio}
                      alt={topMatch.product.name}
                      referrerPolicy="no-referrer"
                      className="max-h-full object-contain"
                    />
                  </div>

                  <div className="md:col-span-7">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[11px] font-bold text-red-600 uppercase tracking-wider">
                        Top Match
                      </span>
                      <span className="text-zinc-400">·</span>
                      <span className="text-xs text-zinc-500">{topMatch.product.series} Series</span>
                    </div>

                    <h4 className="text-2xl font-extrabold text-zinc-900 mb-1">
                      {topMatch.product.name}
                    </h4>
                    <p className="text-xs text-zinc-600 mb-3">
                      {topMatch.product.tagline}
                    </p>

                    <div className="text-lg font-bold font-mono text-zinc-900 mb-4">
                      {formatPrice(topMatch.product.basePrice)}
                    </div>

                    {/* Why this matches list */}
                    <div className="bg-white p-3.5 rounded border border-zinc-200 text-xs mb-5 space-y-2">
                      <span className="font-semibold text-zinc-900 block">
                        Why this matches your criteria:
                      </span>
                      {topMatch.matchReasons.map((reason, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-zinc-600 leading-relaxed">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{reason}</span>
                        </div>
                      ))}
                    </div>

                    {/* Actions */}
                    <div className="flex flex-wrap items-center gap-3">
                      <button
                        onClick={() => navigateToProduct(topMatch.product.id)}
                        className="px-5 py-2.5 bg-zinc-900 text-white font-semibold text-xs rounded hover:bg-black transition-colors flex items-center gap-1.5"
                      >
                        <span>View Full Specs</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => addToCart(topMatch.product.id, topMatch.product.combos[0].id)}
                        className="px-4 py-2.5 bg-white border border-zinc-300 text-zinc-900 font-medium text-xs rounded hover:bg-zinc-50 transition-colors"
                      >
                        Quick Add to Cart
                      </button>

                      <button
                        onClick={() => addToCompare(topMatch.product.id)}
                        className="text-xs text-zinc-500 hover:text-zinc-900 underline"
                      >
                        Add to Comparison
                      </button>
                    </div>
                  </div>
                </div>

                {/* Secondary Alternative if available */}
                {secondMatch && (
                  <div className="border-t border-zinc-200 pt-6">
                    <span className="text-xs font-bold uppercase tracking-wider text-zinc-500 block mb-3">
                      Alternative Contender
                    </span>
                    <div className="flex flex-col sm:flex-row items-center justify-between p-4 bg-white border border-zinc-200 rounded-lg gap-4">
                      <div className="flex items-center gap-4">
                        <img
                          src={secondMatch.product.images.studio}
                          alt={secondMatch.product.name}
                          referrerPolicy="no-referrer"
                          className="w-16 h-16 object-contain"
                        />
                        <div>
                          <h5 className="text-sm font-bold text-zinc-900">
                            {secondMatch.product.name}
                          </h5>
                          <p className="text-xs text-zinc-500">
                            {secondMatch.product.tagline}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 self-end sm:self-center shrink-0">
                        <span className="font-mono text-sm font-bold text-zinc-900">
                          {formatPrice(secondMatch.product.basePrice)}
                        </span>
                        <button
                          onClick={() => navigateToProduct(secondMatch.product.id)}
                          className="text-xs font-semibold text-zinc-900 hover:underline"
                        >
                          Compare →
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              /* No suitable match state */
              <div className="text-center py-8">
                <p className="text-base font-semibold text-zinc-900 mb-2">
                  No direct catalog match found for these exact constraints.
                </p>
                <p className="text-xs text-zinc-500 max-w-md mx-auto mb-6">
                  Professional cinema capabilities typically require a larger airframe and budget. Consider exploring our sub-249g travel line or adjusting your target investment.
                </p>
                <button
                  onClick={handleReset}
                  className="px-6 py-2.5 bg-zinc-900 text-white font-semibold text-xs rounded hover:bg-black"
                >
                  Adjust Requirements
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
