'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { PRODUCTS } from '@/data/products';
import { ACCESSORIES } from '@/data/accessories';
import {
  X,
  CheckCircle,
  Truck,
  CreditCard,
  ShieldCheck,
  Package,
  ArrowRight,
  ArrowLeft,
  Loader2,
} from 'lucide-react';

export default function CheckoutModal() {
  const {
    isCheckoutOpen,
    setIsCheckoutOpen,
    cart,
    cartSubtotal,
    formatPrice,
    clearCart,
    region,
  } = useApp();

  const [step, setStep] = useState<'shipping' | 'delivery' | 'payment' | 'processing' | 'confirmed'>('shipping');

  // Form states
  const [formData, setFormData] = useState({
    firstName: 'Alex',
    lastName: 'Vance',
    email: 'alex.vance@example.com',
    phone: '+1 (555) 234-8901',
    address: '742 Evergreen Terrace',
    city: 'Seattle',
    state: 'WA',
    postalCode: '98101',
    country: 'United States',
  });

  const [deliveryMethod, setDeliveryMethod] = useState<'express' | 'priority'>('express');
  const [paymentMethod, setPaymentMethod] = useState<'sandbox-card' | 'apple-pay' | 'cod'>('sandbox-card');
  const [orderNumber, setOrderNumber] = useState('');

  if (!isCheckoutOpen) return null;

  const shippingCost = deliveryMethod === 'priority' ? 35 : 0;
  const estimatedTax = Math.round(cartSubtotal * 0.08); // 8% tax demo
  const finalTotal = cartSubtotal + shippingCost + estimatedTax;

  const handleNextStep = (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 'shipping') {
      setStep('delivery');
    } else if (step === 'delivery') {
      setStep('payment');
    } else if (step === 'payment') {
      setStep('processing');
      // Simulate backend payment authorization
      setTimeout(() => {
        const generatedOrder = `DJI-2026-${Math.floor(100000 + Math.random() * 900000)}`;
        setOrderNumber(generatedOrder);
        setStep('confirmed');
        clearCart();
      }, 1800);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6">
      <div className="bg-white border border-zinc-200 rounded-xl max-w-2xl w-full shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 text-zinc-900">
        {/* Header */}
        <div className="p-5 border-b border-zinc-200 flex items-center justify-between bg-[#fbfbfb]">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 bg-red-600 rounded-full" />
              <h3 className="text-sm font-bold uppercase tracking-wider text-zinc-900">
                DJI Checkout Demonstration
              </h3>
            </div>
            <span className="text-[11px] text-zinc-500">
              Simulated sandbox checkout · No real charges will occur
            </span>
          </div>

          {step !== 'processing' && (
            <button
              onClick={() => setIsCheckoutOpen(false)}
              className="text-zinc-400 hover:text-zinc-900 p-1 rounded"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Step Indicator */}
        {step !== 'confirmed' && step !== 'processing' && (
          <div className="grid grid-cols-3 text-center text-xs border-b border-zinc-200 bg-zinc-50 font-medium">
            <div
              className={`py-2.5 border-r border-zinc-200 ${
                step === 'shipping' ? 'bg-white text-zinc-900 font-bold border-b-2 border-b-zinc-900' : 'text-zinc-400'
              }`}
            >
              1. Address
            </div>
            <div
              className={`py-2.5 border-r border-zinc-200 ${
                step === 'delivery' ? 'bg-white text-zinc-900 font-bold border-b-2 border-b-zinc-900' : 'text-zinc-400'
              }`}
            >
              2. Delivery
            </div>
            <div
              className={`py-2.5 ${
                step === 'payment' ? 'bg-white text-zinc-900 font-bold border-b-2 border-b-zinc-900' : 'text-zinc-400'
              }`}
            >
              3. Payment
            </div>
          </div>
        )}

        <div className="p-6 sm:p-8">
          {/* Step 1: Shipping Address Form */}
          {step === 'shipping' && (
            <form onSubmit={handleNextStep} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-zinc-700 mb-1">
                    First Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    className="w-full p-2.5 text-xs border border-zinc-300 rounded focus:ring-2 focus:ring-zinc-900 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-700 mb-1">
                    Last Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    className="w-full p-2.5 text-xs border border-zinc-300 rounded focus:ring-2 focus:ring-zinc-900 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-zinc-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full p-2.5 text-xs border border-zinc-300 rounded focus:ring-2 focus:ring-zinc-900 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-700 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full p-2.5 text-xs border border-zinc-300 rounded focus:ring-2 focus:ring-zinc-900 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-700 mb-1">
                  Street Address
                </label>
                <input
                  type="text"
                  required
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full p-2.5 text-xs border border-zinc-300 rounded focus:ring-2 focus:ring-zinc-900 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-zinc-700 mb-1">City</label>
                  <input
                    type="text"
                    required
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className="w-full p-2.5 text-xs border border-zinc-300 rounded focus:ring-2 focus:ring-zinc-900 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-700 mb-1">State / Province</label>
                  <input
                    type="text"
                    required
                    value={formData.state}
                    onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                    className="w-full p-2.5 text-xs border border-zinc-300 rounded focus:ring-2 focus:ring-zinc-900 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-700 mb-1">Postal Code</label>
                  <input
                    type="text"
                    required
                    value={formData.postalCode}
                    onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                    className="w-full p-2.5 text-xs border border-zinc-300 rounded focus:ring-2 focus:ring-zinc-900 focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div className="pt-4 flex justify-end">
                <button
                  type="submit"
                  className="px-6 py-3 bg-zinc-900 hover:bg-black text-white text-xs font-semibold rounded flex items-center gap-2"
                >
                  <span>Continue to Delivery</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}

          {/* Step 2: Delivery Option */}
          {step === 'delivery' && (
            <div className="space-y-4">
              <h4 className="text-sm font-bold text-zinc-900 mb-2">
                Choose Shipping Courier Method
              </h4>

              <div className="space-y-3">
                <label
                  onClick={() => setDeliveryMethod('express')}
                  className={`p-4 rounded-lg border flex items-center justify-between cursor-pointer transition-all ${
                    deliveryMethod === 'express'
                      ? 'border-zinc-900 bg-zinc-50'
                      : 'border-zinc-200 hover:border-zinc-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="delivery"
                      checked={deliveryMethod === 'express'}
                      onChange={() => setDeliveryMethod('express')}
                      className="text-zinc-900"
                    />
                    <div>
                      <span className="text-xs font-bold text-zinc-900 block">
                        Complimentary Global Express (UPS / DHL Air)
                      </span>
                      <span className="text-[11px] text-zinc-500">
                        Delivered in 2 to 4 business days with signature release.
                      </span>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-emerald-700 font-mono">Free</span>
                </label>

                <label
                  onClick={() => setDeliveryMethod('priority')}
                  className={`p-4 rounded-lg border flex items-center justify-between cursor-pointer transition-all ${
                    deliveryMethod === 'priority'
                      ? 'border-zinc-900 bg-zinc-50'
                      : 'border-zinc-200 hover:border-zinc-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="delivery"
                      checked={deliveryMethod === 'priority'}
                      onChange={() => setDeliveryMethod('priority')}
                      className="text-zinc-900"
                    />
                    <div>
                      <span className="text-xs font-bold text-zinc-900 block">
                        Priority Next-Flight Aviation Courier
                      </span>
                      <span className="text-[11px] text-zinc-500">
                        Guaranteed next business day delivery with temperature-controlled battery handling.
                      </span>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-zinc-900 font-mono">{formatPrice(35)}</span>
                </label>
              </div>

              <div className="pt-6 border-t border-zinc-200 flex justify-between">
                <button
                  type="button"
                  onClick={() => setStep('shipping')}
                  className="text-xs text-zinc-500 hover:text-zinc-900 flex items-center gap-1 font-medium"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Address</span>
                </button>

                <button
                  type="button"
                  onClick={() => setStep('payment')}
                  className="px-6 py-3 bg-zinc-900 hover:bg-black text-white text-xs font-semibold rounded flex items-center gap-2"
                >
                  <span>Continue to Payment</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Step 3: Payment Simulation */}
          {step === 'payment' && (
            <div className="space-y-4">
              <h4 className="text-sm font-bold text-zinc-900 mb-1">
                Select Demonstration Payment
              </h4>
              <p className="text-xs text-zinc-500 mb-4">
                This is a simulated testing environment. Pre-filled sandbox credentials are provided.
              </p>

              <div className="space-y-3">
                <label
                  onClick={() => setPaymentMethod('sandbox-card')}
                  className={`p-4 rounded-lg border flex items-center justify-between cursor-pointer transition-all ${
                    paymentMethod === 'sandbox-card'
                      ? 'border-zinc-900 bg-zinc-50'
                      : 'border-zinc-200 hover:border-zinc-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMethod === 'sandbox-card'}
                      onChange={() => setPaymentMethod('sandbox-card')}
                    />
                    <div>
                      <span className="text-xs font-bold text-zinc-900 block">
                        Test Sandbox Credit Card (Instant Pass)
                      </span>
                      <span className="text-[11px] font-mono text-zinc-500">
                        •••• •••• •••• 4242 (Exp 12/28)
                      </span>
                    </div>
                  </div>
                  <CreditCard className="w-5 h-5 text-zinc-500" />
                </label>

                <label
                  onClick={() => setPaymentMethod('apple-pay')}
                  className={`p-4 rounded-lg border flex items-center justify-between cursor-pointer transition-all ${
                    paymentMethod === 'apple-pay'
                      ? 'border-zinc-900 bg-zinc-50'
                      : 'border-zinc-200 hover:border-zinc-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMethod === 'apple-pay'}
                      onChange={() => setPaymentMethod('apple-pay')}
                    />
                    <div>
                      <span className="text-xs font-bold text-zinc-900 block">
                        Digital Wallet (Apple Pay / Google Pay Demo)
                      </span>
                      <span className="text-[11px] text-zinc-500">
                        One-touch biometric authorization simulation.
                      </span>
                    </div>
                  </div>
                  <ShieldCheck className="w-5 h-5 text-zinc-500" />
                </label>
              </div>

              {/* Order Calculation Breakdown */}
              <div className="p-4 bg-zinc-50 rounded-lg border border-zinc-200 text-xs space-y-2 mt-4">
                <div className="flex justify-between text-zinc-600">
                  <span>Product Subtotal</span>
                  <span className="font-mono">{formatPrice(cartSubtotal)}</span>
                </div>
                <div className="flex justify-between text-zinc-600">
                  <span>Shipping Courier</span>
                  <span className="font-mono">
                    {shippingCost === 0 ? 'Free' : formatPrice(shippingCost)}
                  </span>
                </div>
                <div className="flex justify-between text-zinc-600">
                  <span>Estimated Taxes (8%)</span>
                  <span className="font-mono">{formatPrice(estimatedTax)}</span>
                </div>
                <div className="flex justify-between text-sm font-bold text-zinc-900 pt-2 border-t border-zinc-200">
                  <span>Total Simulation Amount</span>
                  <span className="font-mono">{formatPrice(finalTotal)}</span>
                </div>
              </div>

              <div className="pt-6 border-t border-zinc-200 flex justify-between">
                <button
                  type="button"
                  onClick={() => setStep('delivery')}
                  className="text-xs text-zinc-500 hover:text-zinc-900 flex items-center gap-1 font-medium"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Delivery</span>
                </button>

                <button
                  type="button"
                  onClick={handleNextStep}
                  className="px-6 py-3 bg-zinc-900 hover:bg-black text-white text-xs font-bold rounded flex items-center gap-2 shadow"
                >
                  <span>Authorize Demonstration Order ({formatPrice(finalTotal)})</span>
                </button>
              </div>
            </div>
          )}

          {/* Processing Spinner State */}
          {step === 'processing' && (
            <div className="py-16 text-center space-y-4">
              <Loader2 className="w-10 h-10 text-zinc-900 animate-spin mx-auto" />
              <h4 className="text-base font-bold text-zinc-900">
                Authorizing Simulation...
              </h4>
              <p className="text-xs text-zinc-500 max-w-sm mx-auto">
                Allocating factory serial numbers and registering simulated DJI Care Refresh coverage.
              </p>
            </div>
          )}

          {/* Step 4: Order Confirmed Receipt */}
          {step === 'confirmed' && (
            <div className="text-center py-6 space-y-6">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-600">
                <CheckCircle className="w-8 h-8" />
              </div>

              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 block mb-1">
                  Demonstration Order Confirmed
                </span>
                <h4 className="text-2xl font-extrabold text-zinc-900">
                  Thank You for Your Order
                </h4>
                <p className="text-xs text-zinc-500 mt-1">
                  Order confirmation and simulated invoice sent to {formData.email}.
                </p>
              </div>

              {/* Receipt Summary Card */}
              <div className="bg-[#f9f9fa] border border-zinc-200 rounded-lg p-5 text-left text-xs space-y-3">
                <div className="flex justify-between border-b border-zinc-200 pb-2">
                  <span className="text-zinc-500">Order Reference:</span>
                  <span className="font-mono font-bold text-zinc-900">{orderNumber}</span>
                </div>
                <div className="flex justify-between border-b border-zinc-200 pb-2">
                  <span className="text-zinc-500">Recipient:</span>
                  <span className="font-medium text-zinc-900">{formData.firstName} {formData.lastName}</span>
                </div>
                <div className="flex justify-between border-b border-zinc-200 pb-2">
                  <span className="text-zinc-500">Destination:</span>
                  <span className="font-medium text-zinc-900">{formData.address}, {formData.city}, {formData.state} {formData.postalCode}</span>
                </div>
                <div className="flex justify-between border-b border-zinc-200 pb-2">
                  <span className="text-zinc-500">Courier Service:</span>
                  <span className="font-medium text-zinc-900">
                    {deliveryMethod === 'priority' ? 'Next-Flight Priority' : 'Express Air (2–4 Days)'}
                  </span>
                </div>
                <div className="flex justify-between pt-1 font-bold text-zinc-900">
                  <span>Simulated Total:</span>
                  <span className="font-mono text-sm">{formatPrice(finalTotal)}</span>
                </div>
              </div>

              <div className="pt-2 flex flex-col sm:flex-row gap-3 justify-center">
                <button
                  onClick={() => setIsCheckoutOpen(false)}
                  className="px-6 py-3 bg-zinc-900 hover:bg-black text-white text-xs font-bold rounded"
                >
                  Return to Storefront
                </button>
                <button
                  onClick={() => alert(`Receipt print simulated for ${orderNumber}`)}
                  className="px-6 py-3 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 text-xs font-semibold rounded"
                >
                  Print Receipt Summary
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
