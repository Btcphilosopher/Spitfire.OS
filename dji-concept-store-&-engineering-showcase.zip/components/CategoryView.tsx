'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { PRODUCTS, Product } from '@/data/products';
import { ArrowLeft, SlidersHorizontal, ArrowRight, Check, Plus } from 'lucide-react';

export default function CategoryView() {
  const {
    selectedCategory,
    setSelectedCategory,
    navigateToProduct,
    addToCart,
    addToCompare,
    removeFromCompare,
    isInCompare,
    formatPrice,
    setActiveView,
  } = useApp();

  const [weightFilter, setWeightFilter] = useState<'all' | 'under-250' | 'pro'>('all');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'flight-time'>('featured');

  const categoryTitles: Record<string, { title: string; subtitle: string; heroDesc: string }> = {
    'camera-drones': {
      title: 'Camera Drones',
      subtitle: 'Aerial Cinema & High-Performance Flight',
      heroDesc: 'From sub-249g travel aircraft exempt from registration to triple-camera Hasselblad cinema platforms, discover drones engineered for exceptional perspective.',
    },
    'handheld': {
      title: 'Handheld Imaging',
      subtitle: 'Pocket Gimbals, Action Cameras & Microphones',
      heroDesc: 'Physical 3-axis mechanical stabilization, 1-inch CMOS sensors, and extreme weatherproofing built to capture dynamic moments anywhere.',
    },
    'professional': {
      title: 'Professional Cinema Systems',
      subtitle: 'Hollywood Heavy-Lift & Dynamic Stabilization',
      heroDesc: 'Integrated 8K full-frame camera systems, centimeter-level RTK repeatability, and multi-user cinema coordination.',
    },
    'enterprise': {
      title: 'Enterprise & Solutions',
      subtitle: 'Industrial Inspection, Public Safety & Surveying',
      heroDesc: 'Ruggedized weather-sealed platforms with thermal, zoom, and laser rangefinder sensors built for critical infrastructure.',
    },
    'accessories': {
      title: 'Genuine Accessories',
      subtitle: 'Intelligent Batteries, ND Filters & DJI Care',
      heroDesc: 'Maximize flight endurance, optical exposure control, and total operational peace of mind.',
    },
  };

  const currentCatInfo = selectedCategory && categoryTitles[selectedCategory]
    ? categoryTitles[selectedCategory]
    : {
        title: 'All DJI Systems',
        subtitle: 'The Complete Flight & Imaging Fleet',
        heroDesc: 'Explore our comprehensive fleet of camera drones, handheld stabilizers, and cinema aerial rigs.',
      };

  // Filter products
  let filtered = PRODUCTS.filter((p) => {
    if (selectedCategory && selectedCategory !== 'accessories' && p.category !== selectedCategory) {
      return false;
    }
    if (weightFilter === 'under-250' && p.weightGrams >= 250) return false;
    if (weightFilter === 'pro' && p.weightGrams < 250) return false;
    return true;
  });

  // Sort products
  if (sortBy === 'price-asc') {
    filtered.sort((a, b) => a.basePrice - b.basePrice);
  } else if (sortBy === 'price-desc') {
    filtered.sort((a, b) => b.basePrice - a.basePrice);
  } else if (sortBy === 'flight-time') {
    filtered.sort((a, b) => b.flightOrBatteryMinutes - a.flightOrBatteryMinutes);
  }

  return (
    <div className="w-full bg-white text-zinc-900 pb-24">
      {/* Category Hero Banner */}
      <div className="bg-zinc-950 text-white py-16 lg:py-24 border-b border-zinc-800">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
          <div className="flex items-center gap-2 mb-3">
            <button
              onClick={() => setActiveView('home')}
              className="text-xs text-zinc-400 hover:text-white flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Storefront</span>
            </button>
            <span className="text-zinc-600">/</span>
            <span className="text-xs text-zinc-300 font-semibold">{currentCatInfo.title}</span>
          </div>

          <span className="text-xs font-bold text-red-500 uppercase tracking-widest block mb-1">
            {currentCatInfo.subtitle}
          </span>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight mb-4 text-white">
            {currentCatInfo.title}
          </h1>
          <p className="text-sm sm:text-base text-zinc-400 max-w-2xl leading-relaxed">
            {currentCatInfo.heroDesc}
          </p>
        </div>
      </div>

      {/* Filter and Sorting Toolbar */}
      <div className="border-b border-zinc-200 bg-[#fafafa]">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12 py-4 flex flex-wrap items-center justify-between gap-4 text-xs">
          {/* Category Switcher Tabs */}
          <div className="flex flex-wrap items-center gap-1.5">
            {[
              { key: null, label: 'All Fleet' },
              { key: 'camera-drones', label: 'Camera Drones' },
              { key: 'handheld', label: 'Handheld & Action' },
              { key: 'professional', label: 'Professional' },
            ].map((tab) => (
              <button
                key={tab.label}
                onClick={() => setSelectedCategory(tab.key)}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                  selectedCategory === tab.key
                    ? 'bg-zinc-900 text-white font-semibold'
                    : 'text-zinc-600 hover:bg-zinc-200/70'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Secondary Filters: Weight & Sort */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1 text-zinc-600">
              <span className="font-medium text-zinc-500">Weight:</span>
              <select
                value={weightFilter}
                onChange={(e) => setWeightFilter(e.target.value as any)}
                className="bg-white border border-zinc-200 rounded p-1.5 text-xs text-zinc-800"
              >
                <option value="all">All Weights</option>
                <option value="under-250">Under 249g (Reg-Free)</option>
                <option value="pro">Heavy-Duty & Cinema (&gt;250g)</option>
              </select>
            </div>

            <div className="flex items-center gap-1 text-zinc-600">
              <span className="font-medium text-zinc-500">Sort by:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-white border border-zinc-200 rounded p-1.5 text-xs text-zinc-800"
              >
                <option value="featured">Featured Order</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="flight-time">Battery / Flight Endurance</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Product Grid */}
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12 py-12">
        <div className="mb-6 flex justify-between items-center text-xs text-zinc-500">
          <span>Showing {filtered.length} products</span>
          <button
            onClick={() => setActiveView('compare')}
            className="text-zinc-800 hover:text-black font-semibold underline flex items-center gap-1"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Compare Selected Models</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filtered.map((product) => {
            const inCompare = isInCompare(product.id);

            return (
              <div
                key={product.id}
                className="group flex flex-col justify-between bg-[#fbfbfb] border border-zinc-200/90 hover:border-zinc-400 rounded-none transition-all duration-300 hover:shadow-lg overflow-hidden"
              >
                {/* Image */}
                <div
                  onClick={() => navigateToProduct(product.id)}
                  className="aspect-[4/3] w-full bg-[#f3f3f5] p-6 relative flex items-center justify-center cursor-pointer overflow-hidden"
                >
                  {product.badge && (
                    <div className="absolute top-4 left-4 z-10">
                      <span className="text-[11px] font-semibold text-zinc-800 bg-white/90 backdrop-blur-sm border border-zinc-200 px-2 py-0.5 rounded">
                        {product.badge}
                      </span>
                    </div>
                  )}

                  <img
                    src={product.images.studio}
                    alt={product.name}
                    referrerPolicy="no-referrer"
                    className="max-h-full w-auto object-contain group-hover:scale-105 transition-transform duration-500"
                  />
                </div>

                {/* Details */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between text-xs text-zinc-500 mb-1">
                      <span className="font-medium text-zinc-700">{product.series}</span>
                      <span className="font-mono">{product.weightGrams}g</span>
                    </div>

                    <h3
                      onClick={() => navigateToProduct(product.id)}
                      className="text-lg font-bold text-zinc-900 group-hover:text-black cursor-pointer mb-1"
                    >
                      {product.name}
                    </h3>

                    <p className="text-xs text-zinc-500 line-clamp-2 leading-relaxed mb-4">
                      {product.description}
                    </p>

                    <div className="grid grid-cols-2 gap-2 py-3 border-y border-zinc-200/80 text-[11px] text-zinc-600 mb-4 font-mono">
                      <div>
                        <span className="text-zinc-400 block text-[10px] uppercase font-sans">
                          {product.category === 'handheld' ? 'Battery Life' : 'Flight Time'}
                        </span>
                        <span className="font-semibold text-zinc-800">
                          {product.flightOrBatteryMinutes} min
                        </span>
                      </div>
                      <div>
                        <span className="text-zinc-400 block text-[10px] uppercase font-sans">Sensor</span>
                        <span className="font-semibold text-zinc-800 truncate block">
                          {product.sensorSize}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-baseline justify-between mb-4">
                      <div>
                        <span className="text-[10px] text-zinc-400 uppercase tracking-wider block font-medium">
                          Starting at
                        </span>
                        <span className="text-xl font-bold font-mono text-zinc-900">
                          {formatPrice(product.basePrice)}
                        </span>
                      </div>

                      <button
                        onClick={() => {
                          if (inCompare) {
                            removeFromCompare(product.id);
                          } else {
                            addToCompare(product.id);
                          }
                        }}
                        className={`text-xs flex items-center gap-1 py-1 px-2 rounded border transition-colors ${
                          inCompare
                            ? 'bg-zinc-900 border-zinc-900 text-white font-medium'
                            : 'bg-white border-zinc-200 text-zinc-600 hover:border-zinc-400'
                        }`}
                      >
                        {inCompare ? <Check className="w-3 h-3" /> : <Plus className="w-3 h-3" />}
                        <span>{inCompare ? 'In Compare' : 'Compare'}</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => navigateToProduct(product.id)}
                        className="w-full py-2.5 px-3 bg-zinc-900 hover:bg-black text-white text-xs font-semibold rounded transition-colors text-center"
                      >
                        Explore Specs
                      </button>
                      <button
                        onClick={() => addToCart(product.id, product.combos[0].id)}
                        className="w-full py-2.5 px-3 bg-white hover:bg-zinc-100 border border-zinc-300 text-zinc-900 text-xs font-medium rounded transition-colors text-center"
                      >
                        Quick Buy
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
