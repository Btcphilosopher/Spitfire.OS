'use client';

import React, { useState } from 'react';
import { PRODUCTS, Product } from '@/data/products';
import { useApp } from '@/context/AppContext';
import { X, Plus, Check, SlidersHorizontal, ArrowRight, HelpCircle } from 'lucide-react';

interface MetricRow {
  key: string;
  label: string;
  category: string;
  explanation: string;
  getValue: (p: Product) => string | number;
}

const COMPARISON_METRICS: MetricRow[] = [
  {
    key: 'price',
    label: 'Starting Price',
    category: 'Commercial',
    explanation: 'Manufacturer suggested base retail price including standard remote controller.',
    getValue: (p) => `$${p.basePrice}`,
  },
  {
    key: 'sensor',
    label: 'Primary Camera Sensor',
    category: 'Imaging',
    explanation: 'Physical surface area of imaging sensor. Larger sensors capture more light and dynamic range.',
    getValue: (p) => p.sensorSize,
  },
  {
    key: 'video',
    label: 'Max Video Capture',
    category: 'Imaging',
    explanation: 'Peak recording resolution and maximum frame rate achievable.',
    getValue: (p) => p.videoResolution,
  },
  {
    key: 'weight',
    label: 'Takeoff Weight',
    category: 'Airframe / Form',
    explanation: 'Total weight with battery installed. Under 249g is exempt from registration in many regions.',
    getValue: (p) => `${p.weightGrams} g`,
  },
  {
    key: 'endurance',
    label: 'Max Flight / Operating Time',
    category: 'Power',
    explanation: 'Measured in continuous windless conditions or continuous 1080p recording.',
    getValue: (p) => `${p.flightOrBatteryMinutes} minutes`,
  },
  {
    key: 'transmission',
    label: 'Video Transmission System',
    category: 'RF & Control',
    explanation: 'Proprietary RF protocol delivering live FHD video feed to controller.',
    getValue: (p) => p.maxTransmissionKm > 0 ? `${p.maxTransmissionKm} km (FCC)` : 'Handheld / Direct Link',
  },
  {
    key: 'experience',
    label: 'Intended Pilot Level',
    category: 'Usability',
    explanation: 'Recommended skill required to safely pilot or operate the instrument.',
    getValue: (p) => p.experienceLevel.charAt(0).toUpperCase() + p.experienceLevel.slice(1),
  },
];

export default function ProductComparison() {
  const {
    comparedProductIds,
    addToCompare,
    removeFromCompare,
    navigateToProduct,
    addToCart,
    formatPrice,
    setActiveView,
  } = useApp();

  const [highlightDifferences, setHighlightDifferences] = useState(false);
  const [activeTooltip, setActiveTooltip] = useState<string | null>(null);

  // Get compared products (fallback to first 2 products if none selected)
  const activeIds = comparedProductIds.length > 0 ? comparedProductIds : ['mavic-3-pro', 'mini-4-pro'];
  const comparedProducts = activeIds
    .map((id) => PRODUCTS.find((p) => p.id === id))
    .filter((p): p is Product => p !== undefined);

  // Available products to add to compare
  const availableToAdd = PRODUCTS.filter((p) => !activeIds.includes(p.id));

  return (
    <div className="w-full bg-white text-zinc-900 py-12 lg:py-20 border-b border-zinc-200">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        {/* Header & Controls */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10 pb-6 border-b border-zinc-200">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs font-bold uppercase tracking-widest text-red-600">
                Evaluation Matrix
              </span>
              <span className="text-zinc-300">·</span>
              <span className="text-xs text-zinc-500">Comparing {comparedProducts.length} models</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-zinc-900">
              Technical Comparison
            </h1>
            <p className="text-xs sm:text-sm text-zinc-500 mt-1 max-w-xl">
              Inspect verified engineering specifications side by side. Toggle difference highlighting to reveal key divergences in optics, endurance, and airframe dynamics.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            {/* Highlight Differences Toggle */}
            <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-zinc-700 bg-zinc-100 hover:bg-zinc-200/80 px-3 py-2 rounded transition-colors select-none">
              <input
                type="checkbox"
                checked={highlightDifferences}
                onChange={(e) => setHighlightDifferences(e.target.checked)}
                className="rounded border-zinc-300 text-zinc-900 focus:ring-zinc-900"
              />
              <span>Highlight Differences Only</span>
            </label>

            {/* Back to Products */}
            <button
              onClick={() => setActiveView('category')}
              className="text-xs font-medium text-zinc-600 hover:text-zinc-900 underline"
            >
              Browse Full Catalog
            </button>
          </div>
        </div>

        {/* Comparison Table */}
        <div className="overflow-x-auto pb-6">
          <table className="w-full min-w-[760px] border-collapse text-left">
            <thead>
              <tr className="border-b border-zinc-300">
                <th className="py-4 pr-6 w-1/4 text-xs font-bold uppercase tracking-wider text-zinc-400 align-top">
                  Specifications
                </th>

                {comparedProducts.map((p) => (
                  <th key={p.id} className="py-4 px-4 w-1/4 align-top">
                    <div className="relative bg-[#f8f8fa] p-4 rounded-lg border border-zinc-200/80 group">
                      {comparedProducts.length > 1 && (
                        <button
                          onClick={() => removeFromCompare(p.id)}
                          className="absolute top-2 right-2 text-zinc-400 hover:text-red-600 p-1 rounded hover:bg-white"
                          title="Remove from comparison"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}

                      <div className="aspect-[4/3] w-full flex items-center justify-center p-2 mb-3 bg-white rounded">
                        <img
                          src={p.images.studio}
                          alt={p.name}
                          referrerPolicy="no-referrer"
                          className="max-h-full object-contain"
                        />
                      </div>

                      <span className="text-[10px] font-bold text-red-600 uppercase tracking-wider block">
                        {p.series}
                      </span>
                      <h3 className="text-base font-bold text-zinc-900 mb-1 leading-snug">
                        {p.name}
                      </h3>
                      <div className="text-sm font-bold font-mono text-zinc-900 mb-3">
                        {formatPrice(p.basePrice)}
                      </div>

                      <div className="space-y-2">
                        <button
                          onClick={() => navigateToProduct(p.id)}
                          className="w-full py-2 bg-zinc-900 hover:bg-black text-white text-xs font-semibold rounded transition-colors"
                        >
                          View Details
                        </button>
                        <button
                          onClick={() => addToCart(p.id, p.combos[0].id)}
                          className="w-full py-1.5 bg-white border border-zinc-200 hover:bg-zinc-100 text-zinc-800 text-xs font-medium rounded transition-colors"
                        >
                          Add to Bag
                        </button>
                      </div>
                    </div>
                  </th>
                ))}

                {/* Empty slot to add 3rd product if under 3 */}
                {comparedProducts.length < 3 && (
                  <th className="py-4 px-4 w-1/4 align-top">
                    <div className="h-full min-h-[300px] border-2 border-dashed border-zinc-200 rounded-lg p-6 flex flex-col items-center justify-center text-center bg-[#fafafa]">
                      <Plus className="w-8 h-8 text-zinc-400 mb-2" />
                      <span className="text-sm font-bold text-zinc-800 mb-1">
                        Add Model to Compare
                      </span>
                      <p className="text-xs text-zinc-500 mb-4 max-w-[180px]">
                        Select another aircraft or handheld camera to evaluate.
                      </p>

                      <select
                        onChange={(e) => {
                          if (e.target.value) {
                            addToCompare(e.target.value);
                            e.target.value = '';
                          }
                        }}
                        defaultValue=""
                        className="text-xs p-2 rounded border border-zinc-300 bg-white text-zinc-800 font-medium w-full max-w-[200px]"
                      >
                        <option value="" disabled>Select a model...</option>
                        {availableToAdd.map((avail) => (
                          <option key={avail.id} value={avail.id}>
                            {avail.name} ({formatPrice(avail.basePrice)})
                          </option>
                        ))}
                      </select>
                    </div>
                  </th>
                )}
              </tr>
            </thead>

            <tbody className="divide-y divide-zinc-200 text-xs">
              {COMPARISON_METRICS.map((metric) => {
                const values = comparedProducts.map((p) => metric.getValue(p));
                const allEqual = values.every((v) => v === values[0]);

                if (highlightDifferences && allEqual) {
                  return null; // hide row when highlight differences is on and values match
                }

                return (
                  <tr
                    key={metric.key}
                    className={`transition-colors hover:bg-zinc-50/70 ${
                      !allEqual ? 'bg-amber-50/20' : ''
                    }`}
                  >
                    <td className="py-4 pr-6 align-top">
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold text-zinc-800 block">
                          {metric.label}
                        </span>
                        <button
                          onClick={() =>
                            setActiveTooltip(activeTooltip === metric.key ? null : metric.key)
                          }
                          className="text-zinc-400 hover:text-zinc-600 focus:outline-none"
                          title={metric.explanation}
                        >
                          <HelpCircle className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <span className="text-[10px] text-zinc-400 uppercase tracking-wider block mt-0.5">
                        {metric.category}
                      </span>
                      {activeTooltip === metric.key && (
                        <p className="mt-1 text-[11px] text-zinc-600 bg-white p-2 rounded border border-zinc-200 shadow-sm animate-in fade-in duration-200">
                          {metric.explanation}
                        </p>
                      )}
                    </td>

                    {comparedProducts.map((p) => {
                      const val = metric.getValue(p);
                      return (
                        <td key={p.id} className="py-4 px-4 align-top font-mono font-medium text-zinc-900">
                          {metric.key === 'price' ? formatPrice(p.basePrice) : val}
                        </td>
                      );
                    })}

                    {comparedProducts.length < 3 && <td className="py-4 px-4" />}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
