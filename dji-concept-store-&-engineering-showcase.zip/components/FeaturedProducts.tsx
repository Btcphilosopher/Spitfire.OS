'use client';

import React, { useState } from 'react';
import { PRODUCTS, Product } from '@/data/products';
import { useApp } from '@/context/AppContext';
import { ArrowRight, Check, SlidersHorizontal, Plus } from 'lucide-react';

export default function FeaturedProducts() {
  const {
    navigateToProduct,
    addToCart,
    addToCompare,
    removeFromCompare,
    isInCompare,
    formatPrice,
    setActiveView,
  } = useApp();

  const [activeFilter, setActiveFilter] = useState<'all' | 'camera-drones' | 'handheld' | 'professional'>('all');

  const filteredProducts = activeFilter === 'all'
    ? PRODUCTS
    : PRODUCTS.filter((p) => p.category === activeFilter);

  return (
    <section className="w-full bg-white text-zinc-900 py-16 lg:py-24 border-b border-zinc-200">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        {/* Section Header & Category Filter Tabs */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-red-600 block mb-2">
              Engineered Fleet
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-zinc-900">
              Featured Systems
            </h2>
            <p className="text-sm text-zinc-500 mt-1 max-w-xl">
              Each system is designed from raw carbon fiber, magnesium alloys, and custom optics to deliver uncompromising precision in the air and on the ground.
            </p>
          </div>

          {/* Interactive Filter Tabs (Valid per frontend-design skill §1.A) */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-zinc-100 rounded-lg self-start md:self-auto">
            {[
              { id: 'all', label: 'All Systems' },
              { id: 'camera-drones', label: 'Camera Drones' },
              { id: 'handheld', label: 'Handheld & Action' },
              { id: 'professional', label: 'Professional Cinema' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveFilter(tab.id as any)}
                className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  activeFilter === tab.id
                    ? 'bg-white text-zinc-900 shadow-sm font-semibold'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* 3-Column Product Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => {
            const inCompare = isInCompare(product.id);

            return (
              <div
                key={product.id}
                className="group flex flex-col justify-between bg-[#fbfbfb] border border-zinc-200/80 hover:border-zinc-400 rounded-none transition-all duration-300 hover:shadow-lg overflow-hidden"
              >
                {/* Image Area */}
                <div
                  onClick={() => navigateToProduct(product.id)}
                  className="aspect-[4/3] w-full bg-[#f3f3f5] p-6 relative flex items-center justify-center cursor-pointer overflow-hidden"
                >
                  {product.badge && (
                    <div className="absolute top-4 left-4 z-10">
                      <span className="text-[11px] font-semibold text-zinc-800 bg-white/90 backdrop-blur-sm border border-zinc-200 px-2 py-0.5 rounded">
                        {product.badge}
                      </span>
                    </div>
                  )}

                  <img
                    src={product.images.studio}
                    alt={product.name}
                    referrerPolicy="no-referrer"
                    className="max-h-full w-auto object-contain group-hover:scale-105 transition-transform duration-500"
                  />
                </div>

                {/* Details Area */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between text-xs text-zinc-500 mb-1">
                      <span className="font-medium text-zinc-700">{product.series}</span>
                      <span className="tabular-nums font-mono">
                        {product.weightGrams > 0 ? `${product.weightGrams}g` : 'Mount'}
                      </span>
                    </div>

                    <h3
                      onClick={() => navigateToProduct(product.id)}
                      className="text-lg font-bold text-zinc-900 group-hover:text-black cursor-pointer mb-1"
                    >
                      {product.name}
                    </h3>

                    <p className="text-xs text-zinc-500 line-clamp-2 leading-relaxed mb-4">
                      {product.description}
                    </p>

                    {/* Key Technical Metric Chips */}
                    <div className="grid grid-cols-2 gap-2 py-3 border-y border-zinc-200/80 text-[11px] text-zinc-600 mb-4 font-mono">
                      <div>
                        <span className="text-zinc-400 block text-[10px] uppercase font-sans">
                          {product.category === 'handheld' ? 'Battery Life' : 'Flight Time'}
                        </span>
                        <span className="font-semibold text-zinc-800">
                          {product.flightOrBatteryMinutes} min
                        </span>
                      </div>
                      <div>
                        <span className="text-zinc-400 block text-[10px] uppercase font-sans">Sensor</span>
                        <span className="font-semibold text-zinc-800 truncate block" title={product.sensorSize}>
                          {product.sensorSize}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Card Bottom Row: Price & Actions */}
                  <div>
                    <div className="flex items-baseline justify-between mb-4">
                      <div>
                        <span className="text-[10px] text-zinc-400 uppercase tracking-wider block font-medium">
                          Starting at
                        </span>
                        <span className="text-xl font-bold font-mono text-zinc-900">
                          {formatPrice(product.basePrice)}
                        </span>
                      </div>

                      {/* Compare toggle */}
                      <button
                        onClick={() => {
                          if (inCompare) {
                            removeFromCompare(product.id);
                          } else {
                            addToCompare(product.id);
                          }
                        }}
                        className={`text-xs flex items-center gap-1 py-1 px-2 rounded border transition-colors ${
                          inCompare
                            ? 'bg-zinc-900 border-zinc-900 text-white font-medium'
                            : 'bg-white border-zinc-200 text-zinc-600 hover:border-zinc-400'
                        }`}
                        title="Add to side-by-side comparison"
                      >
                        {inCompare ? <Check className="w-3 h-3" /> : <Plus className="w-3 h-3" />}
                        <span>{inCompare ? 'In Compare' : 'Compare'}</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => navigateToProduct(product.id)}
                        className="w-full py-2.5 px-3 bg-zinc-900 hover:bg-black text-white text-xs font-semibold rounded transition-colors text-center"
                      >
                        Explore Specs
                      </button>
                      <button
                        onClick={() => addToCart(product.id, product.combos[0].id)}
                        className="w-full py-2.5 px-3 bg-white hover:bg-zinc-100 border border-zinc-300 text-zinc-900 text-xs font-medium rounded transition-colors text-center"
                      >
                        Quick Buy
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Comparison Bottom Banner if items selected */}
        <div className="mt-12 p-6 bg-zinc-900 text-white rounded-lg flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <SlidersHorizontal className="w-5 h-5 text-red-500" />
            <div>
              <h4 className="text-sm font-bold">Side-by-Side Product Comparison</h4>
              <p className="text-xs text-zinc-400">
                Directly compare technical metrics, transmission ranges, sensors, and flight times between DJI models.
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              setActiveView('compare');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="px-5 py-2.5 bg-white text-black font-semibold text-xs rounded hover:bg-zinc-200 transition-colors whitespace-nowrap flex items-center gap-2"
          >
            <span>Launch Comparison Matrix</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </section>
  );
}
