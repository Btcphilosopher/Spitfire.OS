'use client';

import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import { Search, ShoppingBag, User, Menu, X, ChevronRight, Globe, Compass, ArrowRight } from 'lucide-react';

interface MegaMenuCategory {
  title: string;
  categoryKey: string;
  featured: { name: string; tag: string; id: string; image: string }[];
  series: { label: string; id: string }[];
}

const MEGA_MENU_DATA: Record<string, MegaMenuCategory> = {
  'Camera Drones': {
    title: 'Camera Drones',
    categoryKey: 'camera-drones',
    featured: [
      { name: 'DJI Mavic 3 Pro', tag: 'Flagship Tri-Camera Cinema', id: 'mavic-3-pro', image: '/assets/images/card_camera_drones.png' },
      { name: 'DJI Mini 4 Pro', tag: 'Under 249g Regulation-Free', id: 'mini-4-pro', image: '/assets/images/product_mini4pro_drone_1794403420986.jpg' },
      { name: 'DJI Avata 2', tag: 'FPV Thrills with Motion 3', id: 'avata-2', image: '/assets/images/product_avata2_fpv_1794403422043.jpg' },
    ],
    series: [
      { label: 'Mavic Series (Pro Aerial Cinema)', id: 'mavic-3-pro' },
      { label: 'Mini Series (Sub-249g Travel)', id: 'mini-4-pro' },
      { label: 'Avata Series (First-Person View)', id: 'avata-2' },
      { label: 'Air Series (All-Around Creators)', id: 'mavic-3-pro' },
    ],
  },
  'Handheld': {
    title: 'Handheld & Action',
    categoryKey: 'handheld',
    featured: [
      { name: 'DJI Osmo Pocket 3', tag: '1-Inch CMOS Pocket Gimbal', id: 'osmo-pocket-3', image: '/assets/images/card_handheld.png' },
      { name: 'DJI Osmo Action 5 Pro', tag: '13.5 Stops Dynamic Range', id: 'osmo-action-5-pro', image: '/assets/images/card_handheld.png' },
    ],
    series: [
      { label: 'Osmo Pocket Series (Vlogging)', id: 'osmo-pocket-3' },
      { label: 'Osmo Action Series (Adventure)', id: 'osmo-action-5-pro' },
      { label: 'DJI Mic Series (Wireless Audio)', id: 'osmo-pocket-3' },
    ],
  },
  'Professional': {
    title: 'Professional Filmmaking',
    categoryKey: 'professional',
    featured: [
      { name: 'DJI Inspire 3', tag: 'Full-Frame 8K Cinema Aerial', id: 'inspire-3', image: '/assets/images/card_professional.png' },
    ],
    series: [
      { label: 'Inspire Aerial Cinema Systems', id: 'inspire-3' },
      { label: 'Ronin Camera Gimbals & Focus', id: 'inspire-3' },
      { label: 'Transmission & Pro Monitors', id: 'inspire-3' },
    ],
  },
  'Enterprise': {
    title: 'Enterprise & Solutions',
    categoryKey: 'enterprise',
    featured: [
      { name: 'Matrice 350 RTK', tag: 'Commercial Industrial Platform', id: 'inspire-3', image: '/assets/images/card_professional.png' },
    ],
    series: [
      { label: 'Public Safety & First Response', id: 'inspire-3' },
      { label: 'Surveying & Aerial Mapping', id: 'inspire-3' },
      { label: 'Infrastructure & Inspection', id: 'inspire-3' },
    ],
  },
};

export default function Header() {
  const {
    activeView,
    setActiveView,
    navigateToCategory,
    navigateToProduct,
    cartCount,
    setIsCartOpen,
    setIsSearchOpen,
    currency,
    setCurrency,
    region,
    setRegion,
  } = useApp();

  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [regionModalOpen, setRegionModalOpen] = useState(false);
  const [userModalOpen, setUserModalOpen] = useState(false);
  const menuTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const navLinks = ['Camera Drones', 'Handheld', 'Professional', 'Enterprise', 'Support'];

  const handleMouseEnter = (link: string) => {
    if (menuTimeoutRef.current) clearTimeout(menuTimeoutRef.current);
    if (MEGA_MENU_DATA[link]) {
      setActiveMenu(link);
    } else {
      setActiveMenu(null);
    }
  };

  const handleMouseLeave = () => {
    menuTimeoutRef.current = setTimeout(() => {
      setActiveMenu(null);
    }, 180);
  };

  const handleNavClick = (link: string) => {
    if (link === 'Support') {
      setActiveView('support');
      setActiveMenu(null);
      setMobileMenuOpen(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    const menuData = MEGA_MENU_DATA[link];
    if (menuData) {
      navigateToCategory(menuData.categoryKey);
      setActiveMenu(null);
      setMobileMenuOpen(false);
    }
  };

  return (
    <>
      <header
        className="sticky top-0 z-40 w-full bg-black/95 backdrop-blur-md border-b border-zinc-800 text-white transition-colors duration-200"
        onMouseLeave={handleMouseLeave}
      >
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: DJI Wordmark Brand */}
          <div className="flex items-center gap-6 shrink-0">
            <button
              onClick={() => {
                setActiveView('home');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="flex items-center gap-2 group focus:outline-none focus-visible:ring-2 focus-visible:ring-white rounded py-1"
              aria-label="DJI Homepage"
            >
              {/* Authentic DJI Logo SVG */}
              <svg
                className="h-6 w-auto fill-current text-white group-hover:text-zinc-200 transition-colors"
                viewBox="0 0 100 32"
                aria-hidden="true"
              >
                {/* Clean stylized DJI logomark */}
                <path d="M7 6h11c6 0 11 4.5 11 10s-5 10-11 10H7V6zm7.2 15.5h3.6c3.4 0 5.6-2.2 5.6-5.5s-2.2-5.5-5.6-5.5h-3.6v11zM36 6h7.2v14.5c0 3.5-2.2 5.5-5.6 5.5h-5.2v-4.5h3.6c1.1 0 1.8-.6 1.8-1.5V6zm23.8 0H67v20h-7.2V6z" />
                <path d="M76 6h7.2v20H76V6z" />
              </svg>
            </button>
          </div>

          {/* Zone 2: Navigation Links (Single-Line, accessible, with Mega Menu) */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-zinc-300">
            {navLinks.map((link) => (
              <button
                key={link}
                onMouseEnter={() => handleMouseEnter(link)}
                onClick={() => handleNavClick(link)}
                className={`transition-colors whitespace-nowrap py-5 relative ${
                  activeMenu === link || (link === 'Support' && activeView === 'support')
                    ? 'text-white'
                    : 'text-zinc-300 hover:text-white'
                }`}
              >
                {link}
                {activeMenu === link && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-white transition-all" />
                )}
              </button>
            ))}
          </nav>

          {/* Zone 3: Actions (Explore, Search, Account, Shopping Bag) */}
          <div className="flex items-center gap-4 shrink-0">
            {/* "Explore" pill matching mockup */}
            <button
              onClick={() => {
                setActiveView('selector');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="hidden sm:inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-white border border-zinc-700 hover:border-zinc-500 hover:bg-zinc-900 rounded-full transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
            >
              <Compass className="w-3.5 h-3.5 text-zinc-300" />
              <span>Explore</span>
            </button>

            {/* Product Search */}
            <button
              onClick={() => setIsSearchOpen(true)}
              className="p-2 text-zinc-300 hover:text-white rounded-full hover:bg-zinc-900 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
              aria-label="Search DJI products (⌘K)"
              title="Search products"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Region / Currency selector trigger */}
            <button
              onClick={() => setRegionModalOpen(true)}
              className="hidden lg:flex items-center gap-1 px-2 py-1 text-xs text-zinc-400 hover:text-white rounded transition-colors"
              title="Change region and currency"
            >
              <Globe className="w-3.5 h-3.5" />
              <span className="font-mono">{currency}</span>
            </button>

            {/* User Profile */}
            <button
              onClick={() => setUserModalOpen(true)}
              className="p-2 text-zinc-300 hover:text-white rounded-full hover:bg-zinc-900 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
              aria-label="DJI Account & Orders"
              title="Account"
            >
              <User className="w-5 h-5" />
            </button>

            {/* Cart Bag with badge */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="p-2 text-zinc-300 hover:text-white rounded-full hover:bg-zinc-900 transition-colors relative focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
              aria-label={`Shopping Cart (${cartCount} items)`}
              title="View Cart"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-red-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-in zoom-in-50 duration-200">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Mobile menu hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-zinc-300 hover:text-white rounded focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Accessible Mega Menu Dropdown */}
        {activeMenu && MEGA_MENU_DATA[activeMenu] && (
          <div
            className="absolute top-16 left-0 w-full bg-zinc-950/98 border-b border-zinc-800 shadow-2xl transition-all duration-200 animate-in fade-in slide-in-from-top-2 z-50 text-white"
            onMouseEnter={() => {
              if (menuTimeoutRef.current) clearTimeout(menuTimeoutRef.current);
            }}
            onMouseLeave={handleMouseLeave}
          >
            <div className="max-w-[1440px] mx-auto px-6 lg:px-12 py-8 grid grid-cols-12 gap-8">
              {/* Category Overview & Series Links */}
              <div className="col-span-4 border-r border-zinc-800 pr-8">
                <h3 className="text-xs uppercase tracking-widest text-zinc-400 font-semibold mb-4">
                  {MEGA_MENU_DATA[activeMenu].title}
                </h3>
                <ul className="space-y-3">
                  {MEGA_MENU_DATA[activeMenu].series.map((s, idx) => (
                    <li key={idx}>
                      <button
                        onClick={() => {
                          navigateToProduct(s.id);
                          setActiveMenu(null);
                        }}
                        className="text-sm text-zinc-300 hover:text-white hover:translate-x-1 transition-all flex items-center justify-between w-full py-1 text-left"
                      >
                        <span>{s.label}</span>
                        <ChevronRight className="w-3.5 h-3.5 text-zinc-500" />
                      </button>
                    </li>
                  ))}
                </ul>

                <div className="mt-8 pt-6 border-t border-zinc-800 flex items-center gap-4">
                  <button
                    onClick={() => {
                      navigateToCategory(MEGA_MENU_DATA[activeMenu].categoryKey);
                      setActiveMenu(null);
                    }}
                    className="text-xs font-semibold text-zinc-200 hover:text-white flex items-center gap-1 group"
                  >
                    <span>View all {MEGA_MENU_DATA[activeMenu].title}</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </button>
                  <span className="text-zinc-600">·</span>
                  <button
                    onClick={() => {
                      setActiveView('compare');
                      setActiveMenu(null);
                    }}
                    className="text-xs text-zinc-400 hover:text-white"
                  >
                    Compare Models
                  </button>
                </div>
              </div>

              {/* Featured Showcase Products */}
              <div className="col-span-8 grid grid-cols-3 gap-6">
                {MEGA_MENU_DATA[activeMenu].featured.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => {
                      navigateToProduct(item.id);
                      setActiveMenu(null);
                    }}
                    className="group cursor-pointer rounded-lg bg-zinc-900/60 p-4 border border-zinc-800/80 hover:border-zinc-700 transition-all hover:bg-zinc-900"
                  >
                    <div className="aspect-[4/3] w-full rounded bg-zinc-800/60 overflow-hidden mb-3 relative flex items-center justify-center p-2">
                      <img
                        src={item.image}
                        alt={item.name}
                        referrerPolicy="no-referrer"
                        className="object-contain max-h-full w-auto group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <span className="text-xs text-red-500 font-medium block mb-1">
                      {item.tag}
                    </span>
                    <h4 className="text-sm font-semibold text-white group-hover:text-zinc-200">
                      {item.name}
                    </h4>
                    <span className="text-xs text-zinc-400 mt-1 inline-flex items-center gap-1 group-hover:text-white">
                      Explore specs <ChevronRight className="w-3 h-3" />
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 top-16 z-50 bg-black/95 text-white p-6 overflow-y-auto md:hidden animate-in fade-in duration-200">
          <div className="flex flex-col space-y-6">
            <div className="space-y-4">
              <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
                Explore Products
              </span>
              {navLinks.map((link) => (
                <button
                  key={link}
                  onClick={() => handleNavClick(link)}
                  className="block text-lg font-medium text-left w-full py-2 border-b border-zinc-800 hover:text-zinc-300"
                >
                  {link}
                </button>
              ))}
            </div>

            <div className="pt-4 border-t border-zinc-800 space-y-3">
              <button
                onClick={() => {
                  setActiveView('selector');
                  setMobileMenuOpen(false);
                }}
                className="w-full py-3 px-4 bg-white text-black font-semibold rounded-lg flex items-center justify-center gap-2"
              >
                <Compass className="w-4 h-4" />
                Find Your DJI (Guided Selector)
              </button>

              <button
                onClick={() => {
                  setActiveView('compare');
                  setMobileMenuOpen(false);
                }}
                className="w-full py-3 px-4 bg-zinc-900 border border-zinc-800 text-white font-medium rounded-lg flex items-center justify-center gap-2"
              >
                Compare Products
              </button>
            </div>

            <div className="pt-4 border-t border-zinc-800 flex items-center justify-between text-xs text-zinc-400">
              <span>Region: {region} ({currency})</span>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  setRegionModalOpen(true);
                }}
                className="underline text-white"
              >
                Change
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Region & Currency Modal */}
      {regionModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl max-w-md w-full p-6 text-white shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold">Select Region & Currency</h3>
              <button
                onClick={() => setRegionModalOpen(false)}
                className="text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-zinc-400 mb-6">
              Prices, shipping schedules, and availability update automatically based on your location.
            </p>

            <div className="space-y-3">
              {[
                { r: 'US', name: 'United States', c: 'USD', symbol: '$' },
                { r: 'EU', name: 'European Union (Germany/France/etc.)', c: 'EUR', symbol: '€' },
                { r: 'UK', name: 'United Kingdom', c: 'GBP', symbol: '£' },
                { r: 'CA', name: 'Canada', c: 'CAD', symbol: 'CA$' },
                { r: 'JP', name: 'Japan', c: 'JPY', symbol: '¥' },
              ].map((item) => (
                <button
                  key={item.r}
                  onClick={() => {
                    setRegion(item.r as any);
                    setCurrency(item.c as any);
                    localStorage.setItem('dji_currency', item.c);
                    setRegionModalOpen(false);
                  }}
                  className={`w-full p-3 rounded-lg border flex items-center justify-between text-sm transition-all ${
                    region === item.r
                      ? 'border-white bg-zinc-800 text-white font-semibold'
                      : 'border-zinc-800 bg-zinc-900/50 text-zinc-300 hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-300">
                      {item.r}
                    </span>
                    <span>{item.name}</span>
                  </div>
                  <span className="font-mono text-zinc-400">{item.c} ({item.symbol})</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Account Demo Modal */}
      {userModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl max-w-sm w-full p-6 text-white shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold">DJI Creator Account</h3>
              <button
                onClick={() => setUserModalOpen(false)}
                className="text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 bg-zinc-800/50 rounded-lg mb-4 text-xs text-zinc-300">
              <p className="font-semibold text-white mb-1">Concept Mode Enabled</p>
              <p>
                In this concept preview, purchases and account orders are simulated client-side. Your shopping bag and preferences persist in local storage.
              </p>
            </div>
            <div className="space-y-2 text-xs">
              <button
                onClick={() => {
                  setUserModalOpen(false);
                  setActiveView('support');
                }}
                className="w-full py-2.5 px-3 bg-zinc-800 hover:bg-zinc-700 rounded text-left flex items-center justify-between"
              >
                <span>DJI Care Refresh Status</span>
                <ChevronRight className="w-4 h-4 text-zinc-500" />
              </button>
              <button
                onClick={() => {
                  setUserModalOpen(false);
                  setActiveView('compare');
                }}
                className="w-full py-2.5 px-3 bg-zinc-800 hover:bg-zinc-700 rounded text-left flex items-center justify-between"
              >
                <span>Saved Product Comparisons</span>
                <ChevronRight className="w-4 h-4 text-zinc-500" />
              </button>
            </div>
            <button
              onClick={() => setUserModalOpen(false)}
              className="mt-6 w-full py-2 bg-white text-black font-semibold rounded text-xs"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
}
