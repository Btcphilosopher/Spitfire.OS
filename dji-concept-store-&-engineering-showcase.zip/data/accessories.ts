export interface Accessory {
  id: string;
  name: string;
  category: 'power' | 'protection' | 'optics' | 'mount' | 'care';
  price: number; // in USD
  description: string;
  image: string;
  compatibleProductIds: string[];
  isEssential?: boolean;
}

export const ACCESSORIES: Accessory[] = [
  {
    id: 'care-refresh-mavic3',
    name: 'DJI Care Refresh 1-Year (Mavic 3 Pro)',
    category: 'care',
    price: 239,
    description: 'Comprehensive accident protection covering flyaway, water damage, and collisions with up to 2 low-cost replacements per year.',
    image: '/assets/images/product_accessories_kit_1794403422664.jpg',
    compatibleProductIds: ['mavic-3-pro'],
    isEssential: true,
  },
  {
    id: 'battery-mavic3',
    name: 'Mavic 3 Series Intelligent Flight Battery',
    category: 'power',
    price: 209,
    description: '5000 mAh capacity offering up to 43 minutes of flight time, with real-time battery status monitoring via DJI Fly.',
    image: '/assets/images/product_accessories_kit_1794403422664.jpg',
    compatibleProductIds: ['mavic-3-pro'],
    isEssential: true,
  },
  {
    id: 'nd-filters-mavic3',
    name: 'Mavic 3 Pro ND Filters Set (ND8/16/32/64)',
    category: 'optics',
    price: 179,
    description: 'Precision machined optical glass with dual-sided multi-coating to reduce light transmission by 3 to 6 stops for cinematic shutter angles.',
    image: '/assets/images/product_accessories_kit_1794403422664.jpg',
    compatibleProductIds: ['mavic-3-pro'],
    isEssential: true,
  },
  {
    id: 'charging-hub-mavic3',
    name: 'Mavic 3 100W Two-Way Charging Hub',
    category: 'power',
    price: 99,
    description: 'Charges up to three batteries in sequence according to remaining power level, significantly speeding turnaround time.',
    image: '/assets/images/product_accessories_kit_1794403422664.jpg',
    compatibleProductIds: ['mavic-3-pro'],
  },
  {
    id: 'care-refresh-mini4',
    name: 'DJI Care Refresh 1-Year (Mini 4 Pro)',
    category: 'care',
    price: 79,
    description: 'Full accidental damage coverage including water damage, collision, and flyaway coverage with VIP technical support.',
    image: '/assets/images/product_accessories_kit_1794403422664.jpg',
    compatibleProductIds: ['mini-4-pro'],
    isEssential: true,
  },
  {
    id: 'battery-mini4-plus',
    name: 'Mini 4 Pro Intelligent Flight Battery Plus',
    category: 'power',
    price: 95,
    description: 'High-density 3850 mAh battery boosting max flight time to 45 minutes for extended shooting sessions.',
    image: '/assets/images/product_accessories_kit_1794403422664.jpg',
    compatibleProductIds: ['mini-4-pro'],
    isEssential: true,
  },
  {
    id: 'nd-filters-mini4',
    name: 'Mini 4 Pro ND Filters Set (ND16/64/256)',
    category: 'optics',
    price: 55,
    description: 'Ultralight optical glass designed to not exceed the sub-249g gimbal motor weight balance thresholds.',
    image: '/assets/images/product_accessories_kit_1794403422664.jpg',
    compatibleProductIds: ['mini-4-pro'],
  },
  {
    id: 'prop-guard-mini4',
    name: 'Mini 4 Pro 360° Propeller Guard',
    category: 'protection',
    price: 39,
    description: 'Full 360-degree cage that prevents propellers from contacting obstacles during indoor or tight-space flight.',
    image: '/assets/images/product_accessories_kit_1794403422664.jpg',
    compatibleProductIds: ['mini-4-pro'],
  },
  {
    id: 'care-refresh-pocket3',
    name: 'DJI Care Refresh 1-Year (Osmo Pocket 3)',
    category: 'care',
    price: 35,
    description: 'Peace of mind protection against drops, lens scratches, water splashes, and mechanical wear.',
    image: '/assets/images/product_accessories_kit_1794403422664.jpg',
    compatibleProductIds: ['osmo-pocket-3'],
    isEssential: true,
  },
  {
    id: 'battery-handle-pocket3',
    name: 'Osmo Pocket 3 Battery Handle',
    category: 'power',
    price: 69,
    description: 'Increases operating time by approximately 62% and supports connection to external audio headphones and microphones.',
    image: '/assets/images/product_accessories_kit_1794403422664.jpg',
    compatibleProductIds: ['osmo-pocket-3'],
  },
  {
    id: 'care-refresh-avata2',
    name: 'DJI Care Refresh 1-Year (Avata 2)',
    category: 'care',
    price: 59,
    description: 'Essential FPV protection for high-speed freestyle crashes, flyaways, and water accidents.',
    image: '/assets/images/product_accessories_kit_1794403422664.jpg',
    compatibleProductIds: ['avata-2'],
    isEssential: true,
  },
];
