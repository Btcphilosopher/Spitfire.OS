export interface Story {
  id: string;
  title: string;
  creator: string;
  role: string;
  location: string;
  quote: string;
  synopsis: string;
  gearUsed: string[];
  image: string;
  videoDuration: string;
}

export const STORIES: Story[] = [
  {
    id: 'arctic-frontiers',
    title: 'Echoes of the North: Capturing Iceland’s Volcanic Coastline',
    creator: 'Henrik Lindqvist',
    role: 'Commercial Aerial Director',
    location: 'Vík í Mýrdal, Iceland',
    quote: 'The 70mm medium telephoto on the Mavic 3 Pro compresses the massive basalt columns against the North Atlantic swell in a way no wide angle ever could.',
    synopsis: 'Facing 40-knot coastal wind gusts and sub-zero drizzle, Lindqvist and his three-person crew mapped the sea arches of Dyrhólaey, putting the 4/3 Hasselblad sensor through severe high-contrast mist conditions.',
    gearUsed: ['DJI Mavic 3 Pro Cine', 'DJI Inspire 3', 'ND16 & ND64 Filters'],
    image: '/assets/images/story_cinematographer_iceland_1794403423081.jpg',
    videoDuration: '3m 42s',
  },
  {
    id: 'alpine-ridgeline',
    title: 'Vertical Limits: Chasing Downhill Gravity in the Dolomites',
    creator: 'Elena Rossi',
    role: 'Action Sports Cinematographer',
    location: 'Val Gardena, Italy',
    quote: 'With Avata 2, I can thread the needle between razor-sharp pine trees at 60 km/h while maintaining complete horizon level lock.',
    synopsis: 'Following World Cup downhill mountain bike athletes descending 1,200 meters of vertical scree, Rossi tested the limits of high-speed FPV tracking in extreme dynamic lighting.',
    gearUsed: ['DJI Avata 2', 'DJI Goggles 3', 'Osmo Action 5 Pro'],
    image: '/assets/images/product_avata2_fpv_1794403422043.jpg',
    videoDuration: '2m 18s',
  },
  {
    id: 'tokyo-luminescence',
    title: 'Neon Drift: 24 Hours in Shinjuku After Hours',
    creator: 'Kenji Sato',
    role: 'Documentary Visualist',
    location: 'Tokyo, Japan',
    quote: 'The 1-inch sensor in the Osmo Pocket 3 captures the subtle chromatic gradient between red sodium lamps and wet asphalt without clipping shadows.',
    synopsis: 'A candid visual study through Tokyo’s narrow culinary alleys and subterranean train stations, moving seamlessly between discrete handheld shots and stabilized tracking sequences.',
    gearUsed: ['DJI Osmo Pocket 3', 'DJI Mic 2 Wireless', 'Black Mist Filter'],
    image: '/assets/images/card_handheld.png',
    videoDuration: '4m 05s',
  },
];
