export interface ProductCombo {
  id: string;
  name: string;
  priceDelta: number;
  description: string;
  includes: string[];
}

export interface ProductSpec {
  category: string;
  items: { label: string; value: string; plainExplanation?: string }[];
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  series: 'Mavic' | 'Mini' | 'Air' | 'Inspire' | 'Osmo Pocket' | 'Osmo Action' | 'Ronin' | 'Avata';
  category: 'camera-drones' | 'handheld' | 'professional' | 'enterprise';
  tagline: string;
  description: string;
  basePrice: number; // in USD
  rating: number;
  reviewCount: number;
  badge?: string;
  images: {
    hero: string;
    studio: string;
    folded?: string;
    details: string[];
  };
  keyHighlights: {
    stat: string;
    label: string;
    description: string;
  }[];
  combos: ProductCombo[];
  boxItems: {
    name: string;
    quantity: number;
    icon?: string;
  }[];
  specs: ProductSpec[];
  compatibleAccessoryIds: string[];
  recommendedUse: ('travel' | 'cinema' | 'social-vlogging' | 'action-sports' | 'commercial-inspection')[];
  experienceLevel: 'beginner' | 'enthusiast' | 'professional';
  weightGrams: number;
  flightOrBatteryMinutes: number;
  videoResolution: string;
  maxTransmissionKm: number;
  sensorSize: string;
}

export const PRODUCTS: Product[] = [
  {
    id: 'mavic-3-pro',
    slug: 'mavic-3-pro',
    name: 'DJI Mavic 3 Pro',
    series: 'Mavic',
    category: 'camera-drones',
    tagline: 'Inspiration in Focus. Flagship Tri-Camera Cinema Drone.',
    description: 'Featuring a 4/3 CMOS Hasselblad camera and dual tele cameras, Mavic 3 Pro unlocks multi-focal aerial cinematography with unprecedented optical depth and color fidelity.',
    basePrice: 2199,
    rating: 4.9,
    reviewCount: 348,
    badge: 'Flagship Tri-Camera',
    images: {
      hero: '/assets/images/mockup_hero_slice.png',
      studio: '/assets/images/card_camera_drones.png',
      folded: '/assets/images/card_camera_drones.png',
      details: [
        '/assets/images/card_camera_drones.png',
        '/assets/images/product_accessories_kit_1794403422664.jpg',
        '/assets/images/story_cinematographer_iceland_1794403423081.jpg',
      ],
    },
    keyHighlights: [
      { stat: '4/3 CMOS', label: 'Hasselblad Camera', description: '20MP effective pixels, f/2.8-f/11 adjustable aperture, 12.8 stops dynamic range.' },
      { stat: '3 Lenses', label: 'Tri-Camera System', description: '24mm Hasselblad + 70mm medium tele + 166mm telephoto with 28x hybrid zoom.' },
      { stat: '43 Min', label: 'Max Flight Time', description: 'Extended endurance allowing route exploration, composition, and return-to-home.' },
      { stat: '15 km', label: 'O3+ HD Video', description: 'Stable 1080p/60fps live feed transmission with robust anti-interference.' },
    ],
    combos: [
      {
        id: 'standard-rc',
        name: 'DJI RC (Screen Included)',
        priceDelta: 0,
        description: 'Includes the lightweight DJI RC controller with built-in 5.5-inch FHD screen.',
        includes: ['DJI Mavic 3 Pro Aircraft', 'DJI RC Remote Controller', '1x Intelligent Flight Battery', '3x Low-Noise Propellers (pair)', 'Gimbal Protector', '65W Portable Charger'],
      },
      {
        id: 'fly-more-combo',
        name: 'Fly More Combo (DJI RC)',
        priceDelta: 800,
        description: 'Complete flight kit with 3 total batteries, 100W battery charging hub, ND filter set, and leather shoulder bag.',
        includes: ['DJI Mavic 3 Pro Aircraft', 'DJI RC Remote Controller', '3x Intelligent Flight Batteries', '6x Low-Noise Propellers (pair)', '100W Battery Charging Hub', 'ND Filters Set (ND8/16/32/64)', 'Shoulder Bag'],
      },
      {
        id: 'cine-premium-combo',
        name: 'Cine Premium Combo (DJI RC Pro)',
        priceDelta: 2600,
        description: 'Apple ProRes 422 HQ support on all 3 cameras, built-in 1TB SSD, and ultra-bright DJI RC Pro controller (1,000 nits).',
        includes: ['DJI Mavic 3 Pro Cine Aircraft', 'DJI RC Pro Enterprise Remote', '3x Intelligent Flight Batteries', 'Built-in 1TB SSD & 10Gbps Lightspeed Cable', 'ND Filters Set (ND8/16/32/64)', '100W Hub & Convertible Bag'],
      },
    ],
    boxItems: [
      { name: 'DJI Mavic 3 Pro Aircraft', quantity: 1 },
      { name: 'DJI Remote Controller', quantity: 1 },
      { name: 'Intelligent Flight Battery', quantity: 1 },
      { name: 'DJI 65W Portable Charger', quantity: 1 },
      { name: 'Low-Noise Propellers (Pair)', quantity: 3 },
      { name: 'Storage Cover & Gimbal Protector', quantity: 1 },
      { name: 'Type-C to Type-C Cable', quantity: 1 },
    ],
    specs: [
      {
        category: 'Optics & Gimbal',
        items: [
          { label: 'Hasselblad Camera', value: '4/3 CMOS, 20 MP, 24mm equivalent, f/2.8-f/11', plainExplanation: 'Large physical sensor for cinematic low-light capture and high dynamic range.' },
          { label: 'Medium Tele Camera', value: '1/1.3-inch CMOS, 48 MP, 70mm equivalent, f/2.8', plainExplanation: 'Compresses spatial perspective ideal for architectural and portrait shots.' },
          { label: 'Telephoto Camera', value: '1/2-inch CMOS, 12 MP, 166mm equivalent, f/3.4', plainExplanation: 'Enables safe long-range scouting without disturbing wildlife or subjects.' },
          { label: 'Video Resolution', value: 'Apple ProRes 422 HQ / D-Log 5.1K up to 50fps, 4K up to 120fps' },
          { label: 'Color Profiles', value: 'Hasselblad Natural Colour Solution (HNCS), 10-bit D-Log, 10-bit HLG' },
        ],
      },
      {
        category: 'Flight Performance',
        items: [
          { label: 'Takeoff Weight', value: '958 g', plainExplanation: 'FAA Part 107 registration required for commercial work.' },
          { label: 'Max Flight Time', value: '43 minutes (measured in windless conditions at 32.4 km/h)' },
          { label: 'Max Horizontal Speed', value: '21 m/s (approx. 75.6 km/h) in Sport mode' },
          { label: 'Wind Resistance', value: '12 m/s (Scale 6 wind resistance)' },
          { label: 'Operating Temperature', value: '-10°C to 40°C (14°F to 104°F)' },
        ],
      },
      {
        category: 'Safety & Transmission',
        items: [
          { label: 'Obstacle Sensing', value: 'Omnidirectional Vision Sensing with APAS 5.0' },
          { label: 'Transmission System', value: 'DJI O3+ with dual-frequency auto switching' },
          { label: 'Max Range (FCC)', value: '15 km (Unobstructed, free of interference)' },
          { label: 'Live View Quality', value: '1080p @ 60fps low-latency video feed' },
        ],
      },
    ],
    compatibleAccessoryIds: ['care-refresh-mavic3', 'battery-mavic3', 'nd-filters-mavic3', 'charging-hub-mavic3'],
    recommendedUse: ['cinema', 'travel'],
    experienceLevel: 'enthusiast',
    weightGrams: 958,
    flightOrBatteryMinutes: 43,
    videoResolution: '5.1K / 50fps & 4K / 120fps',
    maxTransmissionKm: 15,
    sensorSize: '4/3 CMOS + 1/1.3" + 1/2"',
  },
  {
    id: 'mini-4-pro',
    slug: 'mini-4-pro',
    name: 'DJI Mini 4 Pro',
    series: 'Mini',
    category: 'camera-drones',
    tagline: 'Mini to the Max. Regulation-Friendly Under 249g Mastery.',
    description: 'The most capable sub-249g drone in history. Omnidirectional active obstacle sensing, 4K/60fps HDR True Vertical Shooting, and next-gen O4 transmission in a pocketable chassis.',
    basePrice: 759,
    rating: 4.8,
    reviewCount: 512,
    badge: 'Under 249g Reg-Free',
    images: {
      hero: '/assets/images/product_mini4pro_drone_1794403420986.jpg',
      studio: '/assets/images/product_mini4pro_drone_1794403420986.jpg',
      folded: '/assets/images/product_mini4pro_drone_1794403420986.jpg',
      details: [
        '/assets/images/product_mini4pro_drone_1794403420986.jpg',
        '/assets/images/product_accessories_kit_1794403422664.jpg',
      ],
    },
    keyHighlights: [
      { stat: '<249 g', label: 'Ultra-Lightweight', description: 'No FAA registration or pilot licensing required in most countries and regions for recreational flight.' },
      { stat: '4K/60fps', label: 'HDR True Vertical', description: 'Gimbal physically rotates 90 degrees for lossless vertical video ready for mobile display.' },
      { stat: '360°', label: 'Omnidirectional Sensing', description: 'Advanced front, rear, downward, and lateral fisheye vision sensors with APAS safety braking.' },
      { stat: '20 km', label: 'DJI O4 Transmission', description: 'FHD live streaming with ultra-low latency and enhanced anti-interference.' },
    ],
    combos: [
      {
        id: 'standard-n2',
        name: 'DJI RC-N2 (Smartphone Holder)',
        priceDelta: 0,
        description: 'Connects to your iOS or Android smartphone to display flight telemetry and camera feed.',
        includes: ['DJI Mini 4 Pro Aircraft', 'DJI RC-N2 Remote Controller', '1x Intelligent Flight Battery', '1x Spare Propellers (pair)', 'Gimbal Protector', 'USB-C Cable'],
      },
      {
        id: 'rc2-screen-combo',
        name: 'DJI RC 2 (Built-in Screen)',
        priceDelta: 200,
        description: 'Includes DJI RC 2 controller with 700-nit 5.5-inch FHD screen. No phone tethering needed.',
        includes: ['DJI Mini 4 Pro Aircraft', 'DJI RC 2 Remote Controller', '1x Intelligent Flight Battery', '1x Spare Propellers (pair)', 'Gimbal Protector', 'Type-C PD Cable'],
      },
      {
        id: 'fly-more-plus',
        name: 'Fly More Combo Plus (DJI RC 2)',
        priceDelta: 400,
        description: '3 Intelligent Flight Batteries Plus (up to 45 min each), two-way charging hub, and shoulder bag.',
        includes: ['DJI Mini 4 Pro Aircraft', 'DJI RC 2 Remote Controller', '3x Intelligent Flight Batteries Plus', '3x Spare Propellers (pair)', 'Two-Way Charging Hub', 'Shoulder Bag'],
      },
    ],
    boxItems: [
      { name: 'DJI Mini 4 Pro Drone', quantity: 1 },
      { name: 'Remote Controller', quantity: 1 },
      { name: 'Intelligent Flight Battery', quantity: 1 },
      { name: 'Spare Propellers (Pair)', quantity: 1 },
      { name: 'Screws & Screwdriver', quantity: 1 },
      { name: 'Gimbal Protector', quantity: 1 },
    ],
    specs: [
      {
        category: 'Camera System',
        items: [
          { label: 'Sensor', value: '1/1.3-inch CMOS, Dual Native ISO Fusion, 48 MP, f/1.7 aperture' },
          { label: 'Video Formats', value: '4K/60fps HDR, 4K/100fps Slow Motion, FHD/200fps' },
          { label: 'Color Modes', value: '10-bit D-Log M, 10-bit HLG, 8-bit Normal' },
          { label: 'Shooting Orientation', value: 'True Vertical Shooting (lossless 9:16 sensor orientation)' },
        ],
      },
      {
        category: 'Flight Dynamics',
        items: [
          { label: 'Takeoff Weight', value: '<249 g (Standard Battery)', plainExplanation: 'Exempt from registration in the US, UK, Canada, and EU for recreational use.' },
          { label: 'Max Flight Time', value: '34 min (Standard Battery) / 45 min (Battery Plus)' },
          { label: 'Wind Resistance', value: '10.7 m/s (Scale 5)' },
          { label: 'Safety Systems', value: 'Omnidirectional Obstacle Sensing + Advanced RTH' },
        ],
      },
      {
        category: 'Transmission & Connectivity',
        items: [
          { label: 'Transmission System', value: 'DJI O4 Transmission' },
          { label: 'Max Distance (FCC)', value: '20 km' },
          { label: 'Live Video Feed', value: '1080p @ 60fps' },
          { label: 'QuickTransfer', value: 'Wi-Fi 6 wireless download at up to 30 MB/s' },
        ],
      },
    ],
    compatibleAccessoryIds: ['care-refresh-mini4', 'battery-mini4-plus', 'nd-filters-mini4', 'prop-guard-mini4'],
    recommendedUse: ['travel', 'social-vlogging'],
    experienceLevel: 'beginner',
    weightGrams: 249,
    flightOrBatteryMinutes: 34,
    videoResolution: '4K / 60fps HDR & True Vertical',
    maxTransmissionKm: 20,
    sensorSize: '1/1.3" CMOS (f/1.7)',
  },
  {
    id: 'osmo-pocket-3',
    slug: 'osmo-pocket-3',
    name: 'DJI Osmo Pocket 3',
    series: 'Osmo Pocket',
    category: 'handheld',
    tagline: 'For Moving Moments. 1-Inch CMOS Pocket Gimbal Camera.',
    description: 'A powerhouse in your palm. Features a potent 1-inch CMOS sensor, 2-inch rotatable OLED touchscreen, 3-axis mechanical stabilization, and full-pixel fast focusing.',
    basePrice: 519,
    rating: 4.9,
    reviewCount: 890,
    badge: '1-Inch CMOS Gimbal',
    images: {
      hero: '/assets/images/card_handheld.png',
      studio: '/assets/images/card_handheld.png',
      folded: '/assets/images/card_handheld.png',
      details: [
        '/assets/images/card_handheld.png',
        '/assets/images/product_accessories_kit_1794403422664.jpg',
      ],
    },
    keyHighlights: [
      { stat: '1-Inch', label: 'CMOS Sensor', description: 'Exceptional low-light performance with clear highlight-shadow detail and rich skin tones.' },
      { stat: '4K/120fps', label: 'High Frame Rate', description: 'Smooth cinematic slow-motion in high resolution for dynamic action and lifestyle.' },
      { stat: '2.0-Inch', label: 'Rotatable OLED', description: 'Instant horizontal-to-vertical switching with a smooth magnetic snap.' },
      { stat: '3-Axis', label: 'Mechanical Gimbal', description: 'Physical brushless stabilization far superior to electronic image stabilization.' },
    ],
    combos: [
      {
        id: 'standard-unit',
        name: 'Standard Package',
        priceDelta: 0,
        description: 'Includes the Osmo Pocket 3, protective cover, wrist strap, and handle with 1/4" thread.',
        includes: ['Osmo Pocket 3 Gimbal Camera', 'Type-C to Type-C PD Cable', 'Protective Cover', 'DJI Wrist Strap', 'Handle With 1/4" Thread'],
      },
      {
        id: 'creator-combo',
        name: 'Creator Combo',
        priceDelta: 150,
        description: 'Complete mobile production package with DJI Mic 2 transmitter, battery handle, mini tripod, and carrying bag.',
        includes: ['Osmo Pocket 3 Gimbal Camera', 'DJI Mic 2 Transmitter (Shadow Black)', 'Battery Handle (extends runtime by 62%)', 'Mini Tripod', 'Wide-Angle Lens', 'Osmo Pocket 3 Carrying Bag'],
      },
    ],
    boxItems: [
      { name: 'Osmo Pocket 3', quantity: 1 },
      { name: 'Protective Cover', quantity: 1 },
      { name: 'Type-C to Type-C PD Cable', quantity: 1 },
      { name: 'Handle with 1/4" Thread', quantity: 1 },
      { name: 'DJI Wrist Strap', quantity: 1 },
    ],
    specs: [
      {
        category: 'Optics & Stabilizer',
        items: [
          { label: 'Sensor Size', value: '1-inch CMOS' },
          { label: 'Lens Equivalent', value: '20mm, f/2.0 aperture' },
          { label: 'Stabilization System', value: '3-axis mechanical gimbal (Pan, Tilt, Roll)' },
          { label: 'Focusing', value: 'Full-pixel fast focusing with Product Showcase mode' },
        ],
      },
      {
        category: 'Display & Battery',
        items: [
          { label: 'Touchscreen', value: '2.0-inch rotatable OLED, 314×556 resolution, 700 nits' },
          { label: 'Operating Time', value: 'Up to 166 minutes (at 1080p/24fps)' },
          { label: 'Fast Charge', value: '80% charged in 16 minutes with 65W PD charger' },
          { label: 'Weight', value: '179 g' },
        ],
      },
      {
        category: 'Audio & Wireless',
        items: [
          { label: 'Microphone Array', value: 'Built-in 3-mic array with omnidirectional stereo recording' },
          { label: 'Direct Wireless Mic', value: 'Built-in Wi-Fi & Bluetooth, connects two DJI Mic 2 transmitters' },
        ],
      },
    ],
    compatibleAccessoryIds: ['care-refresh-pocket3', 'battery-handle-pocket3', 'wide-lens-pocket3'],
    recommendedUse: ['social-vlogging', 'travel'],
    experienceLevel: 'beginner',
    weightGrams: 179,
    flightOrBatteryMinutes: 166,
    videoResolution: '4K / 120fps & 10-bit D-Log M',
    maxTransmissionKm: 0,
    sensorSize: '1.0-inch CMOS (f/2.0)',
  },
  {
    id: 'inspire-3',
    slug: 'inspire-3',
    name: 'DJI Inspire 3',
    series: 'Inspire',
    category: 'professional',
    tagline: 'Master the Unseen. Full-Frame 8K Cinema Aerial System.',
    description: 'Precision redefined for high-end Hollywood and commercial productions. Full-frame 8K/75fps ProRes RAW cinema camera, centimeter-level RTK waypoint repeatability, and 360° pan & tilt boost.',
    basePrice: 16499,
    rating: 5.0,
    reviewCount: 84,
    badge: 'Full-Frame 8K Cinema',
    images: {
      hero: '/assets/images/card_professional.png',
      studio: '/assets/images/card_professional.png',
      folded: '/assets/images/card_professional.png',
      details: [
        '/assets/images/card_professional.png',
        '/assets/images/story_cinematographer_iceland_1794403423081.jpg',
      ],
    },
    keyHighlights: [
      { stat: 'Full-Frame 8K', label: 'CinemaDNG & ProRes', description: 'Internal recording of up to 8K/75fps ProRes RAW and 8K/25fps CinemaDNG with 14+ stops of dynamic range.' },
      { stat: 'RTK Centimeter', label: 'Waypoint Repeatability', description: 'High-precision dual-antenna GNSS positioning enables exact flight path repetition across days and seasons.' },
      { stat: '360° Pan', label: 'Tilt Boost Rig', description: 'Landing gear lowers or raises to provide completely unobstructed 80° upward tilt and 360° pan.' },
      { stat: 'Dual Operator', label: 'Pilot & Camera', description: 'Dedicated FPV ultra-wide night-vision camera for the pilot while cinematographer commands the 8K gimbal.' },
    ],
    combos: [
      {
        id: 'standard-cinema-kit',
        name: 'Inspire 3 Cinema System',
        priceDelta: 0,
        description: 'Complete dual-operator production kit with Zenmuse X9-8K Air gimbal, DJI RC Plus controller, and 6x TB51 batteries.',
        includes: ['DJI Inspire 3 Aircraft', 'Zenmuse X9-8K Air Gimbal Camera', 'DJI RC Plus Remote Controller', '6x TB51 Intelligent Batteries', 'TB51 Intelligent Battery Charging Hub', 'PROSSD 1TB & Trolley Case'],
      },
    ],
    boxItems: [
      { name: 'Inspire 3 Aircraft', quantity: 1 },
      { name: 'Zenmuse X9-8K Air Gimbal', quantity: 1 },
      { name: 'DJI RC Plus Remote', quantity: 1 },
      { name: 'TB51 Intelligent Batteries', quantity: 6 },
      { name: 'PROSSD 1TB', quantity: 1 },
      { name: 'Rolling Hard Case', quantity: 1 },
    ],
    specs: [
      {
        category: 'Zenmuse X9-8K Air Camera',
        items: [
          { label: 'Sensor Format', value: '35mm Full-Frame CMOS (36 × 24 mm)' },
          { label: 'Lens Mount', value: 'DJI DL Mount (18mm, 24mm, 35mm, 50mm f/2.8 full-frame primes)' },
          { label: 'Max Video Spec', value: '8K (8192×4320) @ 75fps ProRes RAW / CinemaDNG' },
          { label: 'Dynamic Range', value: '14+ stops with dual-native ISO 800 / 4000' },
        ],
      },
      {
        category: 'Cinema Airframe Performance',
        items: [
          { label: 'Max Speed', value: '94 km/h (approx. 58 mph)' },
          { label: 'Max Flight Time', value: 'Up to 28 minutes with dual TB51 hot-swappable batteries' },
          { label: 'Max Payload / Takeoff', value: '3,995 g airframe' },
          { label: 'Wind Resistance', value: '14 m/s' },
        ],
      },
      {
        category: 'O3 Pro Video Transmission',
        items: [
          { label: 'Transmission System', value: 'O3 Pro Cinema Dual-Control' },
          { label: 'Max Range (FCC)', value: '15 km single control / 12 km dual control' },
          { label: 'Live Video Feed', value: '1080p/60fps 4K/30fps ultra-low latency' },
        ],
      },
    ],
    compatibleAccessoryIds: ['care-refresh-inspire3', 'tb51-battery-inspire3', 'dl-lens-set-inspire3'],
    recommendedUse: ['cinema', 'commercial-inspection'],
    experienceLevel: 'professional',
    weightGrams: 3995,
    flightOrBatteryMinutes: 28,
    videoResolution: '8K / 75fps ProRes RAW & CinemaDNG',
    maxTransmissionKm: 15,
    sensorSize: '35mm Full-Frame (Zenmuse X9)',
  },
  {
    id: 'avata-2',
    slug: 'avata-2',
    name: 'DJI Avata 2',
    series: 'Avata',
    category: 'camera-drones',
    tagline: 'All-Thrills Flight. FPV Immersion and One-Push ACRO.',
    description: 'Adrenaline-pumping FPV flight made intuitive. Integrated propeller guards, 1/1.3-inch ultra-wide 4K HDR camera, and effortless single-push flips and rolls with DJI RC Motion 3.',
    basePrice: 999,
    rating: 4.8,
    reviewCount: 310,
    badge: 'Intuitive FPV Drone',
    images: {
      hero: '/assets/images/product_avata2_fpv_1794403422043.jpg',
      studio: '/assets/images/product_avata2_fpv_1794403422043.jpg',
      folded: '/assets/images/product_avata2_fpv_1794403422043.jpg',
      details: [
        '/assets/images/product_avata2_fpv_1794403422043.jpg',
        '/assets/images/story_cinematographer_iceland_1794403423081.jpg',
      ],
    },
    keyHighlights: [
      { stat: 'Easy ACRO', label: 'One-Push Flips & Rolls', description: 'Perform front/back flips, 360 rolls, and 180 drift maneuvers with a flick of the joystick.' },
      { stat: '1/1.3-inch', label: '4K/60fps HDR', description: '155° ultra-wide FOV for dynamic close-proximity shots through tight branches and doorways.' },
      { stat: 'Built-in Guard', label: 'Ducted Propellers', description: 'Aerodynamically optimized safety guards withstand accidental collisions and keep flying.' },
      { stat: '23 Min', label: 'Extended FPV Flight', description: 'Class-leading endurance for an FPV cinewhoop with O4 13km 1080p/100fps transmission.' },
    ],
    combos: [
      {
        id: 'single-battery-combo',
        name: 'Fly More Combo (Single Battery)',
        priceDelta: 0,
        description: 'Includes DJI Avata 2, DJI Goggles 3, and DJI RC Motion 3 single-handed controller.',
        includes: ['DJI Avata 2 Drone', 'DJI Goggles 3', 'DJI RC Motion 3', '1x Intelligent Flight Battery', '2x Propellers (pair)', 'Gimbal Protector'],
      },
      {
        id: 'three-battery-combo',
        name: 'Fly More Combo (Three Batteries)',
        priceDelta: 200,
        description: 'Includes 3 flight batteries, two-way charging hub, and sling bag for uninterrupted sessions.',
        includes: ['DJI Avata 2 Drone', 'DJI Goggles 3', 'DJI RC Motion 3', '3x Intelligent Flight Batteries', 'Two-Way Charging Hub', 'Sling Bag'],
      },
    ],
    boxItems: [
      { name: 'DJI Avata 2 Aircraft', quantity: 1 },
      { name: 'DJI Goggles 3', quantity: 1 },
      { name: 'DJI RC Motion 3', quantity: 1 },
      { name: 'Intelligent Flight Battery', quantity: 1 },
      { name: 'Propellers (Pair)', quantity: 2 },
    ],
    specs: [
      {
        category: 'Camera & Optics',
        items: [
          { label: 'Sensor', value: '1/1.3-inch CMOS, 12 MP' },
          { label: 'Lens FOV', value: '155° ultra-wide, f/2.8 aperture' },
          { label: 'Stabilization', value: 'RockSteady 3.0+ & HorizonSteady' },
          { label: 'Video Modes', value: '4K/60fps HDR, 2.7K/120fps' },
        ],
      },
      {
        category: 'FPV Flight & Airframe',
        items: [
          { label: 'Weight', value: '377 g' },
          { label: 'Max Flight Time', value: '23 minutes' },
          { label: 'Turtle Mode', value: 'Automatically flips drone upright if landed upside down' },
        ],
      },
      {
        category: 'Goggles 3 & Transmission',
        items: [
          { label: 'Transmission', value: 'DJI O4, 60Mbps bitrate, 24ms latency' },
          { label: 'Goggles Display', value: 'Dual micro-OLED 1080p 100Hz panels with Real View PiP' },
        ],
      },
    ],
    compatibleAccessoryIds: ['care-refresh-avata2', 'battery-avata2', 'nd-filters-avata2'],
    recommendedUse: ['action-sports', 'social-vlogging'],
    experienceLevel: 'enthusiast',
    weightGrams: 377,
    flightOrBatteryMinutes: 23,
    videoResolution: '4K / 60fps HDR (155° FOV)',
    maxTransmissionKm: 13,
    sensorSize: '1/1.3" CMOS (155° FOV)',
  },
  {
    id: 'osmo-action-5-pro',
    slug: 'osmo-action-5-pro',
    name: 'DJI Osmo Action 5 Pro',
    series: 'Osmo Action',
    category: 'handheld',
    tagline: 'Revolutionary Imaging. 13.5 Stops Dynamic Range Action Camera.',
    description: 'Engineered for extreme adventures. Next-generation 1/1.3-inch sensor delivers 13.5 stops of dynamic range, 4-hour battery endurance, and dual high-brightness OLED screens.',
    basePrice: 349,
    rating: 4.9,
    reviewCount: 420,
    badge: '13.5 Stops Dynamic Range',
    images: {
      hero: '/assets/images/card_handheld.png',
      studio: '/assets/images/card_handheld.png',
      folded: '/assets/images/card_handheld.png',
      details: [
        '/assets/images/card_handheld.png',
        '/assets/images/product_accessories_kit_1794403422664.jpg',
      ],
    },
    keyHighlights: [
      { stat: '13.5 Stops', label: 'Dynamic Range', description: 'Pro-grade high dynamic range rivaling professional cinema cameras in high-contrast sunlight and shadows.' },
      { stat: '4 Hours', label: 'Battery Life', description: 'Continuous recording for up to 240 minutes on a single charge, even at -20°C temperatures.' },
      { stat: '20 m', label: 'Waterproof', description: 'Submersible up to 20 meters without an external waterproof housing.' },
      { stat: 'Dual OLED', label: 'Touchscreens', description: 'Front and rear OLED displays with up to 1000 nits peak brightness for outdoor visibility.' },
    ],
    combos: [
      {
        id: 'standard-combo',
        name: 'Standard Combo',
        priceDelta: 0,
        description: 'Includes camera, 1x Extreme Battery Plus, horizontal-vertical protective frame, and quick-release adapter mount.',
        includes: ['Osmo Action 5 Pro', '1x Extreme Battery Plus (1950 mAh)', 'Horizontal-Vertical Protective Frame', 'Quick-Release Adapter Mount', 'Curved Adhesive Base'],
      },
      {
        id: 'adventure-combo',
        name: 'Adventure Combo',
        priceDelta: 100,
        description: 'Includes 3x Extreme Batteries, multifunctional battery case, and 1.5m extension rod.',
        includes: ['Osmo Action 5 Pro', '3x Extreme Batteries Plus', 'Multifunctional Battery Case', '1.5m Extension Rod', 'Quick-Release Adapter Mounts'],
      },
    ],
    boxItems: [
      { name: 'Osmo Action 5 Pro Camera', quantity: 1 },
      { name: 'Extreme Battery Plus', quantity: 1 },
      { name: 'Protective Frame', quantity: 1 },
      { name: 'Quick-Release Mount', quantity: 1 },
      { name: 'Locking Screw', quantity: 1 },
    ],
    specs: [
      {
        category: 'Optics & Sensor',
        items: [
          { label: 'Sensor', value: '1/1.3-inch next-gen CMOS with 4nm chip' },
          { label: 'Lens FOV', value: '155° ultra-wide, f/2.8' },
          { label: 'Max Video', value: '4K (3840×2880) @ 120fps 4:3 / 4K @ 60fps HDR' },
        ],
      },
      {
        category: 'Durability & Battery',
        items: [
          { label: 'Waterproofing', value: '20 m without case / 60 m with waterproof case' },
          { label: 'Operating Time', value: '240 minutes at 1080p / 160 minutes at 4K/60fps' },
          { label: 'Cold Resistance', value: 'Reliable down to -20°C (-4°F)' },
          { label: 'Weight', value: '146 g' },
        ],
      },
    ],
    compatibleAccessoryIds: ['care-refresh-action5', 'battery-action5', 'mount-action5'],
    recommendedUse: ['action-sports', 'travel'],
    experienceLevel: 'beginner',
    weightGrams: 146,
    flightOrBatteryMinutes: 240,
    videoResolution: '4K / 120fps 4:3 & 13.5 Stops DR',
    maxTransmissionKm: 0,
    sensorSize: '1/1.3" next-gen CMOS',
  },
];
