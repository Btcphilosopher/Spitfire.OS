'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, PRODUCTS } from '@/data/products';
import { Accessory, ACCESSORIES } from '@/data/accessories';

export type Currency = 'USD' | 'EUR' | 'GBP' | 'CAD' | 'JPY';
export type Region = 'US' | 'EU' | 'UK' | 'CA' | 'JP';
export type AppView = 'home' | 'category' | 'pdp' | 'selector' | 'compare' | 'support';

export interface CartItem {
  id: string;
  productId: string;
  comboId: string;
  quantity: number;
  addedAccessoryIds: string[];
}

interface AppContextType {
  // Navigation & View
  activeView: AppView;
  setActiveView: (view: AppView) => void;
  selectedCategory: string | null;
  setSelectedCategory: (cat: string | null) => void;
  selectedProductId: string;
  setSelectedProductId: (id: string) => void;
  navigateToProduct: (id: string) => void;
  navigateToCategory: (cat: string) => void;

  // Comparison
  comparedProductIds: string[];
  addToCompare: (id: string) => boolean;
  removeFromCompare: (id: string) => void;
  isInCompare: (id: string) => boolean;

  // Cart
  cart: CartItem[];
  addToCart: (productId: string, comboId: string, accessoryIds?: string[]) => void;
  updateCartQuantity: (itemId: string, delta: number) => void;
  removeFromCart: (itemId: string) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;

  // Checkout
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;

  // Search
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;

  // Video Film Modal
  activeVideo: { title: string; subtitle: string } | null;
  setActiveVideo: (video: { title: string; subtitle: string } | null) => void;

  // Currency & Region
  currency: Currency;
  setCurrency: (c: Currency) => void;
  region: Region;
  setRegion: (r: Region) => void;
  formatPrice: (usdAmount: number) => string;
}

const CURRENCY_RATES: Record<Currency, { rate: number; symbol: string; decimals: number }> = {
  USD: { rate: 1.0, symbol: '$', decimals: 0 },
  EUR: { rate: 0.92, symbol: '€', decimals: 0 },
  GBP: { rate: 0.79, symbol: '£', decimals: 0 },
  CAD: { rate: 1.36, symbol: 'CA$', decimals: 0 },
  JPY: { rate: 154, symbol: '¥', decimals: 0 },
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [activeView, setActiveView] = useState<AppView>('home');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedProductId, setSelectedProductId] = useState<string>('mavic-3-pro');
  const [comparedProductIds, setComparedProductIds] = useState<string[]>(['mavic-3-pro', 'mini-4-pro']);
  
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeVideo, setActiveVideo] = useState<{ title: string; subtitle: string } | null>(null);

  const [currency, setCurrency] = useState<Currency>(() => {
    if (typeof window === 'undefined') return 'USD';
    try {
      const saved = localStorage.getItem('dji_currency') as Currency;
      if (saved && CURRENCY_RATES[saved]) return saved;
    } catch {
      // ignore
    }
    return 'USD';
  });

  const [region, setRegion] = useState<Region>('US');

  const [cart, setCart] = useState<CartItem[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const saved = localStorage.getItem('dji_concept_cart');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [];
  });

  // Save cart to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('dji_concept_cart', JSON.stringify(cart));
    } catch {
      // ignore
    }
  }, [cart]);

  const navigateToProduct = (id: string) => {
    setSelectedProductId(id);
    setActiveView('pdp');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateToCategory = (cat: string) => {
    setSelectedCategory(cat);
    setActiveView('category');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const addToCompare = (id: string): boolean => {
    if (comparedProductIds.includes(id)) return true;
    if (comparedProductIds.length >= 3) {
      return false; // max 3
    }
    setComparedProductIds(prev => [...prev, id]);
    return true;
  };

  const removeFromCompare = (id: string) => {
    setComparedProductIds(prev => prev.filter(pId => pId !== id));
  };

  const isInCompare = (id: string) => comparedProductIds.includes(id);

  const addToCart = (productId: string, comboId: string, accessoryIds: string[] = []) => {
    setCart(prev => {
      // Check if identical product + combo + accessories already exists
      const existingIndex = prev.findIndex(item => 
        item.productId === productId && 
        item.comboId === comboId && 
        JSON.stringify(item.addedAccessoryIds.sort()) === JSON.stringify(accessoryIds.sort())
      );

      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex].quantity += 1;
        return updated;
      }

      return [
        ...prev,
        {
          id: `${productId}_${comboId}_${Date.now()}`,
          productId,
          comboId,
          quantity: 1,
          addedAccessoryIds: accessoryIds,
        },
      ];
    });

    setIsCartOpen(true);
  };

  const updateCartQuantity = (itemId: string, delta: number) => {
    setCart(prev => {
      return prev
        .map(item => {
          if (item.id === itemId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter((item): item is CartItem => item !== null);
    });
  };

  const removeFromCart = (itemId: string) => {
    setCart(prev => prev.filter(item => item.id !== itemId));
  };

  const clearCart = () => {
    setCart([]);
  };

  // Calculate cart counts and totals
  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);

  const cartSubtotal = cart.reduce((total, item) => {
    const product = PRODUCTS.find(p => p.id === item.productId);
    if (!product) return total;
    const combo = product.combos.find(c => c.id === item.comboId) || product.combos[0];
    const comboPrice = product.basePrice + (combo ? combo.priceDelta : 0);

    const accessoriesPrice = (item.addedAccessoryIds || []).reduce((accTotal, accId) => {
      const accessory = ACCESSORIES.find(a => a.id === accId);
      return accTotal + (accessory ? accessory.price : 0);
    }, 0);

    return total + (comboPrice + accessoriesPrice) * item.quantity;
  }, 0);

  const formatPrice = (usdAmount: number) => {
    const { rate, symbol, decimals } = CURRENCY_RATES[currency];
    const converted = Math.round(usdAmount * rate);
    if (decimals === 0) {
      return `${symbol}${converted.toLocaleString()}`;
    }
    return `${symbol}${converted.toFixed(decimals)}`;
  };

  return (
    <AppContext.Provider
      value={{
        activeView,
        setActiveView,
        selectedCategory,
        setSelectedCategory,
        selectedProductId,
        setSelectedProductId,
        navigateToProduct,
        navigateToCategory,
        comparedProductIds,
        addToCompare,
        removeFromCompare,
        isInCompare,
        cart,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        cartCount,
        cartSubtotal,
        isCartOpen,
        setIsCartOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        isSearchOpen,
        setIsSearchOpen,
        searchQuery,
        setSearchQuery,
        activeVideo,
        setActiveVideo,
        currency,
        setCurrency,
        region,
        setRegion,
        formatPrice,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
