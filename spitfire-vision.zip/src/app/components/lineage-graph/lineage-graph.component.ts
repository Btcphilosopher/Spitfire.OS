import { Component, ChangeDetectionStrategy, input, output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SpitfireProcessedImage } from '../../models/spitfire.models';

export interface LineageNode {
  id: string;
  name: string;
  stageKey: string;
  category: string;
  durationMs: number;
  parameters: Record<string, string | number | boolean | number[]>;
}

@Component({
  selector: 'app-lineage-graph',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-[#181C1E] border border-[#252B2D] rounded p-4 text-xs font-mono select-none">
      <div class="flex items-center justify-between mb-3 pb-2 border-b border-[#252B2D]">
        <div class="flex items-center gap-2 text-[#ECE9E0] font-semibold text-sm">
          <mat-icon class="!text-[18px] !w-4.5 !h-4.5 text-[#31483F]">account_tree</mat-icon>
          <span>DIGITAL IMAGE LINEAGE & AUDIT GRAPH</span>
        </div>
        <div class="flex items-center gap-2 text-[11px] text-[#BFC2BD]/60">
          <span>PIPELINE: {{ processedImage()?.provenance?.pipelineVersion || '1.0.0-R' }}</span>
          <span>·</span>
          <span>TOTAL TIME: {{ processedImage()?.provenance?.totalProcessingTimeMs | number:'1.2-2' }} ms</span>
        </div>
      </div>

      <!-- Pipeline Stage Nodes (Horizontal Flow) -->
      <div class="overflow-x-auto pb-2 no-scrollbar">
        <div class="flex items-center gap-1 min-w-[760px] py-1">
          @for (node of pipelineNodes; track node.id; let last = $last) {
            <button
              type="button"
              (click)="selectNode(node)"
              class="px-2.5 py-2 rounded border cursor-pointer transition-all shrink-0 text-center focus:outline-none"
              [class.bg-[#31483F]]="selectedNodeId() === node.id"
              [class.border-[#31483F]]="selectedNodeId() === node.id"
              [class.text-[#ECE9E0]]="selectedNodeId() === node.id"
              [class.bg-[#111416]]="selectedNodeId() !== node.id"
              [class.border-[#252B2D]]="selectedNodeId() !== node.id"
              [class.text-[#BFC2BD]/80]="selectedNodeId() !== node.id"
              [class.hover:border-[#3D6A7D]]="selectedNodeId() !== node.id">
              <div class="text-[9px] uppercase opacity-60 font-semibold">{{ node.category }}</div>
              <div class="text-[11px] font-bold whitespace-nowrap">{{ node.name }}</div>
              <div class="text-[9px] text-[#C1943D] mt-0.5">{{ node.durationMs | number:'1.1-1' }} ms</div>
            </button>

            @if (!last) {
              <mat-icon class="!text-[14px] !w-3.5 !h-3.5 text-[#BFC2BD]/30 shrink-0">arrow_forward</mat-icon>
            }
          }
        </div>
      </div>

      <!-- Node Detail Inspector Box -->
      @if (activeNode()) {
        @let node = activeNode()!;
        <div class="mt-3 p-3 bg-[#111416] border border-[#252B2D] rounded grid grid-cols-1 md:grid-cols-3 gap-3 text-[11px]">
          <div>
            <div class="text-[10px] uppercase text-[#BFC2BD]/50 font-bold mb-1">Stage Metadata</div>
            <div class="space-y-1">
              <div class="flex justify-between">
                <span class="text-[#BFC2BD]/70">Stage Name:</span>
                <span class="font-bold text-[#ECE9E0]">{{ node.name }}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-[#BFC2BD]/70">Category:</span>
                <span>{{ node.category }}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-[#BFC2BD]/70">Stage Execution:</span>
                <span class="text-[#31483F] font-bold">{{ node.durationMs }} ms</span>
              </div>
            </div>
          </div>

          <div>
            <div class="text-[10px] uppercase text-[#BFC2BD]/50 font-bold mb-1">Exact Input Parameters</div>
            <div class="space-y-1 text-[#BFC2BD]/80">
              @for (param of getParamEntries(node.parameters); track param.key) {
                <div class="flex justify-between">
                  <span>{{ param.key }}:</span>
                  <span class="font-mono text-[#C1943D] font-bold">{{ param.value }}</span>
                </div>
              }
            </div>
          </div>

          <div class="flex flex-col justify-between">
            <div>
              <div class="text-[10px] uppercase text-[#BFC2BD]/50 font-bold mb-1">Intermediate Output Buffer</div>
              <div class="text-[10px] text-[#BFC2BD]/70">
                14-bit floating point precision matrix. Auditable provenance hash verified.
              </div>
            </div>
            <button
              type="button"
              (click)="inspectBuffer(node.stageKey)"
              class="w-full mt-2 py-1.5 bg-[#252B2D] hover:bg-[#31483F] text-[#ECE9E0] rounded transition-colors text-[10px] font-bold uppercase">
              View Stage Buffer on Canvas
            </button>
          </div>
        </div>
      }
    </div>
  `
})
export class LineageGraphComponent {
  public processedImage = input<SpitfireProcessedImage | null>(null);
  public previewStageBuffer = output<string>();

  public selectedNodeId = signal<string>('stage_demosaic');

  public readonly pipelineNodes: LineageNode[] = [
    { id: 'stage_raw', name: 'Raw Capture', stageKey: 'black_level', category: 'SENSOR', durationMs: 0.8, parameters: { cfa: 'RGGB', bitDepth: 14, adcGain: 1.0 } },
    { id: 'stage_black_level', name: 'Black Subtraction', stageKey: 'black_level', category: 'CALIBRATION', durationMs: 0.6, parameters: { pedestalAdu: 512, clampMin: 0 } },
    { id: 'stage_linearise', name: 'Linearisation', stageKey: 'linearisation', category: 'MATH', durationMs: 0.5, parameters: { black: 512, white: 16383, scale: '0..1' } },
    { id: 'stage_bad_pixel', name: 'Defect Correction', stageKey: 'bad_pixel', category: 'CALIBRATION', durationMs: 1.2, parameters: { method: '3x3_median', sigma: 4.0 } },
    { id: 'stage_flat_field', name: 'Flat Field / Vignetting', stageKey: 'flat_field', category: 'OPTICS', durationMs: 1.4, parameters: { prnuComp: '0.8%', cos4theta: 3.6 } },
    { id: 'stage_demosaic', name: 'Bayer Demosaic', stageKey: 'demosaic', category: 'INTERPOLATION', durationMs: 3.5, parameters: { algorithm: 'edge_aware_gradient', channels: 'RGB' } },
    { id: 'stage_lens_corr', name: 'Lens Distortion', stageKey: 'lens_correction', category: 'GEOMETRY', durationMs: 2.8, parameters: { k1: -0.045, k2: 0.008, p1: 0.0002 } },
    { id: 'stage_white_balance', name: 'White Balance', stageKey: 'white_balance', category: 'COLOUR', durationMs: 0.9, parameters: { mode: 'daylight', rgbGains: [1.95, 1.0, 1.55] } },
    { id: 'stage_colour_matrix', name: 'Colour Matrix', stageKey: 'colour_matrix', category: 'COLOUR', durationMs: 1.1, parameters: { targetSpace: 'sRGB', matrix: '3x3_CCM' } },
    { id: 'stage_tone_curve', name: 'Tone Curve', stageKey: 'tone_curve', category: 'TRANSFER', durationMs: 0.7, parameters: { curve: 'srgb_standard', gamma: 2.2 } },
    { id: 'stage_denoise', name: 'Bilateral Denoise', stageKey: 'denoise', category: 'RESTORATION', durationMs: 4.2, parameters: { method: 'bilateral', sigmaS: 1.5, sigmaR: 0.12 } },
    { id: 'stage_sharpen', name: 'Unsharp Sharpen', stageKey: 'sharpen', category: 'ENHANCEMENT', durationMs: 1.8, parameters: { method: 'unsharp_mask', amount: 0.6, radius: 1.2 } },
    { id: 'stage_output', name: 'Output Image', stageKey: 'output', category: 'EXPORT', durationMs: 0.4, parameters: { format: 'sRGB_RGBA_8888', quality: 100 } }
  ];

  public activeNode = () => {
    const id = this.selectedNodeId();
    return this.pipelineNodes.find(n => n.id === id) || this.pipelineNodes[5];
  };

  public selectNode(node: LineageNode): void {
    this.selectedNodeId.set(node.id);
  }

  public inspectBuffer(stageKey: string): void {
    this.previewStageBuffer.emit(stageKey);
  }

  public getParamEntries(params: Record<string, string | number | boolean | number[]>): { key: string; value: string }[] {
    return Object.entries(params).map(([key, val]) => ({
      key,
      value: typeof val === 'object' ? JSON.stringify(val) : String(val)
    }));
  }
}
