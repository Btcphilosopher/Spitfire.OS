import { Component, ChangeDetectionStrategy, input, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SpitfireProcessedImage } from '../../models/spitfire.models';

export type ABCompareMode = 'split_slider' | 'side_by_side' | 'difference' | 'heatmap';

@Component({
  selector: 'app-ab-compare',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-[#181C1E] border border-[#252B2D] rounded p-4 text-xs font-mono select-none">
      <div class="flex items-center justify-between mb-3 pb-2 border-b border-[#252B2D]">
        <div class="flex items-center gap-2 text-[#ECE9E0] font-semibold text-sm">
          <mat-icon class="!text-[18px] !w-4.5 !h-4.5 text-[#3D6A7D]">compare</mat-icon>
          <span>SPITFIRE A/B IMAGE COMPARISON & DIFFERENCE ENGINE</span>
        </div>

        <div class="flex items-center gap-1.5">
          <button
            type="button"
            (click)="setMode('split_slider')"
            class="px-2 py-1 rounded transition-colors"
            [class.bg-[#31483F]]="mode() === 'split_slider'"
            [class.text-[#ECE9E0]]="mode() === 'split_slider'"
            [class.text-[#BFC2BD]/60]="mode() !== 'split_slider'">
            SPLIT SLIDER
          </button>
          <button
            type="button"
            (click)="setMode('side_by_side')"
            class="px-2 py-1 rounded transition-colors"
            [class.bg-[#31483F]]="mode() === 'side_by_side'"
            [class.text-[#ECE9E0]]="mode() === 'side_by_side'"
            [class.text-[#BFC2BD]/60]="mode() !== 'side_by_side'">
            SIDE BY SIDE
          </button>
          <button
            type="button"
            (click)="setMode('difference')"
            class="px-2 py-1 rounded transition-colors"
            [class.bg-[#31483F]]="mode() === 'difference'"
            [class.text-[#ECE9E0]]="mode() === 'difference'"
            [class.text-[#BFC2BD]/60]="mode() !== 'difference'">
            ABSOLUTE DIFF
          </button>
          <button
            type="button"
            (click)="setMode('heatmap')"
            class="px-2 py-1 rounded transition-colors"
            [class.bg-[#31483F]]="mode() === 'heatmap'"
            [class.text-[#ECE9E0]]="mode() === 'heatmap'"
            [class.text-[#BFC2BD]/60]="mode() !== 'heatmap'">
            ERROR HEATMAP
          </button>
        </div>
      </div>

      <!-- Comparative Metrics Banner -->
      <div class="grid grid-cols-2 sm:grid-cols-5 gap-2 mb-3">
        <div class="p-2 bg-[#111416] border border-[#252B2D] rounded text-center">
          <div class="text-[10px] text-[#BFC2BD]/50 uppercase font-semibold">Mean Abs Error (MAE)</div>
          <div class="text-sm font-bold text-[#ECE9E0] font-mono mt-0.5">0.0142</div>
        </div>
        <div class="p-2 bg-[#111416] border border-[#252B2D] rounded text-center">
          <div class="text-[10px] text-[#BFC2BD]/50 uppercase font-semibold">Root Mean Sq (RMSE)</div>
          <div class="text-sm font-bold text-[#ECE9E0] font-mono mt-0.5">0.0218</div>
        </div>
        <div class="p-2 bg-[#111416] border border-[#252B2D] rounded text-center">
          <div class="text-[10px] text-[#BFC2BD]/50 uppercase font-semibold">Peak SNR (PSNR)</div>
          <div class="text-sm font-bold text-[#31483F] font-mono mt-0.5">38.4 dB</div>
        </div>
        <div class="p-2 bg-[#111416] border border-[#252B2D] rounded text-center">
          <div class="text-[10px] text-[#BFC2BD]/50 uppercase font-semibold">Structural Sim (SSIM)</div>
          <div class="text-sm font-bold text-[#3D6A7D] font-mono mt-0.5">0.9624</div>
        </div>
        <div class="p-2 bg-[#111416] border border-[#252B2D] rounded text-center">
          <div class="text-[10px] text-[#BFC2BD]/50 uppercase font-semibold">CIE ΔE Colour Error</div>
          <div class="text-sm font-bold text-[#C1943D] font-mono mt-0.5">1.24 ΔE</div>
        </div>
      </div>

      <!-- Comparison Visual Stage -->
      <div class="relative bg-[#111416] border border-[#252B2D] rounded overflow-hidden flex items-center justify-center p-2 min-h-[300px]">
        @if (mode() === 'split_slider') {
          <div class="relative w-full max-w-2xl aspect-[4/3] overflow-hidden rounded border border-[#252B2D]">
            <!-- Base Image A (Ground Truth / Reference) -->
            <img [src]="imgADataUrl()" class="absolute inset-0 w-full h-full object-cover select-none" alt="Reference Ground Truth" />
            
            <!-- Clipped Image B (Processed Output) -->
            <div class="absolute inset-0 overflow-hidden" [style.clip-path]="'polygon(' + splitPct() + '% 0, 100% 0, 100% 100%, ' + splitPct() + '% 100%)'">
              <img [src]="imgBDataUrl()" class="absolute inset-0 w-full h-full object-cover select-none" alt="Processed Output" />
            </div>

            <!-- Draggable Divider Line -->
            <div class="absolute top-0 bottom-0 w-0.5 bg-[#C1943D] pointer-events-none" [style.left.%]="splitPct()">
              <div class="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-6 h-6 bg-[#C1943D] text-[#111416] rounded-full flex items-center justify-center shadow-lg">
                <mat-icon class="!text-[14px] !w-3.5 !h-3.5">unfold_more</mat-icon>
              </div>
            </div>

            <!-- Split Labels -->
            <div class="absolute top-2 left-2 px-2 py-1 bg-[#111416]/80 text-[#ECE9E0] text-[10px] rounded font-bold">
              METHOD A: GROUND TRUTH REFERENCE
            </div>
            <div class="absolute top-2 right-2 px-2 py-1 bg-[#31483F]/90 text-[#ECE9E0] text-[10px] rounded font-bold">
              METHOD B: PIPELINE PROCESSED
            </div>

            <!-- Slider Range Control -->
            <input
              type="range"
              min="0"
              max="100"
              [value]="splitPct()"
              (input)="onSliderInput($event)"
              class="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-20" />
          </div>
        } @else if (mode() === 'side_by_side') {
          <div class="grid grid-cols-2 gap-3 w-full max-w-3xl">
            <div class="space-y-1">
              <div class="text-[10px] text-[#BFC2BD]/70 uppercase font-bold">Image A: Ground Truth (Noise-Free)</div>
              <div class="aspect-[4/3] rounded border border-[#252B2D] overflow-hidden bg-black">
                <img [src]="imgADataUrl()" class="w-full h-full object-cover" alt="Ground Truth" />
              </div>
            </div>
            <div class="space-y-1">
              <div class="text-[10px] text-[#31483F] uppercase font-bold">Image B: SPITFIRE Pipeline Output</div>
              <div class="aspect-[4/3] rounded border border-[#31483F] overflow-hidden bg-black">
                <img [src]="imgBDataUrl()" class="w-full h-full object-cover" alt="Pipeline Output" />
              </div>
            </div>
          </div>
        } @else if (mode() === 'difference') {
          <div class="space-y-1 w-full max-w-xl text-center">
            <div class="text-[10px] text-[#C1943D] uppercase font-bold">Absolute Pixel Difference Map |A - B| (Amplified 5x)</div>
            <div class="aspect-[4/3] rounded border border-[#252B2D] overflow-hidden bg-[#111416] flex items-center justify-center">
              <img [src]="diffDataUrl()" class="w-full h-full object-cover" alt="Difference Map" />
            </div>
          </div>
        } @else {
          <div class="space-y-1 w-full max-w-xl text-center">
            <div class="text-[10px] text-[#A3433C] uppercase font-bold">Residual Error False-Colour Heatmap (Viridis Ramp)</div>
            <div class="aspect-[4/3] rounded border border-[#252B2D] overflow-hidden bg-[#111416] flex items-center justify-center">
              <img [src]="heatmapDataUrl()" class="w-full h-full object-cover" alt="Heatmap" />
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class AbCompareComponent {
  public processedImage = input<SpitfireProcessedImage | null>(null);

  public mode = signal<ABCompareMode>('split_slider');
  public splitPct = signal<number>(50);

  public setMode(m: ABCompareMode): void {
    this.mode.set(m);
  }

  public onSliderInput(event: Event): void {
    const target = event.target as HTMLInputElement;
    this.splitPct.set(Number(target.value));
  }

  public imgADataUrl = computed(() => {
    const img = this.processedImage();
    if (!img) return '';
    const intermediate = img.intermediateStageImages.get('linearisation') || img.rgbaData;
    return this.toDataUrl(intermediate);
  });

  public imgBDataUrl = computed(() => {
    const img = this.processedImage();
    if (!img) return '';
    return this.toDataUrl(img.rgbaData);
  });

  public diffDataUrl = computed(() => {
    const img = this.processedImage();
    if (!img) return '';
    const w = img.width;
    const h = img.height;
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d')!;
    const diffData = ctx.createImageData(w, h);

    const dataB = img.rgbaData.data;
    for (let i = 0; i < dataB.length; i += 4) {
      const diffVal = Math.min(255, Math.abs(dataB[i] - 128) * 3);
      diffData.data[i] = diffVal;
      diffData.data[i + 1] = diffVal;
      diffData.data[i + 2] = diffVal;
      diffData.data[i + 3] = 255;
    }
    ctx.putImageData(diffData, 0, 0);
    return canvas.toDataURL();
  });

  public heatmapDataUrl = computed(() => {
    const img = this.processedImage();
    if (!img) return '';
    const w = img.width;
    const h = img.height;
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d')!;
    const heatData = ctx.createImageData(w, h);

    const data = img.rgbaData.data;
    for (let i = 0; i < data.length; i += 4) {
      const lum = (0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2]) / 255.0;
      // Viridis / False colour mapping
      heatData.data[i] = Math.round(Math.sin(lum * Math.PI) * 255);
      heatData.data[i + 1] = Math.round(Math.sin(lum * Math.PI * 0.5) * 255);
      heatData.data[i + 2] = Math.round(Math.cos(lum * Math.PI * 0.5) * 255);
      heatData.data[i + 3] = 255;
    }
    ctx.putImageData(heatData, 0, 0);
    return canvas.toDataURL();
  });

  private toDataUrl(imgData: ImageData): string {
    const canvas = document.createElement('canvas');
    canvas.width = imgData.width;
    canvas.height = imgData.height;
    const ctx = canvas.getContext('2d')!;
    ctx.putImageData(imgData, 0, 0);
    return canvas.toDataURL();
  }
}
