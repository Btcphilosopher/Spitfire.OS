import { Component, ChangeDetectionStrategy, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DualLayerMode } from '../../models/spitfire.models';

export type MainNavTab = 
  | 'digital_twin'
  | 'pipeline_lab'
  | 'exposure_iso'
  | 'optics_lens'
  | 'colour_science'
  | 'hdr_low_light'
  | 'computer_vision'
  | 'flight_provenance'
  | 'signature_demos'
  | 'r_engine';

@Component({
  selector: 'app-top-bar',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="h-14 bg-[#111416] border-b border-[#252B2D] px-4 flex items-center justify-between select-none z-30 relative">
      <!-- Zone 1: Single text element wordmark -->
      <div class="flex items-center gap-3 shrink-0">
        <div class="w-7 h-7 bg-[#31483F] border border-[#BFC2BD]/30 rounded flex items-center justify-center text-[#ECE9E0] font-mono font-bold text-xs">
          SV
        </div>
        <a href="/" class="text-sm font-semibold tracking-wider text-[#ECE9E0] uppercase font-mono">
          SPITFIRE VISION
        </a>
        <span class="text-xs text-[#BFC2BD]/50 font-mono hidden sm:inline">· R-Native Sensor Platform</span>
      </div>

      <!-- Zone 2: Navigation Links (single-line, clean typography) -->
      <nav class="hidden lg:flex items-center gap-1 overflow-x-auto no-scrollbar">
        @for (tab of navTabs; track tab.id) {
          <button
            type="button"
            (click)="selectTab.emit(tab.id)"
            class="px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap"
            [class.bg-[#252B2D]]="activeTab() === tab.id"
            [class.text-[#ECE9E0]]="activeTab() === tab.id"
            [class.text-[#BFC2BD]/80]="activeTab() !== tab.id"
            [class.hover:text-[#ECE9E0]]="activeTab() !== tab.id"
            [class.hover:bg-[#252B2D]/50]="activeTab() !== tab.id">
            <span class="inline-flex items-center gap-1">
              <mat-icon class="!text-[14px] !w-3.5 !h-3.5">{{ tab.icon }}</mat-icon>
              {{ tab.label }}
            </span>
          </button>
        }
      </nav>

      <!-- Zone 3: Primary Actions & Dual Layer Switch -->
      <div class="flex items-center gap-2 shrink-0">
        <!-- Dual Layer Switcher: Physical Sensor vs Computed Image -->
        <div class="flex items-center p-0.5 bg-[#252B2D] border border-[#BFC2BD]/20 rounded text-xs font-mono">
          <button
            type="button"
            (click)="toggleDualLayer.emit('physical_sensor')"
            class="px-2 py-1 rounded transition-colors"
            [class.bg-[#31483F]]="dualLayer() === 'physical_sensor'"
            [class.text-[#ECE9E0]]="dualLayer() === 'physical_sensor'"
            [class.text-[#BFC2BD]/70]="dualLayer() !== 'physical_sensor'">
            PHYSICAL SENSOR
          </button>
          <button
            type="button"
            (click)="toggleDualLayer.emit('computed_image')"
            class="px-2 py-1 rounded transition-colors"
            [class.bg-[#263F52]]="dualLayer() === 'computed_image'"
            [class.text-[#ECE9E0]]="dualLayer() === 'computed_image'"
            [class.text-[#BFC2BD]/70]="dualLayer() !== 'computed_image'">
            COMPUTED IMAGE
          </button>
        </div>

        <button
          type="button"
          (click)="openRExport.emit()"
          class="flex items-center gap-1.5 px-3 py-1.5 bg-[#31483F] hover:bg-[#31483F]/80 text-[#ECE9E0] text-xs font-mono font-medium rounded transition-colors">
          <mat-icon class="!text-[16px] !w-4 !h-4">terminal</mat-icon>
          <span class="hidden sm:inline">R Script / Report</span>
        </button>
      </div>
    </header>
  `
})
export class TopBarComponent {
  public activeTab = input.required<MainNavTab>();
  public dualLayer = input.required<DualLayerMode>();

  public selectTab = output<MainNavTab>();
  public toggleDualLayer = output<DualLayerMode>();
  public openRExport = output<void>();

  public readonly navTabs: { id: MainNavTab; label: string; icon: string }[] = [
    { id: 'digital_twin', label: 'Sensor Twin', icon: 'camera_alt' },
    { id: 'pipeline_lab', label: 'Pipeline Lab', icon: 'tune' },
    { id: 'exposure_iso', label: 'Exposure & ISO', icon: 'exposure' },
    { id: 'optics_lens', label: 'Optics & Lens', icon: 'center_focus_strong' },
    { id: 'colour_science', label: 'Colour Science', icon: 'palette' },
    { id: 'hdr_low_light', label: 'HDR & Low-Light', icon: 'hdr_on' },
    { id: 'computer_vision', label: 'Computer Vision', icon: 'grid_view' },
    { id: 'flight_provenance', label: 'Flight & Lineage', icon: 'flight' },
    { id: 'signature_demos', label: 'Signature Demos', icon: 'science' },
    { id: 'r_engine', label: 'R Engine', icon: 'code' }
  ];
}
