import { Component, ChangeDetectionStrategy, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

export interface SignatureDemoItem {
  id: number;
  title: string;
  subtitle: string;
  icon: string;
  badge: string;
  description: string;
}

@Component({
  selector: 'app-signature-demos',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-[#181C1E] border border-[#252B2D] rounded p-4 text-xs font-mono select-none">
      <div class="flex items-center justify-between mb-3 pb-2 border-b border-[#252B2D]">
        <div class="flex items-center gap-2 text-[#ECE9E0] font-semibold text-sm">
          <mat-icon class="!text-[18px] !w-4.5 !h-4.5 text-[#31483F]">science</mat-icon>
          <span>SPITFIRE SIGNATURE DEMONSTRATION SUITE</span>
        </div>
        <span class="text-[11px] text-[#BFC2BD]/60">6 Guided Aerospace Lab Trials</span>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        @for (demo of demos; track demo.id) {
          <button
            type="button"
            (click)="runDemo(demo.id)"
            class="p-3 bg-[#111416] border border-[#252B2D] hover:border-[#31483F] rounded cursor-pointer transition-all hover:bg-[#252B2D]/30 flex flex-col justify-between group text-left focus:outline-none">
            <div>
              <div class="flex items-start justify-between gap-2 mb-1.5">
                <div class="flex items-center gap-1.5 text-[#ECE9E0] font-bold group-hover:text-[#31483F] transition-colors">
                  <mat-icon class="!text-[16px] !w-4 !h-4 text-[#3D6A7D]">{{ demo.icon }}</mat-icon>
                  <span>{{ demo.title }}</span>
                </div>
                <span class="px-1.5 py-0.5 bg-[#252B2D] text-[#BFC2BD] text-[10px] rounded font-mono shrink-0">
                  {{ demo.badge }}
                </span>
              </div>
              <div class="text-[11px] text-[#C1943D] mb-1">{{ demo.subtitle }}</div>
              <p class="text-[11px] text-[#BFC2BD]/70 leading-relaxed">
                {{ demo.description }}
              </p>
            </div>

            <div class="mt-3 pt-2 border-t border-[#252B2D]/60 flex items-center justify-between text-[11px] text-[#31483F] font-semibold group-hover:text-[#ECE9E0]">
              <span>EXECUTE TRIAL #0{{ demo.id }}</span>
              <mat-icon class="!text-[14px] !w-3.5 !h-3.5">play_arrow</mat-icon>
            </div>
          </button>
        }
      </div>
    </div>
  `
})
export class SignatureDemosComponent {
  public triggerDemo = output<number>();

  public readonly demos: SignatureDemoItem[] = [
    {
      id: 1,
      title: 'Demo 1: Sensor Characterisation',
      subtitle: 'ISO 100 → 6400 Noise Sweep & SNR Curves',
      icon: 'insights',
      badge: 'PHYSICS',
      description: 'Generates synthetic sensor response across 7 ISO levels. Computes read noise, Poisson shot noise, dynamic range degradation, and produces the complete VISION-01 Characterisation Report.'
    },
    {
      id: 2,
      title: 'Demo 2: Lens Optics Lab',
      subtitle: 'Distortion, Vignetting & Chromatic Aberration',
      icon: 'center_focus_strong',
      badge: 'OPTICS',
      description: 'Generates calibration grid, applies radial barrel distortion (k1, k2), optical cos⁴(θ) vignetting falloff, and lateral chromatic fringe. Then corrects all three with residual error vectors.'
    },
    {
      id: 3,
      title: 'Demo 3: Flight Image Step-by-Step',
      subtitle: '11-Stage Inspection from RAW to Output',
      icon: 'linear_scale',
      badge: 'PIPELINE',
      description: 'Captures a real SPITFIRE flight scene over Farnborough runway and exposes all intermediate visual buffers: RAW → Linearise → Bad Pixel → Flat Field → Demosaic → Colour → Denoise → Sharpen.'
    },
    {
      id: 4,
      title: 'Demo 4: Night Flight Low-Light',
      subtitle: 'Computational Multi-Frame Averaging',
      icon: 'bedtime',
      badge: 'COMPUTATION',
      description: 'Simulates extreme low-light photon scarcity (1.5 Lux). Compares single noisy frame against 4-frame temporal alignment and averaging to demonstrate quantitative SNR boost.'
    },
    {
      id: 5,
      title: 'Demo 5: Camera + Flight Provenance',
      subtitle: 'Drone Attitude & Lineage Knowledge Graph',
      icon: 'flight',
      badge: 'LINEAGE',
      description: 'Connects captured aerial photograph to aircraft GPS coordinates, altitude, roll/pitch/yaw, gimbal angle, and reveals the complete computational lineage graph answering "How was this image produced?".'
    },
    {
      id: 6,
      title: 'Demo 6: Digital Sensor Twin',
      subtitle: 'Real-Time Dynamic Multi-Parameter Matrix',
      icon: 'settings_input_component',
      badge: 'DIGITAL TWIN',
      description: 'Simultaneous interactive modulation of ISO, electronic shutter speed, junction temperature, optical aperture, and lens distortion with live pixel and noise response.'
    }
  ];

  public runDemo(id: number): void {
    this.triggerDemo.emit(id);
  }
}
