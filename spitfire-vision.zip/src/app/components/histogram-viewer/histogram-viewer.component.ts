import { Component, ChangeDetectionStrategy, input, computed, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HistogramMode, SpitfireProcessedImage, SpitfireRawFrame } from '../../models/spitfire.models';

@Component({
  selector: 'app-histogram-viewer',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-[#181C1E] border border-[#252B2D] rounded p-3 text-xs font-mono select-none">
      <div class="flex items-center justify-between mb-2 pb-1.5 border-b border-[#252B2D]">
        <div class="flex items-center gap-1.5 text-[#ECE9E0] font-semibold">
          <mat-icon class="!text-[14px] !w-3.5 !h-3.5 text-[#3D6A7D]">bar_chart</mat-icon>
          <span>SPITFIRE HISTOGRAM ENGINE</span>
        </div>

        <div class="flex items-center gap-1 text-[10px]">
          <button
            type="button"
            (click)="setMode('rgb')"
            class="px-1.5 py-0.5 rounded transition-colors"
            [class.bg-[#31483F]]="mode() === 'rgb'"
            [class.text-[#ECE9E0]]="mode() === 'rgb'"
            [class.text-[#BFC2BD]/60]="mode() !== 'rgb'">
            RGB
          </button>
          <button
            type="button"
            (click)="setMode('raw')"
            class="px-1.5 py-0.5 rounded transition-colors"
            [class.bg-[#31483F]]="mode() === 'raw'"
            [class.text-[#ECE9E0]]="mode() === 'raw'"
            [class.text-[#BFC2BD]/60]="mode() !== 'raw'">
            RAW ADU
          </button>
          <button
            type="button"
            (click)="setMode('luminance')"
            class="px-1.5 py-0.5 rounded transition-colors"
            [class.bg-[#31483F]]="mode() === 'luminance'"
            [class.text-[#ECE9E0]]="mode() === 'luminance'"
            [class.text-[#BFC2BD]/60]="mode() !== 'luminance'">
            LUM
          </button>
          <button
            type="button"
            (click)="setMode('cumulative')"
            class="px-1.5 py-0.5 rounded transition-colors"
            [class.bg-[#31483F]]="mode() === 'cumulative'"
            [class.text-[#ECE9E0]]="mode() === 'cumulative'"
            [class.text-[#BFC2BD]/60]="mode() !== 'cumulative'">
            CDF
          </button>
          <button
            type="button"
            (click)="toggleLogScale()"
            class="px-1.5 py-0.5 rounded border transition-colors ml-1"
            [class.border-[#C1943D]]="isLogScale()"
            [class.text-[#C1943D]]="isLogScale()"
            [class.border-[#252B2D]]="!isLogScale()"
            [class.text-[#BFC2BD]/50]="!isLogScale()">
            LOG Y
          </button>
        </div>
      </div>

      <!-- Histogram SVG Canvas -->
      <div class="relative h-28 w-full bg-[#111416] border border-[#252B2D] rounded overflow-hidden">
        <svg class="w-full h-full" preserveAspectRatio="none" viewBox="0 0 256 100">
          <defs>
            <linearGradient id="rGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stop-color="#A3433C" stop-opacity="0.6"/>
              <stop offset="100%" stop-color="#A3433C" stop-opacity="0.05"/>
            </linearGradient>
            <linearGradient id="gGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stop-color="#31483F" stop-opacity="0.6"/>
              <stop offset="100%" stop-color="#31483F" stop-opacity="0.05"/>
            </linearGradient>
            <linearGradient id="bGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stop-color="#3D6A7D" stop-opacity="0.6"/>
              <stop offset="100%" stop-color="#3D6A7D" stop-opacity="0.05"/>
            </linearGradient>
            <linearGradient id="rawGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stop-color="#C1943D" stop-opacity="0.7"/>
              <stop offset="100%" stop-color="#C1943D" stop-opacity="0.05"/>
            </linearGradient>
          </defs>

          <!-- Grid Lines -->
          <line x1="64" y1="0" x2="64" y2="100" stroke="#252B2D" stroke-dasharray="2 2" stroke-width="0.8"/>
          <line x1="128" y1="0" x2="128" y2="100" stroke="#252B2D" stroke-dasharray="2 2" stroke-width="0.8"/>
          <line x1="192" y1="0" x2="192" y2="100" stroke="#252B2D" stroke-dasharray="2 2" stroke-width="0.8"/>
          <line x1="0" y1="50" x2="256" y2="50" stroke="#252B2D" stroke-dasharray="2 2" stroke-width="0.8"/>

          @if (mode() === 'rgb') {
            <path [attr.d]="rPath()" fill="url(#rGrad)" stroke="#A3433C" stroke-width="1.2" opacity="0.85"/>
            <path [attr.d]="gPath()" fill="url(#gGrad)" stroke="#4E7E6A" stroke-width="1.2" opacity="0.85"/>
            <path [attr.d]="bPath()" fill="url(#bGrad)" stroke="#3D6A7D" stroke-width="1.2" opacity="0.85"/>
          } @else if (mode() === 'raw') {
            <path [attr.d]="rawPath()" fill="url(#rawGrad)" stroke="#C1943D" stroke-width="1.2"/>
          } @else if (mode() === 'luminance') {
            <path [attr.d]="lumPath()" fill="none" stroke="#ECE9E0" stroke-width="1.5"/>
          } @else if (mode() === 'cumulative') {
            <path [attr.d]="cdfPath()" fill="none" stroke="#3D6A7D" stroke-width="2"/>
          }
        </svg>

        <!-- Clipping markers -->
        @if (highlightClip() > 0.5) {
          <div class="absolute top-1 right-1 px-1 py-0.2 bg-[#A3433C]/80 text-[#ECE9E0] text-[9px] rounded font-bold">
            CLIP: {{ highlightClip() | number:'1.1-1' }}%
          </div>
        }
        @if (shadowClip() > 0.5) {
          <div class="absolute top-1 left-1 px-1 py-0.2 bg-[#252B2D]/80 text-[#C1943D] text-[9px] rounded">
            SHADOW: {{ shadowClip() | number:'1.1-1' }}%
          </div>
        }
      </div>

      <!-- X-Axis Labels -->
      <div class="flex justify-between items-center text-[10px] text-[#BFC2BD]/50 mt-1">
        <span>0 {{ mode() === 'raw' ? 'ADU (Black 512)' : 'Min' }}</span>
        <span>{{ mode() === 'raw' ? '8192 ADU' : 'Mid (18% Grey)' }}</span>
        <span>{{ mode() === 'raw' ? '16383 ADU (Sat)' : '255 Saturation' }}</span>
      </div>
    </div>
  `
})
export class HistogramViewerComponent {
  public rawFrame = input<SpitfireRawFrame | null>(null);
  public processedImage = input<SpitfireProcessedImage | null>(null);

  public mode = signal<HistogramMode>('rgb');
  public isLogScale = signal<boolean>(false);

  public highlightClip = computed(() => this.processedImage()?.metrics.highlightClippingPct ?? 0);
  public shadowClip = computed(() => this.processedImage()?.metrics.shadowClippingPct ?? 0);

  public setMode(m: HistogramMode): void {
    this.mode.set(m);
  }

  public toggleLogScale(): void {
    this.isLogScale.update(v => !v);
  }

  public rPath = computed(() => this.generateChannelPath(0));
  public gPath = computed(() => this.generateChannelPath(1));
  public bPath = computed(() => this.generateChannelPath(2));
  public lumPath = computed(() => this.generateLuminancePath());
  public cdfPath = computed(() => this.generateCdfPath());
  public rawPath = computed(() => this.generateRawPath());

  private generateChannelPath(channelIdx: number): string {
    const img = this.processedImage();
    if (!img) return 'M 0 100 L 256 100';

    const bins = new Uint32Array(256);
    const data = img.rgbaData.data;
    for (let i = 0; i < data.length; i += 4) {
      bins[data[i + channelIdx]]++;
    }

    return this.buildSvgPath(bins);
  }

  private generateLuminancePath(): string {
    const img = this.processedImage();
    if (!img) return 'M 0 100 L 256 100';

    const bins = new Uint32Array(256);
    const data = img.rgbaData.data;
    for (let i = 0; i < data.length; i += 4) {
      const lum = Math.round(0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2]);
      bins[Math.min(255, lum)]++;
    }

    return this.buildSvgPath(bins);
  }

  private generateCdfPath(): string {
    const img = this.processedImage();
    if (!img) return 'M 0 100 L 256 0';

    const bins = new Uint32Array(256);
    const data = img.rgbaData.data;
    for (let i = 0; i < data.length; i += 4) {
      const lum = Math.round(0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2]);
      bins[Math.min(255, lum)]++;
    }

    let cum = 0;
    const total = data.length / 4;
    let path = 'M 0 100 ';
    for (let x = 0; x < 256; x++) {
      cum += bins[x];
      const y = 100 - (cum / total) * 100;
      path += `L ${x} ${y.toFixed(1)} `;
    }
    return path;
  }

  private generateRawPath(): string {
    const raw = this.rawFrame();
    if (!raw) return 'M 0 100 L 256 100';

    const bins = new Uint32Array(256);
    const rawArray = raw.rawArray;
    for (const val of rawArray) {
      const bin = Math.min(255, Math.floor((val / 16383) * 256));
      bins[bin]++;
    }

    return this.buildSvgPath(bins);
  }

  private buildSvgPath(bins: Uint32Array): string {
    let max = 1;
    for (let i = 0; i < 256; i++) {
      if (bins[i] > max) max = bins[i];
    }

    const isLog = this.isLogScale();
    const logMax = Math.log(max + 1);

    let path = 'M 0 100 ';
    for (let x = 0; x < 256; x++) {
      const val = bins[x];
      const norm = isLog ? Math.log(val + 1) / logMax : val / max;
      const y = 100 - Math.min(100, norm * 96);
      path += `L ${x} ${y.toFixed(1)} `;
    }
    path += 'L 255 100 Z';
    return path;
  }
}
