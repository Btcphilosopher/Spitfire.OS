import { Component, ChangeDetectionStrategy, input, output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-r-package-modal',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div class="bg-[#181C1E] border border-[#252B2D] rounded-lg w-full max-w-4xl max-h-[88vh] flex flex-col shadow-2xl font-mono text-xs">
        <!-- Modal Header -->
        <div class="p-4 border-b border-[#252B2D] flex items-center justify-between bg-[#111416]">
          <div class="flex items-center gap-2.5">
            <div class="w-7 h-7 bg-[#31483F] border border-[#BFC2BD]/30 rounded flex items-center justify-center text-[#ECE9E0] font-bold">
              R
            </div>
            <div>
              <div class="text-sm font-bold text-[#ECE9E0]">spitfireVision R PACKAGE & EXPORTS</div>
              <div class="text-[10px] text-[#BFC2BD]/60">Aerospace Computational Imaging Laboratory Platform</div>
            </div>
          </div>

          <div class="flex items-center gap-2">
            <button
              type="button"
              (click)="activeTab.set('r_script')"
              class="px-2.5 py-1 rounded transition-colors"
              [class.bg-[#31483F]]="activeTab() === 'r_script'"
              [class.text-[#ECE9E0]]="activeTab() === 'r_script'"
              [class.text-[#BFC2BD]/60]="activeTab() !== 'r_script'">
              Active R Script
            </button>
            <button
              type="button"
              (click)="activeTab.set('package_tree')"
              class="px-2.5 py-1 rounded transition-colors"
              [class.bg-[#31483F]]="activeTab() === 'package_tree'"
              [class.text-[#ECE9E0]]="activeTab() === 'package_tree'"
              [class.text-[#BFC2BD]/60]="activeTab() !== 'package_tree'">
              Package Files
            </button>
            <button
              type="button"
              (click)="activeTab.set('report')"
              class="px-2.5 py-1 rounded transition-colors"
              [class.bg-[#31483F]]="activeTab() === 'report'"
              [class.text-[#ECE9E0]]="activeTab() === 'report'"
              [class.text-[#BFC2BD]/60]="activeTab() !== 'report'">
              VISION-01 Report
            </button>
            <button
              type="button"
              (click)="dismissModal.emit()"
              class="p-1 hover:bg-[#252B2D] text-[#BFC2BD] hover:text-[#ECE9E0] rounded ml-2">
              <mat-icon class="!text-[18px] !w-4.5 !h-4.5">close</mat-icon>
            </button>
          </div>
        </div>

        <!-- Modal Body Content -->
        <div class="flex-1 overflow-y-auto p-4 bg-[#111416]">
          @if (activeTab() === 'r_script') {
            <div class="space-y-3">
              <div class="flex items-center justify-between text-[11px] text-[#BFC2BD]/70">
                <span>Reproducible R Pipeline Script (spitfireVision v1.0.0):</span>
                <button
                  type="button"
                  (click)="copyToClipboard(rScript())"
                  class="flex items-center gap-1 px-2.5 py-1 bg-[#252B2D] hover:bg-[#31483F] text-[#ECE9E0] rounded transition-colors text-[10px]">
                  <mat-icon class="!text-[12px] !w-3 !h-3">content_copy</mat-icon>
                  <span>{{ copyStatus() }}</span>
                </button>
              </div>

              <pre class="p-3 bg-[#0A0C0E] border border-[#252B2D] rounded text-[11px] text-[#ECE9E0] overflow-x-auto leading-relaxed max-h-[50vh] selection:bg-[#31483F]"><code>{{ rScript() }}</code></pre>
            </div>
          } @else if (activeTab() === 'package_tree') {
            <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
              <!-- Left list of package files -->
              <div class="bg-[#0A0C0E] border border-[#252B2D] rounded p-2 space-y-1">
                <div class="text-[10px] uppercase text-[#BFC2BD]/50 font-bold mb-2 px-1">Package Structure</div>
                @for (f of packageFiles; track f.path) {
                  <button
                    type="button"
                    (click)="selectedFile.set(f)"
                    class="w-full text-left px-2 py-1.5 rounded text-[11px] transition-colors flex items-center justify-between"
                    [class.bg-[#31483F]]="selectedFile().path === f.path"
                    [class.text-[#ECE9E0]]="selectedFile().path === f.path"
                    [class.text-[#BFC2BD]/70]="selectedFile().path !== f.path"
                    [class.hover:bg-[#252B2D]]="selectedFile().path !== f.path">
                    <span>{{ f.path }}</span>
                    <span class="text-[9px] opacity-60">{{ f.type }}</span>
                  </button>
                }
              </div>

              <!-- Right preview of selected package file -->
              <div class="md:col-span-2 bg-[#0A0C0E] border border-[#252B2D] rounded p-3 overflow-x-auto max-h-[50vh]">
                <div class="text-[11px] text-[#C1943D] font-bold mb-2 pb-1 border-b border-[#252B2D]">
                  {{ selectedFile().path }}
                </div>
                <pre class="text-[11px] text-[#ECE9E0] leading-relaxed"><code>{{ selectedFile().content }}</code></pre>
              </div>
            </div>
          } @else {
            <div class="space-y-3">
              <div class="flex items-center justify-between text-[11px] text-[#BFC2BD]/70">
                <span>Formal Sensor Characterisation Document:</span>
                <button
                  type="button"
                  (click)="downloadReportFile()"
                  class="flex items-center gap-1 px-3 py-1 bg-[#31483F] hover:bg-[#31483F]/80 text-[#ECE9E0] rounded transition-colors text-[10px]">
                  <mat-icon class="!text-[14px] !w-3.5 !h-3.5">download</mat-icon>
                  <span>Download Report (TXT/MD)</span>
                </button>
              </div>

              <pre class="p-3 bg-[#0A0C0E] border border-[#252B2D] rounded text-[11px] text-[#ECE9E0] overflow-x-auto leading-relaxed max-h-[50vh]"><code>{{ characterisationReport() }}</code></pre>
            </div>
          }
        </div>

        <!-- Modal Footer -->
        <div class="p-3 border-t border-[#252B2D] bg-[#181C1E] flex items-center justify-between">
          <div class="text-[10px] text-[#BFC2BD]/50">
            "THE SENSOR IS THE INSTRUMENT. THE IMAGE IS THE MEASUREMENT."
          </div>
          <button
            type="button"
            (click)="dismissModal.emit()"
            class="px-4 py-1.5 bg-[#252B2D] hover:bg-[#31483F] text-[#ECE9E0] rounded transition-colors text-xs font-semibold">
            Close Workbench Drawer
          </button>
        </div>
      </div>
    </div>
  `
})
export class RPackageModalComponent {
  public rScript = input.required<string>();
  public characterisationReport = input.required<string>();
  public dismissModal = output<void>();

  public activeTab = signal<'r_script' | 'package_tree' | 'report'>('r_script');
  public copyStatus = signal<string>('Copy R Script');

  public readonly packageFiles = [
    {
      path: 'spitfireVision/DESCRIPTION',
      type: 'METADATA',
      content: `Package: spitfireVision\nType: Package\nTitle: Computational Imaging Sensor & Science Platform\nVersion: 1.0.0\nDepends: R (>= 4.2.0)\nImports: Matrix, stats, graphics, grDevices, methods\nSuggests: testthat, knitr, rmarkdown`
    },
    {
      path: 'spitfireVision/NAMESPACE',
      type: 'EXPORTS',
      content: `export(spitfire_sensor)\nexport(spitfire_lens)\nexport(spitfire_capture)\nexport(spitfire_pipeline)\nexport(run_pipeline)\nexport(spitfire_characterisation_report)\nexportClasses(SpitfireSensor, SpitfireLens, SpitfireRawFrame, SpitfireImage)`
    },
    {
      path: 'spitfireVision/R/spitfire_sensor.R',
      type: 'PHYSICS',
      content: `spitfire_sensor <- function(model = "VISION-01", width = 8192, height = 6144, pixel_pitch_um = 3.2, bit_depth = 14, iso = 100, temperature_c = 38.5) {\n  gain <- iso / 100.0\n  read_noise_e <- 1.8 * sqrt(1.0 + (gain - 1.0) * 0.15)\n  dark_current_e_s <- 0.5 * (2.0 ^ ((temperature_c - 20.0) / 6.0))\n  new("SpitfireSensor", model = model, width = width, height = height, pixel_pitch_um = pixel_pitch_um, bit_depth = bit_depth, iso = iso, gain = gain, read_noise_e = read_noise_e, dark_current_e_s = dark_current_e_s)\n}`
    },
    {
      path: 'spitfireVision/R/spitfire_pipeline.R',
      type: 'PIPELINE',
      content: `pipe <- spitfire_pipeline() |>\n  black_level(512) |>\n  linearise() |>\n  bad_pixel_correct(threshold_sigma = 4.0) |>\n  demosaic(method = "edge_aware") |>\n  white_balance(mode = "daylight") |>\n  colour_transform("srgb") |>\n  denoise("bilateral") |>\n  sharpen("unsharp_mask")\n\nresult <- run_pipeline(raw, pipe)`
    },
    {
      path: 'spitfireVision/tests/testthat/test_sensor.R',
      type: 'TESTS',
      content: `library(testthat)\ntest_that("SpitfireSensor initializes with valid parameters", {\n  sensor <- spitfire_sensor(width = 8192, height = 6144, iso = 100)\n  expect_equal(sensor@width, 8192)\n  expect_equal(sensor@cfa_pattern, "RGGB")\n})`
    }
  ];

  public selectedFile = signal(this.packageFiles[0]);

  public copyToClipboard(text: string): void {
    navigator.clipboard.writeText(text);
    this.copyStatus.set('Copied to Clipboard!');
    setTimeout(() => this.copyStatus.set('Copy R Script'), 2500);
  }

  public downloadReportFile(): void {
    const text = this.characterisationReport();
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SPITFIRE-VISION-01-REPORT-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
