import { Component, ChangeDetectionStrategy, input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PixelInspection } from '../../models/spitfire.models';

@Component({
  selector: 'app-pixel-inspector',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-[#181C1E] border border-[#252B2D] rounded p-3 text-xs font-mono select-none">
      <div class="flex items-center justify-between mb-2 pb-1.5 border-b border-[#252B2D]">
        <div class="flex items-center gap-1.5 text-[#ECE9E0] font-semibold">
          <mat-icon class="!text-[14px] !w-3.5 !h-3.5 text-[#31483F]">colorize</mat-icon>
          <span>SPITFIRE PIXEL PROBE</span>
        </div>
        @if (inspection()) {
          <span class="text-[10px] text-[#C1943D] font-mono">
            X:{{ inspection()!.x }} Y:{{ inspection()!.y }}
          </span>
        } @else {
          <span class="text-[10px] text-[#BFC2BD]/40">HOVER / CLICK CANVAS</span>
        }
      </div>

      @if (inspection()) {
        @let px = inspection()!;
        <div class="grid grid-cols-2 gap-2 text-[11px]">
          <!-- Left Column: Raw & Sensor Physics -->
          <div class="space-y-1.5 bg-[#111416] p-2 rounded border border-[#252B2D]">
            <div class="text-[10px] uppercase text-[#BFC2BD]/50 font-bold border-b border-[#252B2D] pb-0.5">
              Sensor Physical Measurement
            </div>
            <div class="flex justify-between">
              <span class="text-[#BFC2BD]/70">CFA Channel:</span>
              <span class="font-bold" [class.text-[#A3433C]]="px.cfaChannel === 'R'" [class.text-[#31483F]]="px.cfaChannel === 'Gr' || px.cfaChannel === 'Gb'" [class.text-[#3D6A7D]]="px.cfaChannel === 'B'">
                {{ px.cfaChannel }} (Bayer)
              </span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#BFC2BD]/70">14-bit RAW:</span>
              <span class="text-[#C1943D] font-bold">{{ px.rawAdu }} ADU</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#BFC2BD]/70">Linearised:</span>
              <span>{{ px.normalizedRaw | number:'1.4-4' }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#BFC2BD]/70">Est. Noise:</span>
              <span class="text-[#ECE9E0]">{{ px.estimatedNoiseE | number:'1.1-1' }} e⁻</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#BFC2BD]/70">Depth Dist:</span>
              <span class="text-[#3D6A7D]">{{ px.depthValueM | number:'1.1-1' }} m</span>
            </div>
          </div>

          <!-- Right Column: Computed Image & Local Neighborhood -->
          <div class="space-y-1.5 bg-[#111416] p-2 rounded border border-[#252B2D]">
            <div class="text-[10px] uppercase text-[#BFC2BD]/50 font-bold border-b border-[#252B2D] pb-0.5">
              Computed Representation
            </div>
            <div class="flex items-center justify-between">
              <span class="text-[#BFC2BD]/70">Display RGB:</span>
              <div class="flex items-center gap-1">
                <span class="w-2.5 h-2.5 rounded-full border border-white/20 inline-block" [style.background-color]="'rgb(' + px.displayRgb[0] + ',' + px.displayRgb[1] + ',' + px.displayRgb[2] + ')'"></span>
                <span>{{ px.displayRgb[0] }}, {{ px.displayRgb[1] }}, {{ px.displayRgb[2] }}</span>
              </div>
            </div>
            <div class="flex justify-between">
              <span class="text-[#BFC2BD]/70">5x5 Mean:</span>
              <span>{{ px.localMean | number:'1.3-3' }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#BFC2BD]/70">5x5 Local SD:</span>
              <span>{{ px.localSd | number:'1.4-4' }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#BFC2BD]/70">Edge Gradient:</span>
              <span class="text-[#31483F] font-semibold">{{ px.localGradient | number:'1.2-2' }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#BFC2BD]/70">Pedestal Sub:</span>
              <span>-512 ADU</span>
            </div>
          </div>
        </div>
      } @else {
        <div class="h-24 flex flex-col items-center justify-center text-center text-[#BFC2BD]/40 text-xs gap-1">
          <mat-icon class="!text-[20px] !w-5 !h-5">mouse</mat-icon>
          <span>Move cursor across the central image canvas to inspect individual 14-bit CMOS pixels.</span>
        </div>
      }
    </div>
  `
})
export class PixelInspectorComponent {
  public inspection = input<PixelInspection | null>(null);
}
