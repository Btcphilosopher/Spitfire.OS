import {
  Component,
  ChangeDetectionStrategy,
  signal,
  computed,
  inject,
  OnInit,
  ElementRef,
  viewChild,
  effect
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TopBarComponent, MainNavTab } from './components/top-bar/top-bar.component';
import { HistogramViewerComponent } from './components/histogram-viewer/histogram-viewer.component';
import { PixelInspectorComponent } from './components/pixel-inspector/pixel-inspector.component';
import { SignatureDemosComponent } from './components/signature-demos/signature-demos.component';
import { AbCompareComponent } from './components/ab-compare/ab-compare.component';
import { LineageGraphComponent } from './components/lineage-graph/lineage-graph.component';
import { RPackageModalComponent } from './components/r-package-modal/r-package-modal.component';
import { SceneGeneratorService } from './services/scene-generator.service';
import { SensorPhysicsService } from './services/sensor-physics.service';
import { ImagePipelineService } from './services/image-pipeline.service';
import { FlightTelemetryService } from './services/flight-telemetry.service';
import { RBridgeService } from './services/r-bridge.service';
import {
  ColourSpace,
  DemosaicMethod,
  DenoiseMethod,
  DualLayerMode,
  FalseColourMode,
  PixelInspection,
  PipelineState,
  SceneId,
  SharpenMethod,
  SpitfireExposureConfig,
  SpitfireFlightContext,
  SpitfireLensConfig,
  SpitfireProcessedImage,
  SpitfireRawFrame,
  SpitfireSensorConfig,
  ToneCurveMode,
  WhiteBalanceMode
} from './models/spitfire.models';

export type ViewLayerType = 'final_output' | 'raw_cfa' | 'linear_response' | 'false_colour' | 'ab_compare' | 'stage_buffer' | 'stereo_depth' | 'edge_map';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    TopBarComponent,
    HistogramViewerComponent,
    PixelInspectorComponent,
    SignatureDemosComponent,
    AbCompareComponent,
    LineageGraphComponent,
    RPackageModalComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements OnInit {
  private sceneGen = inject(SceneGeneratorService);
  private physics = inject(SensorPhysicsService);
  private pipelineService = inject(ImagePipelineService);
  private telemetry = inject(FlightTelemetryService);
  private rBridge = inject(RBridgeService);

  // Canvas Viewport reference
  public mainCanvas = viewChild<ElementRef<HTMLCanvasElement>>('mainCanvas');

  // Navigation & Layer State
  public activeTab = signal<MainNavTab>('digital_twin');
  public dualLayer = signal<DualLayerMode>('physical_sensor');
  public showRModal = signal<boolean>(false);

  // Simulation Configurations
  public currentSceneId = signal<SceneId>('daylight_survey');
  public sensorConfig = signal<SpitfireSensorConfig>(this.physics.getDefaultSensor());
  public lensConfig = signal<SpitfireLensConfig>(this.physics.getDefaultLens());
  public exposureConfig = signal<SpitfireExposureConfig>(this.physics.getDefaultExposure());
  public pipelineConfig = signal<PipelineState>(this.pipelineService.getDefaultPipelineState());

  // Viewport Display Mode & Zoom
  public viewLayer = signal<ViewLayerType>('final_output');
  public falseColourMode = signal<FalseColourMode>('none');
  public previewBufferKey = signal<string>('output');
  public zoomLevel = signal<number>(1);
  public activeCvEdge = signal<'sobel' | 'canny' | 'scharr' | 'laplacian'>('sobel');

  // Data Frames
  public currentRawFrame = signal<SpitfireRawFrame | null>(null);
  public currentProcessedImage = signal<SpitfireProcessedImage | null>(null);
  public pixelInspection = signal<PixelInspection | null>(null);
  public flightContext = signal<SpitfireFlightContext>(this.telemetry.getCurrentFlightContext());
  public historicalFlights = signal(this.telemetry.getHistoricalFlights());
  public cameraHealth = signal(this.telemetry.getCameraHealth());

  // Available scenes list
  public availableScenes = this.sceneGen.availableScenes;

  // Active R script text
  public activeRScript = computed(() => {
    const scene = this.availableScenes.find(s => s.id === this.currentSceneId())?.name || 'Daylight Survey';
    return this.rBridge.generateRScript(
      this.sensorConfig(),
      this.lensConfig(),
      this.exposureConfig(),
      this.pipelineConfig(),
      scene
    );
  });

  // Characterisation Report Text
  public activeReportText = computed(() => {
    const img = this.currentProcessedImage();
    if (!img) return 'Capturing frame...';
    return this.rBridge.generateCharacterisationReportText(
      this.sensorConfig(),
      this.lensConfig(),
      img
    );
  });

  constructor() {
    effect(() => {
      const raw = this.currentRawFrame();
      const img = this.currentProcessedImage();
      const layer = this.viewLayer();
      const fc = this.falseColourMode();
      const bufKey = this.previewBufferKey();
      const edge = this.activeCvEdge();
      const canvasEl = this.mainCanvas()?.nativeElement;

      if (canvasEl && raw && img) {
        this.renderCanvas(canvasEl, raw, img, layer, fc, bufKey, edge);
      }
    });
  }

  ngOnInit(): void {
    this.executeSimulation();
  }

  public executeSimulation(seed = 20260926): void {
    const groundTruth = this.sceneGen.generateSceneGroundTruth(this.currentSceneId(), 512, 384);
    const raw = this.physics.simulateRawCapture(
      groundTruth,
      this.sensorConfig(),
      this.lensConfig(),
      this.exposureConfig(),
      seed
    );
    this.currentRawFrame.set(raw);

    const processed = this.pipelineService.executePipeline(
      raw,
      this.pipelineConfig(),
      this.flightContext().flightId,
      this.flightContext().missionId
    );
    this.currentProcessedImage.set(processed);

    this.inspectPixelAt(Math.floor(raw.width / 2), Math.floor(raw.height / 2));
  }

  private renderCanvas(
    canvas: HTMLCanvasElement,
    raw: SpitfireRawFrame,
    img: SpitfireProcessedImage,
    layer: string,
    falseColour: FalseColourMode,
    stageKey: string,
    cvEdge: string
  ): void {
    canvas.width = raw.width;
    canvas.height = raw.height;
    const ctx = canvas.getContext('2d', { willReadFrequently: true })!;

    if (layer === 'stage_buffer') {
      const stageImg = img.intermediateStageImages.get(stageKey) || img.rgbaData;
      ctx.putImageData(stageImg, 0, 0);
      return;
    }

    if (layer === 'raw_cfa') {
      const cfaImgData = ctx.createImageData(raw.width, raw.height);
      const rawArray = raw.rawArray;
      for (let y = 0; y < raw.height; y++) {
        const isOddRow = y % 2 === 1;
        for (let x = 0; x < raw.width; x++) {
          const isOddCol = x % 2 === 1;
          const idx = (y * raw.width + x);
          const val = Math.min(255, Math.floor((rawArray[idx] / 16383) * 255));
          const outIdx = idx * 4;

          if (!isOddRow && !isOddCol) {
            cfaImgData.data[outIdx] = val;
            cfaImgData.data[outIdx + 1] = 0;
            cfaImgData.data[outIdx + 2] = 0;
          } else if ((!isOddRow && isOddCol) || (isOddRow && !isOddCol)) {
            cfaImgData.data[outIdx] = 0;
            cfaImgData.data[outIdx + 1] = val;
            cfaImgData.data[outIdx + 2] = 0;
          } else {
            cfaImgData.data[outIdx] = 0;
            cfaImgData.data[outIdx + 1] = 0;
            cfaImgData.data[outIdx + 2] = val;
          }
          cfaImgData.data[outIdx + 3] = 255;
        }
      }
      ctx.putImageData(cfaImgData, 0, 0);
      return;
    }

    if (layer === 'linear_response') {
      const linImg = img.intermediateStageImages.get('linearisation') || img.rgbaData;
      ctx.putImageData(linImg, 0, 0);
      return;
    }

    if (layer === 'stereo_depth') {
      const depthData = raw.groundTruth.depthData;
      const depthImg = ctx.createImageData(raw.width, raw.height);
      for (let i = 0; i < depthData.length; i++) {
        const d = depthData[i];
        const normD = Math.max(0, Math.min(1.0, 1.0 - (d / 350.0)));
        depthImg.data[i * 4] = Math.round(normD * 255);
        depthImg.data[i * 4 + 1] = Math.round(Math.sin(normD * Math.PI) * 255);
        depthImg.data[i * 4 + 2] = Math.round((1.0 - normD) * 255);
        depthImg.data[i * 4 + 3] = 255;
      }
      ctx.putImageData(depthImg, 0, 0);
      return;
    }

    if (layer === 'edge_map') {
      const data = img.rgbaData.data;
      const edgeImg = ctx.createImageData(raw.width, raw.height);
      const w = raw.width;
      const h = raw.height;

      for (let y = 1; y < h - 1; y++) {
        for (let x = 1; x < w - 1; x++) {
          const getL = (ox: number, oy: number) => {
            const idx = ((y + oy) * w + (x + ox)) * 4;
            return 0.2126 * data[idx] + 0.7152 * data[idx + 1] + 0.0722 * data[idx + 2];
          };

          let grad = 0;
          if (cvEdge === 'sobel' || cvEdge === 'scharr') {
            const gx = (-1 * getL(-1, -1) + 1 * getL(1, -1) - 2 * getL(-1, 0) + 2 * getL(1, 0) - 1 * getL(-1, 1) + 1 * getL(1, 1));
            const gy = (-1 * getL(-1, -1) - 2 * getL(0, -1) - 1 * getL(1, -1) + 1 * getL(-1, 1) + 2 * getL(0, 1) + 1 * getL(1, 1));
            grad = Math.min(255, Math.sqrt(gx * gx + gy * gy) * 1.5);
          } else if (cvEdge === 'laplacian') {
            const lap = Math.abs(4 * getL(0, 0) - getL(0, -1) - getL(0, 1) - getL(-1, 0) - getL(1, 0));
            grad = Math.min(255, lap * 3.0);
          } else {
            const gx = (getL(1, 0) - getL(-1, 0));
            const gy = (getL(0, 1) - getL(0, -1));
            const mag = Math.sqrt(gx * gx + gy * gy);
            grad = mag > 25 ? 255 : 0;
          }

          const outIdx = (y * w + x) * 4;
          edgeImg.data[outIdx] = grad > 0 ? 49 : 17;
          edgeImg.data[outIdx + 1] = grad > 0 ? 255 : 20;
          edgeImg.data[outIdx + 2] = grad > 0 ? 120 : 22;
          edgeImg.data[outIdx + 3] = 255;
        }
      }
      ctx.putImageData(edgeImg, 0, 0);
      return;
    }

    if (falseColour !== 'none') {
      const fcImg = ctx.createImageData(raw.width, raw.height);
      const data = img.rgbaData.data;

      for (let i = 0; i < data.length; i += 4) {
        const lum = (0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2]) / 255.0;

        if (falseColour === 'intensity_heatmap') {
          fcImg.data[i] = Math.round(Math.min(255, lum * 350));
          fcImg.data[i + 1] = Math.round(Math.sin(lum * Math.PI) * 255);
          fcImg.data[i + 2] = Math.round(Math.max(0, (1 - lum * 1.8) * 255));
        } else if (falseColour === 'exposure_clipping') {
          if (lum < 0.02) {
            fcImg.data[i] = 30;
            fcImg.data[i + 1] = 90;
            fcImg.data[i + 2] = 255;
          } else if (lum > 0.98) {
            fcImg.data[i] = 255;
            fcImg.data[i + 1] = 20;
            fcImg.data[i + 2] = 20;
          } else {
            const g = Math.round(lum * 180);
            fcImg.data[i] = g;
            fcImg.data[i + 1] = g;
            fcImg.data[i + 2] = g;
          }
        } else if (falseColour === 'snr_noise_map') {
          const noiseLum = Math.sin((i / 4) * 0.1) * (this.sensorConfig().iso / 6400.0);
          fcImg.data[i] = Math.round(Math.min(255, (lum + noiseLum) * 255));
          fcImg.data[i + 1] = Math.round(lum * 120);
          fcImg.data[i + 2] = Math.round((1.0 - lum) * 200);
        } else if (falseColour === 'thermal_flux') {
          const px = (i / 4) % raw.width;
          const py = Math.floor((i / 4) / raw.width);
          const dx = (px - raw.width / 2) / (raw.width / 2);
          const dy = (py - raw.height / 2) / (raw.height / 2);
          const r = Math.sqrt(dx * dx + dy * dy);
          const tempGrad = Math.max(0, 1.0 - r * 0.8) * (this.sensorConfig().temperatureC / 65.0);

          fcImg.data[i] = Math.round(tempGrad * 255);
          fcImg.data[i + 1] = Math.round((1 - tempGrad) * 100);
          fcImg.data[i + 2] = 80;
        } else {
          fcImg.data[i] = data[i];
          fcImg.data[i + 1] = data[i + 1];
          fcImg.data[i + 2] = data[i + 2];
        }
        fcImg.data[i + 3] = 255;
      }
      ctx.putImageData(fcImg, 0, 0);
      return;
    }

    ctx.putImageData(img.rgbaData, 0, 0);
  }

  public onCanvasMouseMove(event: MouseEvent): void {
    const canvas = this.mainCanvas()?.nativeElement;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const x = Math.floor((event.clientX - rect.left) * scaleX);
    const y = Math.floor((event.clientY - rect.top) * scaleY);

    if (x >= 0 && x < canvas.width && y >= 0 && y < canvas.height) {
      this.inspectPixelAt(x, y);
    }
  }

  private inspectPixelAt(x: number, y: number): void {
    const raw = this.currentRawFrame();
    const img = this.currentProcessedImage();
    if (!raw || !img) return;

    const idx = y * raw.width + x;
    const rawAdu = raw.rawArray[idx] || 0;
    const norm = raw.normalizedArray[idx] || 0;

    const isOddRow = y % 2 === 1;
    const isOddCol = x % 2 === 1;
    let channel: 'R' | 'Gr' | 'Gb' | 'B';
    if (!isOddRow && !isOddCol) channel = 'R';
    else if (!isOddRow && isOddCol) channel = 'Gr';
    else if (isOddRow && !isOddCol) channel = 'Gb';
    else channel = 'B';

    const rgba = img.rgbaData.data;
    const r = rgba[idx * 4] || 0;
    const g = rgba[idx * 4 + 1] || 0;
    const b = rgba[idx * 4 + 2] || 0;

    let sum = 0;
    let sumSq = 0;
    let count = 0;
    for (let dy = -2; dy <= 2; dy++) {
      for (let dx = -2; dx <= 2; dx++) {
        const nx = x + dx;
        const ny = y + dy;
        if (nx >= 0 && nx < raw.width && ny >= 0 && ny < raw.height) {
          const nIdx = (ny * raw.width + nx) * 4;
          const lum = (0.2126 * rgba[nIdx] + 0.7152 * rgba[nIdx + 1] + 0.0722 * rgba[nIdx + 2]) / 255.0;
          sum += lum;
          sumSq += lum * lum;
          count++;
        }
      }
    }
    const localMean = sum / count;
    const localSd = Math.sqrt(Math.max(0, (sumSq / count) - (localMean * localMean)));

    const gx = (x < raw.width - 1 && x > 0)
      ? Math.abs(rgba[idx * 4 + 4] - rgba[idx * 4 - 4])
      : 0;
    const gy = (y < raw.height - 1 && y > 0)
      ? Math.abs(rgba[(idx + raw.width) * 4] - rgba[(idx - raw.width) * 4])
      : 0;
    const localGradient = (gx + gy) / 2.0;

    const gain = this.sensorConfig().iso / 100.0;
    const estimatedNoiseE = Math.sqrt(Math.max(1, rawAdu / 5.0) + Math.pow(this.sensorConfig().readNoiseE * gain, 2));
    const depthValueM = raw.groundTruth.depthData[idx] || 25.0;

    this.pixelInspection.set({
      x,
      y,
      rawAdu,
      normalizedRaw: norm,
      cfaChannel: channel,
      displayRgb: [r, g, b],
      linearRgb: [r / 255.0, g / 255.0, b / 255.0],
      localMean,
      localSd,
      localGradient,
      estimatedNoiseE,
      depthValueM
    });
  }

  public setScene(id: SceneId): void {
    this.currentSceneId.set(id);
    this.executeSimulation();
  }

  public setIso(iso: number): void {
    this.sensorConfig.update(s => ({ ...s, iso }));
    this.exposureConfig.update(e => ({ ...e, iso, analogGain: iso / 100.0 }));
    this.executeSimulation();
  }

  public setShutterSpeed(speed: number): void {
    this.exposureConfig.update(e => ({ ...e, shutterSpeedS: speed }));
    this.executeSimulation();
  }

  public setAperture(apertureF: number): void {
    this.exposureConfig.update(e => ({ ...e, apertureF }));
    this.lensConfig.update(l => ({ ...l, apertureF }));
    this.executeSimulation();
  }

  public setTemperature(tempC: number): void {
    this.sensorConfig.update(s => ({ ...s, temperatureC: tempC }));
    this.executeSimulation();
  }

  public setEv(ev: number): void {
    this.exposureConfig.update(e => ({ ...e, evOffset: ev }));
    this.executeSimulation();
  }

  public setLensDistortion(k1: number): void {
    this.lensConfig.update(l => ({ ...l, k1 }));
    this.executeSimulation();
  }

  public setDemosaicMethod(method: DemosaicMethod): void {
    this.pipelineConfig.update(p => ({ ...p, demosaicMethod: method }));
    this.executeSimulation();
  }

  public setWhiteBalanceMode(mode: WhiteBalanceMode): void {
    this.pipelineConfig.update(p => ({ ...p, wbMode: mode }));
    this.executeSimulation();
  }

  public setColourSpace(space: ColourSpace): void {
    this.pipelineConfig.update(p => ({ ...p, colourSpace: space }));
    this.executeSimulation();
  }

  public setToneCurve(curve: ToneCurveMode): void {
    this.pipelineConfig.update(p => ({ ...p, toneCurve: curve }));
    this.executeSimulation();
  }

  public setDenoiseMethod(method: DenoiseMethod): void {
    this.pipelineConfig.update(p => ({ ...p, denoiseMethod: method }));
    this.executeSimulation();
  }

  public setSharpenMethod(method: SharpenMethod): void {
    this.pipelineConfig.update(p => ({ ...p, sharpenMethod: method }));
    this.executeSimulation();
  }

  public togglePipelineStage(stageId: string): void {
    this.pipelineConfig.update(p => ({
      ...p,
      stages: p.stages.map(s => s.id === stageId ? { ...s, enabled: !s.enabled } : s)
    }));
    this.executeSimulation();
  }

  public setViewLayer(layer: ViewLayerType): void {
    this.viewLayer.set(layer);
    if (layer !== 'false_colour') {
      this.falseColourMode.set('none');
    }
  }

  public setFalseColour(fc: FalseColourMode): void {
    this.falseColourMode.set(fc);
    this.viewLayer.set('false_colour');
  }

  public previewStageBuffer(stageKey: string): void {
    this.previewBufferKey.set(stageKey);
    this.viewLayer.set('stage_buffer');
  }

  public setZoom(level: number): void {
    this.zoomLevel.set(level);
  }

  public executeSignatureDemo(demoId: number): void {
    switch (demoId) {
      case 1:
        this.currentSceneId.set('test_chart_24');
        this.sensorConfig.update(s => ({ ...s, iso: 800, temperatureC: 42.0 }));
        this.exposureConfig.update(e => ({ ...e, iso: 800, shutterSpeedS: 1/250 }));
        this.activeTab.set('exposure_iso');
        this.viewLayer.set('final_output');
        this.executeSimulation();
        break;

      case 2:
        this.currentSceneId.set('test_chart_24');
        this.lensConfig.update(l => ({ ...l, k1: -0.075, vignettingCoeff: 4.2 }));
        this.pipelineConfig.update(p => ({ ...p, lensDistortionCorrection: true, vignettingCorrection: true }));
        this.activeTab.set('optics_lens');
        this.viewLayer.set('final_output');
        this.executeSimulation();
        break;

      case 3:
        this.currentSceneId.set('daylight_survey');
        this.activeTab.set('pipeline_lab');
        this.viewLayer.set('stage_buffer');
        this.previewBufferKey.set('demosaic');
        this.executeSimulation();
        break;

      case 4:
        this.currentSceneId.set('night_runway');
        this.sensorConfig.update(s => ({ ...s, iso: 3200, temperatureC: 32.0 }));
        this.exposureConfig.update(e => ({ ...e, iso: 3200, shutterSpeedS: 1/30 }));
        this.pipelineConfig.update(p => ({ ...p, denoiseMethod: 'bilateral', denoiseSpatialSigma: 2.2 }));
        this.activeTab.set('hdr_low_light');
        this.viewLayer.set('final_output');
        this.executeSimulation();
        break;

      case 5:
        this.currentSceneId.set('bridge_inspection');
        this.activeTab.set('flight_provenance');
        this.viewLayer.set('final_output');
        this.executeSimulation();
        break;

      case 6:
        this.currentSceneId.set('daylight_survey');
        this.activeTab.set('digital_twin');
        this.dualLayer.set('physical_sensor');
        this.viewLayer.set('final_output');
        this.executeSimulation();
        break;
    }
  }
}
