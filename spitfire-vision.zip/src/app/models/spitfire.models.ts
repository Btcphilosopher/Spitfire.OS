export type SensorModelId = 'VISION-01' | 'VISION-02-PRO' | 'VISION-THERMAL';
export type CfaPattern = 'RGGB' | 'BGGR' | 'GRBG' | 'GBRG';
export type DemosaicMethod = 'edge_aware' | 'bilinear' | 'high_quality';
export type WhiteBalanceMode = 'daylight' | 'auto_grey_world' | 'cloudy' | 'tungsten' | 'fluorescent' | 'white_patch' | 'percentile' | 'reference_card' | 'custom';
export type ColourSpace = 'sRGB' | 'Display P3' | 'Linear RGB' | 'CIE XYZ' | 'CIE Lab' | 'CIE LCh';
export type ToneCurveMode = 'srgb_standard' | 'filmic_s' | 'drago_log' | 'linear' | 'high_contrast';
export type DenoiseMethod = 'bilateral' | 'gaussian' | 'median' | 'temporal' | 'none';
export type SharpenMethod = 'unsharp_mask' | 'laplacian' | 'none';
export type FalseColourMode = 'none' | 'intensity_heatmap' | 'exposure_clipping' | 'snr_noise_map' | 'depth_map' | 'thermal_flux' | 'edge_gradient';
export type HistogramMode = 'rgb' | 'raw' | 'luminance' | 'cumulative' | 'log';
export type DualLayerMode = 'physical_sensor' | 'computed_image';

export type SceneId = 
  | 'daylight_survey'
  | 'overcast_coastal'
  | 'low_light_industrial'
  | 'sunset_aerospace'
  | 'bridge_inspection'
  | 'forest_canopy'
  | 'agricultural_ndvi'
  | 'high_contrast'
  | 'night_runway'
  | 'test_chart_24';

export interface SpitfireSensorConfig {
  model: SensorModelId;
  width: number;
  height: number;
  pixelPitchUm: number;
  bitDepth: number;
  iso: number;
  temperatureC: number;
  blackLevel: number;
  whiteLevel: number;
  readNoiseE: number;
  darkCurrentRate: number; // e-/px/s
  saturationCapacityE: number;
  cfaPattern: CfaPattern;
  prnuPct: number;
  dsnuE: number;
}

export interface SpitfireLensConfig {
  model: string;
  focalLengthMm: number;
  apertureF: number;
  fovDeg: number;
  k1: number; // Radial 1
  k2: number; // Radial 2
  p1: number; // Tangential 1
  p2: number; // Tangential 2
  vignettingCoeff: number; // cos^4 falloff factor
  chromaticAberrationPx: number; // Lateral chromatic fringe
  focusDistanceM: number;
}

export interface SpitfireExposureConfig {
  shutterSpeedS: number;
  apertureF: number;
  iso: number;
  evOffset: number;
  analogGain: number;
}

export interface PipelineStageConfig {
  id: string;
  name: string;
  enabled: boolean;
  durationMs: number;
  parameters: Record<string, string | number | boolean | number[]>;
}

export interface PipelineState {
  stages: PipelineStageConfig[];
  demosaicMethod: DemosaicMethod;
  wbMode: WhiteBalanceMode;
  wbGains: [number, number, number];
  colourSpace: ColourSpace;
  toneCurve: ToneCurveMode;
  denoiseMethod: DenoiseMethod;
  denoiseSpatialSigma: number;
  denoiseRangeSigma: number;
  sharpenMethod: SharpenMethod;
  sharpenAmount: number;
  sharpenRadius: number;
  lensDistortionCorrection: boolean;
  vignettingCorrection: boolean;
  chromaticCorrection: boolean;
}

export interface GroundTruthData {
  name: string;
  description: string;
  illuminanceLux: number;
  colourTempK: number;
  baseRgbData: ImageData;
  depthData: Float32Array;
  dynamicRangeStops: number;
}

export interface SpitfireRawFrame {
  id: string;
  timestamp: string;
  width: number;
  height: number;
  rawArray: Uint16Array; // 14-bit ADU values [0..16383]
  normalizedArray: Float32Array; // [0..1]
  cfaPattern: CfaPattern;
  sensorConfig: SpitfireSensorConfig;
  exposureConfig: SpitfireExposureConfig;
  lensConfig: SpitfireLensConfig;
  groundTruth: GroundTruthData;
}

export interface SpitfireProcessedImage {
  id: string;
  rawFrameId: string;
  timestamp: string;
  width: number;
  height: number;
  rgbaData: ImageData;
  linearRgbData: Float32Array;
  intermediateStageImages: Map<string, ImageData>;
  metrics: ImageQualityMetrics;
  provenance: ImageProvenance;
}

export interface ImageQualityMetrics {
  meanLuminance: number;
  medianLuminance: number;
  variance: number;
  shadowClippingPct: number;
  highlightClippingPct: number;
  dynamicRangeStops: number;
  snrDb: number;
  psnrDb: number;
  ssim: number;
  colourDeltaE: number;
  mtf50LpMm: number;
  laplacianSharpness: number;
  exposureState: 'UNDEREXPOSED' | 'OPTIMAL' | 'OVEREXPOSED';
  spitfireIqComposite: number;
}

export interface ImageProvenance {
  imageId: string;
  parentRawId: string;
  sensorId: string;
  lensId: string;
  calibrationId: string;
  pipelineVersion: string;
  stagesExecuted: string[];
  totalProcessingTimeMs: number;
  parameters: Record<string, string | number | boolean | number[]>;
  timestamp: string;
  flightId: string;
  missionId: string;
  seed: number;
}

export interface SpitfireFlightContext {
  flightId: string;
  missionId: string;
  aircraftName: string;
  callsign: string;
  timestamp: string;
  latitude: number;
  longitude: number;
  altitudeMslM: number;
  altitudeAglM: number;
  airspeedKts: number;
  rollDeg: number;
  pitchDeg: number;
  yawDeg: number;
  gimbalPitchDeg: number;
  gimbalYawDeg: number;
  gimbalRollDeg: number;
  ambientTempC: number;
  batteryPct: number;
}

export interface PixelInspection {
  x: number;
  y: number;
  rawAdu: number;
  normalizedRaw: number;
  cfaChannel: 'R' | 'Gr' | 'Gb' | 'B';
  displayRgb: [number, number, number];
  linearRgb: [number, number, number];
  localMean: number;
  localSd: number;
  localGradient: number;
  estimatedNoiseE: number;
  depthValueM: number;
}

export interface SpitfireHistogramData {
  bins: number[];
  rChannel: number[];
  gChannel: number[];
  bChannel: number[];
  luminance: number[];
  rawAdu: number[];
  cumulative: number[];
  maxCount: number;
}

export interface ABCompareState {
  enabled: boolean;
  mode: 'split_slider' | 'side_by_side' | 'difference' | 'heatmap';
  splitPositionPct: number;
  imageAId: string;
  imageBId: string;
  labelA: string;
  labelB: string;
}

export interface CameraHealthMetrics {
  sensorHealthScore: number;
  pixelDefectRatePct: number;
  darkCurrentDriftPct: number;
  readNoiseStatus: 'NOMINAL' | 'ELEVATED' | 'CRITICAL';
  opticalAlignmentStatus: 'CALIBRATED_NOMINAL' | 'MINOR_TILT' | 'MISALIGNED';
  calibrationDriftPct: number;
  temperatureStabilityC: number;
  overallStatus: 'SYSTEM_NOMINAL' | 'CALIBRATION_ADVISED' | 'FAULT';
}
