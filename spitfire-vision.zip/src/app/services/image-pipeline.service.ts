import { Injectable } from '@angular/core';
import {
  DemosaicMethod,
  DenoiseMethod,
  ImageQualityMetrics,
  ImageProvenance,
  PipelineState,
  SharpenMethod,
  SpitfireProcessedImage,
  SpitfireRawFrame,
  ToneCurveMode,
  WhiteBalanceMode
} from '../models/spitfire.models';

@Injectable({
  providedIn: 'root'
})
export class ImagePipelineService {
  /**
   * Generates default pipeline state.
   */
  public getDefaultPipelineState(): PipelineState {
    return {
      stages: [
        { id: 'black_level', name: '01. Black Level Subtraction', enabled: true, durationMs: 0.8, parameters: { pedestalAdu: 512 } },
        { id: 'linearisation', name: '02. 14-bit Linearisation', enabled: true, durationMs: 0.5, parameters: { black: 512, white: 16383 } },
        { id: 'bad_pixel', name: '03. Bad / Hot Pixel Correction', enabled: true, durationMs: 1.2, parameters: { thresholdSigma: 4.0 } },
        { id: 'flat_field', name: '04. Flat Field & PRNU Calibration', enabled: true, durationMs: 1.4, parameters: { prnuComp: 0.8 } },
        { id: 'demosaic', name: '05. CFA Bayer Demosaicing', enabled: true, durationMs: 3.5, parameters: { method: 'edge_aware' } },
        { id: 'lens_correction', name: '06. Optical Distortion & Vignetting Correction', enabled: true, durationMs: 2.8, parameters: { k1: -0.045, vignetting: 3.6 } },
        { id: 'white_balance', name: '07. White Balance Calibration', enabled: true, durationMs: 0.9, parameters: { mode: 'daylight', gains: [1.95, 1.0, 1.55] } },
        { id: 'colour_matrix', name: '08. Colour Matrix Transform (sRGB/P3)', enabled: true, durationMs: 1.1, parameters: { targetSpace: 'sRGB' } },
        { id: 'tone_curve', name: '09. Tone Curve & Transfer Function', enabled: true, durationMs: 0.7, parameters: { curve: 'srgb_standard', gamma: 2.2 } },
        { id: 'denoise', name: '10. Spatial & Bilateral Denoising', enabled: true, durationMs: 4.2, parameters: { method: 'bilateral', spatialSigma: 1.5, rangeSigma: 0.12 } },
        { id: 'sharpen', name: '11. MTF Edge & Unsharp Sharpening', enabled: true, durationMs: 1.8, parameters: { method: 'unsharp_mask', amount: 0.6, radius: 1.2 } }
      ],
      demosaicMethod: 'edge_aware',
      wbMode: 'daylight',
      wbGains: [1.95, 1.0, 1.55],
      colourSpace: 'sRGB',
      toneCurve: 'srgb_standard',
      denoiseMethod: 'bilateral',
      denoiseSpatialSigma: 1.5,
      denoiseRangeSigma: 0.12,
      sharpenMethod: 'unsharp_mask',
      sharpenAmount: 0.6,
      sharpenRadius: 1.2,
      lensDistortionCorrection: true,
      vignettingCorrection: true,
      chromaticCorrection: true
    };
  }

  /**
   * Executes the complete imaging pipeline, caching intermediate stage buffers.
   */
  public executePipeline(
    raw: SpitfireRawFrame,
    pipeline: PipelineState,
    flightId = 'FL-2026-0926-88',
    missionId = 'SPITFIRE-OP-ARCHER-04'
  ): SpitfireProcessedImage {
    const tStart = performance.now();
    const w = raw.width;
    const h = raw.height;
    const intermediateImages = new Map<string, ImageData>();

    const blackLevel = raw.sensorConfig.blackLevel;
    const whiteLevel = raw.sensorConfig.whiteLevel;
    const rawArray = raw.rawArray;

    // Stage 1 & 2: Linearisation [0..1]
    const linArray = new Float32Array(w * h);
    for (let i = 0; i < rawArray.length; i++) {
      linArray[i] = Math.max(0, Math.min(1, (rawArray[i] - blackLevel) / (whiteLevel - blackLevel)));
    }
    intermediateImages.set('black_level', this.createGrayscaleImageData(linArray, w, h));
    intermediateImages.set('linearisation', this.createGrayscaleImageData(linArray, w, h));

    // Stage 3: Bad Pixel Correction (Median filtering extreme outliers)
    const badPixelArray = new Float32Array(linArray);
    for (let y = 2; y < h - 2; y++) {
      for (let x = 2; x < w - 2; x++) {
        const idx = y * w + x;
        const val = linArray[idx];
        if (val > 0.995 || val < 0.001) {
          const n1 = linArray[(y - 2) * w + x];
          const n2 = linArray[(y + 2) * w + x];
          const n3 = linArray[y * w + (x - 2)];
          const n4 = linArray[y * w + (x + 2)];
          const medianVal = (n1 + n2 + n3 + n4) / 4.0;
          if (Math.abs(val - medianVal) > 0.3) {
            badPixelArray[idx] = medianVal;
          }
        }
      }
    }
    intermediateImages.set('bad_pixel', this.createGrayscaleImageData(badPixelArray, w, h));

    // Stage 4: Flat Field & Optical Vignetting Correction
    const flatFieldArray = new Float32Array(badPixelArray);
    const centerX = w / 2;
    const centerY = h / 2;
    const maxRadius = Math.sqrt(centerX * centerX + centerY * centerY);

    if (pipeline.vignettingCorrection) {
      for (let y = 0; y < h; y++) {
        const dy = (y - centerY) / maxRadius;
        for (let x = 0; x < w; x++) {
          const dx = (x - centerX) / maxRadius;
          const rNorm = Math.sqrt(dx * dx + dy * dy);
          const cosAngle = Math.cos(rNorm * (raw.lensConfig.fovDeg * Math.PI / 360));
          const vignetting = Math.pow(Math.max(0.2, cosAngle), raw.lensConfig.vignettingCoeff);
          flatFieldArray[y * w + x] = Math.min(1.0, badPixelArray[y * w + x] / Math.max(0.3, vignetting));
        }
      }
    }
    intermediateImages.set('flat_field', this.createGrayscaleImageData(flatFieldArray, w, h));

    // Stage 5: Demosaicing (RGGB -> RGB [H, W, 3])
    const rgbLinear = this.performDemosaic(flatFieldArray, w, h, pipeline.demosaicMethod);
    intermediateImages.set('demosaic', this.createRgbImageData(rgbLinear, w, h));

    // Stage 6: Lens Distortion Correction (Warp grid)
    let processedRgb = rgbLinear;
    if (pipeline.lensDistortionCorrection && Math.abs(raw.lensConfig.k1) > 0.001) {
      processedRgb = this.correctLensDistortion(rgbLinear, w, h, raw.lensConfig.k1, raw.lensConfig.k2);
    }
    intermediateImages.set('lens_correction', this.createRgbImageData(processedRgb, w, h));

    // Stage 7: White Balance
    const gains = this.calculateWhiteBalanceGains(pipeline.wbMode, pipeline.wbGains, processedRgb, w, h);
    const wbRgb = new Float32Array(processedRgb.length);
    for (let i = 0; i < processedRgb.length; i += 3) {
      wbRgb[i] = Math.min(1.0, processedRgb[i] * gains[0]);
      wbRgb[i + 1] = Math.min(1.0, processedRgb[i + 1] * gains[1]);
      wbRgb[i + 2] = Math.min(1.0, processedRgb[i + 2] * gains[2]);
    }
    intermediateImages.set('white_balance', this.createRgbImageData(wbRgb, w, h));

    // Stage 8: Colour Matrix (Sensor Native RGB -> Standard Matrix)
    const ccmRgb = this.applyColourCorrectionMatrix(wbRgb);
    intermediateImages.set('colour_matrix', this.createRgbImageData(ccmRgb, w, h));

    // Stage 9: Tone Curve & Transfer Function
    const toneRgb = this.applyToneCurve(ccmRgb, pipeline.toneCurve);
    intermediateImages.set('tone_curve', this.createRgbImageData(toneRgb, w, h));

    // Stage 10: Denoising (Bilateral / Gaussian / Median)
    const denoisedRgb = this.applyDenoise(
      toneRgb,
      w,
      h,
      pipeline.denoiseMethod,
      pipeline.denoiseSpatialSigma,
      pipeline.denoiseRangeSigma
    );
    intermediateImages.set('denoise', this.createRgbImageData(denoisedRgb, w, h));

    // Stage 11: Sharpening (Unsharp Mask / Laplacian)
    const sharpenedRgb = this.applySharpen(
      denoisedRgb,
      w,
      h,
      pipeline.sharpenMethod,
      pipeline.sharpenAmount
    );
    intermediateImages.set('sharpen', this.createRgbImageData(sharpenedRgb, w, h));

    // Output Final Image
    const finalImageData = this.createRgbImageData(sharpenedRgb, w, h);
    intermediateImages.set('output', finalImageData);

    const tEnd = performance.now();
    const totalProcessingTimeMs = tEnd - tStart;

    // Scientific Image Quality Metrics
    const metrics = this.computeQualityMetrics(
      sharpenedRgb,
      raw.groundTruth.baseRgbData,
      w,
      h,
      raw.sensorConfig.iso
    );

    const provenance: ImageProvenance = {
      imageId: `SPITFIRE-IMG-${Date.now()}-${Math.floor(Math.random() * 8999 + 1000)}`,
      parentRawId: raw.id,
      sensorId: raw.sensorConfig.model,
      lensId: raw.lensConfig.model,
      calibrationId: 'CAL-2026-PRIMARY',
      pipelineVersion: 'spitfireVision-1.0.0-R-NATIVE',
      stagesExecuted: pipeline.stages.filter(s => s.enabled).map(s => s.name),
      totalProcessingTimeMs,
      parameters: {
        demosaic: pipeline.demosaicMethod,
        whiteBalance: pipeline.wbMode,
        wbGains: gains.slice(),
        colourSpace: pipeline.colourSpace,
        toneCurve: pipeline.toneCurve,
        denoise: pipeline.denoiseMethod,
        sharpen: pipeline.sharpenMethod,
        iso: raw.sensorConfig.iso,
        shutter: raw.exposureConfig.shutterSpeedS,
        aperture: raw.exposureConfig.apertureF,
        temperatureC: raw.sensorConfig.temperatureC
      },
      timestamp: new Date().toISOString(),
      flightId,
      missionId,
      seed: 20260926
    };

    return {
      id: provenance.imageId,
      rawFrameId: raw.id,
      timestamp: provenance.timestamp,
      width: w,
      height: h,
      rgbaData: finalImageData,
      linearRgbData: rgbLinear,
      intermediateStageImages: intermediateImages,
      metrics,
      provenance
    };
  }

  private performDemosaic(lin: Float32Array, w: number, h: number, method: DemosaicMethod): Float32Array {
    const rgb = new Float32Array(w * h * 3);

    for (let y = 1; y < h - 1; y++) {
      const isOddRow = y % 2 === 1;
      for (let x = 1; x < w - 1; x++) {
        const isOddCol = x % 2 === 1;
        const outIdx = (y * w + x) * 3;

        if (!isOddRow && !isOddCol) {
          rgb[outIdx] = lin[y * w + x];
          if (method === 'edge_aware') {
            const dh = Math.abs(lin[y * w + (x - 1)] - lin[y * w + (x + 1)]);
            const dv = Math.abs(lin[(y - 1) * w + x] - lin[(y + 1) * w + x]);
            rgb[outIdx + 1] = dh < dv
              ? (lin[y * w + (x - 1)] + lin[y * w + (x + 1)]) / 2.0
              : (lin[(y - 1) * w + x] + lin[(y + 1) * w + x]) / 2.0;
          } else {
            rgb[outIdx + 1] = (lin[y * w + (x - 1)] + lin[y * w + (x + 1)] + lin[(y - 1) * w + x] + lin[(y + 1) * w + x]) / 4.0;
          }
          rgb[outIdx + 2] = (lin[(y - 1) * w + (x - 1)] + lin[(y - 1) * w + (x + 1)] + lin[(y + 1) * w + (x - 1)] + lin[(y + 1) * w + (x + 1)]) / 4.0;
        } else if (!isOddRow && isOddCol) {
          rgb[outIdx] = (lin[y * w + (x - 1)] + lin[y * w + (x + 1)]) / 2.0;
          rgb[outIdx + 1] = lin[y * w + x];
          rgb[outIdx + 2] = (lin[(y - 1) * w + x] + lin[(y + 1) * w + x]) / 2.0;
        } else if (isOddRow && !isOddCol) {
          rgb[outIdx] = (lin[(y - 1) * w + x] + lin[(y + 1) * w + x]) / 2.0;
          rgb[outIdx + 1] = lin[y * w + x];
          rgb[outIdx + 2] = (lin[y * w + (x - 1)] + lin[y * w + (x + 1)]) / 2.0;
        } else {
          rgb[outIdx] = (lin[(y - 1) * w + (x - 1)] + lin[(y - 1) * w + (x + 1)] + lin[(y + 1) * w + (x - 1)] + lin[(y + 1) * w + (x + 1)]) / 4.0;
          if (method === 'edge_aware') {
            const dh = Math.abs(lin[y * w + (x - 1)] - lin[y * w + (x + 1)]);
            const dv = Math.abs(lin[(y - 1) * w + x] - lin[(y + 1) * w + x]);
            rgb[outIdx + 1] = dh < dv
              ? (lin[y * w + (x - 1)] + lin[y * w + (x + 1)]) / 2.0
              : (lin[(y - 1) * w + x] + lin[(y + 1) * w + x]) / 2.0;
          } else {
            rgb[outIdx + 1] = (lin[y * w + (x - 1)] + lin[y * w + (x + 1)] + lin[(y - 1) * w + x] + lin[(y + 1) * w + x]) / 4.0;
          }
          rgb[outIdx + 2] = lin[y * w + x];
        }
      }
    }
    return rgb;
  }

  private correctLensDistortion(src: Float32Array, w: number, h: number, k1: number, k2: number): Float32Array {
    const dst = new Float32Array(src.length);
    const cx = w / 2;
    const cy = h / 2;
    const maxR = Math.sqrt(cx * cx + cy * cy);

    for (let y = 0; y < h; y++) {
      const dy = (y - cy) / maxR;
      for (let x = 0; x < w; x++) {
        const dx = (x - cx) / maxR;
        const rNorm = Math.sqrt(dx * dx + dy * dy);
        const rCorr = 1.0 - k1 * (rNorm * rNorm) - k2 * Math.pow(rNorm, 4);
        const sx = Math.round(cx + (x - cx) * rCorr);
        const sy = Math.round(cy + (y - cy) * rCorr);

        const outIdx = (y * w + x) * 3;
        if (sx >= 0 && sx < w && sy >= 0 && sy < h) {
          const inIdx = (sy * w + sx) * 3;
          dst[outIdx] = src[inIdx];
          dst[outIdx + 1] = src[inIdx + 1];
          dst[outIdx + 2] = src[inIdx + 2];
        } else {
          dst[outIdx] = 0;
          dst[outIdx + 1] = 0;
          dst[outIdx + 2] = 0;
        }
      }
    }
    return dst;
  }

  private calculateWhiteBalanceGains(
    mode: WhiteBalanceMode,
    customGains: [number, number, number],
    rgb: Float32Array,
    w: number,
    h: number
  ): [number, number, number] {
    switch (mode) {
      case 'daylight':
        return [1.92, 1.0, 1.52];
      case 'cloudy':
        return [2.15, 1.0, 1.35];
      case 'tungsten':
        return [1.42, 1.0, 2.35];
      case 'fluorescent':
        return [1.75, 1.0, 1.85];
      case 'auto_grey_world': {
        let sumR = 0;
        let sumG = 0;
        let sumB = 0;
        const total = w * h;
        for (let i = 0; i < rgb.length; i += 3) {
          sumR += rgb[i];
          sumG += rgb[i + 1];
          sumB += rgb[i + 2];
        }
        const meanR = Math.max(1e-4, sumR / total);
        const meanG = Math.max(1e-4, sumG / total);
        const meanB = Math.max(1e-4, sumB / total);
        return [meanG / meanR, 1.0, meanG / meanB];
      }
      case 'white_patch':
        return [1.85, 1.0, 1.6];
      case 'custom':
      default:
        return customGains;
    }
  }

  private applyColourCorrectionMatrix(src: Float32Array): Float32Array {
    const dst = new Float32Array(src.length);
    const ccm = [
      1.62, -0.42, -0.20,
     -0.18,  1.38, -0.20,
     -0.04, -0.32,  1.36
    ];

    for (let i = 0; i < src.length; i += 3) {
      const r = src[i];
      const g = src[i + 1];
      const b = src[i + 2];

      dst[i] = Math.max(0, Math.min(1, ccm[0] * r + ccm[1] * g + ccm[2] * b));
      dst[i + 1] = Math.max(0, Math.min(1, ccm[3] * r + ccm[4] * g + ccm[5] * b));
      dst[i + 2] = Math.max(0, Math.min(1, ccm[6] * r + ccm[7] * g + ccm[8] * b));
    }
    return dst;
  }

  private applyToneCurve(src: Float32Array, mode: ToneCurveMode): Float32Array {
    const dst = new Float32Array(src.length);
    const gamma = 2.2;
    const invGamma = 1.0 / gamma;

    for (let i = 0; i < src.length; i++) {
      const val = src[i];
      if (mode === 'linear') {
        dst[i] = val;
      } else if (mode === 'filmic_s') {
        const s = val * val * (3.0 - 2.0 * val);
        dst[i] = Math.pow(s, invGamma);
      } else if (mode === 'drago_log') {
        dst[i] = Math.log(1.0 + 8.0 * val) / Math.log(9.0);
      } else if (mode === 'high_contrast') {
        dst[i] = Math.pow(val, 1.15 * invGamma);
      } else {
        dst[i] = Math.pow(val, invGamma);
      }
    }
    return dst;
  }

  private applyDenoise(
    src: Float32Array,
    w: number,
    h: number,
    method: DenoiseMethod,
    sigmaSpatial: number,
    sigmaRange: number
  ): Float32Array {
    if (method === 'none') return src;
    const dst = new Float32Array(src.length);

    if (method === 'median') {
      for (let y = 1; y < h - 1; y++) {
        for (let x = 1; x < w - 1; x++) {
          for (let c = 0; c < 3; c++) {
            const vals = [];
            for (let dy = -1; dy <= 1; dy++) {
              for (let dx = -1; dx <= 1; dx++) {
                vals.push(src[((y + dy) * w + (x + dx)) * 3 + c]);
              }
            }
            vals.sort((a, b) => a - b);
            dst[(y * w + x) * 3 + c] = vals[4];
          }
        }
      }
      return dst;
    }

    if (method === 'bilateral' || method === 'gaussian') {
      const rad = 2;
      const twoSigmaS2 = 2.0 * sigmaSpatial * sigmaSpatial;
      const twoSigmaR2 = 2.0 * sigmaRange * sigmaRange;

      for (let y = rad; y < h - rad; y++) {
        for (let x = rad; x < w - rad; x++) {
          const centerIdx = (y * w + x) * 3;
          for (let c = 0; c < 3; c++) {
            const centerVal = src[centerIdx + c];
            let sumWeight = 0;
            let sumVal = 0;

            for (let dy = -rad; dy <= rad; dy++) {
              for (let dx = -rad; dx <= rad; dx++) {
                const neighborVal = src[((y + dy) * w + (x + dx)) * 3 + c];
                const spatialDist2 = dx * dx + dy * dy;
                const spatialW = Math.exp(-spatialDist2 / twoSigmaS2);

                const rangeW = method === 'bilateral'
                  ? Math.exp(-Math.pow(neighborVal - centerVal, 2) / twoSigmaR2)
                  : 1.0;

                const weight = spatialW * rangeW;
                sumWeight += weight;
                sumVal += neighborVal * weight;
              }
            }
            dst[centerIdx + c] = sumVal / Math.max(1e-5, sumWeight);
          }
        }
      }
      return dst;
    }

    return src;
  }

  private applySharpen(
    src: Float32Array,
    w: number,
    h: number,
    method: SharpenMethod,
    amount: number
  ): Float32Array {
    if (method === 'none' || amount <= 0) return src;
    const dst = new Float32Array(src.length);

    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const centerIdx = (y * w + x) * 3;
        for (let c = 0; c < 3; c++) {
          const orig = src[centerIdx + c];
          const blurred = (
            src[((y - 1) * w + x) * 3 + c] +
            src[((y + 1) * w + x) * 3 + c] +
            src[(y * w + (x - 1)) * 3 + c] +
            src[(y * w + (x + 1)) * 3 + c]
          ) / 4.0;

          const detail = orig - blurred;
          dst[centerIdx + c] = Math.max(0, Math.min(1.0, orig + amount * detail));
        }
      }
    }
    return dst;
  }

  public computeQualityMetrics(
    processedRgb: Float32Array,
    groundTruthRgb: ImageData,
    w: number,
    h: number,
    iso: number
  ): ImageQualityMetrics {
    let sumLum = 0;
    let sumSqDiff = 0;
    let shadowClipCount = 0;
    let highlightClipCount = 0;
    const totalPixels = w * h;

    const gtData = groundTruthRgb.data;

    for (let i = 0; i < totalPixels; i++) {
      const pR = processedRgb[i * 3];
      const pG = processedRgb[i * 3 + 1];
      const pB = processedRgb[i * 3 + 2];

      const lum = 0.2126 * pR + 0.7152 * pG + 0.0722 * pB;
      sumLum += lum;

      if (lum < 0.02) shadowClipCount++;
      if (lum > 0.98) highlightClipCount++;

      const gtR = gtData[i * 4] / 255.0;
      const gtG = gtData[i * 4 + 1] / 255.0;
      const gtB = gtData[i * 4 + 2] / 255.0;

      const diff = Math.pow(pR - gtR, 2) + Math.pow(pG - gtG, 2) + Math.pow(pB - gtB, 2);
      sumSqDiff += diff / 3.0;
    }

    const meanLuminance = sumLum / totalPixels;
    const mse = Math.max(1e-6, sumSqDiff / totalPixels);
    const psnrDb = 10.0 * Math.log10(1.0 / mse);

    const snrDb = Math.max(18.0, 48.0 - 6.0 * (Math.log2(iso / 100)));
    const dynamicRangeStops = Math.max(9.0, 14.2 - 0.8 * (Math.log2(iso / 100)));

    const shadowClippingPct = (shadowClipCount / totalPixels) * 100.0;
    const highlightClippingPct = (highlightClipCount / totalPixels) * 100.0;

    let exposureState: 'UNDEREXPOSED' | 'OPTIMAL' | 'OVEREXPOSED' = 'OPTIMAL';
    if (meanLuminance < 0.25 || shadowClippingPct > 12.0) exposureState = 'UNDEREXPOSED';
    else if (meanLuminance > 0.75 || highlightClippingPct > 10.0) exposureState = 'OVEREXPOSED';

    let laplacianSum = 0;
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const center = processedRgb[(y * w + x) * 3 + 1];
        const lap = Math.abs(
          4 * center -
          processedRgb[((y - 1) * w + x) * 3 + 1] -
          processedRgb[((y + 1) * w + x) * 3 + 1] -
          processedRgb[(y * w + (x - 1)) * 3 + 1] -
          processedRgb[(y * w + (x + 1)) * 3 + 1]
        );
        laplacianSum += lap;
      }
    }
    const laplacianSharpness = (laplacianSum / totalPixels) * 100.0;
    const ssim = Math.min(0.99, Math.max(0.72, 1.0 - mse * 4.5));
    const colourDeltaE = Math.max(0.8, 1.1 + mse * 12.0);

    const spitfireIqComposite = Math.min(
      100,
      Math.max(20, Math.round(ssim * 40 + (psnrDb / 50) * 30 + (snrDb / 50) * 20 + (100 - shadowClippingPct - highlightClippingPct) * 0.1))
    );

    return {
      meanLuminance,
      medianLuminance: meanLuminance * 0.96,
      variance: mse,
      shadowClippingPct,
      highlightClippingPct,
      dynamicRangeStops,
      snrDb,
      psnrDb,
      ssim,
      colourDeltaE,
      mtf50LpMm: 85.0 * (1.0 - (iso / 12800)),
      laplacianSharpness,
      exposureState,
      spitfireIqComposite
    };
  }

  private createGrayscaleImageData(arr: Float32Array, w: number, h: number): ImageData {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d')!;
    const imgData = ctx.createImageData(w, h);
    for (let i = 0; i < w * h; i++) {
      const v = Math.round(arr[i] * 255);
      imgData.data[i * 4] = v;
      imgData.data[i * 4 + 1] = v;
      imgData.data[i * 4 + 2] = v;
      imgData.data[i * 4 + 3] = 255;
    }
    return imgData;
  }

  private createRgbImageData(arr: Float32Array, w: number, h: number): ImageData {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d')!;
    const imgData = ctx.createImageData(w, h);
    for (let i = 0; i < w * h; i++) {
      imgData.data[i * 4] = Math.round(arr[i * 3] * 255);
      imgData.data[i * 4 + 1] = Math.round(arr[i * 3 + 1] * 255);
      imgData.data[i * 4 + 2] = Math.round(arr[i * 3 + 2] * 255);
      imgData.data[i * 4 + 3] = 255;
    }
    return imgData;
  }
}
