import { Injectable } from '@angular/core';
import {
  GroundTruthData,
  SpitfireExposureConfig,
  SpitfireLensConfig,
  SpitfireRawFrame,
  SpitfireSensorConfig
} from '../models/spitfire.models';

@Injectable({
  providedIn: 'root'
})
export class SensorPhysicsService {
  /**
   * Generates a default VISION-01 Sensor Configuration.
   */
  public getDefaultSensor(): SpitfireSensorConfig {
    return {
      model: 'VISION-01',
      width: 512,
      height: 384,
      pixelPitchUm: 3.2,
      bitDepth: 14,
      iso: 100,
      temperatureC: 38.5,
      blackLevel: 512,
      whiteLevel: 16383,
      readNoiseE: 1.8,
      darkCurrentRate: 0.42,
      saturationCapacityE: 32000,
      cfaPattern: 'RGGB',
      prnuPct: 0.8,
      dsnuE: 2.2
    };
  }

  /**
   * Generates a default SPITFIRE 24mm f/2.8 Aerial Lens Configuration.
   */
  public getDefaultLens(): SpitfireLensConfig {
    return {
      model: 'SPITFIRE-AERO-24MM-F2.8',
      focalLengthMm: 24,
      apertureF: 2.8,
      fovDeg: 84.0,
      k1: -0.045,
      k2: 0.008,
      p1: 0.0002,
      p2: -0.0001,
      vignettingCoeff: 3.6,
      chromaticAberrationPx: 1.6,
      focusDistanceM: 25.0
    };
  }

  /**
   * Generates a default Exposure Configuration.
   */
  public getDefaultExposure(): SpitfireExposureConfig {
    return {
      shutterSpeedS: 1 / 500,
      apertureF: 2.8,
      iso: 100,
      evOffset: 0.0,
      analogGain: 1.0
    };
  }

  /**
   * Simulates the complete Physical Sensor Capture Process:
   * Scene Radiance -> Optics (Distortion, Vignetting, Chromatic) -> CFA Mosaic -> Photon Shot Noise -> Thermal Dark Current -> Read Noise -> Saturation -> 14-bit ADC Quantisation.
   */
  public simulateRawCapture(
    groundTruth: GroundTruthData,
    sensor: SpitfireSensorConfig,
    lens: SpitfireLensConfig,
    exposure: SpitfireExposureConfig,
    seed = 42
  ): SpitfireRawFrame {
    const w = sensor.width;
    const h = sensor.height;
    const srcData = groundTruth.baseRgbData.data;

    const rawArray = new Uint16Array(w * h);
    const normalizedArray = new Float32Array(w * h);

    let s = seed;
    const pseudoRandom = () => {
      s = (s * 9301 + 49297) % 233280;
      return s / 233280;
    };
    const gaussianRandom = (mean: number, sd: number) => {
      const u1 = Math.max(1e-7, pseudoRandom());
      const u2 = pseudoRandom();
      const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
      return mean + z * sd;
    };
    const poissonRandom = (lambda: number) => {
      if (lambda < 30) {
        const l = Math.exp(-lambda);
        let k = 0;
        let p = 1;
        do {
          k++;
          p *= pseudoRandom();
        } while (p > l);
        return k - 1;
      }
      return Math.max(0, Math.round(gaussianRandom(lambda, Math.sqrt(lambda))));
    };

    const gain = exposure.iso / 100.0;
    const effectiveReadNoiseE = sensor.readNoiseE * Math.sqrt(1.0 + (gain - 1.0) * 0.12);

    const thermalDarkRate = sensor.darkCurrentRate * Math.pow(2.0, (sensor.temperatureC - 20.0) / 6.0);
    const darkElectronsMean = thermalDarkRate * exposure.shutterSpeedS;

    const evMultiplier = Math.pow(2.0, exposure.evOffset);
    const apertureFactor = 1.0 / (4.0 * Math.pow(exposure.apertureF, 2));
    const shutterFactor = exposure.shutterSpeedS / (1 / 500);
    const throughput = apertureFactor * shutterFactor * evMultiplier * 35000;

    const centerX = w / 2;
    const centerY = h / 2;
    const maxRadius = Math.sqrt(centerX * centerX + centerY * centerY);

    const qe = { r: 0.62, g: 0.74, b: 0.58 };

    for (let y = 0; y < h; y++) {
      const isOddRow = y % 2 === 1;
      const dy = (y - centerY) / maxRadius;

      for (let x = 0; x < w; x++) {
        const isOddCol = x % 2 === 1;
        const dx = (x - centerX) / maxRadius;
        const rNorm = Math.sqrt(dx * dx + dy * dy);

        const cosAngle = Math.cos(rNorm * (lens.fovDeg * Math.PI / 360));
        const vignetting = Math.pow(Math.max(0.2, cosAngle), lens.vignettingCoeff);

        const rDistort = 1.0 + lens.k1 * (rNorm * rNorm) + lens.k2 * Math.pow(rNorm, 4);
        let srcX = Math.round(centerX + (x - centerX) * rDistort);
        let srcY = Math.round(centerY + (y - centerY) * rDistort);
        srcX = Math.max(0, Math.min(w - 1, srcX));
        srcY = Math.max(0, Math.min(h - 1, srcY));

        const pixelIdx = (srcY * w + srcX) * 4;

        let sceneVal: number;
        let qeVal: number;

        if (!isOddRow && !isOddCol) {
          sceneVal = (srcData[pixelIdx] / 255.0) * vignetting;
          qeVal = qe.r;
        } else if (!isOddRow && isOddCol) {
          sceneVal = (srcData[pixelIdx + 1] / 255.0) * vignetting;
          qeVal = qe.g;
        } else if (isOddRow && !isOddCol) {
          sceneVal = (srcData[pixelIdx + 1] / 255.0) * vignetting;
          qeVal = qe.g;
        } else {
          sceneVal = (srcData[pixelIdx + 2] / 255.0) * vignetting;
          qeVal = qe.b;
        }

        const incidentPhotons = Math.max(0, sceneVal * throughput * qeVal);
        let electrons = poissonRandom(incidentPhotons);

        const prnuVariation = gaussianRandom(1.0, sensor.prnuPct / 100.0);
        electrons *= prnuVariation;

        const darkNoise = poissonRandom(darkElectronsMean) + gaussianRandom(0, sensor.dsnuE);
        electrons += darkNoise;

        electrons = Math.min(sensor.saturationCapacityE, Math.max(0, electrons));
        electrons += gaussianRandom(0, effectiveReadNoiseE);

        const conversionGain = (sensor.whiteLevel - sensor.blackLevel) / sensor.saturationCapacityE;
        let adu = sensor.blackLevel + electrons * conversionGain * gain;

        if (pseudoRandom() < 0.00003) {
          adu = sensor.whiteLevel;
        }

        const finalAdu = Math.min(sensor.whiteLevel, Math.max(0, Math.round(adu)));
        const targetIdx = y * w + x;

        rawArray[targetIdx] = finalAdu;
        normalizedArray[targetIdx] = finalAdu / sensor.whiteLevel;
      }
    }

    const frameId = `SPITFIRE-RAW-${Date.now()}-${Math.floor(Math.random() * 8999 + 1000)}`;

    return {
      id: frameId,
      timestamp: new Date().toISOString(),
      width: w,
      height: h,
      rawArray,
      normalizedArray,
      cfaPattern: sensor.cfaPattern,
      sensorConfig: { ...sensor },
      exposureConfig: { ...exposure },
      lensConfig: { ...lens },
      groundTruth
    };
  }
}
