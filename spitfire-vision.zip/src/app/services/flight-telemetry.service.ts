import { Injectable } from '@angular/core';
import { CameraHealthMetrics, SpitfireFlightContext } from '../models/spitfire.models';

export interface HistoricalFlightRecord {
  flightId: string;
  missionName: string;
  date: string;
  framesCaptured: number;
  avgSharpness: number;
  avgSnrDb: number;
  darkCurrentDriftPct: number;
  prnuVariancePct: number;
  status: 'NOMINAL' | 'FLAGGED';
}

@Injectable({
  providedIn: 'root'
})
export class FlightTelemetryService {
  public getCurrentFlightContext(): SpitfireFlightContext {
    return {
      flightId: 'FL-2026-0926-88',
      missionId: 'SPITFIRE-OP-ARCHER-04',
      aircraftName: 'SPITFIRE D-01 HEAVY',
      callsign: 'SPITFIRE-88-ALPHA',
      timestamp: new Date().toISOString(),
      latitude: 51.2783, // Farnborough aerodrome / Salisbury Plain test range
      longitude: -0.7762,
      altitudeMslM: 320.4,
      altitudeAglM: 125.0,
      airspeedKts: 38.5,
      rollDeg: -1.2,
      pitchDeg: 2.8,
      yawDeg: 214.5,
      gimbalPitchDeg: -45.0, // 45 degree oblique survey angle
      gimbalYawDeg: 0.0,
      gimbalRollDeg: 0.0,
      ambientTempC: 18.2,
      batteryPct: 86
    };
  }

  public getHistoricalFlights(): HistoricalFlightRecord[] {
    return [
      { flightId: 'FL-2026-0926-88', missionName: 'Farnborough Runways Survey', date: '2026-09-26', framesCaptured: 840, avgSharpness: 94.2, avgSnrDb: 43.8, darkCurrentDriftPct: 0.02, prnuVariancePct: 0.81, status: 'NOMINAL' },
      { flightId: 'FL-2026-0924-87', missionName: 'Salisbury Plain Mapping', date: '2026-09-24', framesCaptured: 1250, avgSharpness: 93.8, avgSnrDb: 44.1, darkCurrentDriftPct: 0.03, prnuVariancePct: 0.80, status: 'NOMINAL' },
      { flightId: 'FL-2026-0921-86', missionName: 'Dover Coastal Cliff Inspection', date: '2026-09-21', framesCaptured: 920, avgSharpness: 91.5, avgSnrDb: 42.6, darkCurrentDriftPct: 0.05, prnuVariancePct: 0.83, status: 'NOMINAL' },
      { flightId: 'FL-2026-0918-85', missionName: 'Severn Bridge Photogrammetry', date: '2026-09-18', framesCaptured: 1540, avgSharpness: 95.0, avgSnrDb: 44.5, darkCurrentDriftPct: 0.01, prnuVariancePct: 0.79, status: 'NOMINAL' },
      { flightId: 'FL-2026-0914-84', missionName: 'Night Runway Beacon Verification', date: '2026-09-14', framesCaptured: 610, avgSharpness: 88.2, avgSnrDb: 28.4, darkCurrentDriftPct: 0.04, prnuVariancePct: 0.82, status: 'NOMINAL' },
      { flightId: 'FL-2026-0910-83', missionName: 'Agricultural Crop NDVI Benchmark', date: '2026-09-10', framesCaptured: 1800, avgSharpness: 93.1, avgSnrDb: 43.9, darkCurrentDriftPct: 0.02, prnuVariancePct: 0.80, status: 'NOMINAL' }
    ];
  }

  public getCameraHealth(): CameraHealthMetrics {
    return {
      sensorHealthScore: 98.6,
      pixelDefectRatePct: 0.003,
      darkCurrentDriftPct: 0.04,
      readNoiseStatus: 'NOMINAL',
      opticalAlignmentStatus: 'CALIBRATED_NOMINAL',
      calibrationDriftPct: 0.35,
      temperatureStabilityC: 38.5,
      overallStatus: 'SYSTEM_NOMINAL'
    };
  }
}
