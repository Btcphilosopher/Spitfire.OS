import { Injectable } from '@angular/core';
import { GroundTruthData, SceneId } from '../models/spitfire.models';

export interface SceneDefinition {
  id: SceneId;
  name: string;
  category: string;
  description: string;
  illuminanceLux: number;
  colourTempK: number;
  dynamicRangeStops: number;
}

@Injectable({
  providedIn: 'root'
})
export class SceneGeneratorService {
  public readonly availableScenes: SceneDefinition[] = [
    {
      id: 'daylight_survey',
      name: '01. Daylight Aerospace Survey',
      category: 'AERIAL_SURVEY',
      description: 'Farnborough airfield runway, hangars, tarmac markings, grass fields, and ground service vehicles under direct British sunlight.',
      illuminanceLux: 65000,
      colourTempK: 5500,
      dynamicRangeStops: 12.8
    },
    {
      id: 'overcast_coastal',
      name: '02. Overcast Coastal Drone',
      category: 'MARITIME',
      description: 'Dover chalk cliffs, crashing sea waves, offshore wind turbines, and atmospheric coastal mist under diffused cloud cover.',
      illuminanceLux: 18000,
      colourTempK: 6500,
      dynamicRangeStops: 10.5
    },
    {
      id: 'bridge_inspection',
      name: '03. Industrial Bridge Infrastructure',
      category: 'INSPECTION',
      description: 'Suspension bridge steel girders, high-contrast rivets, concrete piers, asphalt road deck, and structural inspection targets.',
      illuminanceLux: 35000,
      colourTempK: 5200,
      dynamicRangeStops: 13.5
    },
    {
      id: 'low_light_industrial',
      name: '04. Low Light Dusk Industrial Plant',
      category: 'LOW_LIGHT',
      description: 'Power station cooling towers, steam plumes, sodium floodlights, metal tanks, and deep shadow crepuscular gradients.',
      illuminanceLux: 350,
      colourTempK: 3200,
      dynamicRangeStops: 14.0
    },
    {
      id: 'sunset_aerospace',
      name: '05. Sunset Horizon Transition',
      category: 'ATMOSPHERIC',
      description: 'Golden hour sunset over Salisbury Plain, intense solar disk, backlit cumulus clouds, and deep terrain silhouette.',
      illuminanceLux: 4500,
      colourTempK: 2800,
      dynamicRangeStops: 14.2
    },
    {
      id: 'forest_canopy',
      name: '06. Forest Canopy & Topography',
      category: 'MULTISPECTRAL',
      description: 'Dense deciduous woodland canopy, sunlit leaves, shadow pockets, forestry track, and topographical elevation contours.',
      illuminanceLux: 42000,
      colourTempK: 5600,
      dynamicRangeStops: 11.8
    },
    {
      id: 'agricultural_ndvi',
      name: '07. Precision Agriculture Field',
      category: 'AGRONOMY',
      description: 'Tractor tramlines, geometric crop rows, soil moisture gradients, and vegetative vigour density patterns.',
      illuminanceLux: 58000,
      colourTempK: 5400,
      dynamicRangeStops: 11.2
    },
    {
      id: 'high_contrast',
      name: '08. High-Contrast Backlit Scene',
      category: 'STRESS_TEST',
      description: 'Extreme dynamic range test: bright sun glare on metal roof juxtaposed against shaded aircraft hangar interior.',
      illuminanceLux: 95000,
      colourTempK: 5800,
      dynamicRangeStops: 14.8
    },
    {
      id: 'night_runway',
      name: '09. Night Operations & Beacons',
      category: 'NIGHT_MISSION',
      description: 'Extreme low-light night simulation: airport approach lights, taxiway green centerline, and dark tarmac.',
      illuminanceLux: 1.5,
      colourTempK: 2200,
      dynamicRangeStops: 13.0
    },
    {
      id: 'test_chart_24',
      name: '10. SPITFIRE Colour Target 24 & ISO Chart',
      category: 'CALIBRATION',
      description: 'Standard 24-patch calibrated colour target, USAF 1951 resolution bars, Siemens star, and 14-step greyscale wedge.',
      illuminanceLux: 2000,
      colourTempK: 5000,
      dynamicRangeStops: 11.0
    }
  ];

  public generateSceneGroundTruth(sceneId: SceneId, width = 512, height = 384): GroundTruthData {
    const sceneDef = this.availableScenes.find(s => s.id === sceneId) || this.availableScenes[0];
    
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d', { willReadFrequently: true })!;

    const depthBuffer = new Float32Array(width * height);

    this.renderProceduralScene(ctx, sceneId, width, height, depthBuffer);

    const baseRgbData = ctx.getImageData(0, 0, width, height);

    return {
      name: sceneDef.name,
      description: sceneDef.description,
      illuminanceLux: sceneDef.illuminanceLux,
      colourTempK: sceneDef.colourTempK,
      baseRgbData,
      depthData: depthBuffer,
      dynamicRangeStops: sceneDef.dynamicRangeStops
    };
  }

  private renderProceduralScene(
    ctx: CanvasRenderingContext2D,
    sceneId: SceneId,
    w: number,
    h: number,
    depth: Float32Array
  ): void {
    ctx.clearRect(0, 0, w, h);

    switch (sceneId) {
      case 'test_chart_24':
        this.renderTestChart(ctx, w, h, depth);
        break;
      case 'daylight_survey':
        this.renderDaylightRunway(ctx, w, h, depth);
        break;
      case 'overcast_coastal':
        this.renderCoastalCliffs(ctx, w, h, depth);
        break;
      case 'bridge_inspection':
        this.renderBridgeInspection(ctx, w, h, depth);
        break;
      case 'low_light_industrial':
        this.renderLowLightIndustrial(ctx, w, h, depth);
        break;
      case 'sunset_aerospace':
        this.renderSunsetHorizon(ctx, w, h, depth);
        break;
      case 'forest_canopy':
        this.renderForestCanopy(ctx, w, h, depth);
        break;
      case 'agricultural_ndvi':
        this.renderAgricultural(ctx, w, h, depth);
        break;
      case 'high_contrast':
        this.renderHighContrast(ctx, w, h, depth);
        break;
      case 'night_runway':
        this.renderNightRunway(ctx, w, h, depth);
        break;
      default:
        this.renderDaylightRunway(ctx, w, h, depth);
    }
  }

  private renderTestChart(ctx: CanvasRenderingContext2D, w: number, h: number, depth: Float32Array): void {
    ctx.fillStyle = '#DCD8CE';
    ctx.fillRect(0, 0, w, h);

    const patches = [
      '#735244', '#c29682', '#627a9d', '#576c43', '#8580b1', '#67bdaa',
      '#d67e2c', '#505ba6', '#c15a63', '#5e3c6c', '#9dbc40', '#e0a32e',
      '#383d96', '#469449', '#af363c', '#e7c71f', '#bb5695', '#0885a1',
      '#f3f3f2', '#c8c8c8', '#a0a0a0', '#7a7a79', '#555555', '#343434'
    ];

    const gridX = 40;
    const gridY = 30;
    const gridW = w - 80;
    const gridH = h * 0.55;
    const patchW = gridW / 6;
    const patchH = gridH / 4;

    ctx.fillStyle = '#181A1B';
    ctx.fillRect(gridX - 8, gridY - 8, gridW + 16, gridH + 16);

    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 6; c++) {
        const idx = r * 6 + c;
        const px = gridX + c * patchW + 4;
        const py = gridY + r * patchH + 4;
        ctx.fillStyle = patches[idx];
        ctx.fillRect(px, py, patchW - 8, patchH - 8);
      }
    }

    const resY = gridY + gridH + 20;
    ctx.fillStyle = '#222527';
    ctx.fillRect(40, resY, w - 80, h - resY - 20);

    ctx.fillStyle = '#FFFFFF';
    for (let i = 0; i < 30; i++) {
      const barW = Math.max(1, 10 - Math.floor(i / 3));
      const bx = 50 + i * 14;
      ctx.fillRect(bx, resY + 10, barW, 40);
    }

    const starX = w - 90;
    const starY = resY + 30;
    const radius = 24;
    for (let a = 0; a < 360; a += 15) {
      ctx.beginPath();
      ctx.moveTo(starX, starY);
      ctx.arc(starX, starY, radius, (a * Math.PI) / 180, ((a + 7.5) * Math.PI) / 180);
      ctx.closePath();
      ctx.fill();
    }

    for (let i = 0; i < depth.length; i++) depth[i] = 1.5;
  }

  private renderDaylightRunway(ctx: CanvasRenderingContext2D, w: number, h: number, depth: Float32Array): void {
    const skyGrad = ctx.createLinearGradient(0, 0, 0, h * 0.35);
    skyGrad.addColorStop(0, '#5A8BB5');
    skyGrad.addColorStop(1, '#9CC2DD');
    ctx.fillStyle = skyGrad;
    ctx.fillRect(0, 0, w, h * 0.35);

    ctx.fillStyle = '#3E5C4E';
    ctx.beginPath();
    ctx.moveTo(0, h * 0.35);
    ctx.lineTo(w * 0.25, h * 0.32);
    ctx.lineTo(w * 0.6, h * 0.34);
    ctx.lineTo(w, h * 0.31);
    ctx.lineTo(w, h * 0.35);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#486842';
    ctx.fillRect(0, h * 0.35, w, h * 0.65);

    ctx.fillStyle = '#7A8084';
    ctx.beginPath();
    ctx.moveTo(w * 0.46, h * 0.35);
    ctx.lineTo(w * 0.54, h * 0.35);
    ctx.lineTo(w * 0.85, h);
    ctx.lineTo(w * 0.15, h);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#E8ECEF';
    for (let i = 0; i < 7; i++) {
      const t0 = i / 7;
      const t1 = (i + 0.5) / 7;
      const y0 = h * (0.35 + t0 * 0.65);
      const y1 = h * (0.35 + t1 * 0.65);
      const dashW = 4 + t0 * 16;
      ctx.fillRect(w * 0.5 - dashW / 2, y0, dashW, y1 - y0);
    }

    ctx.fillStyle = '#2B3944';
    ctx.fillRect(w * 0.72, h * 0.30, w * 0.18, h * 0.12);
    ctx.fillStyle = '#B0B8BE';
    ctx.beginPath();
    ctx.moveTo(w * 0.72, h * 0.30);
    ctx.lineTo(w * 0.81, h * 0.26);
    ctx.lineTo(w * 0.90, h * 0.30);
    ctx.closePath();
    ctx.fill();

    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const idx = y * w + x;
        if (y < h * 0.35) {
          depth[idx] = 1200.0;
        } else {
          const normY = (y - h * 0.35) / (h * 0.65);
          depth[idx] = Math.max(15.0, 450.0 * (1.0 - normY * 0.92));
        }
      }
    }
  }

  private renderCoastalCliffs(ctx: CanvasRenderingContext2D, w: number, h: number, depth: Float32Array): void {
    const sky = ctx.createLinearGradient(0, 0, 0, h * 0.4);
    sky.addColorStop(0, '#8E9CA6');
    sky.addColorStop(1, '#BAC5CE');
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, w, h * 0.4);

    const sea = ctx.createLinearGradient(0, h * 0.4, 0, h);
    sea.addColorStop(0, '#243A48');
    sea.addColorStop(1, '#1A2A35');
    ctx.fillStyle = sea;
    ctx.fillRect(0, h * 0.4, w, h * 0.6);

    ctx.fillStyle = '#D9DFE3';
    ctx.beginPath();
    ctx.moveTo(0, h * 0.28);
    ctx.bezierCurveTo(w * 0.3, h * 0.32, w * 0.45, h * 0.45, w * 0.55, h * 0.65);
    ctx.lineTo(0, h * 0.65);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#838D95';
    ctx.fillRect(0, h * 0.62, w * 0.52, 6);

    ctx.fillStyle = '#F0F4F7';
    for (const tx of [w * 0.7, w * 0.82, w * 0.92]) {
      ctx.fillRect(tx, h * 0.32, 2, 28);
      ctx.beginPath();
      ctx.arc(tx + 1, h * 0.32, 12, 0, Math.PI * 2);
      ctx.strokeStyle = '#F0F4F7';
      ctx.stroke();
    }

    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        depth[y * w + x] = y < h * 0.3 ? 800 : 150 - (y / h) * 100;
      }
    }
  }

  private renderBridgeInspection(ctx: CanvasRenderingContext2D, w: number, h: number, depth: Float32Array): void {
    ctx.fillStyle = '#6E818F';
    ctx.fillRect(0, 0, w, h * 0.45);

    ctx.fillStyle = '#20323C';
    ctx.fillRect(0, h * 0.45, w, h * 0.55);

    ctx.fillStyle = '#9FA9B0';
    ctx.fillRect(w * 0.35, h * 0.1, w * 0.12, h * 0.8);

    ctx.strokeStyle = '#B33E32';
    ctx.lineWidth = 3;
    for (let i = 0; i < 8; i++) {
      ctx.beginPath();
      ctx.moveTo(w * 0.41, h * 0.15);
      ctx.lineTo(w * (0.05 + i * 0.05), h * 0.55);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(w * 0.41, h * 0.15);
      ctx.lineTo(w * (0.5 + i * 0.06), h * 0.55);
      ctx.stroke();
    }

    ctx.fillStyle = '#31373C';
    ctx.fillRect(0, h * 0.54, w, h * 0.08);

    for (let i = 0; i < depth.length; i++) depth[i] = 35.0;
  }

  private renderLowLightIndustrial(ctx: CanvasRenderingContext2D, w: number, h: number, depth: Float32Array): void {
    const dusk = ctx.createLinearGradient(0, 0, 0, h * 0.5);
    dusk.addColorStop(0, '#101720');
    dusk.addColorStop(1, '#24212F');
    ctx.fillStyle = dusk;
    ctx.fillRect(0, 0, w, h * 0.5);

    ctx.fillStyle = '#0F1215';
    ctx.fillRect(0, h * 0.5, w, h * 0.5);

    ctx.fillStyle = '#1A1E22';
    ctx.beginPath();
    ctx.moveTo(w * 0.18, h * 0.5);
    ctx.lineTo(w * 0.22, h * 0.2);
    ctx.lineTo(w * 0.38, h * 0.2);
    ctx.lineTo(w * 0.42, h * 0.5);
    ctx.closePath();
    ctx.fill();

    const glow = ctx.createRadialGradient(w * 0.3, h * 0.48, 2, w * 0.3, h * 0.48, 60);
    glow.addColorStop(0, '#F5A623');
    glow.addColorStop(0.4, 'rgba(245, 166, 35, 0.4)');
    glow.addColorStop(1, 'transparent');
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, w, h);

    for (let i = 0; i < depth.length; i++) depth[i] = 75.0;
  }

  private renderSunsetHorizon(ctx: CanvasRenderingContext2D, w: number, h: number, depth: Float32Array): void {
    const sunset = ctx.createLinearGradient(0, 0, 0, h * 0.6);
    sunset.addColorStop(0, '#1B263B');
    sunset.addColorStop(0.4, '#8D3A38');
    sunset.addColorStop(0.7, '#D66A2B');
    sunset.addColorStop(1, '#F7B733');
    ctx.fillStyle = sunset;
    ctx.fillRect(0, 0, w, h * 0.6);

    ctx.fillStyle = '#FFF2C6';
    ctx.beginPath();
    ctx.arc(w * 0.6, h * 0.52, 28, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#111518';
    ctx.beginPath();
    ctx.moveTo(0, h * 0.6);
    ctx.lineTo(w * 0.3, h * 0.58);
    ctx.lineTo(w * 0.7, h * 0.61);
    ctx.lineTo(w, h * 0.59);
    ctx.lineTo(w, h);
    ctx.lineTo(0, h);
    ctx.closePath();
    ctx.fill();

    for (let i = 0; i < depth.length; i++) depth[i] = 300.0;
  }

  private renderForestCanopy(ctx: CanvasRenderingContext2D, w: number, h: number, depth: Float32Array): void {
    ctx.fillStyle = '#263923';
    ctx.fillRect(0, 0, w, h);

    const greens = ['#3E5E35', '#4E723F', '#2C4426', '#5C864D', '#1F301B'];
    for (let i = 0; i < 180; i++) {
      const cx = (i * 73) % w;
      const cy = (i * 97) % h;
      const r = 18 + (i % 24);
      ctx.fillStyle = greens[i % greens.length];
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.strokeStyle = '#8B7355';
    ctx.lineWidth = 14;
    ctx.beginPath();
    ctx.moveTo(0, h * 0.4);
    ctx.bezierCurveTo(w * 0.3, h * 0.6, w * 0.7, h * 0.2, w, h * 0.5);
    ctx.stroke();

    for (let i = 0; i < depth.length; i++) depth[i] = 45.0;
  }

  private renderAgricultural(ctx: CanvasRenderingContext2D, w: number, h: number, depth: Float32Array): void {
    ctx.fillStyle = '#655541';
    ctx.fillRect(0, 0, w, h);

    for (let x = 0; x < w; x += 18) {
      ctx.fillStyle = (x % 36 === 0) ? '#457338' : '#5A8A47';
      ctx.fillRect(x, 0, 12, h);
    }

    ctx.strokeStyle = '#32281D';
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.moveTo(w * 0.65, 0);
    ctx.lineTo(w * 0.65, h);
    ctx.stroke();

    for (let i = 0; i < depth.length; i++) depth[i] = 60.0;
  }

  private renderHighContrast(ctx: CanvasRenderingContext2D, w: number, h: number, depth: Float32Array): void {
    ctx.fillStyle = '#06080A';
    ctx.fillRect(0, 0, w, h);

    ctx.fillStyle = '#FDFEFE';
    ctx.fillRect(w * 0.25, h * 0.15, w * 0.5, h * 0.7);

    ctx.fillStyle = '#111416';
    ctx.beginPath();
    ctx.moveTo(w * 0.5, h * 0.35);
    ctx.lineTo(w * 0.65, h * 0.6);
    ctx.lineTo(w * 0.35, h * 0.6);
    ctx.closePath();
    ctx.fill();

    for (let i = 0; i < depth.length; i++) depth[i] = 20.0;
  }

  private renderNightRunway(ctx: CanvasRenderingContext2D, w: number, h: number, depth: Float32Array): void {
    ctx.fillStyle = '#040608';
    ctx.fillRect(0, 0, w, h);

    ctx.fillStyle = '#090D11';
    ctx.beginPath();
    ctx.moveTo(w * 0.48, h * 0.4);
    ctx.lineTo(w * 0.52, h * 0.4);
    ctx.lineTo(w * 0.75, h);
    ctx.lineTo(w * 0.25, h);
    ctx.closePath();
    ctx.fill();

    for (let i = 0; i < 10; i++) {
      const t = (i + 1) / 10;
      const y = h * (0.4 + t * 0.6);
      ctx.fillStyle = '#00FF66';
      ctx.beginPath();
      ctx.arc(w * 0.5, y, 2 + t * 2, 0, Math.PI * 2);
      ctx.fill();
    }

    for (let i = 0; i < 8; i++) {
      const t = (i + 1) / 8;
      const y = h * (0.4 + t * 0.6);
      const leftX = w * (0.48 - t * 0.23);
      const rightX = w * (0.52 + t * 0.23);
      ctx.fillStyle = '#FFFFEE';
      ctx.fillRect(leftX - 1, y - 1, 3, 3);
      ctx.fillRect(rightX - 1, y - 1, 3, 3);
    }

    for (let i = 0; i < depth.length; i++) depth[i] = 120.0;
  }
}
