import { Injectable } from '@angular/core';
import {
  PipelineState,
  SpitfireExposureConfig,
  SpitfireLensConfig,
  SpitfireProcessedImage,
  SpitfireSensorConfig
} from '../models/spitfire.models';

@Injectable({
  providedIn: 'root'
})
export class RBridgeService {
  /**
   * Generates a fully reproducible R script matching the exact current workbench state.
   */
  public generateRScript(
    sensor: SpitfireSensorConfig,
    lens: SpitfireLensConfig,
    exposure: SpitfireExposureConfig,
    pipeline: PipelineState,
    sceneName: string,
    seed = 20260926
  ): string {
    return `# ==============================================================================
# SPITFIRE VISION - R-NATIVE COMPUTATIONAL IMAGING SCRIPT
# British Professional Drone Optical & Computational Laboratory
# Reproducible Pipeline Execution
# Generated: ${new Date().toISOString()}
# ==============================================================================

library(spitfireVision)
library(Matrix)

# 1. Set Deterministic Random Seed for Full Reproducibility
set.seed(${seed})

# 2. Define Physical Sensor Specification (VISION-01 CMOS Model)
sensor <- spitfire_sensor(
  model = "${sensor.model}",
  width = 8192,
  height = 6144,
  pixel_pitch_um = ${sensor.pixelPitchUm},
  bit_depth = ${sensor.bitDepth},
  iso = ${sensor.iso},
  temperature_c = ${sensor.temperatureC.toFixed(1)},
  black_level = ${sensor.blackLevel},
  white_level = ${sensor.whiteLevel}
)

# 3. Define Optical Drone Lens Model
lens <- spitfire_lens(
  focal_length_mm = ${lens.focalLengthMm},
  aperture_f = ${exposure.apertureF},
  fov_deg = ${lens.fovDeg},
  k1 = ${lens.k1},
  k2 = ${lens.k2},
  p1 = ${lens.p1},
  p2 = ${lens.p2},
  vignetting_coeff = ${lens.vignettingCoeff},
  chromatic_aberration_px = ${lens.chromaticAberrationPx}
)

# 4. Synthesize Ground Truth Scene: ${sceneName}
scene <- spitfire_scene_generator(
  scene_id = "${sceneName.toLowerCase().replace(/[^a-z0-9]/g, '_')}",
  illuminance_lux = 65000,
  colour_temp_k = 5500
)

# 5. Simulate Physical Raw Frame Capture (Poisson Shot Noise + Thermal Dark Current + ADC)
raw_frame <- spitfire_capture(
  sensor = sensor,
  scene = scene,
  exposure = list(
    shutter_s = ${exposure.shutterSpeedS.toFixed(5)},
    aperture_f = ${exposure.apertureF},
    ev = ${exposure.evOffset}
  ),
  seed = ${seed}
)

# 6. Construct Auditable Composable Pipeline via S3 Pipe Operators
pipe <- spitfire_pipeline() |>
  black_level(${sensor.blackLevel}) |>
  linearise(black_level = ${sensor.blackLevel}, white_level = ${sensor.whiteLevel}) |>
  bad_pixel_correct(threshold_sigma = 4.0) |>
  flat_field_correct() |>
  demosaic(method = "${pipeline.demosaicMethod}") |>
  white_balance(mode = "${pipeline.wbMode}", custom_gains = c(${pipeline.wbGains.join(', ')})) |>
  colour_transform(target_space = "${pipeline.colourSpace.toLowerCase().replace(/\s+/g, '_')}") |>
  tone_curve(gamma = 2.2) |>
  denoise(method = "${pipeline.denoiseMethod}", sigma_spatial = ${pipeline.denoiseSpatialSigma}, sigma_range = ${pipeline.denoiseRangeSigma}) |>
  sharpen(method = "${pipeline.sharpenMethod}", amount = ${pipeline.sharpenAmount}, radius = ${pipeline.sharpenRadius})

# 7. Execute Image Pipeline & Retain Complete Provenance
processed_image <- run_pipeline(raw_frame, pipe)

# 8. Compute Scientific Image Quality Metrics
metrics <- spitfire_iq_index(processed_image, reference = scene)
print(metrics)

# 9. Generate Camera Characterisation Report
report <- spitfire_characterisation_report(sensor, lens, calibration = NULL)
summary(report)
`;
  }

  /**
   * Generates a downloadable Characterisation Report as a Markdown/Text document.
   */
  public generateCharacterisationReportText(
    sensor: SpitfireSensorConfig,
    lens: SpitfireLensConfig,
    image: SpitfireProcessedImage
  ): string {
    return `# SPITFIRE VISION-01
## SENSOR & CAMERA PIPELINE CHARACTERISATION REPORT
Document ID: SPITFIRE-REP-${Date.now()}
Classification: COMMERCIAL AEROSPACE OPTICAL MEASUREMENT
Platform: SPITFIRE D-01 HEAVY DRONE

--------------------------------------------------------------------------------

1. PHYSICAL SENSOR SPECIFICATIONS
- Sensor Model: ${sensor.model}
- Architecture: Large-Format CMOS with Electronic Rolling Shutter Model
- Full Resolution: 8192 x 6144 px (50.3 Megapixels)
- Pixel Pitch: ${sensor.pixelPitchUm} µm
- ADC Bit Depth: ${sensor.bitDepth}-bit Linear Output (0 to ${sensor.whiteLevel} ADU)
- CFA Pattern: ${sensor.cfaPattern} Bayer Arrangement
- Saturation Capacity (Full Well): ${sensor.saturationCapacityE.toLocaleString()} e-
- Read Noise: ${sensor.readNoiseE.toFixed(2)} e- (RMS @ Base ISO 100)
- Thermal Dark Current: ${sensor.darkCurrentRate} e-/pixel/sec @ 20°C (Measured: ${(sensor.darkCurrentRate * Math.pow(2, (sensor.temperatureC - 20)/6)).toFixed(3)} e-/px/s @ ${sensor.temperatureC.toFixed(1)}°C)
- Pixel Response Non-Uniformity (PRNU): ${sensor.prnuPct}%
- Dark Signal Non-Uniformity (DSNU): ${sensor.dsnuE} e-

2. OPTICAL LENS CHARACTERISTICS
- Lens Model: ${lens.model}
- Focal Length: ${lens.focalLengthMm} mm
- Maximum Aperture: f/${lens.apertureF}
- Diagonal Field of View: ${lens.fovDeg}°
- Radial Distortion (k1, k2): ${lens.k1}, ${lens.k2} (Corrected via Brown-Conrady inverse warp)
- Tangential Distortion (p1, p2): ${lens.p1}, ${lens.p2}
- Optical Vignetting: cos^4(theta) power ${lens.vignettingCoeff}
- Lateral Chromatic Aberration: ${lens.chromaticAberrationPx} px corner shift

3. EMPIRICAL IMAGE QUALITY METRICS
- Mean Luminance: ${(image.metrics.meanLuminance * 100).toFixed(2)}%
- Exposure State: ${image.metrics.exposureState}
- Shadow Clipping: ${image.metrics.shadowClippingPct.toFixed(2)}%
- Highlight Clipping: ${image.metrics.highlightClippingPct.toFixed(2)}%
- Signal-to-Noise Ratio (SNR): ${image.metrics.snrDb.toFixed(1)} dB
- Peak Signal-to-Noise Ratio (PSNR): ${image.metrics.psnrDb.toFixed(1)} dB
- Structural Similarity Index (SSIM): ${image.metrics.ssim.toFixed(4)}
- Colour Fidelity (CIE Delta-E): ${image.metrics.colourDeltaE.toFixed(2)}
- MTF50 Spatial Frequency: ${image.metrics.mtf50LpMm.toFixed(1)} lp/mm
- SPITFIRE Composite IQ Score: ${image.metrics.spitfireIqComposite}/100

4. DIGITAL LINEAGE & PROVENANCE
- Raw Frame ID: ${image.rawFrameId}
- Flight ID: ${image.provenance.flightId}
- Mission ID: ${image.provenance.missionId}
- Pipeline Version: ${image.provenance.pipelineVersion}
- Total Processing Execution Time: ${image.provenance.totalProcessingTimeMs.toFixed(2)} ms
- Stages Executed: ${image.provenance.stagesExecuted.join(' -> ')}

--------------------------------------------------------------------------------
"The sensor is the instrument. The image is the measurement."
SPITFIRE Aerospace Optical Systems Laboratory, Farnborough, UK
`;
  }
}
