import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json());

/**
 * SPITFIRE VISION REST API
 */
app.get('/api/health', (req, res) => {
  res.json({
    status: 'SYSTEM_NOMINAL',
    sensor: 'VISION-01',
    version: '1.0.0-R-NATIVE',
    platform: 'SPITFIRE D-01 HEAVY DRONE',
    timestamp: new Date().toISOString()
  });
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`SPITFIRE VISION Server running on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI.
 */
export const reqHandler = createNodeRequestHandler(app);
