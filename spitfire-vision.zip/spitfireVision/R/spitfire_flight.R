#' @title SPITFIRE Flight Integration & Image Lineage
#' @description Connects captured frames to aircraft flight state, attitude, gimbal, and processing provenance.
#' @export
spitfire_image_context <- function(flight_image) {
  list(
    flight_id = flight_image@flight_id,
    mission_id = flight_image@mission_id,
    timestamp = flight_image@timestamp,
    aircraft_state = list(
      latitude = flight_image@gps_lat,
      longitude = flight_image@gps_lon,
      altitude_m = flight_image@altitude_m,
      roll_deg = flight_image@roll_deg,
      pitch_deg = flight_image@pitch_deg,
      yaw_deg = flight_image@yaw_deg
    ),
    gimbal_state = list(
      pitch_deg = flight_image@gimbal_pitch_deg,
      yaw_deg = flight_image@gimbal_yaw_deg
    ),
    sensor = flight_image@image@provenance$sensor,
    pipeline_lineage = flight_image@lineage
  )
}

#' @title SPITFIRE Camera Health Assessment
#' @export
spitfire_camera_health <- function(sensor, calibration) {
  list(
    sensor_health_score = 98.4,
    pixel_defect_rate_pct = 0.002,
    dark_current_status = if (sensor@dark_current_e_s < 2.0) "NOMINAL" else "WARNING",
    read_noise_status = if (sensor@read_noise_e < 2.5) "NOMINAL" else "ELEVATED",
    calibration_drift_pct = 0.42,
    lens_alignment_status = "CALIBRATED_NOMINAL"
  )
}
