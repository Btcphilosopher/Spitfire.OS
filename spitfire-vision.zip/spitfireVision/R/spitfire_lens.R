#' @title SPITFIRE Optical Lens Model
#' @description Models drone lens geometry, radial distortion (k1, k2), tangential distortion (p1, p2), optical vignetting, and chromatic aberration.
#' @param focal_length_mm Lens focal length in millimetres. Default 24.
#' @param aperture_f Lens aperture f-stop. Default 2.8.
#' @param fov_deg Diagonal field of view in degrees. Default 84.
#' @param k1 Primary radial distortion coefficient (Brown-Conrady). Default -0.045 (slight barrel).
#' @param k2 Secondary radial distortion coefficient. Default 0.008.
#' @param p1 Tangential distortion coefficient 1. Default 0.0002.
#' @param p2 Tangential distortion coefficient 2. Default -0.0001.
#' @param vignetting_coeff Cosine-fourth optical falloff power factor. Default 3.8.
#' @param chromatic_aberration_px Lateral chromatic aberration in pixels at image corner. Default 1.8.
#' @export
spitfire_lens <- function(
    focal_length_mm = 24,
    aperture_f = 2.8,
    fov_deg = 84,
    k1 = -0.045,
    k2 = 0.008,
    p1 = 0.0002,
    p2 = -0.0001,
    vignetting_coeff = 3.8,
    chromatic_aberration_px = 1.8,
    focus_distance_m = 15.0) {

  new("SpitfireLens",
      model = "SPITFIRE-AERO-24MM-F2.8",
      focal_length_mm = focal_length_mm,
      aperture_f = aperture_f,
      fov_deg = fov_deg,
      k1 = k1,
      k2 = k2,
      p1 = p1,
      p2 = p2,
      vignetting_coeff = vignetting_coeff,
      chromatic_aberration_px = chromatic_aberration_px,
      focus_distance_m = focus_distance_m
  )
}
