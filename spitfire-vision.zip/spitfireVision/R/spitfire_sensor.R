#' @title SPITFIRE Sensor Constructor and Simulation Model
#' @description Creates and configures a synthetic SPITFIRE sensor model (e.g. VISION-01).
#' @param model Sensor identifier string. Default "VISION-01".
#' @param width Sensor horizontal resolution in pixels. Default 8192.
#' @param height Sensor vertical resolution in pixels. Default 6144.
#' @param pixel_pitch_um Pixel pitch in micrometres. Default 3.2.
#' @param bit_depth ADC quantisation bit depth. Default 14.
#' @param iso ISO sensitivity setting (100 to 6400). Default 100.
#' @param temperature_c Sensor junction temperature in degrees Celsius. Default 38.5.
#' @param black_level Configurable digital black level pedestal (ADU). Default 512.
#' @param white_level Configurable digital saturation level (ADU). Default 16383.
#' @return A new SpitfireSensor object.
#' @export
spitfire_sensor <- function(
    model = "VISION-01",
    width = 8192,
    height = 6144,
    pixel_pitch_um = 3.2,
    bit_depth = 14,
    iso = 100,
    temperature_c = 38.5,
    black_level = 512,
    white_level = 16383) {

  # Sensor Physics: Analog gain proportional to ISO / 100
  gain <- iso / 100.0

  # Read noise in electrons (e-) follows CMOS amplifier model
  # Base read noise ~ 1.8 e- at base ISO, slightly rises with thermal and high conversion gain
  read_noise_e <- 1.8 * sqrt(1.0 + (gain - 1.0) * 0.15)

  # Dark current doubling every 6.0 °C (Arrhenius thermal relationship)
  # Base dark current ~ 0.5 e-/pixel/sec at 20 °C
  dark_current_e_s <- 0.5 * (2.0 ^ ((temperature_c - 20.0) / 6.0))

  # Full Well Capacity ~ 32,000 electrons for 3.2 um pixel pitch
  saturation_capacity_e <- 32000.0

  # PRNU (Pixel Response Non-Uniformity) ~ 0.8% standard CMOS
  prnu_pct <- 0.8

  # DSNU (Dark Signal Non-Uniformity) ~ 2.4 e-
  dsnu_e <- 2.4 * (1.0 + (temperature_c - 20.0) * 0.03)

  new("SpitfireSensor",
      model = model,
      width = width,
      height = height,
      pixel_pitch_um = pixel_pitch_um,
      bit_depth = bit_depth,
      iso = iso,
      gain = gain,
      read_noise_e = read_noise_e,
      dark_current_e_s = dark_current_e_s,
      saturation_capacity_e = saturation_capacity_e,
      black_level = black_level,
      white_level = white_level,
      temperature_c = temperature_c,
      cfa_pattern = "RGGB",
      prnu_pct = prnu_pct,
      dsnu_e = dsnu_e
  )
}
