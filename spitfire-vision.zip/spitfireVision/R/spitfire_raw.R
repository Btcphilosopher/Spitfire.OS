#' @title SPITFIRE Raw Sensor Simulator
#' @description Simulates the physical image capture process from incident scene radiance through optics, CFA mosaic, photon shot noise, dark current, read noise, fixed pattern noise, and ADC quantisation.
#' @param sensor A SpitfireSensor object.
#' @param scene A ground truth scene list or synthetic matrix containing 'rgb' and optional 'depth'.
#' @param exposure A list with 'shutter_s', 'aperture_f', 'ev'.
#' @param seed Optional random seed for reproducible Monte Carlo simulation.
#' @return A SpitfireRawFrame object containing the synthetic 14-bit CFA array and metadata.
#' @export
spitfire_capture <- function(sensor, scene, exposure = list(shutter_s = 1/500, aperture_f = 2.8, ev = 0), seed = NULL) {
  if (!is.null(seed)) {
    set.seed(seed)
  }

  h <- if (is.matrix(scene$rgb)) nrow(scene$rgb) else dim(scene$rgb)[1]
  w <- if (is.matrix(scene$rgb)) ncol(scene$rgb) else dim(scene$rgb)[2]

  # Incident photon flux scaled by scene luminance, exposure time, aperture area, and gain
  t_exp <- exposure$shutter_s
  f_num <- exposure$aperture_f
  ev_factor <- 2.0 ^ exposure$ev
  optical_throughput <- (1.0 / (4.0 * f_num^2)) * (t_exp / (1/500)) * ev_factor

  # CFA Pattern: Bayer RGGB
  # (Row 1: R G R G..., Row 2: G B G B...)
  raw_mat <- matrix(0, nrow = h, ncol = w)

  # Photons to electrons conversion (Quantum Efficiency ~ 68% peak)
  qe_r <- 0.62
  qe_g <- 0.74
  qe_b <- 0.58

  # Generate synthetic photon shot noise (Poisson) and read noise (Gaussian)
  for (r in seq_len(h)) {
    is_odd_row <- (r %% 2 == 1)
    for (c in seq_len(w)) {
      is_odd_col <- (c %% 2 == 1)

      if (is_odd_row && is_odd_col) {
        # Red pixel
        flux <- scene$rgb[r, c, 1] * optical_throughput * 40000.0 * qe_r
      } else if (is_odd_row && !is_odd_col) {
        # Green (Gr) pixel
        flux <- scene$rgb[r, c, 2] * optical_throughput * 40000.0 * qe_g
      } else if (!is_odd_row && is_odd_col) {
        # Green (Gb) pixel
        flux <- scene$rgb[r, c, 2] * optical_throughput * 40000.0 * qe_g
      } else {
        # Blue pixel
        flux <- scene$rgb[r, c, 3] * optical_throughput * 40000.0 * qe_b
      }

      # 1. Photon Shot Noise: Poisson(flux)
      electrons <- rpois(1, max(0.01, flux))

      # 2. PRNU (Pixel Response Non-Uniformity) multiplicative gain variation
      prnu_factor <- rnorm(1, mean = 1.0, sd = sensor@prnu_pct / 100.0)
      electrons <- electrons * prnu_factor

      # 3. Dark Current + DSNU
      dark_electrons <- rpois(1, max(0.001, sensor@dark_current_e_s * t_exp)) + rnorm(1, 0, sensor@dsnu_e)
      electrons <- electrons + dark_electrons

      # 4. Saturation clipping (Full Well Capacity)
      electrons <- min(sensor@saturation_capacity_e, max(0, electrons))

      # 5. Read noise (Amplifier Gaussian noise)
      electrons <- electrons + rnorm(1, mean = 0, sd = sensor@read_noise_e)

      # 6. ADC Quantisation to 14-bit with black level offset
      adc_conversion_gain <- (sensor@white_level - sensor@black_level) / sensor@saturation_capacity_e
      adu <- sensor@black_level + electrons * adc_conversion_gain * sensor@gain

      # 7. Hot / Stuck Pixel Injection (synthetic 0.005% probability)
      if (runif(1) < 0.00005) {
        adu <- sensor@white_level
      }

      # 8. Digital clamping to 14-bit range [0, 16383]
      raw_mat[r, c] <- min(sensor@white_level, max(0, round(adu)))
    }
  }

  frame_id <- paste0("SPITFIRE-FRAME-", as.numeric(Sys.time()), "-", sample(1000:9999, 1))

  new("SpitfireRawFrame",
      raw_array = raw_mat,
      sensor = sensor,
      exposure = exposure,
      timestamp = Sys.time(),
      frame_id = frame_id,
      metadata = list(
        dimensions = c(w, h),
        cfa = "RGGB",
        iso = sensor@iso,
        shutter = t_exp,
        aperture = f_num,
        temp_c = sensor@temperature_c,
        bit_depth = sensor@bit_depth
      ),
      ground_truth = scene
  )
}
