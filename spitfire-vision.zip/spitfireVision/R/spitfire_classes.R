#' @title SPITFIRE S4 Core Classes
#' @description Core formal class definitions for the SPITFIRE VISION imaging platform.
#' @import methods
#' @exportClass SpitfireSensor SpitfireLens SpitfirePixelArray SpitfireRawFrame SpitfireImage SpitfireCalibration SpitfireExposure SpitfireColourProfile SpitfireCameraState SpitfireFrameMetadata SpitfireLensModel SpitfireNoiseModel SpitfireImageQuality SpitfireFlightImage

setClass("SpitfireSensor",
  slots = list(
    model = "character",
    width = "numeric",
    height = "numeric",
    pixel_pitch_um = "numeric",
    bit_depth = "numeric",
    iso = "numeric",
    gain = "numeric",
    read_noise_e = "numeric",
    dark_current_e_s = "numeric",
    saturation_capacity_e = "numeric",
    black_level = "numeric",
    white_level = "numeric",
    temperature_c = "numeric",
    cfa_pattern = "character",
    prnu_pct = "numeric",
    dsnu_e = "numeric"
  )
)

setClass("SpitfireLens",
  slots = list(
    model = "character",
    focal_length_mm = "numeric",
    aperture_f = "numeric",
    fov_deg = "numeric",
    k1 = "numeric",
    k2 = "numeric",
    p1 = "numeric",
    p2 = "numeric",
    vignetting_coeff = "numeric",
    chromatic_aberration_px = "numeric",
    focus_distance_m = "numeric"
  )
)

setClass("SpitfireRawFrame",
  slots = list(
    raw_array = "ANY", # 2D numeric matrix [height, width]
    sensor = "SpitfireSensor",
    exposure = "list",
    timestamp = "POSIXct",
    frame_id = "character",
    metadata = "list",
    ground_truth = "list"
  )
)

setClass("SpitfireImage",
  slots = list(
    data = "array", # 3D array [height, width, channels]
    colour_space = "character",
    bit_depth = "numeric",
    provenance = "list",
    quality_metrics = "list"
  )
)

setClass("SpitfireCalibration",
  slots = list(
    calibration_id = "character",
    timestamp = "POSIXct",
    dark_frame = "ANY",
    flat_field_map = "ANY",
    bad_pixel_map = "ANY",
    colour_matrix_3x3 = "matrix",
    white_balance_gains = "numeric",
    lens_distortion_coeffs = "numeric"
  )
)

setClass("SpitfireFlightImage",
  slots = list(
    image = "SpitfireImage",
    flight_id = "character",
    mission_id = "character",
    timestamp = "POSIXct",
    gps_lat = "numeric",
    gps_lon = "numeric",
    altitude_m = "numeric",
    roll_deg = "numeric",
    pitch_deg = "numeric",
    yaw_deg = "numeric",
    gimbal_pitch_deg = "numeric",
    gimbal_yaw_deg = "numeric",
    sensor_telemetry = "list",
    lineage = "list"
  )
)
