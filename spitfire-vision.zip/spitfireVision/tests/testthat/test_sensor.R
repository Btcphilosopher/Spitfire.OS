library(testthat)

test_that("SpitfireSensor initializes with valid parameters", {
  sensor <- spitfire_sensor(width = 8192, height = 6144, iso = 100)
  expect_equal(sensor@width, 8192)
  expect_equal(sensor@height, 6144)
  expect_equal(sensor@bit_depth, 14)
  expect_equal(sensor@cfa_pattern, "RGGB")
  expect_true(sensor@read_noise_e > 0)
  expect_true(sensor@dark_current_e_s > 0)
})

test_that("SpitfirePipeline executes correctly and preserves lineage", {
  sensor <- spitfire_sensor(width = 64, height = 64, iso = 100)
  test_scene <- list(rgb = array(0.5, dim = c(64, 64, 3)))
  raw <- spitfire_capture(sensor, test_scene, seed = 42)

  pipeline <- spitfire_pipeline() |>
    black_level(512) |>
    demosaic("edge_aware") |>
    white_balance("daylight")

  result <- run_pipeline(raw, pipeline)

  expect_s4_class(result, "SpitfireImage")
  expect_equal(dim(result@data), c(64, 64, 3))
  expect_true(length(result@provenance$stages) >= 3)
})
