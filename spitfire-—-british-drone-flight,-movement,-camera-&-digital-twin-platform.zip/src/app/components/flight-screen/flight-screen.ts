import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SpitfireService } from '../../services/spitfire.service';
import { NavTab } from '../../models/spitfire.types';

@Component({
  selector: 'app-flight-screen',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full w-full bg-[#111416] text-[#ECE9E0] flex flex-col overflow-hidden p-3 gap-3 font-mono-tech select-none">
      
      <!-- Top Status Banner -->
      <div class="bg-[#252B2D] border border-[#31483F]/60 p-2.5 rounded-sm flex items-center justify-between text-xs shrink-0">
        <div class="flex items-center gap-4">
          <div class="flex items-center gap-2">
            <span class="text-[#C2C4BE]/60 uppercase text-[10px]">AIRCRAFT:</span>
            <span class="font-bold text-[#F4F3ED]">SPITFIRE S1 (SPF-00418)</span>
          </div>
          <div class="flex items-center gap-2 border-l border-[#31483F] pl-4">
            <span class="text-[#C2C4BE]/60 uppercase text-[10px]">ACTIVE MISSION:</span>
            <span class="font-bold text-[#C1943D] truncate max-w-xs">{{ activeMission().name }}</span>
          </div>
        </div>

        <div class="flex items-center gap-3">
          <span class="text-[10px] text-[#C2C4BE]/60">FAILSAFE STATUS:</span>
          <span class="px-2 py-0.5 rounded-xs text-[10px] font-bold"
            [ngClass]="activeFailures().size === 0 ? 'bg-[#31483F] text-emerald-300' : 'bg-[#A3433C] text-white animate-pulse'">
            {{ activeFailures().size === 0 ? 'NOMINAL' : activeFailures().size + ' ACTIVE FAULTS' }}
          </span>
        </div>
      </div>

      <!-- Main Flight Workspace Grid: 3 Columns -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-3 flex-1 min-h-0">
        
        <!-- LEFT: Map & FOV Navigation Field (Col 5) -->
        <div class="lg:col-span-5 bg-[#252B2D]/90 border border-[#31483F] rounded-sm flex flex-col overflow-hidden relative">
          <!-- Map Header Overlay -->
          <div class="absolute top-2 left-2 z-10 bg-[#111416]/90 border border-[#31483F] px-2.5 py-1 rounded-xs text-[10px] flex items-center gap-2">
            <mat-icon class="!text-[14px] !w-[14px] !h-[14px] text-[#3D6A7D]">map</mat-icon>
            <span class="font-bold text-[#F4F3ED]">SALISBURY / FIRTH OF FORTH TEST RANGE</span>
            <span class="text-[#C2C4BE]/60">· LAT {{ position().lat.toFixed(4) }}° N, LNG {{ position().lng.toFixed(4) }}° W</span>
          </div>

          <!-- Wind Vector Indicator -->
          <div class="absolute top-2 right-2 z-10 bg-[#111416]/90 border border-[#31483F] px-2 py-1 rounded-xs text-[10px] flex items-center gap-1.5">
            <mat-icon class="!text-[14px] !w-[14px] !h-[14px] text-[#C1943D]" [style.transform]="'rotate(' + wind().directionDeg + 'deg)'">navigation</mat-icon>
            <span>WIND {{ wind().speedMs }} m/s (GUST {{ wind().gustMs }})</span>
          </div>

          <!-- Interactive Synthetic Map Canvas -->
          <div class="w-full h-full bg-[#111416] bg-blueprint-grid relative overflow-hidden flex items-center justify-center cursor-crosshair">
            
            <!-- Map Grid Lines & Coordinate Vectors -->
            <svg class="w-full h-full absolute inset-0 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
              <line x1="0" y1="50%" x2="100%" y2="50%" stroke="rgba(38, 63, 82, 0.4)" stroke-dasharray="4 4"/>
              <line x1="50%" y1="0" x2="50%" y2="100%" stroke="rgba(38, 63, 82, 0.4)" stroke-dasharray="4 4"/>
              
              <!-- Flight Path Vector Trace -->
              <polyline points="120,380 180,320 260,280 340,240 410,210" fill="none" stroke="#3D6A7D" stroke-width="2" stroke-dasharray="2 2"/>
              <polyline points="410,210 460,190" fill="none" stroke="#C1943D" stroke-width="2.5"/>

              <!-- Mission Waypoints -->
              @for (wp of activeMission().items; track wp.id; let idx = $index) {
                <g [attr.transform]="'translate(' + (120 + idx * 70) + ',' + (380 - idx * 35) + ')'">
                  <circle r="8" fill="#111416" stroke="#C1943D" stroke-width="2"/>
                  <text y="3" text-anchor="middle" fill="#F4F3ED" font-size="9" font-weight="bold">{{ wp.seq }}</text>
                </g>
              }

              <!-- Camera FOV Projection Cone -->
              <g transform="translate(460, 190)">
                <path d="M 0 0 L -40 -120 L 40 -120 Z" fill="rgba(49, 72, 63, 0.35)" stroke="#31483F" stroke-width="1.5"
                      [attr.transform]="'rotate(' + (position().heading + gimbal().yawDeg) + ')'"/>
              </g>

              <!-- Drone Center Position Icon -->
              <g transform="translate(460, 190)">
                <!-- Rotating Drone Body -->
                <g [attr.transform]="'rotate(' + position().heading + ')'">
                  <circle r="14" fill="#111416" stroke="#ECE9E0" stroke-width="2"/>
                  <!-- 4 Rotor Arms -->
                  <line x1="-18" y1="-18" x2="18" y2="18" stroke="#ECE9E0" stroke-width="2"/>
                  <line x1="-18" y1="18" x2="18" y2="-18" stroke="#ECE9E0" stroke-width="2"/>
                  <circle cx="-18" cy="-18" r="6" fill="#31483F" stroke="#F4F3ED"/>
                  <circle cx="18" cy="-18" r="6" fill="#31483F" stroke="#F4F3ED"/>
                  <circle cx="-18" cy="18" r="6" fill="#252B2D" stroke="#C2C4BE"/>
                  <circle cx="18" cy="18" r="6" fill="#252B2D" stroke="#C2C4BE"/>
                  <polygon points="0,-18 -4,-10 4,-10" fill="#C1943D"/>
                </g>
              </g>
            </svg>

            <!-- Map HUD Footer Overlay -->
            <div class="absolute bottom-2 left-2 right-2 z-10 flex items-center justify-between text-[10px] text-[#C2C4BE] bg-[#111416]/80 px-2 py-1 border border-[#252B2D]">
              <span>RANGE DIST: 1,840 m</span>
              <span>FOV ANGLE: 84°</span>
              <span>ALT AGL: {{ position().relativeAlt.toFixed(1) }} m</span>
            </div>
          </div>
        </div>

        <!-- CENTRE: Attitude Sphere / Artificial Horizon (Col 4) -->
        <div class="lg:col-span-4 bg-[#252B2D]/90 border border-[#31483F] rounded-sm flex flex-col overflow-hidden p-3 gap-2">
          <div class="flex items-center justify-between border-b border-[#31483F] pb-1.5 text-xs">
            <span class="font-bold text-[#F4F3ED] flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#31483F]">explore</mat-icon>
              3D ATTITUDE & GIMBAL HUD
            </span>
            <span class="text-[#C2C4BE]/60">RATE: 100Hz</span>
          </div>

          <!-- Artificial Horizon Gauge -->
          <div class="flex-1 bg-[#111416] border border-[#31483F] rounded-xs relative flex items-center justify-center overflow-hidden">
            
            <!-- Pitch & Roll Gyro Container -->
            <div class="w-full h-full relative transition-transform duration-100 ease-out"
                 [style.transform]="'rotate(' + (-attitude().roll) + 'deg)'">
              
              <!-- Sky & Ground Dynamic Horizon -->
              <div class="w-[200%] h-[200%] absolute -top-[50%] -left-[50%] transition-transform duration-100 ease-out"
                   [style.transform]="'translateY(' + (attitude().pitch * 3) + 'px)'">
                <!-- Sky -->
                <div class="w-full h-1/2 bg-[#263F52]/60 border-b-2 border-emerald-400"></div>
                <!-- Ground -->
                <div class="w-full h-1/2 bg-[#31483F]/80"></div>
              </div>

              <!-- Pitch Ladder Lines -->
              <div class="absolute inset-0 flex flex-col items-center justify-center gap-4 text-[9px] font-bold text-emerald-400/80 pointer-events-none">
                <div class="border-t border-[#ECE9E0] w-20 text-center">-20°</div>
                <div class="border-t border-[#ECE9E0] w-14 text-center">-10°</div>
                <div class="border-t-2 stroke-dasharray border-emerald-400 w-28 text-center">0° HORIZON</div>
                <div class="border-t border-[#ECE9E0] w-14 text-center">+10°</div>
                <div class="border-t border-[#ECE9E0] w-20 text-center">+20°</div>
              </div>
            </div>

            <!-- Fixed Aircraft Horizon Crosshair -->
            <svg class="absolute inset-0 w-full h-full pointer-events-none z-10" viewBox="0 0 200 200">
              <!-- Center Aircraft Reticle -->
              <path d="M 60 100 L 85 100 L 95 110 L 105 110 L 115 100 L 140 100" stroke="#C1943D" stroke-width="2.5" fill="none"/>
              <circle cx="100" cy="100" r="3" fill="#C1943D"/>
            </svg>

            <!-- Gimbal Pitch Overlay Bar -->
            <div class="absolute right-2 top-4 bottom-4 w-5 bg-[#252B2D]/80 border border-[#31483F] rounded-xs flex flex-col justify-between items-center py-2 text-[8px] text-[#C2C4BE]">
              <span>+20°</span>
              <!-- Gimbal Indicator Marker -->
              <div class="w-full h-1.5 bg-[#C1943D] transition-all" 
                   [style.transform]="'translateY(' + (-(gimbal().pitchDeg + 45) * 0.8) + 'px)'"></div>
              <span>-90°</span>
            </div>
          </div>

          <!-- Euler Angle Digital Readouts -->
          <div class="grid grid-cols-3 gap-2 text-center text-xs bg-[#111416] p-2 border border-[#252B2D]">
            <div class="flex flex-col">
              <span class="text-[9px] text-[#C2C4BE]/60 uppercase">ROLL</span>
              <span class="font-bold text-[#F4F3ED] text-sm">{{ attitude().roll > 0 ? '+' : '' }}{{ attitude().roll.toFixed(1) }}°</span>
            </div>
            <div class="flex flex-col border-x border-[#252B2D]">
              <span class="text-[9px] text-[#C2C4BE]/60 uppercase">PITCH</span>
              <span class="font-bold text-[#F4F3ED] text-sm">{{ attitude().pitch > 0 ? '+' : '' }}{{ attitude().pitch.toFixed(1) }}°</span>
            </div>
            <div class="flex flex-col">
              <span class="text-[9px] text-[#C2C4BE]/60 uppercase">YAW / HDG</span>
              <span class="font-bold text-[#C1943D] text-sm">{{ position().heading.toFixed(0).padStart(3, '0') }}°</span>
            </div>
          </div>
        </div>

        <!-- RIGHT: Telemetry Readout Grid (Col 3) -->
        <div class="lg:col-span-3 bg-[#252B2D]/90 border border-[#31483F] rounded-sm flex flex-col overflow-hidden p-3 gap-2">
          <div class="flex items-center justify-between border-b border-[#31483F] pb-1.5 text-xs">
            <span class="font-bold text-[#F4F3ED] flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-emerald-400">monitor_heart</mat-icon>
              TELEMETRY BUS
            </span>
            <span class="text-[#ECE9E0] font-bold">LIVE STREAM</span>
          </div>

          <div class="flex-1 grid grid-cols-1 gap-2 overflow-y-auto pr-1">
            
            <!-- Altitude -->
            <div class="bg-[#111416] p-2.5 border border-[#252B2D] flex items-center justify-between">
              <div>
                <div class="text-[9px] text-[#C2C4BE]/60 uppercase">ALTITUDE (AGL)</div>
                <div class="text-xl font-bold text-[#F4F3ED] font-display">{{ position().alt.toFixed(1) }} <span class="text-xs text-[#C2C4BE]">m</span></div>
              </div>
              <mat-icon class="text-[#3D6A7D]">height</mat-icon>
            </div>

            <!-- Ground Speed -->
            <div class="bg-[#111416] p-2.5 border border-[#252B2D] flex items-center justify-between">
              <div>
                <div class="text-[9px] text-[#C2C4BE]/60 uppercase">GROUND SPEED</div>
                <div class="text-xl font-bold text-[#F4F3ED] font-display">{{ position().groundSpeed.toFixed(1) }} <span class="text-xs text-[#C2C4BE]">m/s</span></div>
              </div>
              <mat-icon class="text-[#3D6A7D]">speed</mat-icon>
            </div>

            <!-- Vertical Speed -->
            <div class="bg-[#111416] p-2.5 border border-[#252B2D] flex items-center justify-between">
              <div>
                <div class="text-[9px] text-[#C2C4BE]/60 uppercase">VERTICAL SPEED</div>
                <div class="text-xl font-bold font-display" [ngClass]="position().verticalSpeed >= 0 ? 'text-emerald-400' : 'text-[#A3433C]'">
                  {{ position().verticalSpeed >= 0 ? '+' : '' }}{{ position().verticalSpeed.toFixed(1) }} <span class="text-xs text-[#C2C4BE]">m/s</span>
                </div>
              </div>
              <mat-icon class="text-[#3D6A7D]">swap_vert</mat-icon>
            </div>

            <!-- Heading -->
            <div class="bg-[#111416] p-2.5 border border-[#252B2D] flex items-center justify-between">
              <div>
                <div class="text-[9px] text-[#C2C4BE]/60 uppercase">HEADING</div>
                <div class="text-xl font-bold text-[#C1943D] font-display">{{ position().heading.toFixed(0).padStart(3, '0') }}°</div>
              </div>
              <mat-icon class="text-[#C1943D]">compass_calibration</mat-icon>
            </div>

            <!-- Battery -->
            <div class="bg-[#111416] p-2.5 border border-[#252B2D] flex items-center justify-between">
              <div>
                <div class="text-[9px] text-[#C2C4BE]/60 uppercase">BATTERY SOC</div>
                <div class="text-xl font-bold font-display text-emerald-400">{{ battery().soc }} <span class="text-xs text-[#C2C4BE]">% ({{ battery().voltage }}V)</span></div>
              </div>
              <mat-icon class="text-emerald-400">battery_charging_full</mat-icon>
            </div>

            <!-- GPS Fix -->
            <div class="bg-[#111416] p-2.5 border border-[#252B2D] flex items-center justify-between">
              <div>
                <div class="text-[9px] text-[#C2C4BE]/60 uppercase">GNSS / SATELLITES</div>
                <div class="text-sm font-bold text-[#F4F3ED] font-display">{{ sensors().gnssFix }} ({{ sensors().satellites }} SATS)</div>
              </div>
              <mat-icon class="text-[#3D6A7D]">gps_fixed</mat-icon>
            </div>

            <!-- Flight Time -->
            <div class="bg-[#111416] p-2.5 border border-[#252B2D] flex items-center justify-between">
              <div>
                <div class="text-[9px] text-[#C2C4BE]/60 uppercase">FLIGHT TIME ELAPSED</div>
                <div class="text-xl font-bold text-[#F4F3ED] font-display">{{ formatFlightTime(telemetry().elapsedSec) }}</div>
              </div>
              <mat-icon class="text-[#31483F]">timer</mat-icon>
            </div>

          </div>
        </div>

      </div>

      <!-- BOTTOM: State-Aware Action Control Bar -->
      <div class="bg-[#252B2D] border border-[#31483F] p-2.5 rounded-sm flex flex-wrap items-center justify-between gap-2 shrink-0">
        
        <!-- Left State Command Buttons -->
        <div class="flex items-center gap-2">
          
          <button (click)="sendCommand('ARM')" 
            [disabled]="isArmed()"
            class="px-3.5 py-2 bg-[#31483F] hover:bg-[#263F52] disabled:opacity-40 disabled:hover:bg-[#31483F] text-[#F4F3ED] font-bold rounded-xs flex items-center gap-1.5 transition-colors">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">power_settings_new</mat-icon>
            <span>ARM AIRCRAFT</span>
          </button>

          <button (click)="sendCommand('TAKEOFF')" 
            [disabled]="!isArmed() || vehicleState() === 'FLIGHT'"
            class="px-3 py-2 bg-[#263F52] hover:bg-[#3D6A7D] disabled:opacity-40 text-[#F4F3ED] font-bold rounded-xs flex items-center gap-1.5 transition-colors">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">flight_takeoff</mat-icon>
            <span>TAKEOFF</span>
          </button>

          <button (click)="selectTab('MISSION')" 
            class="px-3 py-2 bg-[#111416] hover:bg-[#31483F] text-[#ECE9E0] border border-[#31483F] font-bold rounded-xs flex items-center gap-1.5 transition-colors">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#C1943D]">route</mat-icon>
            <span>MISSION PLANNER</span>
          </button>

          <button (click)="triggerCapture()" 
            class="px-3 py-2 bg-[#C1943D] hover:bg-[#b08532] text-[#111416] font-bold rounded-xs flex items-center gap-1.5 transition-colors">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">photo_camera</mat-icon>
            <span>CAPTURE PHOTO</span>
          </button>

          <button (click)="sendCommand('RTL')" 
            class="px-3 py-2 bg-[#111416] hover:bg-[#A3433C] text-[#ECE9E0] border border-[#A3433C]/60 font-bold rounded-xs flex items-center gap-1.5 transition-colors">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#A3433C]">home</mat-icon>
            <span>RETURN TO LAND</span>
          </button>

          <button (click)="sendCommand('LAND')" 
            class="px-3 py-2 bg-[#111416] hover:bg-[#31483F] text-[#ECE9E0] border border-[#31483F] font-bold rounded-xs flex items-center gap-1.5 transition-colors">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">flight_land</mat-icon>
            <span>LAND NOW</span>
          </button>
        </div>

        <!-- Right Safety & Emergency Actions -->
        <div class="flex items-center gap-2">
          
          <button (click)="toggleSimulation()" 
            class="px-3 py-2 bg-[#111416] border border-[#31483F] text-[#ECE9E0] hover:text-white font-bold rounded-xs flex items-center gap-1.5 transition-colors">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" [ngClass]="simulationActive() ? 'text-emerald-400' : 'text-[#C2C4BE]'">
              {{ simulationActive() ? 'pause' : 'play_arrow' }}
            </mat-icon>
            <span>SIMULATION: {{ simulationActive() ? 'RUNNING' : 'PAUSED' }}</span>
          </button>

          <button (click)="sendCommand('EMERGENCY')" 
            class="px-3 py-2 bg-[#A3433C] hover:bg-red-700 text-white font-bold rounded-xs flex items-center gap-1.5 transition-colors">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">emergency</mat-icon>
            <span>EMERGENCY CUT</span>
          </button>

        </div>

      </div>

    </div>
  `
})
export class FlightScreen {
  spitfire = inject(SpitfireService);

  telemetry = this.spitfire.telemetry;
  position = () => this.telemetry().position;
  attitude = () => this.telemetry().attitude;
  battery = () => this.telemetry().battery;
  sensors = () => this.telemetry().sensors;
  camera = () => this.telemetry().camera;
  gimbal = () => this.telemetry().gimbal;
  wind = () => this.telemetry().windVector;
  
  activeMission = this.spitfire.activeMission;
  activeFailures = this.spitfire.activeFailures;
  simulationActive = this.spitfire.simulationActive;
  isArmed = this.spitfire.isArmed;
  vehicleState = this.spitfire.vehicleState;

  selectTab(tab: NavTab) {
    this.spitfire.setActiveTab(tab);
  }

  sendCommand(cmd: 'ARM' | 'DISARM' | 'TAKEOFF' | 'LAND' | 'RTL' | 'PAUSE' | 'EMERGENCY') {
    this.spitfire.sendCommand(cmd);
  }

  triggerCapture() {
    this.spitfire.triggerCapture();
  }

  toggleSimulation() {
    this.spitfire.simulationActive.set(!this.spitfire.simulationActive());
  }

  formatFlightTime(sec: number): string {
    const mins = Math.floor(sec / 60);
    const secs = Math.floor(sec % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
}
