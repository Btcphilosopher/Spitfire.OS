import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { SpitfireService } from '../../services/spitfire.service';

@Component({
  selector: 'app-telemetry-screen',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full w-full bg-[#111416] text-[#ECE9E0] flex flex-col p-3 gap-3 font-mono-tech select-none overflow-hidden">
      
      <!-- Header Bar -->
      <div class="bg-[#252B2D] border border-[#31483F] p-2.5 rounded-sm flex items-center justify-between text-xs shrink-0">
        <div class="flex items-center gap-3">
          <mat-icon class="text-emerald-400">sensors</mat-icon>
          <div>
            <span class="font-bold text-[#F4F3ED] font-display uppercase tracking-wider">SPITFIRE BLACK BOX & HIGH-FREQUENCY TELEMETRY BUS</span>
            <span class="text-[10px] text-[#C2C4BE]/60 ml-2">FLIGHT LOG: FLIGHT-2026-004812</span>
          </div>
        </div>

        <button (click)="exportBlackBox()" 
          class="px-3 py-1.5 bg-[#31483F] hover:bg-[#263F52] text-[#F4F3ED] font-bold rounded-xs text-xs flex items-center gap-1.5 transition-colors">
          <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">file_download</mat-icon>
          <span>EXPORT BLACK BOX LOG (.SBB)</span>
        </button>
      </div>

      <!-- Main Content Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-3 flex-1 min-h-0">
        
        <!-- LEFT: Channel Inspector Table (Col 6) -->
        <div class="lg:col-span-6 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0">
          
          <div class="flex items-center justify-between text-xs border-b border-[#31483F] pb-2">
            <span class="font-bold text-[#F4F3ED] flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#3D6A7D]">list</mat-icon>
              TELEMETRY CHANNEL REGISTER
            </span>
            <span class="text-emerald-400 font-bold">FREQUENCY: 100 Hz</span>
          </div>

          <div class="flex-1 overflow-y-auto border border-[#252B2D] bg-[#111416]">
            <table class="w-full text-left text-xs border-collapse">
              <thead>
                <tr class="bg-[#252B2D] text-[#C2C4BE] border-b border-[#31483F] text-[10px] uppercase font-bold">
                  <th class="p-2">CHANNEL ID</th>
                  <th class="p-2">DESCRIPTION</th>
                  <th class="p-2">VALUE</th>
                  <th class="p-2">UNIT</th>
                  <th class="p-2 text-right">QUALITY</th>
                </tr>
              </thead>
              <tbody>
                <tr class="border-b border-[#252B2D] hover:bg-[#31483F]/20">
                  <td class="p-2 font-bold text-[#C1943D]">POS_LAT</td>
                  <td class="p-2 text-[#ECE9E0]">Vehicle Latitude</td>
                  <td class="p-2 font-mono-tech font-bold text-[#F4F3ED]">{{ telemetry().position.lat.toFixed(6) }}</td>
                  <td class="p-2 text-[#C2C4BE]">deg N</td>
                  <td class="p-2 text-right text-emerald-400 font-bold">100%</td>
                </tr>
                <tr class="border-b border-[#252B2D] hover:bg-[#31483F]/20">
                  <td class="p-2 font-bold text-[#C1943D]">POS_LNG</td>
                  <td class="p-2 text-[#ECE9E0]">Vehicle Longitude</td>
                  <td class="p-2 font-mono-tech font-bold text-[#F4F3ED]">{{ telemetry().position.lng.toFixed(6) }}</td>
                  <td class="p-2 text-[#C2C4BE]">deg W</td>
                  <td class="p-2 text-right text-emerald-400 font-bold">100%</td>
                </tr>
                <tr class="border-b border-[#252B2D] hover:bg-[#31483F]/20">
                  <td class="p-2 font-bold text-[#C1943D]">ALT_AGL</td>
                  <td class="p-2 text-[#ECE9E0]">Baro/Range Alt AGL</td>
                  <td class="p-2 font-mono-tech font-bold text-[#F4F3ED]">{{ telemetry().position.alt.toFixed(2) }}</td>
                  <td class="p-2 text-[#C2C4BE]">m</td>
                  <td class="p-2 text-right text-emerald-400 font-bold">99.8%</td>
                </tr>
                <tr class="border-b border-[#252B2D] hover:bg-[#31483F]/20">
                  <td class="p-2 font-bold text-[#C1943D]">ATT_ROLL</td>
                  <td class="p-2 text-[#ECE9E0]">Roll Euler Angle</td>
                  <td class="p-2 font-mono-tech font-bold text-[#F4F3ED]">{{ telemetry().attitude.roll.toFixed(2) }}</td>
                  <td class="p-2 text-[#C2C4BE]">deg</td>
                  <td class="p-2 text-right text-emerald-400 font-bold">100%</td>
                </tr>
                <tr class="border-b border-[#252B2D] hover:bg-[#31483F]/20">
                  <td class="p-2 font-bold text-[#C1943D]">ATT_PITCH</td>
                  <td class="p-2 text-[#ECE9E0]">Pitch Euler Angle</td>
                  <td class="p-2 font-mono-tech font-bold text-[#F4F3ED]">{{ telemetry().attitude.pitch.toFixed(2) }}</td>
                  <td class="p-2 text-[#C2C4BE]">deg</td>
                  <td class="p-2 text-right text-emerald-400 font-bold">100%</td>
                </tr>
                <tr class="border-b border-[#252B2D] hover:bg-[#31483F]/20">
                  <td class="p-2 font-bold text-[#C1943D]">BAT_SOC</td>
                  <td class="p-2 text-[#ECE9E0]">State of Charge</td>
                  <td class="p-2 font-mono-tech font-bold text-emerald-400">{{ telemetry().battery.soc }}</td>
                  <td class="p-2 text-[#C2C4BE]">%</td>
                  <td class="p-2 text-right text-emerald-400 font-bold">100%</td>
                </tr>
                <tr class="border-b border-[#252B2D] hover:bg-[#31483F]/20">
                  <td class="p-2 font-bold text-[#C1943D]">LINK_LATENCY</td>
                  <td class="p-2 text-[#ECE9E0]">Telemetry Link RTT</td>
                  <td class="p-2 font-mono-tech font-bold text-[#F4F3ED]">{{ telemetry().sensors.linkLatencyMs }}</td>
                  <td class="p-2 text-[#C2C4BE]">ms</td>
                  <td class="p-2 text-right text-emerald-400 font-bold">98.5%</td>
                </tr>
              </tbody>
            </table>
          </div>

        </div>

        <!-- RIGHT: Live Event Log Stream (Col 6) -->
        <div class="lg:col-span-6 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0">
          
          <div class="flex items-center justify-between text-xs border-b border-[#31483F] pb-2">
            <span class="font-bold text-[#F4F3ED] flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#C1943D]">history</mat-icon>
              SYSTEM EVENT BUS LOG
            </span>
            <span class="text-[#C2C4BE]">{{ events().length }} EVENTS RECORDED</span>
          </div>

          <div class="flex-1 overflow-y-auto border border-[#252B2D] bg-[#111416] p-2 flex flex-col gap-1.5 font-mono-tech text-xs">
            @for (ev of events(); track ev.id) {
              <div class="p-2 bg-[#252B2D] border-l-2 text-[11px] flex flex-col gap-0.5"
                   [ngClass]="getEventBorderClass(ev.severity)">
                <div class="flex items-center justify-between font-bold">
                  <span class="text-[#F4F3ED]">{{ ev.timestamp }} · {{ ev.category }}</span>
                  <span class="px-1.5 py-0.2 rounded-xs text-[9px]" [ngClass]="getEventBadgeClass(ev.severity)">{{ ev.severity }}</span>
                </div>
                <div class="text-[#ECE9E0]">{{ ev.message }}</div>
                @if (ev.details) {
                  <div class="text-[9px] text-[#C2C4BE]/60">{{ ev.details }}</div>
                }
              </div>
            }
          </div>

        </div>

      </div>

      <!-- BOTTOM: Timeline Scrubber (0:00 -> 30:00) -->
      <div class="bg-[#252B2D] border border-[#31483F] p-3 rounded-sm flex flex-col gap-2 shrink-0">
        <div class="flex items-center justify-between text-xs">
          <span class="font-bold text-[#F4F3ED] flex items-center gap-1.5">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#3D6A7D]">linear_scale</mat-icon>
            FLIGHT TIMELINE SCRUBBER (0:00 → 30:00)
          </span>
          <span class="font-bold text-[#C1943D]">REPLAY TIME: {{ formatTime(scrubTime()) }} / 30:00</span>
        </div>

        <input type="range" min="0" max="1800" [ngModel]="scrubTime()" (ngModelChange)="onScrub($event)" 
               class="w-full accent-[#C1943D] cursor-pointer">
      </div>

    </div>
  `
})
export class TelemetryScreen {
  spitfire = inject(SpitfireService);

  telemetry = this.spitfire.telemetry;
  events = this.spitfire.events;

  scrubTime = signal<number>(868);

  onScrub(val: number) {
    this.scrubTime.set(val);
    this.spitfire.telemetry.update(t => ({ ...t, elapsedSec: val }));
  }

  formatTime(sec: number): string {
    const mins = Math.floor(sec / 60);
    const secs = Math.floor(sec % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }

  getEventBorderClass(sev: string): string {
    if (sev === 'CRITICAL' || sev === 'SAFETY') return 'border-[#A3433C]';
    if (sev === 'WARNING') return 'border-[#C1943D]';
    return 'border-[#3D6A7D]';
  }

  getEventBadgeClass(sev: string): string {
    if (sev === 'CRITICAL' || sev === 'SAFETY') return 'bg-[#A3433C] text-white';
    if (sev === 'WARNING') return 'bg-[#C1943D] text-[#111416] font-bold';
    return 'bg-[#263F52] text-[#F4F3ED]';
  }

  exportBlackBox() {
    const data = JSON.stringify({
      flightId: 'FLIGHT-2026-004812',
      exportedAt: new Date().toISOString(),
      telemetry: this.telemetry(),
      events: this.events()
    }, null, 2);

    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'SPITFIRE-BLACKBOX-FLIGHT-2026-004812.json';
    a.click();
  }
}
