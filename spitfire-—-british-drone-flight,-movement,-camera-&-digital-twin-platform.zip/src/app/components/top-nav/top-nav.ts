import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SpitfireService } from '../../services/spitfire.service';
import { FlightMode, NavTab } from '../../models/spitfire.types';

@Component({
  selector: 'app-top-nav',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-[#111416] border-b border-[#252B2D] px-4 py-2.5 flex items-center justify-between text-xs font-mono-tech select-none shrink-0 z-30">
      <!-- Zone 1: Brand & State Lockup -->
      <div class="flex items-center gap-3 shrink-0">
        <a (click)="selectTab('FLIGHT')" (keydown.enter)="selectTab('FLIGHT')" tabindex="0" role="button" class="cursor-pointer flex items-center gap-2 group">
          <div class="w-6 h-6 bg-[#31483F] border border-[#ECE9E0]/20 rounded-sm flex items-center justify-center text-[#F4F3ED] font-bold font-display text-sm tracking-wider group-hover:bg-[#263F52] transition-colors">
            S
          </div>
          <div class="flex flex-col leading-tight">
            <span class="font-display font-bold text-sm tracking-widest text-[#F4F3ED] group-hover:text-[#C2C4BE] transition-colors">
              SPITFIRE
            </span>
            <span class="text-[10px] text-[#C2C4BE]/60 tracking-wider font-mono-tech">
              BRITISH AEROSPACE S1
            </span>
          </div>
        </a>

        <div class="h-6 w-[1px] bg-[#252B2D] mx-1"></div>

        <!-- System State Pill -->
        <div class="flex items-center gap-2 px-2.5 py-1 bg-[#252B2D]/80 border border-[#31483F]/50 rounded-sm">
          <span class="w-2 h-2 rounded-full animate-pulse" [ngClass]="getStateDotClass()"></span>
          <span class="font-bold tracking-wide text-[#F4F3ED]">{{ telemetry().vehicleState }}</span>
        </div>

        <!-- Mode Indicator -->
        <div class="hidden lg:flex items-center gap-1 bg-[#111416] border border-[#252B2D] p-0.5 rounded-sm">
          @for (m of modes; track m) {
            <button 
              (click)="setMode(m)" 
              [class]="flightMode() === m 
                ? 'bg-[#31483F] text-[#F4F3ED] font-semibold px-2 py-0.5 rounded-xs' 
                : 'text-[#C2C4BE]/60 hover:text-[#ECE9E0] px-2 py-0.5 transition-colors'"
              class="text-[10px] tracking-wider uppercase transition-colors">
              {{ m }}
            </button>
          }
        </div>
      </div>

      <!-- Zone 2: Navigation Links (11 Tabs) -->
      <nav class="hidden xl:flex items-center gap-1 bg-[#111416] border border-[#252B2D] p-1 rounded-sm">
        @for (t of navTabs; track t.id) {
          <button 
            (click)="selectTab(t.id)"
            [class]="activeTab() === t.id 
              ? 'bg-[#263F52] text-[#F4F3ED] font-bold border-b-2 border-[#C1943D]' 
              : 'text-[#C2C4BE] hover:text-[#F4F3ED] hover:bg-[#252B2D]/50'"
            class="px-2.5 py-1 text-[11px] font-mono-tech tracking-wider uppercase transition-all flex items-center gap-1.5 whitespace-nowrap">
            <mat-icon class="!text-[14px] !w-[14px] !h-[14px] opacity-80">{{ t.icon }}</mat-icon>
            <span>{{ t.label }}</span>
          </button>
        }
      </nav>

      <!-- Mobile/Medium Tab Selector Dropdown -->
      <div class="xl:hidden flex items-center">
        <select 
          [value]="activeTab()" 
          (change)="onTabSelect($event)" 
          class="bg-[#252B2D] text-[#F4F3ED] border border-[#31483F] text-xs px-2 py-1 rounded-sm font-mono-tech">
          @for (t of navTabs; track t.id) {
            <option [value]="t.id">{{ t.label }}</option>
          }
        </select>
      </div>

      <!-- Zone 3: Clock & System Health -->
      <div class="flex items-center gap-3 shrink-0">
        <div class="hidden sm:flex flex-col text-right leading-none">
          <span class="text-[11px] font-mono-tech font-bold text-[#F4F3ED]">{{ utcTime() }}</span>
          <span class="text-[9px] text-[#C2C4BE]/60 font-mono-tech uppercase">UTC TELEMETRY BUS</span>
        </div>

        <div class="hidden sm:flex items-center gap-1.5 px-2 py-1 bg-[#31483F]/20 border border-[#31483F] rounded-sm text-[#ECE9E0]">
          <mat-icon class="!text-[14px] !w-[14px] !h-[14px] text-emerald-400">verified_user</mat-icon>
          <span class="text-[10px] font-bold tracking-wider">SAFETY BUS: OK</span>
        </div>
      </div>
    </header>
  `
})
export class TopNav {
  spitfire = inject(SpitfireService);

  activeTab = this.spitfire.activeTab;
  telemetry = this.spitfire.telemetry;
  flightMode = this.spitfire.flightMode;

  utcTime = signal<string>(new Date().toISOString().substring(11, 19) + ' UTC');

  modes: FlightMode[] = ['SIMULATION', 'SITL', 'HIL', 'BENCH', 'FLIGHT_TEST'];

  navTabs: { id: NavTab; label: string; icon: string }[] = [
    { id: 'FLIGHT', label: 'FLIGHT', icon: 'flight_takeoff' },
    { id: 'MISSION', label: 'MISSION', icon: 'route' },
    { id: 'CAMERA', label: 'CAMERA', icon: 'photo_camera' },
    { id: 'MAP', label: 'MAP', icon: 'map' },
    { id: 'TELEMETRY', label: 'TELEMETRY', icon: 'sensors' },
    { id: 'VEHICLE', label: 'VEHICLE', icon: 'flight' },
    { id: 'BATTERY', label: 'BATTERY', icon: 'battery_charging_full' },
    { id: 'VISION', label: 'VISION', icon: 'remove_red_eye' },
    { id: 'TWIN', label: 'TWIN', icon: 'view_in_ar' },
    { id: 'FLIGHT_TEST', label: 'FLIGHT TEST', icon: 'analytics' },
    { id: 'DATA', label: 'DATA', icon: 'folder' }
  ];

  constructor() {
    if (typeof window !== 'undefined') {
      setInterval(() => {
        this.utcTime.set(new Date().toISOString().substring(11, 19) + ' UTC');
      }, 1000);
    }
  }

  selectTab(tab: NavTab) {
    this.spitfire.setActiveTab(tab);
  }

  setMode(m: FlightMode) {
    this.spitfire.setFlightMode(m);
  }

  onTabSelect(event: Event) {
    const val = (event.target as HTMLSelectElement).value as NavTab;
    this.spitfire.setActiveTab(val);
  }

  getStateDotClass(): string {
    const state = this.telemetry().vehicleState;
    if (['EMERGENCY', 'MOTOR_FAULT', 'CAMERA_FAULT'].includes(state)) return 'bg-[#A3433C]';
    if (['SENSOR_DEGRADED', 'LOW_BATTERY', 'LINK_DEGRADED', 'NAVIGATION_DEGRADED'].includes(state)) return 'bg-[#C1943D]';
    if (['FLIGHT', 'MISSION', 'TAKEOFF', 'ARMED'].includes(state)) return 'bg-emerald-400';
    return 'bg-[#3D6A7D]';
  }
}
