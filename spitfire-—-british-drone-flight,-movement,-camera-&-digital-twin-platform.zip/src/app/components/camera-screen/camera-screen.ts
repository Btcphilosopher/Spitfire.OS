import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { SpitfireService } from '../../services/spitfire.service';
import { CameraMode } from '../../models/spitfire.types';

@Component({
  selector: 'app-camera-screen',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full w-full bg-[#111416] text-[#ECE9E0] flex flex-col p-3 gap-3 font-mono-tech select-none overflow-hidden">
      
      <!-- Top Payload Status Bar -->
      <div class="bg-[#252B2D] border border-[#31483F] p-2.5 rounded-sm flex items-center justify-between text-xs shrink-0">
        <div class="flex items-center gap-3">
          <mat-icon class="text-[#C1943D]">photo_camera</mat-icon>
          <div>
            <span class="font-bold text-[#F4F3ED] font-display uppercase tracking-wider">SPITFIRE VISION-01 OPTICAL PAYLOAD & GIMBAL-01</span>
            <span class="text-[10px] text-[#C2C4BE]/60 ml-2">48 MP CMOS · 4K/60FPS RAW PIPELINE</span>
          </div>
        </div>

        <div class="flex items-center gap-3">
          <span class="text-[10px] text-[#C2C4BE]">STORAGE: {{ camera().storageAvailableGb.toFixed(1) }} GB / {{ camera().storageTotalGb }} GB</span>
          <span class="px-2 py-0.5 rounded-xs text-[10px] font-bold"
                [ngClass]="camera().recording ? 'bg-[#A3433C] text-white animate-pulse' : 'bg-[#31483F] text-emerald-300'">
            {{ camera().recording ? '● RECORDING' : 'READY' }}
          </span>
        </div>
      </div>

      <!-- Main Workspace: Camera Live Stream & Pipeline Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-3 flex-1 min-h-0">
        
        <!-- LEFT: Live Viewfinder & Target Geometry (Col 7) -->
        <div class="lg:col-span-7 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0">
          
          <div class="flex items-center justify-between text-xs border-b border-[#31483F] pb-2">
            <span class="font-bold text-[#F4F3ED] flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-emerald-400">videocam</mat-icon>
              SPITFIRE VISION-01 LIVE FEED OVERLAY
            </span>
            <span class="text-[#C1943D]">MODE: {{ camera().mode }}</span>
          </div>

          <!-- Synthetic Live Video Stream Viewport -->
          <div class="flex-1 bg-[#111416] border border-[#31483F] rounded-xs relative overflow-hidden flex items-center justify-center">
            
            <!-- Background Feed Image -->
            <img [src]="activeImage()" alt="Camera Feed" class="w-full h-full object-cover opacity-85" referrerpolicy="no-referrer">

            <!-- Viewfinder Crosshair Overlay -->
            <svg class="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 500 300">
              <!-- Frame Bounding Corners -->
              <path d="M 20 40 L 20 20 L 40 20" stroke="#ECE9E0" stroke-width="2" fill="none"/>
              <path d="M 480 40 L 480 20 L 460 20" stroke="#ECE9E0" stroke-width="2" fill="none"/>
              <path d="M 20 260 L 20 280 L 40 280" stroke="#ECE9E0" stroke-width="2" fill="none"/>
              <path d="M 480 260 L 480 280 L 460 280" stroke="#ECE9E0" stroke-width="2" fill="none"/>

              <!-- Center Reticle -->
              <circle cx="250" cy="150" r="24" stroke="rgba(193, 148, 61, 0.8)" stroke-width="1.5" fill="none"/>
              <line x1="250" y1="120" x2="250" y2="180" stroke="#C1943D" stroke-width="1"/>
              <line x1="220" y1="150" x2="280" y2="150" stroke="#C1943D" stroke-width="1"/>
            </svg>

            <!-- Top Viewfinder Telemetry Overlay -->
            <div class="absolute top-3 left-3 right-3 flex justify-between text-[10px] text-[#F4F3ED] bg-[#111416]/80 px-2.5 py-1.5 border border-[#31483F] font-mono-tech">
              <span>SPITFIRE S1 // CAM-00418</span>
              <span>ALT: {{ telemetry().position.alt.toFixed(1) }}M</span>
              <span>HDG: {{ telemetry().position.heading.toFixed(0) }}°</span>
              <span [ngClass]="camera().recording ? 'text-red-400 font-bold' : 'text-emerald-400'">REC ● {{ camera().recording ? '00:14:28' : 'STANDBY' }}</span>
            </div>

            <!-- Bottom Camera Controls Floating Toolbar -->
            <div class="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs bg-[#111416]/90 p-2 border border-[#31483F]">
              
              <div class="flex items-center gap-2">
                <button (click)="triggerCapture()" 
                  class="px-3 py-1.5 bg-[#C1943D] hover:bg-[#a67c2e] text-[#111416] font-bold rounded-xs flex items-center gap-1 transition-colors">
                  <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">photo_camera</mat-icon>
                  <span>SNAPSHOT</span>
                </button>

                <button (click)="toggleRecording()" 
                  [class]="camera().recording ? 'bg-[#A3433C] text-white' : 'bg-[#31483F] text-[#F4F3ED]'"
                  class="px-3 py-1.5 font-bold rounded-xs flex items-center gap-1 transition-colors">
                  <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">videocam</mat-icon>
                  <span>{{ camera().recording ? 'STOP REC' : 'START REC' }}</span>
                </button>
              </div>

              <!-- Zoom Slider -->
              <div class="flex items-center gap-2 text-[10px]">
                <span class="text-[#C2C4BE]">ZOOM: {{ camera().zoomFactor.toFixed(1) }}x</span>
                <input type="range" min="1.0" max="8.0" step="0.5" 
                       [ngModel]="camera().zoomFactor" (ngModelChange)="setZoom($event)" 
                       class="w-24 accent-[#C1943D]">
              </div>

            </div>
          </div>

          <!-- FOV & Camera Pointing Geometry Readout -->
          <div class="bg-[#111416] border border-[#31483F] p-2.5 rounded-xs grid grid-cols-2 lg:grid-cols-4 gap-2 text-center text-xs">
            <div>
              <span class="text-[9px] text-[#C2C4BE]/60 uppercase block">AIRCRAFT HEADING</span>
              <span class="font-bold text-[#F4F3ED]">{{ telemetry().position.heading.toFixed(0) }}°</span>
            </div>
            <div>
              <span class="text-[9px] text-[#C2C4BE]/60 uppercase block">GIMBAL PITCH / YAW</span>
              <span class="font-bold text-[#C1943D]">{{ gimbal().pitchDeg.toFixed(0) }}° / {{ gimbal().yawDeg.toFixed(0) }}°</span>
            </div>
            <div>
              <span class="text-[9px] text-[#C2C4BE]/60 uppercase block">TARGET DISTANCE</span>
              <span class="font-bold text-[#F4F3ED]">28.4 m</span>
            </div>
            <div>
              <span class="text-[9px] text-[#C2C4BE]/60 uppercase block">LINE OF SIGHT</span>
              <span class="font-bold text-emerald-400">CLEAR (0% OBS)</span>
            </div>
          </div>

        </div>

        <!-- RIGHT: Camera Controls & Pipeline Architecture (Col 5) -->
        <div class="lg:col-span-5 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0 overflow-y-auto">
          
          <!-- Camera Mode Selector -->
          <div class="bg-[#111416] border border-[#31483F] p-3 rounded-xs flex flex-col gap-2">
            <span class="text-xs font-bold text-[#F4F3ED] uppercase font-display flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#3D6A7D]">settings_center_focus</mat-icon>
              CAMERA ORIENTATION MODE
            </span>

            <div class="grid grid-cols-3 gap-1.5 text-[10px]">
              @for (m of cameraModes; track m) {
                <button (click)="setCameraMode(m)" 
                  [class]="camera().mode === m ? 'bg-[#263F52] text-[#F4F3ED] font-bold border-b-2 border-[#C1943D]' : 'bg-[#252B2D] text-[#C2C4BE] hover:text-[#F4F3ED]'"
                  class="p-2 text-center transition-colors rounded-xs uppercase">
                  {{ m }}
                </button>
              }
            </div>
          </div>

          <!-- Exposure & Focus Controls -->
          <div class="bg-[#111416] border border-[#31483F] p-3 rounded-xs grid grid-cols-2 gap-3 text-xs">
            <div>
              <label for="isoSel" class="text-[9px] text-[#C2C4BE]/60 block mb-1">ISO SENSITIVITY</label>
              <select id="isoSel" [ngModel]="camera().iso" 
                class="w-full bg-[#252B2D] text-[#F4F3ED] border border-[#31483F] p-1.5 rounded-xs font-bold">
                <option [value]="100">ISO 100</option>
                <option [value]="200">ISO 200</option>
                <option [value]="400">ISO 400</option>
                <option [value]="800">ISO 800</option>
                <option [value]="1600">ISO 1600</option>
              </select>
            </div>

            <div>
              <label for="shutterSel" class="text-[9px] text-[#C2C4BE]/60 block mb-1">SHUTTER SPEED</label>
              <select id="shutterSel" [ngModel]="camera().shutterSpeed"
                class="w-full bg-[#252B2D] text-[#F4F3ED] border border-[#31483F] p-1.5 rounded-xs font-bold">
                <option value="1/2000s">1/2000s</option>
                <option value="1/1000s">1/1000s</option>
                <option value="1/500s">1/500s</option>
                <option value="1/250s">1/250s</option>
              </select>
            </div>

            <div>
              <label for="focusSel" class="text-[9px] text-[#C2C4BE]/60 block mb-1">FOCUS MODE</label>
              <select id="focusSel" [ngModel]="camera().focusMode"
                class="w-full bg-[#252B2D] text-[#F4F3ED] border border-[#31483F] p-1.5 rounded-xs font-bold">
                <option value="AUTO">AUTOFOCUS (CONTINUOUS)</option>
                <option value="MANUAL">MANUAL LOCK</option>
              </select>
            </div>

            <div>
              <label for="formatSel" class="text-[9px] text-[#C2C4BE]/60 block mb-1">FORMAT</label>
              <select id="formatSel" [ngModel]="camera().photoFormat"
                class="w-full bg-[#252B2D] text-[#F4F3ED] border border-[#31483F] p-1.5 rounded-xs font-bold">
                <option value="RAW+JPEG">RAW + JPEG</option>
                <option value="RAW">UNCOMPRESSED RAW</option>
                <option value="LOG">SPITFIRE LOG-01</option>
              </select>
            </div>
          </div>

          <!-- Synthetic Digital Image Pipeline Architecture -->
          <div class="bg-[#111416] border border-[#31483F] p-3 rounded-xs flex flex-col gap-2">
            <span class="text-xs font-bold text-[#F4F3ED] uppercase font-display flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-emerald-400">account_tree</mat-icon>
              SYNTHETIC DIGITAL IMAGE PIPELINE
            </span>

            <div class="flex flex-col gap-1.5 text-[10px] text-[#C2C4BE]">
              <div class="bg-[#252B2D] p-1.5 border-l-2 border-[#3D6A7D] flex justify-between">
                <span>1. CMOS SENSOR</span>
                <span class="text-[#F4F3ED]">48 MP RAW @ 14-BIT</span>
              </div>
              <div class="bg-[#252B2D] p-1.5 border-l-2 border-[#3D6A7D] flex justify-between">
                <span>2. DSP COLOUR & NOISE</span>
                <span class="text-[#F4F3ED]">DEBAYER & SHARPNESS CORRECTION</span>
              </div>
              <div class="bg-[#252B2D] p-1.5 border-l-2 border-[#31483F] flex justify-between">
                <span>3. GIMBAL STABILISATION</span>
                <span class="text-[#F4F3ED]">3-AXIS GYRO LOCK (±0.005°)</span>
              </div>
              <div class="bg-[#252B2D] p-1.5 border-l-2 border-[#C1943D] flex justify-between">
                <span>4. METADATA FUSION</span>
                <span class="text-[#C1943D]">EXIF + AIRCRAFT ATTITUDE TAGS</span>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  `
})
export class CameraScreen {
  spitfire = inject(SpitfireService);

  telemetry = this.spitfire.telemetry;
  camera = () => this.telemetry().camera;
  gimbal = () => this.telemetry().gimbal;

  cameraModes: CameraMode[] = ['FREE_LOOK', 'FORWARD', 'NADIR', 'TRACK', 'ORBIT'];

  activeImage = () => this.spitfire.selectedCapture()?.imageUrl || '/src/assets/images/spitfire_bridge_inspection_1790423887379.jpg';

  triggerCapture() {
    this.spitfire.triggerCapture();
  }

  toggleRecording() {
    this.spitfire.toggleRecording();
  }

  setZoom(z: number) {
    this.spitfire.setZoom(z);
  }

  setCameraMode(mode: CameraMode) {
    this.spitfire.setCameraMode(mode);
  }
}
