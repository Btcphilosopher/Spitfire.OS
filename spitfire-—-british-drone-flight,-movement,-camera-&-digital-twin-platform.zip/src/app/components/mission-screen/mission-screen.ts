import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { SpitfireService } from '../../services/spitfire.service';
import { MissionItem } from '../../models/spitfire.types';

@Component({
  selector: 'app-mission-screen',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full w-full bg-[#111416] text-[#ECE9E0] flex flex-col p-3 gap-3 font-mono-tech select-none overflow-hidden">
      
      <!-- Top Mission Controls Header -->
      <div class="bg-[#252B2D] border border-[#31483F] p-3 rounded-sm flex items-center justify-between shrink-0">
        <div class="flex items-center gap-3">
          <mat-icon class="text-[#C1943D]">route</mat-icon>
          <div>
            <h1 class="text-sm font-bold text-[#F4F3ED] uppercase font-display tracking-wider">
              SPITFIRE MISSION PLANNER & SIMULATOR
            </h1>
            <p class="text-[10px] text-[#C2C4BE]/60">
              Deterministic Trajectory Engine & Camera Action Trigger System
            </p>
          </div>
        </div>

        <!-- Mission Selector Dropdown & Actions -->
        <div class="flex items-center gap-2">
          <select [ngModel]="activeMission().id" (ngModelChange)="onSelectMission($event)"
            class="bg-[#111416] text-[#F4F3ED] border border-[#31483F] text-xs px-2.5 py-1.5 rounded-xs font-mono-tech">
            @for (m of missions(); track m.id) {
              <option [value]="m.id">{{ m.name }} ({{ m.type }})</option>
            }
          </select>

          <button (click)="runSimulation()" 
            class="px-3.5 py-1.5 bg-[#31483F] hover:bg-[#263F52] text-[#F4F3ED] font-bold rounded-xs text-xs flex items-center gap-1.5 transition-colors">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">play_arrow</mat-icon>
            <span>SIMULATE MISSION</span>
          </button>

          <button (click)="addWaypoint()" 
            class="px-3 py-1.5 bg-[#263F52] hover:bg-[#3D6A7D] text-[#F4F3ED] font-bold rounded-xs text-xs flex items-center gap-1.5 transition-colors">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">add_location</mat-icon>
            <span>ADD WAYPOINT</span>
          </button>
        </div>
      </div>

      <!-- Main Grid: Left Map Trajectory + Right Waypoint Table -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-3 flex-1 min-h-0">
        
        <!-- Left Trajectory & Profile Visualizer (Col 5) -->
        <div class="lg:col-span-5 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0">
          
          <div class="flex items-center justify-between text-xs border-b border-[#31483F] pb-2">
            <span class="font-bold text-[#F4F3ED] flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#3D6A7D]">map</mat-icon>
              MISSION SPATIAL PATH & ALTITUDE PROFILE
            </span>
            <span class="text-[#C1943D]">DIST: {{ activeMission().totalDistanceM }}m</span>
          </div>

          <!-- Synthetic Spatial Trajectory Viewport -->
          <div class="flex-1 bg-[#111416] border border-[#31483F] rounded-xs relative overflow-hidden bg-blueprint-grid flex items-center justify-center">
            
            <svg class="w-full h-full absolute inset-0" viewBox="0 0 500 350">
              <!-- Grid coordinate markers -->
              <line x1="50" y1="300" x2="450" y2="300" stroke="#252B2D" stroke-width="2"/>
              <line x1="50" y1="50" x2="50" y2="300" stroke="#252B2D" stroke-width="2"/>

              <!-- Polyline Flight Path -->
              <polyline points="60,280 120,200 200,160 300,120 400,180 440,280" 
                        fill="none" stroke="#C1943D" stroke-width="2.5" stroke-dasharray="4 2"/>

              <!-- Orbit Radius Visualizer for WP 4 -->
              <circle cx="300" cy="120" r="30" fill="rgba(61, 106, 125, 0.2)" stroke="#3D6A7D" stroke-width="1.5"/>

              <!-- Waypoint Markers -->
              @for (item of activeMission().items; track item.id; let idx = $index) {
                <g [attr.transform]="'translate(' + (60 + idx * 62) + ',' + (280 - item.altM * 3.5) + ')'" 
                   class="cursor-pointer group" (click)="selectItem(item)" (keydown.enter)="selectItem(item)" tabindex="0" role="button">
                  <circle r="12" fill="#111416" stroke="#31483F" stroke-width="2" class="group-hover:stroke-[#C1943D]"/>
                  <text y="4" text-anchor="middle" fill="#F4F3ED" font-size="10" font-weight="bold">{{ item.seq }}</text>
                  <text y="-16" text-anchor="middle" fill="#C2C4BE" font-size="8">{{ item.command }}</text>
                </g>
              }
            </svg>

            <div class="absolute bottom-2 left-2 text-[10px] text-[#C2C4BE] bg-[#111416]/80 px-2 py-1 border border-[#252B2D]">
              TARGET: {{ activeMission().targetLocationName }}
            </div>
          </div>

          <!-- Altitude Profile Graph -->
          <div class="h-28 bg-[#111416] border border-[#252B2D] p-2 flex flex-col justify-between">
            <div class="flex items-center justify-between text-[10px] text-[#C2C4BE]">
              <span>ALTITUDE PROFILE (AGL METERS)</span>
              <span>MAX ALT: 45.0m</span>
            </div>

            <!-- Altitude Line -->
            <div class="flex-1 flex items-end gap-2 pt-2 px-2">
              @for (item of activeMission().items; track item.id) {
                <div class="flex-1 flex flex-col items-center gap-1 group cursor-pointer" (click)="selectItem(item)" (keydown.enter)="selectItem(item)" tabindex="0" role="button">
                  <div class="text-[8px] text-[#C2C4BE]">{{ item.altM }}m</div>
                  <div class="w-full bg-[#31483F] group-hover:bg-[#C1943D] transition-colors rounded-t-xs" 
                       [style.height.%]="(item.altM / 50) * 100"></div>
                  <div class="text-[8px] font-bold text-[#F4F3ED]">WP{{ item.seq }}</div>
                </div>
              }
            </div>
          </div>

        </div>

        <!-- Right Waypoints Table & Inspector (Col 7) -->
        <div class="lg:col-span-7 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0">
          
          <div class="flex items-center justify-between text-xs border-b border-[#31483F] pb-2">
            <span class="font-bold text-[#F4F3ED] flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-emerald-400">format_list_numbered</mat-icon>
              WAYPOINT SEQUENCE & CAMERA ACTION MATRIX
            </span>
            <span class="text-[#C2C4BE]">{{ activeMission().items.length }} ITEMS</span>
          </div>

          <!-- Waypoints Table -->
          <div class="flex-1 overflow-y-auto border border-[#252B2D] bg-[#111416]">
            <table class="w-full text-left text-xs border-collapse">
              <thead>
                <tr class="bg-[#252B2D] text-[#C2C4BE] border-b border-[#31483F] text-[10px] uppercase font-bold">
                  <th class="p-2">SEQ</th>
                  <th class="p-2">COMMAND</th>
                  <th class="p-2">LAT / LNG</th>
                  <th class="p-2">ALT (m)</th>
                  <th class="p-2">SPEED (m/s)</th>
                  <th class="p-2">CAMERA ACTION</th>
                  <th class="p-2 text-right">ACTION</th>
                </tr>
              </thead>
              <tbody>
                @for (item of activeMission().items; track item.id) {
                  <tr class="border-b border-[#252B2D] hover:bg-[#31483F]/20 transition-colors cursor-pointer"
                      [ngClass]="selectedItem()?.id === item.id ? 'bg-[#263F52]/40 border-l-2 border-[#C1943D]' : ''"
                      (click)="selectItem(item)">
                    <td class="p-2 font-bold text-[#C1943D]">{{ item.seq }}</td>
                    <td class="p-2 font-bold text-[#F4F3ED]">{{ item.command }}</td>
                    <td class="p-2 font-mono-tech text-[10px] text-[#C2C4BE]">
                      {{ item.lat.toFixed(4) }}, {{ item.lng.toFixed(4) }}
                    </td>
                    <td class="p-2 font-bold text-[#ECE9E0]">{{ item.altM }} m</td>
                    <td class="p-2 text-[#ECE9E0]">{{ item.speedMs }} m/s</td>
                    <td class="p-2">
                      <span class="px-2 py-0.5 rounded-xs text-[9px] font-bold"
                        [ngClass]="item.cameraAction === 'PHOTO' ? 'bg-[#31483F] text-emerald-300' : 'bg-[#252B2D] text-[#C2C4BE]'">
                        {{ item.cameraAction }}
                      </span>
                    </td>
                    <td class="p-2 text-right">
                      <button (click)="removeItem(item.id); $event.stopPropagation()" 
                        class="text-[#A3433C] hover:text-red-400 p-1">
                        <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">delete</mat-icon>
                      </button>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>

          <!-- Active Waypoint Inspector Panel -->
          @if (selectedItem(); as sel) {
            <div class="bg-[#111416] border border-[#31483F] p-3 rounded-xs grid grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
              <div>
                <label for="cmdTypeSel" class="text-[9px] text-[#C2C4BE]/60 block mb-1">COMMAND TYPE</label>
                <select id="cmdTypeSel" [ngModel]="sel.command" (ngModelChange)="updateItem(sel.id, 'command', $event)"
                  class="w-full bg-[#252B2D] text-[#F4F3ED] border border-[#31483F] p-1 rounded-xs">
                  <option value="TAKEOFF">TAKEOFF</option>
                  <option value="WAYPOINT">WAYPOINT</option>
                  <option value="ORBIT">ORBIT</option>
                  <option value="CAMERA_ACTION">CAMERA_ACTION</option>
                  <option value="RETURN">RETURN</option>
                  <option value="LAND">LAND</option>
                </select>
              </div>

              <div>
                <label for="altInput" class="text-[9px] text-[#C2C4BE]/60 block mb-1">ALTITUDE AGL (m)</label>
                <input id="altInput" type="number" [ngModel]="sel.altM" (ngModelChange)="updateItem(sel.id, 'altM', +$event)"
                  class="w-full bg-[#252B2D] text-[#F4F3ED] border border-[#31483F] p-1 rounded-xs font-bold">
              </div>

              <div>
                <label for="speedInput" class="text-[9px] text-[#C2C4BE]/60 block mb-1">CRUISE SPEED (m/s)</label>
                <input id="speedInput" type="number" [ngModel]="sel.speedMs" (ngModelChange)="updateItem(sel.id, 'speedMs', +$event)"
                  class="w-full bg-[#252B2D] text-[#F4F3ED] border border-[#31483F] p-1 rounded-xs font-bold">
              </div>

              <div>
                <label for="camTrigSel" class="text-[9px] text-[#C2C4BE]/60 block mb-1">CAMERA TRIGGER</label>
                <select id="camTrigSel" [ngModel]="sel.cameraAction" (ngModelChange)="updateItem(sel.id, 'cameraAction', $event)"
                  class="w-full bg-[#252B2D] text-[#F4F3ED] border border-[#31483F] p-1 rounded-xs">
                  <option value="NONE">NONE</option>
                  <option value="PHOTO">PHOTO</option>
                  <option value="RECORD_START">RECORD_START</option>
                  <option value="RECORD_STOP">RECORD_STOP</option>
                  <option value="POINT_TARGET">POINT_TARGET</option>
                </select>
              </div>
            </div>
          }

        </div>

      </div>

    </div>
  `
})
export class MissionScreen {
  spitfire = inject(SpitfireService);

  missions = this.spitfire.missions;
  activeMission = this.spitfire.activeMission;
  
  selectedItem = signal<MissionItem | null>(this.activeMission().items[1] || null);

  onSelectMission(id: string) {
    const m = this.missions().find(x => x.id === id);
    if (m) {
      this.spitfire.activeMission.set(m);
      this.selectedItem.set(m.items[0] || null);
    }
  }

  selectItem(item: MissionItem) {
    this.selectedItem.set(item);
  }

  addWaypoint() {
    const currentItems = this.activeMission().items;
    const last = currentItems[currentItems.length - 1] || { lat: 56.0010, lng: -3.3888, altM: 30 };
    const newSeq = currentItems.length + 1;
    
    const newItem: MissionItem = {
      id: `item-${Date.now()}`,
      seq: newSeq,
      command: 'WAYPOINT',
      lat: last.lat + 0.0005,
      lng: last.lng + 0.0005,
      altM: last.altM,
      speedMs: 5.0,
      headingDeg: 90,
      holdTimeSec: 2,
      cameraAction: 'PHOTO'
    };

    const updated = {
      ...this.activeMission(),
      items: [...currentItems, newItem]
    };

    this.spitfire.activeMission.set(updated);
    this.selectedItem.set(newItem);
  }

  removeItem(id: string) {
    const updatedItems = this.activeMission().items.filter(x => x.id !== id).map((item, idx) => ({ ...item, seq: idx + 1 }));
    this.spitfire.activeMission.set({ ...this.activeMission(), items: updatedItems });
    if (this.selectedItem()?.id === id) {
      this.selectedItem.set(updatedItems[0] || null);
    }
  }

  updateItem(id: string, key: keyof MissionItem, val: string | number) {
    const updatedItems = this.activeMission().items.map(item => {
      if (item.id === id) {
        return { ...item, [key]: val };
      }
      return item;
    });
    this.spitfire.activeMission.set({ ...this.activeMission(), items: updatedItems });
  }

  runSimulation() {
    this.spitfire.sendCommand('TAKEOFF');
    this.spitfire.setActiveTab('FLIGHT');
  }
}
