import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SpitfireService } from '../../services/spitfire.service';
import { VehicleState } from '../../models/spitfire.types';

@Component({
  selector: 'app-vehicle-screen',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full w-full bg-[#111416] text-[#ECE9E0] flex flex-col p-3 gap-3 font-mono-tech select-none overflow-hidden">
      
      <!-- Header -->
      <div class="bg-[#252B2D] border border-[#31483F] p-2.5 rounded-sm flex items-center justify-between text-xs shrink-0">
        <div class="flex items-center gap-3">
          <mat-icon class="text-[#3D6A7D]">flight</mat-icon>
          <div>
            <span class="font-bold text-[#F4F3ED] font-display uppercase tracking-wider">SPITFIRE VEHICLE STATE MACHINE & PROPULSION TWIN</span>
            <span class="text-[10px] text-[#C2C4BE]/60 ml-2">SPITFIRE FC-01 ENGINE · 4 × PROPULSION UNITS</span>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <span class="text-[10px] text-[#C2C4BE]">ACTIVE STATE:</span>
          <span class="px-2.5 py-1 bg-[#31483F] text-emerald-300 font-bold rounded-xs">{{ vehicleState() }}</span>
        </div>
      </div>

      <!-- Main Workspace Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-3 flex-1 min-h-0">
        
        <!-- LEFT: Vehicle State Machine Flow (Col 6) -->
        <div class="lg:col-span-6 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0">
          
          <div class="flex items-center justify-between text-xs border-b border-[#31483F] pb-2">
            <span class="font-bold text-[#F4F3ED] flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-emerald-400">account_tree</mat-icon>
              FORMAL VEHICLE STATE TRANSITION GRAPH
            </span>
            <span class="text-[#C2C4BE]">RTIC KERNEL v2.4</span>
          </div>

          <!-- State Flow Pipeline -->
          <div class="flex-1 overflow-y-auto bg-[#111416] border border-[#252B2D] p-3 flex flex-col gap-2">
            
            <div class="text-[10px] font-bold text-[#C2C4BE] uppercase mb-1">PRIMARY FLIGHT PIPELINE</div>

            <div class="grid grid-cols-3 gap-2 text-center text-xs">
              @for (st of primaryStates; track st) {
                <div class="p-2.5 border rounded-xs transition-all flex flex-col items-center justify-center gap-1"
                     [ngClass]="vehicleState() === st ? 'bg-[#31483F] border-emerald-400 text-emerald-300 font-bold shadow-md' : 'bg-[#252B2D] border-[#31483F] text-[#C2C4BE]'">
                  <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">{{ getStateIcon(st) }}</mat-icon>
                  <span class="text-[10px] tracking-wider">{{ st }}</span>
                </div>
              }
            </div>

            <div class="text-[10px] font-bold text-[#A3433C] uppercase mt-3 mb-1">SAFETY & FAULT DEGRADATION STATES</div>

            <div class="grid grid-cols-2 gap-2 text-center text-xs">
              @for (st of faultStates; track st) {
                <div class="p-2 border rounded-xs transition-all flex items-center justify-between px-3"
                     [ngClass]="vehicleState() === st ? 'bg-[#A3433C] border-red-400 text-white font-bold animate-pulse' : 'bg-[#252B2D] border-[#252B2D] text-[#C2C4BE]'">
                  <span class="text-[10px]">{{ st }}</span>
                  <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">warning</mat-icon>
                </div>
              }
            </div>

          </div>

        </div>

        <!-- RIGHT: 4 x Propulsion Digital Twin (Col 6) -->
        <div class="lg:col-span-6 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0">
          
          <div class="flex items-center justify-between text-xs border-b border-[#31483F] pb-2">
            <span class="font-bold text-[#F4F3ED] flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#C1943D]">propeller</mat-icon>
              4 × ELECTRIC PROPULSION DIGITAL TWIN
            </span>
            <span class="text-[#C1943D]">TOTAL THRUST: {{ getTotalThrust().toFixed(1) }} N</span>
          </div>

          <!-- 4 Motor Cards Grid -->
          <div class="grid grid-cols-2 gap-3 flex-1 min-h-0 overflow-y-auto">
            @for (m of motors(); track m.id) {
              <div class="bg-[#111416] border border-[#31483F] p-3 rounded-xs flex flex-col justify-between">
                <div>
                  <div class="flex items-center justify-between text-xs font-bold border-b border-[#252B2D] pb-1.5 mb-2">
                    <span class="text-[#F4F3ED]">{{ m.label }}</span>
                    <span class="px-1.5 py-0.5 rounded-xs text-[9px]"
                          [ngClass]="m.health === 'NORMAL' ? 'bg-[#31483F] text-emerald-300' : 'bg-[#A3433C] text-white'">
                      {{ m.health }}
                    </span>
                  </div>

                  <div class="grid grid-cols-2 gap-2 text-[10px] text-[#C2C4BE] mb-2">
                    <div>
                      <span class="block text-[8px] text-[#C2C4BE]/60">RPM</span>
                      <span class="text-sm font-bold text-[#F4F3ED] font-mono-tech">{{ m.rpm }}</span>
                    </div>
                    <div>
                      <span class="block text-[8px] text-[#C2C4BE]/60">CURRENT</span>
                      <span class="text-sm font-bold text-[#ECE9E0] font-mono-tech">{{ m.current }} A</span>
                    </div>
                    <div>
                      <span class="block text-[8px] text-[#C2C4BE]/60">TEMPERATURE</span>
                      <span class="text-sm font-bold text-[#C1943D] font-mono-tech">{{ m.temperature }} °C</span>
                    </div>
                    <div>
                      <span class="block text-[8px] text-[#C2C4BE]/60">EST. THRUST</span>
                      <span class="text-sm font-bold text-emerald-400 font-mono-tech">{{ m.estimatedThrustN }} N</span>
                    </div>
                  </div>
                </div>

                <!-- RPM Visual Bar -->
                <div class="w-full bg-[#252B2D] h-2 rounded-xs overflow-hidden">
                  <div class="bg-[#3D6A7D] h-full transition-all duration-300" [style.width.%]="(m.rpm / 8000) * 100"></div>
                </div>
              </div>
            }
          </div>

        </div>

      </div>

    </div>
  `
})
export class VehicleScreen {
  spitfire = inject(SpitfireService);

  telemetry = this.spitfire.telemetry;
  vehicleState = this.spitfire.vehicleState;
  motors = () => this.telemetry().motors;

  primaryStates: VehicleState[] = [
    'INITIALISING', 'READY', 'ARMED',
    'TAKEOFF', 'FLIGHT', 'MISSION',
    'RETURN', 'LANDING', 'LANDED'
  ];

  faultStates: VehicleState[] = [
    'SENSOR_DEGRADED', 'LOW_BATTERY', 'LINK_DEGRADED',
    'NAVIGATION_DEGRADED', 'MOTOR_FAULT', 'EMERGENCY'
  ];

  getStateIcon(st: string): string {
    if (st === 'ARMED') return 'power_settings_new';
    if (st === 'TAKEOFF') return 'flight_takeoff';
    if (st === 'FLIGHT') return 'flight';
    if (st === 'MISSION') return 'route';
    if (st === 'RETURN') return 'home';
    if (st === 'LANDING' || st === 'LANDED') return 'flight_land';
    return 'check_circle';
  }

  getTotalThrust(): number {
    return this.motors().reduce((acc, m) => acc + m.estimatedThrustN, 0);
  }
}
