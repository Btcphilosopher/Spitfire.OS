import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { SpitfireService } from '../../services/spitfire.service';
import { InspectionFinding } from '../../models/spitfire.types';

@Component({
  selector: 'app-vision-screen',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full w-full bg-[#111416] text-[#ECE9E0] flex flex-col p-3 gap-3 font-mono-tech select-none overflow-hidden">
      
      <!-- Top Mode Selector Bar -->
      <div class="bg-[#252B2D] border border-[#31483F] p-2.5 rounded-sm flex items-center justify-between text-xs shrink-0">
        <div class="flex items-center gap-3">
          <mat-icon class="text-[#3D6A7D]">remove_red_eye</mat-icon>
          <div>
            <span class="font-bold text-[#F4F3ED] font-display uppercase tracking-wider">SPITFIRE VISION LAB & PHOTOGRAMMETRY SUITE</span>
            <span class="text-[10px] text-[#C2C4BE]/60 ml-2">Optical Feature Matching · Camera Calibration · Inspection Record</span>
          </div>
        </div>

        <div class="flex items-center gap-1 bg-[#111416] p-1 border border-[#31483F]">
          <button (click)="subMode.set('INSPECTION')" 
            [class]="subMode() === 'INSPECTION' ? 'bg-[#31483F] text-[#F4F3ED] font-bold' : 'text-[#C2C4BE]'"
            class="px-3 py-1 rounded-xs transition-colors">
            INSPECTION RECORD
          </button>
          <button (click)="subMode.set('CALIBRATION')" 
            [class]="subMode() === 'CALIBRATION' ? 'bg-[#31483F] text-[#F4F3ED] font-bold' : 'text-[#C2C4BE]'"
            class="px-3 py-1 rounded-xs transition-colors">
            CAMERA CALIBRATION
          </button>
          <button (click)="subMode.set('PHOTOGRAMMETRY')" 
            [class]="subMode() === 'PHOTOGRAMMETRY' ? 'bg-[#31483F] text-[#F4F3ED] font-bold' : 'text-[#C2C4BE]'"
            class="px-3 py-1 rounded-xs transition-colors">
            3D PHOTOGRAMMETRY
          </button>
        </div>
      </div>

      <!-- Main SubMode Viewports -->
      <div class="flex-1 min-h-0">
        
        <!-- SUBMODE 1: INSPECTION RECORD -->
        @if (subMode() === 'INSPECTION') {
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-3 h-full">
            
            <!-- Left Image with Annotation Overlay Pins (Col 7) -->
            <div class="lg:col-span-7 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0 relative">
              <div class="flex items-center justify-between text-xs border-b border-[#31483F] pb-2">
                <span class="font-bold text-[#F4F3ED] flex items-center gap-1.5">
                  <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#C1943D]">photo_camera</mat-icon>
                  INSPECTION ANNOTATION OVERLAY
                </span>
                <span class="text-[#C1943D]">FINDINGS: {{ findings().length }} RECORDED</span>
              </div>

              <div class="flex-1 bg-[#111416] border border-[#31483F] rounded-xs relative overflow-hidden flex items-center justify-center">
                <img [src]="selectedFinding() ? getFindingImg(selectedFinding()!) : '/src/assets/images/spitfire_bridge_inspection_1790423887379.jpg'" 
                     alt="Inspection photo" class="w-full h-full object-cover" referrerpolicy="no-referrer">

                <!-- Annotation Marker Pin -->
                @if (selectedFinding(); as find) {
                  <div class="absolute bg-[#A3433C] text-white p-2 rounded-xs border border-white shadow-lg text-xs font-bold animate-pulse"
                       [style.left.px]="find.coordPx.x" [style.top.px]="find.coordPx.y">
                    <span>{{ find.id }} ({{ find.severity }})</span>
                  </div>
                }
              </div>
            </div>

            <!-- Right Findings Inspector & AI Gemini Assistant (Col 5) -->
            <div class="lg:col-span-5 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0 overflow-y-auto">
              
              <div class="flex items-center justify-between text-xs border-b border-[#31483F] pb-2">
                <span class="font-bold text-[#F4F3ED]">PROJECT INSPECTION FINDINGS</span>
                <span class="text-emerald-400 font-bold">GEMINI AI INTEGRATED</span>
              </div>

              <div class="flex flex-col gap-2">
                @for (f of findings(); track f.id) {
                  <div (click)="selectedFinding.set(f)" (keydown.enter)="selectedFinding.set(f)" tabindex="0" role="button"
                       class="p-2.5 bg-[#111416] border rounded-xs cursor-pointer transition-all flex flex-col gap-1"
                       [ngClass]="selectedFinding()?.id === f.id ? 'border-[#C1943D]' : 'border-[#252B2D]'">
                    
                    <div class="flex items-center justify-between font-bold text-xs">
                      <span class="text-[#F4F3ED]">{{ f.id }} · {{ f.locationName }}</span>
                      <span class="px-2 py-0.5 rounded-xs text-[9px]"
                            [ngClass]="f.severity === 'MEDIUM' ? 'bg-[#C1943D] text-[#111416]' : 'bg-[#31483F] text-emerald-300'">
                        {{ f.severity }}
                      </span>
                    </div>

                    <p class="text-[11px] text-[#ECE9E0]">{{ f.description }}</p>

                    @if (f.aiAssessment) {
                      <div class="bg-[#252B2D] p-2 border-l-2 border-[#3D6A7D] text-[10px] text-[#ECE9E0] mt-1 whitespace-pre-line">
                        <strong class="text-[#3D6A7D]">SPITFIRE AI REPORT:</strong>
                        <div>{{ f.aiAssessment }}</div>
                      </div>
                    }

                    <div class="flex justify-end mt-1">
                      <button (click)="runAiAssessment(f); $event.stopPropagation()" 
                        class="px-2.5 py-1 bg-[#31483F] hover:bg-[#263F52] text-[#F4F3ED] font-bold rounded-xs text-[10px] flex items-center gap-1">
                        <mat-icon class="!text-[12px] !w-[12px] !h-[12px]">auto_awesome</mat-icon>
                        <span>RUN GEMINI ANALYSIS</span>
                      </button>
                    </div>

                  </div>
                }
              </div>

            </div>

          </div>
        }

        <!-- SUBMODE 2: CAMERA CALIBRATION -->
        @if (subMode() === 'CALIBRATION') {
          <div class="grid grid-cols-1 lg:grid-cols-2 gap-3 h-full">
            
            <div class="bg-[#252B2D]/80 border border-[#31483F] p-3 rounded-sm flex flex-col gap-3">
              <span class="font-bold text-[#F4F3ED] border-b border-[#31483F] pb-2 text-xs">
                BEFORE CALIBRATION (RAW LENS DISTORTION GRID)
              </span>
              <div class="flex-1 bg-[#111416] border border-[#31483F] flex items-center justify-center p-4 bg-blueprint-grid">
                <svg class="w-full h-full" viewBox="0 0 300 200">
                  <path d="M 30 30 Q 150 10 270 30 Q 290 100 270 170 Q 150 190 30 170 Q 10 100 30 30 Z" 
                        fill="none" stroke="#A3433C" stroke-width="2" stroke-dasharray="3 3"/>
                  <text x="150" y="105" text-anchor="middle" fill="#A3433C" font-size="11" font-weight="bold">RADIAL DISTORTION K1 = -0.0142</text>
                </svg>
              </div>
            </div>

            <div class="bg-[#252B2D]/80 border border-[#31483F] p-3 rounded-sm flex flex-col gap-3">
              <span class="font-bold text-[#F4F3ED] border-b border-[#31483F] pb-2 text-xs">
                AFTER CALIBRATION (spitfireR REPROJECTION MODEL)
              </span>
              <div class="flex-1 bg-[#111416] border border-[#31483F] flex items-center justify-center p-4 bg-blueprint-grid">
                <svg class="w-full h-full" viewBox="0 0 300 200">
                  <rect x="30" y="30" width="240" height="140" fill="none" stroke="emerald-400" stroke-width="2"/>
                  <text x="150" y="105" text-anchor="middle" fill="emerald-400" font-size="11" font-weight="bold">REPROJECTION ERROR: 0.28 PX (VALIDATED)</text>
                </svg>
              </div>
            </div>

          </div>
        }

        <!-- SUBMODE 3: PHOTOGRAMMETRY -->
        @if (subMode() === 'PHOTOGRAMMETRY') {
          <div class="bg-[#252B2D]/80 border border-[#31483F] p-3 rounded-sm h-full flex flex-col gap-3">
            <div class="flex items-center justify-between border-b border-[#31483F] pb-2 text-xs">
              <span class="font-bold text-[#F4F3ED]">SYNTHETIC 3D POINT CLOUD & ORTHOMOSAIC RECONSTRUCTION</span>
              <span class="text-emerald-400">18,420 POINTS DENSE MESH</span>
            </div>

            <div class="flex-1 bg-[#111416] border border-[#31483F] relative overflow-hidden bg-radar-grid flex items-center justify-center">
              <svg class="w-full h-full" viewBox="0 0 600 350">
                <!-- 3D Point Cloud Scatter -->
                @for (i of pointCloudPoints; track $index) {
                  <circle [attr.cx]="i.x" [attr.cy]="i.y" r="2" fill="#3D6A7D" opacity="0.8"/>
                }
                <text x="300" y="180" text-anchor="middle" fill="#C1943D" font-size="14" font-weight="bold" font-family="Chakra Petch">
                  SPITFIRE ORTHOMOSAIC RECONSTRUCTION COMPLETE
                </text>
              </svg>
            </div>
          </div>
        }

      </div>

    </div>
  `
})
export class VisionScreen {
  spitfire = inject(SpitfireService);

  findings = this.spitfire.findings;
  selectedFinding = signal<InspectionFinding | null>(this.findings()[0] || null);

  subMode = signal<'INSPECTION' | 'CALIBRATION' | 'PHOTOGRAMMETRY'>('INSPECTION');

  pointCloudPoints = Array.from({ length: 120 }, () => ({
    x: 50 + Math.random() * 500,
    y: 40 + Math.random() * 270
  }));

  getFindingImg(f: InspectionFinding): string {
    if (f.imageId === 'IMAGE-004181') return '/src/assets/images/spitfire_roof_inspection_1790423897774.jpg';
    return '/src/assets/images/spitfire_bridge_inspection_1790423887379.jpg';
  }

  runAiAssessment(finding: InspectionFinding) {
    this.spitfire.runAIInspection(finding);
  }
}
