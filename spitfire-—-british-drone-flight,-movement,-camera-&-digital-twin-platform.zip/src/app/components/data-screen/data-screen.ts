import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SpitfireService } from '../../services/spitfire.service';
import { FlightRecord } from '../../models/spitfire.types';

@Component({
  selector: 'app-data-screen',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full w-full bg-[#111416] text-[#ECE9E0] flex flex-col p-3 gap-3 font-mono-tech select-none overflow-hidden">
      
      <!-- Top Header -->
      <div class="bg-[#252B2D] border border-[#31483F] p-2.5 rounded-sm flex items-center justify-between text-xs shrink-0">
        <div class="flex items-center gap-3">
          <mat-icon class="text-[#3D6A7D]">folder</mat-icon>
          <div>
            <span class="font-bold text-[#F4F3ED] font-display uppercase tracking-wider">SPITFIRE FLIGHT LOG LIBRARY & REPORT ENGINE</span>
            <span class="text-[10px] text-[#C2C4BE]/60 ml-2">Reproducible Flights · Provenance Tags · Flight Test Reports</span>
          </div>
        </div>

        <button (click)="generateReport()" 
          class="px-3.5 py-1.5 bg-[#31483F] hover:bg-[#263F52] text-[#F4F3ED] font-bold rounded-xs text-xs flex items-center gap-1.5 transition-colors">
          <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">picture_as_pdf</mat-icon>
          <span>GENERATE SPITFIRE REPORT</span>
        </button>
      </div>

      <!-- Main Workspace Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-3 flex-1 min-h-0">
        
        <!-- LEFT: Flight Library Table (Col 7) -->
        <div class="lg:col-span-7 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0">
          
          <div class="flex items-center justify-between text-xs border-b border-[#31483F] pb-2">
            <span class="font-bold text-[#F4F3ED] flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-emerald-400">history_edu</mat-icon>
              REPRODUCIBLE FLIGHT LOG DATABASE
            </span>
            <span class="text-[#C2C4BE]">{{ flights().length }} LOGS LOADED</span>
          </div>

          <div class="flex-1 overflow-y-auto border border-[#252B2D] bg-[#111416]">
            <table class="w-full text-left text-xs border-collapse">
              <thead>
                <tr class="bg-[#252B2D] text-[#C2C4BE] border-b border-[#31483F] text-[10px] uppercase font-bold">
                  <th class="p-2">FLIGHT ID</th>
                  <th class="p-2">MISSION NAME</th>
                  <th class="p-2">DATE</th>
                  <th class="p-2">DURATION</th>
                  <th class="p-2">CAPTURES</th>
                  <th class="p-2 text-right">PROVENANCE</th>
                </tr>
              </thead>
              <tbody>
                @for (f of flights(); track f.id) {
                  <tr class="border-b border-[#252B2D] hover:bg-[#31483F]/20 transition-colors cursor-pointer"
                      [ngClass]="selectedFlight().id === f.id ? 'bg-[#263F52]/40 border-l-2 border-[#C1943D]' : ''"
                      (click)="selectFlight(f)">
                    <td class="p-2 font-bold text-[#C1943D]">{{ f.id }}</td>
                    <td class="p-2 font-bold text-[#F4F3ED]">{{ f.name }}</td>
                    <td class="p-2 text-[10px] text-[#C2C4BE]">{{ f.date }}</td>
                    <td class="p-2 text-[#ECE9E0]">{{ Math.floor(f.durationSec / 60) }}m {{ f.durationSec % 60 }}s</td>
                    <td class="p-2 text-emerald-400 font-bold">{{ f.capturesCount }}</td>
                    <td class="p-2 text-right">
                      <span class="px-2 py-0.5 rounded-xs text-[9px] font-bold bg-[#31483F] text-emerald-300">
                        {{ f.provenance }}
                      </span>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>

        </div>

        <!-- RIGHT: Flight Test Report Previewer (Col 5) -->
        <div class="lg:col-span-5 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0 overflow-y-auto">
          
          <div class="flex items-center justify-between text-xs border-b border-[#31483F] pb-2">
            <span class="font-bold text-[#F4F3ED] flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#C1943D]">description</mat-icon>
              FLIGHT TEST REPORT PREVIEW
            </span>
            <span class="text-emerald-400 font-bold">SPITFIRE AEROSPACE</span>
          </div>

          <!-- Document Sheet -->
          <div class="bg-[#F4F3ED] text-[#111416] p-4 rounded-xs flex flex-col gap-3 font-sans border border-[#C2C4BE] shadow-md">
            
            <div class="border-b-2 border-[#111416] pb-2 flex justify-between items-start">
              <div>
                <h2 class="text-base font-bold font-display tracking-wider">SPITFIRE FLIGHT TEST REPORT</h2>
                <div class="text-[10px] font-mono font-bold text-slate-600">BRITISH AEROSPACE ADVANCED SYSTEMS</div>
              </div>
              <div class="text-right text-[10px] font-mono text-slate-700">
                <div>LOG: {{ selectedFlight().id }}</div>
                <div>VER: {{ selectedFlight().softwareVersion }}</div>
              </div>
            </div>

            <div class="grid grid-cols-2 gap-2 text-xs font-mono border-b border-slate-300 pb-2">
              <div><strong>DRONE:</strong> {{ selectedFlight().droneModel }}</div>
              <div><strong>DATE:</strong> {{ selectedFlight().date }}</div>
              <div><strong>MISSION:</strong> {{ selectedFlight().missionName }}</div>
              <div><strong>ENERGY:</strong> {{ selectedFlight().energyUsedWh }} Wh</div>
              <div><strong>DISTANCE:</strong> {{ selectedFlight().distanceM }} m</div>
              <div><strong>HEALTH:</strong> {{ selectedFlight().sensorHealthPct }}%</div>
            </div>

            <div class="text-xs font-mono text-slate-800">
              <strong class="block mb-1 text-slate-900">ENGINEERING EXECUTIVE SUMMARY:</strong>
              <p class="text-[11px] leading-relaxed">
                Flight test {{ selectedFlight().id }} executed under {{ selectedFlight().provenance }} simulation conditions.
                Sensor fusion residuals and trajectory tracking remained nominal throughout the {{ Math.floor(selectedFlight().durationSec / 60) }}-minute flight window.
                Optical payload recorded {{ selectedFlight().capturesCount }} geo-tagged raw frames.
              </p>
            </div>

            <div class="bg-slate-200 p-2 text-[10px] font-mono border border-slate-300 flex justify-between">
              <span>DATA PROVENANCE: {{ selectedFlight().provenance }}</span>
              <span>CALIBRATION: {{ selectedFlight().calibrationVersion }}</span>
            </div>

          </div>

        </div>

      </div>

    </div>
  `
})
export class DataScreen {
  spitfire = inject(SpitfireService);

  flights = this.spitfire.flights;
  selectedFlight = this.spitfire.selectedFlight;

  Math = Math;

  selectFlight(f: FlightRecord) {
    this.spitfire.selectFlight(f);
  }

  generateReport() {
    window.print();
  }
}
