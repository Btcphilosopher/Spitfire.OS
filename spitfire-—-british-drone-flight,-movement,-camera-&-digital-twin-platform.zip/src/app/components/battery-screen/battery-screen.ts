import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { SpitfireService } from '../../services/spitfire.service';

@Component({
  selector: 'app-battery-screen',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full w-full bg-[#111416] text-[#ECE9E0] flex flex-col p-3 gap-3 font-mono-tech select-none overflow-hidden">
      
      <!-- Header -->
      <div class="bg-[#252B2D] border border-[#31483F] p-2.5 rounded-sm flex items-center justify-between text-xs shrink-0">
        <div class="flex items-center gap-3">
          <mat-icon class="text-emerald-400">battery_charging_full</mat-icon>
          <div>
            <span class="font-bold text-[#F4F3ED] font-display uppercase tracking-wider">HIGH-DENSITY LITHIUM BATTERY TWIN & ENDURANCE LAB</span>
            <span class="text-[10px] text-[#C2C4BE]/60 ml-2">SPITFIRE 4S 8500mAh / 125.8 Wh POWER CELL</span>
          </div>
        </div>

        <div class="flex items-center gap-3">
          <span class="text-[10px] text-[#C2C4BE]">HEALTH: 100% (24 CYCLES)</span>
          <span class="px-2 py-0.5 bg-[#31483F] text-emerald-300 font-bold rounded-xs text-[10px]">{{ battery().soc }}% SOC</span>
        </div>
      </div>

      <!-- Main Workspace Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-3 flex-1 min-h-0">
        
        <!-- LEFT: Real-Time Battery Telemetry & 4 Cell Voltages (Col 6) -->
        <div class="lg:col-span-6 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0">
          
          <div class="flex items-center justify-between text-xs border-b border-[#31483F] pb-2">
            <span class="font-bold text-[#F4F3ED] flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-emerald-400">bolt</mat-icon>
              SMART BMS REAL-TIME TELEMETRY
            </span>
            <span class="text-[#C1943D]">{{ battery().voltage }} V · {{ battery().current }} A</span>
          </div>

          <!-- Top Metrics Cards -->
          <div class="grid grid-cols-3 gap-2">
            <div class="bg-[#111416] p-2.5 border border-[#31483F]">
              <span class="text-[9px] text-[#C2C4BE]/60 block uppercase">TOTAL POWER</span>
              <span class="text-lg font-bold text-[#F4F3ED] font-display">{{ battery().power.toFixed(1) }} <span class="text-xs text-[#C2C4BE]">W</span></span>
            </div>
            <div class="bg-[#111416] p-2.5 border border-[#31483F]">
              <span class="text-[9px] text-[#C2C4BE]/60 block uppercase">ENERGY USED</span>
              <span class="text-lg font-bold text-[#ECE9E0] font-display">{{ battery().energyUsedWh.toFixed(1) }} <span class="text-xs text-[#C2C4BE]">Wh</span></span>
            </div>
            <div class="bg-[#111416] p-2.5 border border-[#31483F]">
              <span class="text-[9px] text-[#C2C4BE]/60 block uppercase">PACK TEMP</span>
              <span class="text-lg font-bold text-[#C1943D] font-display">{{ battery().temperature }} <span class="text-xs text-[#C2C4BE]">°C</span></span>
            </div>
          </div>

          <!-- 4 Cell Voltage Balance -->
          <div class="bg-[#111416] border border-[#31483F] p-3 rounded-xs flex flex-col gap-2">
            <span class="text-xs font-bold text-[#F4F3ED] uppercase font-display">4S INDIVIDUAL CELL BALANCE (DELTA &lt; 0.01V)</span>
            
            <div class="grid grid-cols-4 gap-2 text-center text-xs">
              @for (cell of battery().cellVoltages; track $index) {
                <div class="bg-[#252B2D] p-2 border border-[#31483F] flex flex-col gap-1">
                  <span class="text-[9px] text-[#C2C4BE]">CELL 0{{ $index + 1 }}</span>
                  <span class="font-bold text-emerald-400 font-mono-tech">{{ cell.toFixed(2) }} V</span>
                  <div class="w-full bg-[#111416] h-1.5 rounded-xs overflow-hidden">
                    <div class="bg-emerald-400 h-full" [style.width.%]="((cell - 3.0) / 1.2) * 100"></div>
                  </div>
                </div>
              }
            </div>
          </div>

        </div>

        <!-- RIGHT: Range & Endurance Predictive Simulation Lab (Col 6) -->
        <div class="lg:col-span-6 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0">
          
          <div class="flex items-center justify-between text-xs border-b border-[#31483F] pb-2">
            <span class="font-bold text-[#F4F3ED] flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#3D6A7D]">science</mat-icon>
              RANGE & ENDURANCE SIMULATION LAB
            </span>
            <span class="text-[#C1943D]">spitfireR MODEL</span>
          </div>

          <!-- Sliders for Endurance Model -->
          <div class="bg-[#111416] border border-[#31483F] p-3 rounded-xs flex flex-col gap-3 text-xs">
            <div>
              <div class="flex justify-between text-[10px] text-[#C2C4BE] mb-1">
                <span>PAYLOAD MASS ADDITION</span>
                <span class="text-[#F4F3ED] font-bold">+{{ payloadKg() }} kg</span>
              </div>
              <input type="range" min="0" max="2.0" step="0.1" [ngModel]="payloadKg()" (ngModelChange)="payloadKg.set(+$event)"
                     class="w-full accent-[#C1943D]">
            </div>

            <div>
              <div class="flex justify-between text-[10px] text-[#C2C4BE] mb-1">
                <span>HEADWIND VELOCITY</span>
                <span class="text-[#F4F3ED] font-bold">{{ windMs() }} m/s</span>
              </div>
              <input type="range" min="0" max="15.0" step="0.5" [ngModel]="windMs()" (ngModelChange)="windMs.set(+$event)"
                     class="w-full accent-[#C1943D]">
            </div>
          </div>

          <!-- Output Estimated Endurance Card -->
          <div class="bg-[#111416] border border-[#31483F] p-4 rounded-xs flex items-center justify-between">
            <div>
              <span class="text-[10px] text-[#C2C4BE] uppercase block">PREDICTED REMAINING ENDURANCE</span>
              <span class="text-3xl font-bold text-emerald-400 font-display">{{ estimatedEnduranceMinutes() }} <span class="text-sm text-[#C2C4BE]">MINUTES</span></span>
            </div>
            <div class="text-right">
              <span class="text-[10px] text-[#C2C4BE] uppercase block">PREDICTED MAX RANGE</span>
              <span class="text-2xl font-bold text-[#F4F3ED] font-display">{{ estimatedMaxRangeKm() }} <span class="text-sm text-[#C2C4BE]">KM</span></span>
            </div>
          </div>

        </div>

      </div>

    </div>
  `
})
export class BatteryScreen {
  spitfire = inject(SpitfireService);

  battery = () => this.spitfire.telemetry().battery;

  payloadKg = signal<number>(0.2);
  windMs = signal<number>(3.5);

  estimatedEnduranceMinutes(): number {
    const soc = this.battery().soc;
    const baseMins = (soc / 100) * 26.0;
    const massPenalty = this.payloadKg() * 3.5;
    const windPenalty = this.windMs() * 0.4;
    return Math.max(1, Math.round(baseMins - massPenalty - windPenalty));
  }

  estimatedMaxRangeKm(): number {
    const mins = this.estimatedEnduranceMinutes();
    const speedMs = 8.5 - this.windMs() * 0.2;
    return parseFloat(((mins * 60 * speedMs) / 1000).toFixed(1));
  }
}
