import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SpitfireService } from '../../services/spitfire.service';
import { ComponentPassport } from '../../models/spitfire.types';

@Component({
  selector: 'app-twin-screen',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full w-full bg-[#111416] text-[#ECE9E0] flex flex-col p-3 gap-3 font-mono-tech select-none overflow-hidden">
      
      <!-- Top Header Bar -->
      <div class="bg-[#252B2D] border border-[#31483F] p-2.5 rounded-sm flex items-center justify-between text-xs shrink-0">
        <div class="flex items-center gap-3">
          <mat-icon class="text-emerald-400">view_in_ar</mat-icon>
          <div>
            <span class="font-bold text-[#F4F3ED] font-display uppercase tracking-wider">SPITFIRE TWIN — 3D DIGITAL TWIN & SYSTEM VIEW</span>
            <span class="text-[10px] text-[#C2C4BE]/60 ml-2">Click any hardware node to inspect Digital Passport & Live Health</span>
          </div>
        </div>

        <button (click)="explodedView.set(!explodedView())" 
          [class]="explodedView() ? 'bg-[#C1943D] text-[#111416] font-bold' : 'bg-[#31483F] text-[#F4F3ED]'"
          class="px-3 py-1.5 rounded-xs text-xs flex items-center gap-1.5 transition-colors">
          <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">device_hub</mat-icon>
          <span>{{ explodedView() ? 'COLLAPSE SYSTEM VIEW' : 'EXPLODED SYSTEM VIEW' }}</span>
        </button>
      </div>

      <!-- Main Grid: 3D Twin Model (Col 8) + Component Passport Inspector (Col 4) -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-3 flex-1 min-h-0">
        
        <!-- LEFT: 3D Model Stage with Interactive Component Hotspots (Col 8) -->
        <div class="lg:col-span-8 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0 relative">
          
          <div class="flex items-center justify-between text-xs border-b border-[#31483F] pb-2 z-10">
            <span class="font-bold text-[#F4F3ED]">SPITFIRE S1 DIGITAL TWIN STAGE</span>
            <span class="text-[#C1943D]">ATTITUDE SYNCED: ROLL {{ attitude().roll.toFixed(1) }}°, PITCH {{ attitude().pitch.toFixed(1) }}°</span>
          </div>

          <!-- 3D Drone Model Canvas / SVG Stage -->
          <div class="flex-1 bg-[#111416] border border-[#31483F] rounded-xs relative overflow-hidden bg-blueprint-grid flex items-center justify-center">
            
            <svg class="w-full h-full absolute inset-0 cursor-grab" viewBox="0 0 600 400">
              
              <!-- Background Concentric Target Rings -->
              <circle cx="300" cy="200" r="140" fill="none" stroke="#252B2D" stroke-width="1.5" stroke-dasharray="4 4"/>
              <circle cx="300" cy="200" r="80" fill="none" stroke="#252B2D" stroke-width="1.5"/>

              <!-- Central Drone Model Group (Rotates with Roll/Pitch) -->
              <g [attr.transform]="'translate(300, 200) rotate(' + attitude().roll + ') scale(' + (explodedView() ? 1.2 : 1.0) + ')'">
                
                <!-- Airframe Arms -->
                <line x1="-120" y1="-120" x2="120" y2="120" stroke="#ECE9E0" stroke-width="8"/>
                <line x1="-120" y1="120" x2="120" y2="-120" stroke="#ECE9E0" stroke-width="8"/>

                <!-- 4 Motors -->
                <circle cx="-120" cy="-120" r="22" fill="#31483F" stroke="#F4F3ED" stroke-width="3" class="cursor-pointer" (click)="selectComponent('PASSPORT-AIRFRAME')"/>
                <circle cx="120" cy="-120" r="22" fill="#31483F" stroke="#F4F3ED" stroke-width="3" class="cursor-pointer" (click)="selectComponent('PASSPORT-AIRFRAME')"/>
                <circle cx="-120" cy="120" r="22" fill="#252B2D" stroke="#C2C4BE" stroke-width="3" class="cursor-pointer" (click)="selectComponent('PASSPORT-AIRFRAME')"/>
                <circle cx="120" cy="120" r="22" fill="#252B2D" stroke="#C2C4BE" stroke-width="3" class="cursor-pointer" (click)="selectComponent('PASSPORT-AIRFRAME')"/>

                <!-- Propeller Blades (Rotating) -->
                <ellipse cx="-120" cy="-120" rx="35" ry="6" fill="rgba(236, 233, 224, 0.4)"/>
                <ellipse cx="120" cy="-120" rx="35" ry="6" fill="rgba(236, 233, 224, 0.4)"/>

                <!-- Central Fuselage Deck -->
                <rect x="-45" y="-55" width="90" height="110" rx="8" fill="#111416" stroke="#ECE9E0" stroke-width="3"/>
                
                <!-- FC-01 Module -->
                <rect x="-25" y="-35" width="50" height="40" rx="4" fill="#31483F" stroke="#C1943D" stroke-width="2" class="cursor-pointer" (click)="selectComponent('PASSPORT-FC01')"/>
                <text x="0" y="-12" text-anchor="middle" fill="#F4F3ED" font-size="9" font-weight="bold">FC-01</text>

                <!-- Battery Module -->
                <rect x="-30" y="15" width="60" height="30" rx="4" fill="#263F52" stroke="#ECE9E0" stroke-width="2" class="cursor-pointer" (click)="selectComponent('PASSPORT-BATTERY')"/>
                <text x="0" y="34" text-anchor="middle" fill="#F4F3ED" font-size="9" font-weight="bold">BATTERY</text>

                <!-- Camera Vision-01 Payload -->
                <circle cx="0" cy="-70" r="16" fill="#111416" stroke="#C1943D" stroke-width="2" class="cursor-pointer" (click)="selectComponent('PASSPORT-VISION01')"/>
                <text x="0" y="-66" text-anchor="middle" fill="#C1943D" font-size="8" font-weight="bold">CAM</text>
              </g>

              <!-- Node Callout Lines (Exploded View) -->
              @if (explodedView()) {
                <g stroke="#31483F" stroke-width="1.5" stroke-dasharray="2 2">
                  <line x1="180" y1="80" x2="80" y2="40"/>
                  <line x1="300" y1="130" x2="300" y2="50"/>
                  <line x1="420" y1="80" x2="500" y2="40"/>
                </g>
              }
            </svg>

            <div class="absolute bottom-2 left-2 text-[10px] text-[#C2C4BE] bg-[#111416]/80 px-2 py-1 border border-[#252B2D]">
              CAN BUS TELEMETRY LATENCY: 12ms
            </div>
          </div>

        </div>

        <!-- RIGHT: Component Digital Passport Inspector (Col 4) -->
        <div class="lg:col-span-4 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0 overflow-y-auto">
          
          <div class="flex items-center justify-between text-xs border-b border-[#31483F] pb-2">
            <span class="font-bold text-[#F4F3ED] flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#C1943D]">badge</mat-icon>
              COMPONENT DIGITAL PASSPORT
            </span>
            <span class="text-emerald-400 font-bold">{{ selectedPassport()?.healthStatus }}</span>
          </div>

          @if (selectedPassport(); as p) {
            <div class="bg-[#111416] border border-[#31483F] p-3 rounded-xs flex flex-col gap-3 text-xs">
              
              <div>
                <span class="text-[9px] text-[#C2C4BE]/60 block uppercase">COMPONENT NAME</span>
                <span class="font-bold text-sm text-[#F4F3ED] font-display">{{ p.name }}</span>
              </div>

              <div class="grid grid-cols-2 gap-2 text-[10px]">
                <div>
                  <span class="text-[#C2C4BE]/60 block">SERIAL NO</span>
                  <span class="font-mono-tech text-[#C1943D] font-bold">{{ p.serialNumber }}</span>
                </div>
                <div>
                  <span class="text-[#C2C4BE]/60 block">FIRMWARE</span>
                  <span class="font-mono-tech text-[#ECE9E0] font-bold">{{ p.firmwareVersion }}</span>
                </div>
                <div>
                  <span class="text-[#C2C4BE]/60 block">TEMP</span>
                  <span class="font-mono-tech text-[#F4F3ED] font-bold">{{ p.temperatureC }} °C</span>
                </div>
                <div>
                  <span class="text-[#C2C4BE]/60 block">RUNTIME</span>
                  <span class="font-mono-tech text-[#ECE9E0] font-bold">{{ p.runtimeHours }} hrs</span>
                </div>
              </div>

              <!-- Technical Specifications Table -->
              <div class="border-t border-[#252B2D] pt-2 flex flex-col gap-1.5">
                <span class="text-[10px] font-bold text-[#C2C4BE] uppercase">AEROSPACE SPECIFICATIONS</span>
                @for (spec of getSpecsArray(p.specifications); track spec.key) {
                  <div class="flex justify-between text-[10px] bg-[#252B2D] p-1.5">
                    <span class="text-[#C2C4BE]">{{ spec.key }}</span>
                    <span class="font-bold text-[#F4F3ED]">{{ spec.value }}</span>
                  </div>
                }
              </div>

            </div>
          }

        </div>

      </div>

    </div>
  `
})
export class TwinScreen {
  spitfire = inject(SpitfireService);

  telemetry = this.spitfire.telemetry;
  attitude = () => this.telemetry().attitude;
  passports = this.spitfire.passports;

  selectedPassport = signal<ComponentPassport | null>(this.passports()[1] || null);
  explodedView = signal<boolean>(false);

  selectComponent(id: string) {
    const p = this.passports().find(x => x.id === id);
    if (p) this.selectedPassport.set(p);
  }

  getSpecsArray(specs: Record<string, string>): { key: string; value: string }[] {
    return Object.entries(specs).map(([key, value]) => ({ key, value }));
  }
}
