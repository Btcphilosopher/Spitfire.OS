import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SpitfireService } from '../../services/spitfire.service';

@Component({
  selector: 'app-flight-test-screen',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full w-full bg-[#111416] text-[#ECE9E0] flex flex-col p-3 gap-3 font-mono-tech select-none overflow-hidden">
      
      <!-- Top Header -->
      <div class="bg-[#252B2D] border border-[#31483F] p-2.5 rounded-sm flex items-center justify-between text-xs shrink-0">
        <div class="flex items-center gap-3">
          <mat-icon class="text-[#3D6A7D]">analytics</mat-icon>
          <div>
            <span class="font-bold text-[#F4F3ED] font-display uppercase tracking-wider">SPITFIRE LAB — R SCIENTIFIC ANALYTICS SUITE (spitfireR)</span>
            <span class="text-[10px] text-[#C2C4BE]/60 ml-2">R Analytics Engine · Sensor Residuals · Flight Comparison · Failure Testing</span>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <button (click)="runRAnalysis()" 
            class="px-3.5 py-1.5 bg-[#31483F] hover:bg-[#263F52] text-[#F4F3ED] font-bold rounded-xs text-xs flex items-center gap-1.5 transition-colors">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">refresh</mat-icon>
            <span>RE-RUN spitfireR ANALYTICS</span>
          </button>
        </div>
      </div>

      <!-- Main Scientific Workspace Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-3 flex-1 min-h-0">
        
        <!-- LEFT: R Scientific Charts Grid (Col 8) -->
        <div class="lg:col-span-8 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0 overflow-y-auto">
          
          <div class="flex items-center justify-between text-xs border-b border-[#31483F] pb-2">
            <span class="font-bold text-[#F4F3ED]">spitfireR TELEMETRY & ATTITUDE DYNAMICS PLOTS</span>
            <span class="text-[#C1943D]">ANALYSIS AT: {{ rAnalysis().analyzedAt }}</span>
          </div>

          <!-- Chart 1: Altitude & Speed Profile vs Time -->
          <div class="bg-[#111416] border border-[#31483F] p-3 rounded-xs flex flex-col gap-2">
            <div class="flex items-center justify-between text-[11px] font-bold text-[#F4F3ED]">
              <span>ALTITUDE (AGL m) & GROUND SPEED (m/s) vs TIME</span>
              <span class="text-emerald-400">TRAJECTORY ERROR: {{ rAnalysis().trajectoryErrorM }}m</span>
            </div>

            <div class="h-32 w-full bg-blueprint-grid relative flex items-end p-2 border border-[#252B2D]">
              <svg class="w-full h-full absolute inset-0" viewBox="0 0 500 100">
                <!-- Altitude Curve (Blue) -->
                <path d="M 0 90 Q 100 20 200 25 T 400 30 L 500 90" fill="none" stroke="#3D6A7D" stroke-width="2.5"/>
                <!-- Speed Curve (Amber) -->
                <path d="M 0 95 Q 120 40 250 50 T 450 60 L 500 95" fill="none" stroke="#C1943D" stroke-width="2" stroke-dasharray="3 3"/>
              </svg>
            </div>
            <div class="flex justify-between text-[9px] text-[#C2C4BE]">
              <span>0:00 (TAKEOFF)</span>
              <span>15:00 (WAYPOINT ORBIT)</span>
              <span>30:00 (LANDED)</span>
            </div>
          </div>

          <!-- Chart 2: Battery Discharge & Power Curve -->
          <div class="bg-[#111416] border border-[#31483F] p-3 rounded-xs flex flex-col gap-2">
            <div class="flex items-center justify-between text-[11px] font-bold text-[#F4F3ED]">
              <span>spitfireR BATTERY DISCHARGE MODEL (SOC % vs EST REMAINING MINS)</span>
              <span class="text-[#C1943D]">4S 8500mAh EMPIRICAL CURVE</span>
            </div>

            <div class="grid grid-cols-7 gap-1 text-center text-[10px]">
              @for (pt of rAnalysis().batteryDischargeCurve; track pt.socPct) {
                <div class="bg-[#252B2D] p-2 border border-[#31483F] flex flex-col gap-1">
                  <span class="text-emerald-400 font-bold">{{ pt.socPct }}%</span>
                  <span class="text-[#F4F3ED] font-mono-tech">{{ pt.estMinutesRemaining }} m</span>
                  <span class="text-[8px] text-[#C2C4BE]">{{ pt.powerWatts }}W</span>
                </div>
              }
            </div>
          </div>

          <!-- Chart 3: Camera Sharpness & Image Quality Distribution -->
          <div class="bg-[#111416] border border-[#31483F] p-3 rounded-xs flex flex-col gap-2">
            <div class="flex items-center justify-between text-[11px] font-bold text-[#F4F3ED]">
              <span>SPITFIRE VISION-01 SHARPNESS & EXPOSURE INDEX</span>
              <span class="text-emerald-400">AVG SHARPNESS: {{ rAnalysis().imageQualityStats.avgSharpness }}/100</span>
            </div>

            <div class="grid grid-cols-4 gap-2 text-center text-xs">
              <div class="bg-[#252B2D] p-2 border border-[#31483F]">
                <span class="text-[9px] text-[#C2C4BE]/60 block uppercase">AVG SHARPNESS</span>
                <span class="font-bold text-emerald-400 font-mono-tech">{{ rAnalysis().imageQualityStats.avgSharpness }}</span>
              </div>
              <div class="bg-[#252B2D] p-2 border border-[#31483F]">
                <span class="text-[9px] text-[#C2C4BE]/60 block uppercase">AVG EXPOSURE</span>
                <span class="font-bold text-[#ECE9E0] font-mono-tech">{{ rAnalysis().imageQualityStats.avgExposure }}</span>
              </div>
              <div class="bg-[#252B2D] p-2 border border-[#31483F]">
                <span class="text-[9px] text-[#C2C4BE]/60 block uppercase">BLUR RISK</span>
                <span class="font-bold text-[#F4F3ED] font-mono-tech">{{ rAnalysis().imageQualityStats.motionBlurRiskPct }}%</span>
              </div>
              <div class="bg-[#252B2D] p-2 border border-[#31483F]">
                <span class="text-[9px] text-[#C2C4BE]/60 block uppercase">NOISE FLOOR</span>
                <span class="font-bold text-[#C1943D] font-mono-tech">{{ rAnalysis().imageQualityStats.noiseFloorDb }} dB</span>
              </div>
            </div>
          </div>

        </div>

        <!-- RIGHT: Failure Simulation Playground & Flight Comparison (Col 4) -->
        <div class="lg:col-span-4 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0 overflow-y-auto">
          
          <!-- Failure Injection Testing Playground -->
          <div class="bg-[#111416] border border-[#31483F] p-3 rounded-xs flex flex-col gap-2">
            <span class="text-xs font-bold text-[#A3433C] uppercase font-display flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">warning</mat-icon>
              FAILURE SIMULATION TESTING GROUND
            </span>
            <p class="text-[10px] text-[#C2C4BE]/60">
              Inject synthetic sensor & actuator anomalies to test state machine transitions.
            </p>

            <div class="grid grid-cols-2 gap-2 text-[10px] mt-1">
              <button (click)="inject('GNSS')" 
                [class]="activeFailures().has('GNSS') ? 'bg-[#A3433C] text-white font-bold' : 'bg-[#252B2D] text-[#C2C4BE]'"
                class="p-2 border border-[#31483F] rounded-xs text-center">
                GNSS LOSS
              </button>

              <button (click)="inject('IMU')" 
                [class]="activeFailures().has('IMU') ? 'bg-[#A3433C] text-white font-bold' : 'bg-[#252B2D] text-[#C2C4BE]'"
                class="p-2 border border-[#31483F] rounded-xs text-center">
                IMU DRIFT
              </button>

              <button (click)="inject('CAMERA')" 
                [class]="activeFailures().has('CAMERA') ? 'bg-[#A3433C] text-white font-bold' : 'bg-[#252B2D] text-[#C2C4BE]'"
                class="p-2 border border-[#31483F] rounded-xs text-center">
                CAMERA FAULT
              </button>

              <button (click)="inject('MOTOR')" 
                [class]="activeFailures().has('MOTOR') ? 'bg-[#A3433C] text-white font-bold' : 'bg-[#252B2D] text-[#C2C4BE]'"
                class="p-2 border border-[#31483F] rounded-xs text-center">
                MOTOR ANOMALY
              </button>
            </div>

            <button (click)="clearFailures()" 
              class="w-full mt-1 p-2 bg-[#31483F] hover:bg-[#263F52] text-[#F4F3ED] font-bold text-xs rounded-xs">
              CLEAR ALL FAULTS
            </button>
          </div>

          <!-- Flight Comparison Tool -->
          <div class="bg-[#111416] border border-[#31483F] p-3 rounded-xs flex flex-col gap-2 text-xs">
            <span class="font-bold text-[#F4F3ED] uppercase font-display">FLIGHT COMPARISON (FLIGHT 001 VS FLIGHT 002)</span>
            
            <div class="flex flex-col gap-1.5 text-[10px] text-[#C2C4BE]">
              <div class="flex justify-between bg-[#252B2D] p-1.5">
                <span>METRIC</span>
                <span class="text-[#C1943D]">FLIGHT 001</span>
                <span class="text-[#3D6A7D]">FLIGHT 002</span>
              </div>
              <div class="flex justify-between border-b border-[#252B2D] pb-1">
                <span>Duration</span>
                <span class="font-bold text-[#F4F3ED]">14m 28s</span>
                <span class="font-bold text-[#F4F3ED]">15m 40s</span>
              </div>
              <div class="flex justify-between border-b border-[#252B2D] pb-1">
                <span>Energy Used</span>
                <span class="font-bold text-[#F4F3ED]">35.0 Wh</span>
                <span class="font-bold text-[#F4F3ED]">38.4 Wh</span>
              </div>
              <div class="flex justify-between border-b border-[#252B2D] pb-1">
                <span>Max Altitude</span>
                <span class="font-bold text-[#F4F3ED]">45.2 m</span>
                <span class="font-bold text-[#F4F3ED]">35.0 m</span>
              </div>
              <div class="flex justify-between">
                <span>Captures Count</span>
                <span class="font-bold text-emerald-400">42 photos</span>
                <span class="font-bold text-emerald-400">68 photos</span>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  `
})
export class FlightTestScreen {
  spitfire = inject(SpitfireService);

  rAnalysis = this.spitfire.rAnalysis;
  activeFailures = this.spitfire.activeFailures;

  runRAnalysis() {
    this.spitfire.runRAnalysis('FLIGHT-2026-004812');
  }

  inject(type: 'GNSS' | 'IMU' | 'BARO' | 'CAMERA' | 'BATTERY' | 'MOTOR') {
    this.spitfire.injectFailure(type);
  }

  clearFailures() {
    this.spitfire.clearFailures();
  }
}
