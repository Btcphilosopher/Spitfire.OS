import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SpitfireService } from '../../services/spitfire.service';
import { CameraCapture } from '../../models/spitfire.types';

@Component({
  selector: 'app-map-screen',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full w-full bg-[#111416] text-[#ECE9E0] flex flex-col p-3 gap-3 font-mono-tech select-none overflow-hidden">
      
      <!-- Top Header -->
      <div class="bg-[#252B2D] border border-[#31483F] p-2.5 rounded-sm flex items-center justify-between text-xs shrink-0">
        <div class="flex items-center gap-3">
          <mat-icon class="text-[#3D6A7D]">map</mat-icon>
          <div>
            <span class="font-bold text-[#F4F3ED] font-display uppercase tracking-wider">SYNCHRONISED MAP ↔ IMAGE ↔ TELEMETRY DIGITAL THREAD</span>
            <span class="text-[10px] text-[#C2C4BE]/60 ml-2">Click any image to reconstruct exact aircraft position & attitude</span>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <span class="text-[10px] text-[#C1943D]">CAPTURES IN THREAD: {{ captures().length }}</span>
        </div>
      </div>

      <!-- Main Map & Image Split View -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-3 flex-1 min-h-0">
        
        <!-- LEFT: Interactive Map Canvas with Geo-Tagged Image Pins (Col 7) -->
        <div class="lg:col-span-7 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0 relative">
          
          <div class="flex items-center justify-between text-xs border-b border-[#31483F] pb-2">
            <span class="font-bold text-[#F4F3ED] flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-emerald-400">place</mat-icon>
              SALISBURY / QUEENSFERRY SURVEY RANGE MAP
            </span>
            <span class="text-[#C2C4BE]">ACTIVE FLIGHT: {{ selectedCapture()?.flightId || 'FLIGHT-2026-004812' }}</span>
          </div>

          <!-- Synthetic Map Canvas -->
          <div class="flex-1 bg-[#111416] border border-[#31483F] rounded-xs relative overflow-hidden bg-blueprint-grid flex items-center justify-center cursor-crosshair">
            
            <svg class="w-full h-full absolute inset-0" viewBox="0 0 600 400">
              <!-- Flight Track Polyline -->
              <polyline points="80,320 180,240 280,180 400,140 500,220" 
                        fill="none" stroke="#3D6A7D" stroke-width="2.5" stroke-dasharray="4 2"/>

              <!-- Image Pins -->
              @for (cap of captures(); track cap.id; let idx = $index) {
                <g [attr.transform]="'translate(' + (120 + idx * 110) + ',' + (280 - idx * 45) + ')'"
                   class="cursor-pointer group" (click)="selectCapture(cap)">
                  
                  <!-- Pin Stem & Head -->
                  <circle r="16" [attr.fill]="selectedCapture()?.id === cap.id ? '#C1943D' : '#252B2D'" 
                          stroke="#F4F3ED" stroke-width="2" class="group-hover:stroke-[#C1943D] transition-colors"/>
                  <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-white -translate-x-2 -translate-y-2">photo_camera</mat-icon>

                  <!-- Image Label Flag -->
                  <rect x="-35" y="-38" width="70" height="18" fill="#111416" stroke="#31483F" rx="2"/>
                  <text x="0" y="-26" text-anchor="middle" fill="#F4F3ED" font-size="9" font-weight="bold">{{ cap.id }}</text>
                </g>
              }

              <!-- Drone Marker at Selected Capture Position -->
              @if (selectedCapture(); as sel) {
                <g [attr.transform]="'translate(' + (120 + getCaptureIndex(sel.id) * 110) + ',' + (280 - getCaptureIndex(sel.id) * 45) + ')'">
                  <g [attr.transform]="'rotate(' + sel.headingDeg + ')'">
                    <polygon points="0,-16 -8,12 0,6 8,12" fill="#emerald-400" stroke="#F4F3ED" stroke-width="1.5"/>
                  </g>
                </g>
              }
            </svg>

            <!-- Floating Map Pin Toast -->
            @if (selectedCapture(); as sel) {
              <div class="absolute top-3 left-3 bg-[#111416]/95 border border-[#C1943D] p-2.5 rounded-xs text-xs flex flex-col gap-1 max-w-xs z-10">
                <div class="font-bold text-[#C1943D] flex items-center gap-1">
                  <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">photo_camera</mat-icon>
                  IMAGE CAPTURED HERE: {{ sel.id }}
                </div>
                <div class="text-[10px] text-[#C2C4BE]">
                  LAT: {{ sel.lat.toFixed(4) }}° N · LNG: {{ sel.lng.toFixed(4) }}° W
                </div>
                <div class="text-[10px] text-[#F4F3ED]">
                  ALT AGL: {{ sel.altM.toFixed(1) }}m · HDG: {{ sel.headingDeg.toFixed(0) }}°
                </div>
              </div>
            }

          </div>

        </div>

        <!-- RIGHT: Selected Image & Telemetry Freeze-Frame Inspector (Col 5) -->
        <div class="lg:col-span-5 bg-[#252B2D]/80 border border-[#31483F] rounded-sm p-3 flex flex-col gap-3 min-h-0 overflow-y-auto">
          
          <div class="flex items-center justify-between text-xs border-b border-[#31483F] pb-2">
            <span class="font-bold text-[#F4F3ED] flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#C1943D]">preview</mat-icon>
              IMAGE & TELEMETRY FREEZE-FRAME
            </span>
            <span class="text-emerald-400 font-bold">QUALITY SCORE: {{ selectedCapture()?.imageQualityIndex || 94 }}/100</span>
          </div>

          <!-- Captured Photo Display Frame -->
          @if (selectedCapture(); as cap) {
            <div class="bg-[#111416] border border-[#31483F] rounded-xs p-2 flex flex-col gap-2">
              <div class="h-56 w-full overflow-hidden border border-[#252B2D] relative">
                <img [src]="cap.imageUrl" alt="Captured Frame" class="w-full h-full object-cover" referrerpolicy="no-referrer">
                <div class="absolute top-2 left-2 bg-[#111416]/80 text-[#F4F3ED] px-2 py-0.5 text-[9px] font-bold border border-[#31483F]">
                  {{ cap.id }} · {{ cap.timestamp }}
                </div>
              </div>

              <!-- Annotation Note -->
              <p class="text-xs text-[#ECE9E0] bg-[#252B2D] p-2 border-l-2 border-[#C1943D]">
                <strong class="text-[#C1943D]">INSPECTOR NOTE:</strong> {{ cap.annotation || 'No anomaly noted.' }}
              </p>
            </div>

            <!-- Frozen Aircraft State Metadata Matrix -->
            <div class="bg-[#111416] border border-[#31483F] p-3 rounded-xs grid grid-cols-2 gap-2 text-xs">
              <div>
                <span class="text-[9px] text-[#C2C4BE]/60 uppercase block">TIMESTAMP</span>
                <span class="font-bold text-[#F4F3ED]">{{ cap.timestamp }}</span>
              </div>
              <div>
                <span class="text-[9px] text-[#C2C4BE]/60 uppercase block">ALTITUDE (AGL)</span>
                <span class="font-bold text-[#F4F3ED]">{{ cap.altM.toFixed(1) }} m</span>
              </div>
              <div>
                <span class="text-[9px] text-[#C2C4BE]/60 uppercase block">AIRCRAFT HEADING</span>
                <span class="font-bold text-[#C1943D]">{{ cap.headingDeg.toFixed(0) }}°</span>
              </div>
              <div>
                <span class="text-[9px] text-[#C2C4BE]/60 uppercase block">GIMBAL PITCH</span>
                <span class="font-bold text-[#F4F3ED]">{{ cap.gimbalPitchDeg.toFixed(0) }}°</span>
              </div>
              <div>
                <span class="text-[9px] text-[#C2C4BE]/60 uppercase block">EXPOSURE / ISO</span>
                <span class="font-bold text-[#ECE9E0]">{{ cap.shutterSpeed }} @ ISO {{ cap.iso }}</span>
              </div>
              <div>
                <span class="text-[9px] text-[#C2C4BE]/60 uppercase block">GPS RTK FIX QUALITY</span>
                <span class="font-bold text-emerald-400">{{ cap.gpsQualityPct }}%</span>
              </div>
            </div>
          } @else {
            <div class="flex-1 flex items-center justify-center text-xs text-[#C2C4BE]">
              Select an image from the map or timeline below.
            </div>
          }

        </div>

      </div>

      <!-- BOTTOM: Image Timeline Strip (Scannable Thumbnails) -->
      <div class="bg-[#252B2D] border border-[#31483F] p-2.5 rounded-sm flex flex-col gap-2 shrink-0">
        <div class="text-[10px] text-[#C2C4BE] font-bold uppercase tracking-wider">
          FLIGHT CAPTURE TIMELINE (CLICK THUMBNAIL TO RECONSTRUCT AIRCRAFT STATE)
        </div>

        <div class="flex items-center gap-3 overflow-x-auto pb-1">
          @for (cap of captures(); track cap.id) {
            <div (click)="selectCapture(cap)" (keydown.enter)="selectCapture(cap)" tabindex="0" role="button"
                 class="shrink-0 w-28 bg-[#111416] border rounded-xs p-1 cursor-pointer transition-all hover:border-[#C1943D]"
                 [ngClass]="selectedCapture()?.id === cap.id ? 'border-[#C1943D] ring-1 ring-[#C1943D]' : 'border-[#31483F]'">
              <div class="h-14 w-full overflow-hidden mb-1">
                <img [src]="cap.thumbnailUrl" alt="Thumbnail" class="w-full h-full object-cover" referrerpolicy="no-referrer">
              </div>
              <div class="text-[9px] font-bold text-[#F4F3ED] truncate">{{ cap.id }}</div>
              <div class="text-[8px] text-[#C2C4BE]">{{ cap.altM.toFixed(0) }}m · {{ cap.headingDeg.toFixed(0) }}°</div>
            </div>
          }
        </div>
      </div>

    </div>
  `
})
export class MapScreen {
  spitfire = inject(SpitfireService);

  captures = this.spitfire.captures;
  selectedCapture = this.spitfire.selectedCapture;

  selectCapture(cap: CameraCapture) {
    this.spitfire.selectCapture(cap);
  }

  getCaptureIndex(id: string): number {
    const idx = this.captures().findIndex(c => c.id === id);
    return idx >= 0 ? idx : 0;
  }
}
