import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TopNav } from './components/top-nav/top-nav';
import { FlightScreen } from './components/flight-screen/flight-screen';
import { MissionScreen } from './components/mission-screen/mission-screen';
import { CameraScreen } from './components/camera-screen/camera-screen';
import { MapScreen } from './components/map-screen/map-screen';
import { TelemetryScreen } from './components/telemetry-screen/telemetry-screen';
import { VehicleScreen } from './components/vehicle-screen/vehicle-screen';
import { BatteryScreen } from './components/battery-screen/battery-screen';
import { VisionScreen } from './components/vision-screen/vision-screen';
import { TwinScreen } from './components/twin-screen/twin-screen';
import { FlightTestScreen } from './components/flight-test-screen/flight-test-screen';
import { DataScreen } from './components/data-screen/data-screen';
import { SpitfireService } from './services/spitfire.service';

@Component({
  selector: 'app-root',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    TopNav,
    FlightScreen,
    MissionScreen,
    CameraScreen,
    MapScreen,
    TelemetryScreen,
    VehicleScreen,
    BatteryScreen,
    VisionScreen,
    TwinScreen,
    FlightTestScreen,
    DataScreen
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  spitfire = inject(SpitfireService);
  activeTab = this.spitfire.activeTab;
}
