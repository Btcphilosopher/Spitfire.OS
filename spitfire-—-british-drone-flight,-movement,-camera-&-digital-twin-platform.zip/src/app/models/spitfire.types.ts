export type NavTab = 
  | 'FLIGHT' 
  | 'MISSION' 
  | 'CAMERA' 
  | 'MAP' 
  | 'TELEMETRY' 
  | 'VEHICLE' 
  | 'BATTERY' 
  | 'VISION' 
  | 'TWIN' 
  | 'FLIGHT_TEST' 
  | 'DATA';

export type VehicleState = 
  | 'INITIALISING'
  | 'READY'
  | 'ARMED'
  | 'TAKEOFF'
  | 'FLIGHT'
  | 'MISSION'
  | 'RETURN'
  | 'LANDING'
  | 'LANDED'
  | 'SENSOR_DEGRADED'
  | 'LOW_BATTERY'
  | 'LINK_DEGRADED'
  | 'NAVIGATION_DEGRADED'
  | 'MOTOR_FAULT'
  | 'CAMERA_FAULT'
  | 'EMERGENCY';

export type FlightMode = 'SIMULATION' | 'SITL' | 'HIL' | 'BENCH' | 'FLIGHT_TEST';

export type CameraMode = 'FREE_LOOK' | 'FORWARD' | 'NADIR' | 'TRACK' | 'ORBIT';

export type GimbalMode = 'STABILIZED' | 'TARGET_LOCK' | 'NADIR_LOCK' | 'MANUAL';

export interface PositionState {
  lat: number;
  lng: number;
  alt: number;            // meters MSL
  relativeAlt: number;    // meters AGL
  groundSpeed: number;    // m/s
  verticalSpeed: number;  // m/s
  heading: number;        // degrees 0-360
}

export interface AttitudeState {
  roll: number;     // degrees
  pitch: number;    // degrees
  yaw: number;      // degrees
  rollRate: number; // deg/s
  pitchRate: number;// deg/s
  yawRate: number;  // deg/s
  q0: number;       // quaternion w
  q1: number;       // quaternion x
  q2: number;       // quaternion y
  q3: number;       // quaternion z
}

export interface BatteryState {
  voltage: number;         // Volts (e.g. 15.2V)
  current: number;         // Amperes (e.g. 18.4A)
  power: number;           // Watts
  soc: number;             // % State of Charge
  temperature: number;     // Celsius
  cellVoltages: number[];  // 4 cells (V)
  energyUsedWh: number;    // Watt-hours
  capacityWh: number;      // Total capacity (e.g. 125Wh)
  estimatedRemainingSec: number; // Remaining flight seconds
}

export interface MotorState {
  id: number;
  label: string;
  rpm: number;
  current: number;
  voltage: number;
  temperature: number;
  estimatedThrustN: number;
  health: 'NORMAL' | 'ATTENTION' | 'DEGRADED' | 'FAULT';
}

export interface SensorState {
  imuHealth: 'NORMAL' | 'DEGRADED' | 'FAULT';
  imuResidualMs2: number;
  gnssFix: 'NO_FIX' | '2D' | '3D' | 'RTK_FLOAT' | 'RTK_FIXED';
  gnssQuality: number; // 0-100
  satellites: number;
  baroAltM: number;
  baroHealth: 'NORMAL' | 'FAULT';
  magHeadingDeg: number;
  magHealth: 'NORMAL' | 'DEGRADED' | 'FAULT';
  rangefinderDistM: number;
  opticalFlowQuality: number; // 0-100
  linkQualityPct: number;
  linkLatencyMs: number;
}

export interface CameraState {
  connected: boolean;
  recording: boolean;
  mode: CameraMode;
  photoFormat: 'RAW' | 'JPEG' | 'RAW+JPEG' | 'LOG';
  resolution: '4K_60FPS' | '4K_30FPS' | '1080P_120FPS' | '48MP_RAW';
  zoomFactor: number;      // 1.0 - 8.0x
  focusMode: 'AUTO' | 'MANUAL';
  focusDistanceM: number;
  iso: number;             // 100 - 6400
  shutterSpeed: string;    // e.g. "1/1000s"
  aperture: string;        // e.g. "f/2.8"
  whiteBalance: 'AUTO' | '5600K' | '3200K' | 'CLOUDY';
  storageAvailableGb: number;
  storageTotalGb: number;
  capturesCount: number;
  temperature: number;     // Celsius
}

export interface GimbalState {
  mode: GimbalMode;
  rollDeg: number;
  pitchDeg: number;       // e.g. -90 (nadir) to +20
  yawDeg: number;
  targetPitchDeg: number;
  targetYawDeg: number;
  pitchRateDegS: number;
  stabilizationActive: boolean;
  targetCoordinates?: { lat: number; lng: number; alt: number };
}

export interface TelemetryData {
  timestamp: string;
  elapsedSec: number;
  vehicleState: VehicleState;
  flightMode: FlightMode;
  position: PositionState;
  attitude: AttitudeState;
  battery: BatteryState;
  motors: MotorState[];
  sensors: SensorState;
  camera: CameraState;
  gimbal: GimbalState;
  windVector: { speedMs: number; directionDeg: number; gustMs: number };
  activeMissionId?: string;
  activeWaypointIndex?: number;
}

export interface MissionItem {
  id: string;
  seq: number;
  command: 'TAKEOFF' | 'WAYPOINT' | 'ORBIT' | 'CAMERA_ACTION' | 'RETURN' | 'LAND';
  lat: number;
  lng: number;
  altM: number;
  speedMs: number;
  headingDeg: number;
  holdTimeSec: number;
  orbitRadiusM?: number;
  cameraAction?: 'NONE' | 'PHOTO' | 'RECORD_START' | 'RECORD_STOP' | 'SET_PITCH' | 'POINT_TARGET';
}

export interface Mission {
  id: string;
  name: string;
  description: string;
  type: 'HERITAGE_SURVEY' | 'BRIDGE_INSPECTION' | 'ROOF_SURVEY' | 'AGRICULTURAL' | 'CALIBRATION' | 'CUSTOM';
  targetLocationName: string;
  estimatedDurationSec: number;
  totalDistanceM: number;
  items: MissionItem[];
  createdDate: string;
}

export interface CameraCapture {
  id: string;
  flightId: string;
  missionId?: string;
  timestamp: string;
  elapsedSec: number;
  lat: number;
  lng: number;
  altM: number;
  headingDeg: number;
  rollDeg: number;
  pitchDeg: number;
  gimbalPitchDeg: number;
  gimbalYawDeg: number;
  iso: number;
  shutterSpeed: string;
  focalLengthMm: number;
  gpsQualityPct: number;
  imageUrl: string;
  thumbnailUrl: string;
  imageQualityIndex: number; // 0-100
  sharpnessScore: number;    // 0-100
  exposureScore: number;     // 0-100
  noiseLevelDb: number;
  provenance: 'MEASURED' | 'SIMULATED' | 'DERIVED';
  annotation?: string;
  findingsCount?: number;
}

export interface FlightRecord {
  id: string;
  name: string;
  missionName: string;
  date: string;
  durationSec: number;
  distanceM: number;
  maxAltM: number;
  maxSpeedMs: number;
  energyUsedWh: number;
  sensorHealthPct: number;
  capturesCount: number;
  status: 'COMPLETED' | 'SIMULATED' | 'ABORTED' | 'IN_PROGRESS';
  provenance: 'SIMULATED' | 'MEASURED' | 'IMPORTED';
  softwareVersion: string;
  calibrationVersion: string;
  droneModel: string;
}

export interface FlightEvent {
  id: string;
  timestamp: string;
  elapsedSec: number;
  severity: 'INFO' | 'WARNING' | 'CRITICAL' | 'SAFETY';
  category: 'STATE_CHANGE' | 'SENSOR' | 'BATTERY' | 'CAMERA' | 'NAV' | 'SAFETY';
  message: string;
  details?: string;
}

export interface ComponentPassport {
  id: string;
  name: string;
  type: 'AIRFRAME' | 'BATTERY' | 'FLIGHT_CONTROLLER' | 'COMPANION_COMPUTER' | 'GNSS' | 'IMU' | 'CAMERA' | 'GIMBAL' | 'MOTOR';
  serialNumber: string;
  firmwareVersion: string;
  hardwareRev: string;
  healthStatus: 'NORMAL' | 'ATTENTION' | 'DEGRADED' | 'FAULT';
  temperatureC: number;
  runtimeHours: number;
  captureCount?: number;
  lastCalibratedDate: string;
  specifications: Record<string, string>;
}

export interface InspectionFinding {
  id: string;
  projectId: string;
  flightId: string;
  imageId: string;
  locationName: string;
  category: 'STRUCTURAL' | 'CORROSION' | 'SURFACE_DEFECT' | 'THERMAL' | 'ALIGNMENT';
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  description: string;
  status: 'OPEN' | 'UNDER_REVIEW' | 'RESOLVED';
  coordPx: { x: number; y: number };
  aiAssessment?: string;
}

export interface RAnalysisResult {
  flightId: string;
  analyzedAt: string;
  trajectoryErrorM: number;
  attitudeStabilityIndex: number; // 0-100
  energyEfficiencyWhKm: number;
  sensorResiduals: {
    imuMPerSec2: number;
    gnssMeters: number;
    baroMeters: number;
    magDegrees: number;
  };
  imageQualityStats: {
    avgSharpness: number;
    avgExposure: number;
    motionBlurRiskPct: number;
    noiseFloorDb: number;
  };
  batteryDischargeCurve: { socPct: number; estMinutesRemaining: number; powerWatts: number }[];
  anomaliesDetected: string[];
  reportSummary: string;
}
