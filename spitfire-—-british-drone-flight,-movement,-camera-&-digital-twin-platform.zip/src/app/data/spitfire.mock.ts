import { 
  ComponentPassport, 
  FlightRecord, 
  InspectionFinding, 
  Mission, 
  CameraCapture, 
  TelemetryData,
  RAnalysisResult
} from '../models/spitfire.types';

export const INITIAL_TELEMETRY: TelemetryData = {
  timestamp: new Date().toISOString(),
  elapsedSec: 868, // 14:28
  vehicleState: 'FLIGHT',
  flightMode: 'SIMULATION',
  position: {
    lat: 56.0012,
    lng: -3.3884,
    alt: 42.6,
    relativeAlt: 42.6,
    groundSpeed: 8.4,
    verticalSpeed: 0.8,
    heading: 84
  },
  attitude: {
    roll: 1.8,
    pitch: -2.4,
    yaw: 84.0,
    rollRate: 0.02,
    pitchRate: -0.01,
    yawRate: 0.1,
    q0: 0.737,
    q1: 0.012,
    q2: -0.018,
    q3: 0.675
  },
  battery: {
    voltage: 15.24,
    current: 18.4,
    power: 280.4,
    soc: 72,
    temperature: 34.2,
    cellVoltages: [3.81, 3.81, 3.81, 3.81],
    energyUsedWh: 35.0,
    capacityWh: 125.0,
    estimatedRemainingSec: 1120
  },
  motors: [
    { id: 1, label: 'MOTOR 01 (FRONT-RIGHT)', rpm: 4820, current: 4.6, voltage: 15.2, temperature: 41.2, estimatedThrustN: 9.8, health: 'NORMAL' },
    { id: 2, label: 'MOTOR 02 (REAR-LEFT)', rpm: 4810, current: 4.5, voltage: 15.2, temperature: 40.8, estimatedThrustN: 9.7, health: 'NORMAL' },
    { id: 3, label: 'MOTOR 03 (FRONT-LEFT)', rpm: 4850, current: 4.7, voltage: 15.2, temperature: 42.1, estimatedThrustN: 9.9, health: 'NORMAL' },
    { id: 4, label: 'MOTOR 04 (REAR-RIGHT)', rpm: 4830, current: 4.6, voltage: 15.2, temperature: 41.5, estimatedThrustN: 9.8, health: 'NORMAL' }
  ],
  sensors: {
    imuHealth: 'NORMAL',
    imuResidualMs2: 0.04,
    gnssFix: 'RTK_FIXED',
    gnssQuality: 98,
    satellites: 18,
    baroAltM: 42.62,
    baroHealth: 'NORMAL',
    magHeadingDeg: 84.2,
    magHealth: 'NORMAL',
    rangefinderDistM: 42.58,
    opticalFlowQuality: 94,
    linkQualityPct: 98,
    linkLatencyMs: 12
  },
  camera: {
    connected: true,
    recording: true,
    mode: 'FORWARD',
    photoFormat: 'RAW+JPEG',
    resolution: '4K_60FPS',
    zoomFactor: 1.0,
    focusMode: 'AUTO',
    focusDistanceM: 25.0,
    iso: 200,
    shutterSpeed: '1/1000s',
    aperture: 'f/2.8',
    whiteBalance: '5600K',
    storageAvailableGb: 112.4,
    storageTotalGb: 128.0,
    capturesCount: 42,
    temperature: 38.5
  },
  gimbal: {
    mode: 'STABILIZED',
    rollDeg: 0.0,
    pitchDeg: -15.0,
    yawDeg: 84.0,
    targetPitchDeg: -15.0,
    targetYawDeg: 84.0,
    pitchRateDegS: 0.0,
    stabilizationActive: true
  },
  windVector: {
    speedMs: 3.2,
    directionDeg: 120,
    gustMs: 4.8
  },
  activeMissionId: 'MISSION-2026-001',
  activeWaypointIndex: 3
};

export const MOCK_MISSIONS: Mission[] = [
  {
    id: 'MISSION-2026-001',
    name: 'Firth of Forth Rail Bridge Structural Survey',
    type: 'BRIDGE_INSPECTION',
    description: 'High-resolution photogrammetric inspection of steel truss piers and rivet clusters.',
    targetLocationName: 'Firth of Forth, Queensferry, Scotland',
    estimatedDurationSec: 1200,
    totalDistanceM: 3450,
    createdDate: '2026-09-26',
    items: [
      { id: 'item-1', seq: 1, command: 'TAKEOFF', lat: 56.0005, lng: -3.3892, altM: 15, speedMs: 2.0, headingDeg: 0, holdTimeSec: 5, cameraAction: 'NONE' },
      { id: 'item-2', seq: 2, command: 'WAYPOINT', lat: 56.0010, lng: -3.3888, altM: 30, speedMs: 5.0, headingDeg: 45, holdTimeSec: 2, cameraAction: 'PHOTO' },
      { id: 'item-3', seq: 3, command: 'WAYPOINT', lat: 56.0012, lng: -3.3884, altM: 42.6, speedMs: 4.0, headingDeg: 84, holdTimeSec: 4, cameraAction: 'PHOTO' },
      { id: 'item-4', seq: 4, command: 'ORBIT', lat: 56.0018, lng: -3.3875, altM: 45, speedMs: 3.0, headingDeg: 90, holdTimeSec: 30, orbitRadiusM: 25, cameraAction: 'POINT_TARGET' },
      { id: 'item-5', seq: 5, command: 'WAYPOINT', lat: 56.0022, lng: -3.3860, altM: 40, speedMs: 6.0, headingDeg: 120, holdTimeSec: 2, cameraAction: 'PHOTO' },
      { id: 'item-6', seq: 6, command: 'RETURN', lat: 56.0005, lng: -3.3892, altM: 30, speedMs: 8.0, headingDeg: 270, holdTimeSec: 0, cameraAction: 'NONE' },
      { id: 'item-7', seq: 7, command: 'LAND', lat: 56.0005, lng: -3.3892, altM: 0, speedMs: 1.5, headingDeg: 0, holdTimeSec: 0, cameraAction: 'NONE' }
    ]
  },
  {
    id: 'MISSION-2026-002',
    name: 'Industrial Estate Roof & Solar Array Inspection',
    type: 'ROOF_SURVEY',
    description: 'Autonomous nadir grid flight for thermal & optical solar cell defect mapping.',
    targetLocationName: 'Farnborough Aerospace Park, UK',
    estimatedDurationSec: 950,
    totalDistanceM: 2800,
    createdDate: '2026-09-25',
    items: [
      { id: 'item-201', seq: 1, command: 'TAKEOFF', lat: 51.2780, lng: -0.7720, altM: 20, speedMs: 2.0, headingDeg: 0, holdTimeSec: 3, cameraAction: 'SET_PITCH' },
      { id: 'item-202', seq: 2, command: 'WAYPOINT', lat: 51.2785, lng: -0.7715, altM: 35, speedMs: 6.0, headingDeg: 90, holdTimeSec: 0, cameraAction: 'RECORD_START' },
      { id: 'item-203', seq: 3, command: 'WAYPOINT', lat: 51.2790, lng: -0.7700, altM: 35, speedMs: 6.0, headingDeg: 180, holdTimeSec: 0, cameraAction: 'PHOTO' },
      { id: 'item-204', seq: 4, command: 'WAYPOINT', lat: 51.2782, lng: -0.7700, altM: 35, speedMs: 6.0, headingDeg: 270, holdTimeSec: 0, cameraAction: 'PHOTO' },
      { id: 'item-205', seq: 5, command: 'RETURN', lat: 51.2780, lng: -0.7720, altM: 20, speedMs: 7.0, headingDeg: 270, holdTimeSec: 0, cameraAction: 'RECORD_STOP' },
      { id: 'item-206', seq: 6, command: 'LAND', lat: 51.2780, lng: -0.7720, altM: 0, speedMs: 1.5, headingDeg: 0, holdTimeSec: 0, cameraAction: 'NONE' }
    ]
  },
  {
    id: 'MISSION-2026-003',
    name: 'Salisbury Plain High-Wind Calibration Flight',
    type: 'CALIBRATION',
    description: 'System identification flight under turbulent gust vectors for sensor fusion verification.',
    targetLocationName: 'Salisbury Plain Flight Test Area, Wiltshire',
    estimatedDurationSec: 1500,
    totalDistanceM: 5200,
    createdDate: '2026-09-24',
    items: [
      { id: 'item-301', seq: 1, command: 'TAKEOFF', lat: 51.2200, lng: -1.8100, altM: 25, speedMs: 3.0, headingDeg: 0, holdTimeSec: 10, cameraAction: 'NONE' },
      { id: 'item-302', seq: 2, command: 'ORBIT', lat: 51.2210, lng: -1.8080, altM: 50, speedMs: 8.0, headingDeg: 0, holdTimeSec: 60, orbitRadiusM: 50, cameraAction: 'NONE' },
      { id: 'item-303', seq: 3, command: 'RETURN', lat: 51.2200, lng: -1.8100, altM: 25, speedMs: 10.0, headingDeg: 180, holdTimeSec: 0, cameraAction: 'NONE' },
      { id: 'item-304', seq: 4, command: 'LAND', lat: 51.2200, lng: -1.8100, altM: 0, speedMs: 1.5, headingDeg: 0, holdTimeSec: 0, cameraAction: 'NONE' }
    ]
  }
];

export const MOCK_FLIGHTS: FlightRecord[] = [
  {
    id: 'FLIGHT-2026-004812',
    name: 'FLIGHT 001 - Firth of Forth Bridge Survey',
    missionName: 'Firth of Forth Rail Bridge Structural Survey',
    date: '2026-09-26 14:14:02',
    durationSec: 868,
    distanceM: 2840,
    maxAltM: 45.2,
    maxSpeedMs: 9.8,
    energyUsedWh: 35.0,
    sensorHealthPct: 99.4,
    capturesCount: 42,
    status: 'IN_PROGRESS',
    provenance: 'SIMULATED',
    softwareVersion: 'v2.4.1-spitfire-rust',
    calibrationVersion: 'CAL-2026-v2',
    droneModel: 'SPITFIRE S1'
  },
  {
    id: 'FLIGHT-2026-004811',
    name: 'FLIGHT 002 - Industrial Roof Survey',
    missionName: 'Industrial Estate Roof & Solar Array Inspection',
    date: '2026-09-25 11:30:15',
    durationSec: 940,
    distanceM: 2790,
    maxAltM: 35.0,
    maxSpeedMs: 6.2,
    energyUsedWh: 38.4,
    sensorHealthPct: 98.8,
    capturesCount: 68,
    status: 'COMPLETED',
    provenance: 'SIMULATED',
    softwareVersion: 'v2.4.1-spitfire-rust',
    calibrationVersion: 'CAL-2026-v2',
    droneModel: 'SPITFIRE S1'
  },
  {
    id: 'FLIGHT-2026-004810',
    name: 'FLIGHT 003 - Salisbury Plain High Wind Test',
    missionName: 'Salisbury Plain High-Wind Calibration Flight',
    date: '2026-09-24 16:45:00',
    durationSec: 1420,
    distanceM: 5120,
    maxAltM: 52.0,
    maxSpeedMs: 12.4,
    energyUsedWh: 68.2,
    sensorHealthPct: 96.2,
    capturesCount: 12,
    status: 'COMPLETED',
    provenance: 'SIMULATED',
    softwareVersion: 'v2.4.0-spitfire-rust',
    calibrationVersion: 'CAL-2026-v1',
    droneModel: 'SPITFIRE S1'
  },
  {
    id: 'FLIGHT-2026-004809',
    name: 'FLIGHT 004 - Heritage Estate Topographic Mapping',
    missionName: 'Historical Estate Survey',
    date: '2026-09-22 09:15:30',
    durationSec: 1180,
    distanceM: 4100,
    maxAltM: 60.0,
    maxSpeedMs: 8.0,
    energyUsedWh: 48.6,
    sensorHealthPct: 100.0,
    capturesCount: 112,
    status: 'COMPLETED',
    provenance: 'SIMULATED',
    softwareVersion: 'v2.4.0-spitfire-rust',
    calibrationVersion: 'CAL-2026-v1',
    droneModel: 'SPITFIRE S1'
  },
  {
    id: 'FLIGHT-2026-004808',
    name: 'FLIGHT 005 - Offshore Wind Turbine Inspection',
    missionName: 'Turbine Nacelle Blade Inspection',
    date: '2026-09-20 13:20:00',
    durationSec: 1350,
    distanceM: 4800,
    maxAltM: 85.0,
    maxSpeedMs: 10.5,
    energyUsedWh: 58.1,
    sensorHealthPct: 97.5,
    capturesCount: 84,
    status: 'COMPLETED',
    provenance: 'SIMULATED',
    softwareVersion: 'v2.4.0-spitfire-rust',
    calibrationVersion: 'CAL-2026-v1',
    droneModel: 'SPITFIRE S1'
  },
  {
    id: 'FLIGHT-2026-004807',
    name: 'FLIGHT 006 - Camera Calibration Grid Flight',
    missionName: 'Vision-01 Calibration Lab Test',
    date: '2026-09-18 15:00:10',
    durationSec: 620,
    distanceM: 1200,
    maxAltM: 20.0,
    maxSpeedMs: 3.5,
    energyUsedWh: 22.0,
    sensorHealthPct: 100.0,
    capturesCount: 54,
    status: 'COMPLETED',
    provenance: 'SIMULATED',
    softwareVersion: 'v2.3.9-spitfire-rust',
    calibrationVersion: 'CAL-2026-v1',
    droneModel: 'SPITFIRE S1'
  },
  {
    id: 'FLIGHT-2026-004806',
    name: 'FLIGHT 007 - GNSS Degradation Safety Regression',
    missionName: 'Fault Injection Regression Flight',
    date: '2026-09-15 10:10:40',
    durationSec: 780,
    distanceM: 1850,
    maxAltM: 30.0,
    maxSpeedMs: 5.0,
    energyUsedWh: 31.4,
    sensorHealthPct: 82.0,
    capturesCount: 8,
    status: 'COMPLETED',
    provenance: 'SIMULATED',
    softwareVersion: 'v2.3.9-spitfire-rust',
    calibrationVersion: 'CAL-2026-v1',
    droneModel: 'SPITFIRE S1'
  }
];

export const MOCK_CAPTURES: CameraCapture[] = [
  {
    id: 'IMAGE-004182',
    flightId: 'FLIGHT-2026-004812',
    missionId: 'MISSION-2026-001',
    timestamp: '2026-09-26T14:28:18Z',
    elapsedSec: 858,
    lat: 56.0012,
    lng: -3.3884,
    altM: 42.6,
    headingDeg: 84.0,
    rollDeg: 1.8,
    pitchDeg: -2.4,
    gimbalPitchDeg: -15.0,
    gimbalYawDeg: 84.0,
    iso: 200,
    shutterSpeed: '1/1000s',
    focalLengthMm: 24.0,
    gpsQualityPct: 98,
    imageUrl: '/src/assets/images/spitfire_bridge_inspection_1790423887379.jpg',
    thumbnailUrl: '/src/assets/images/spitfire_bridge_inspection_1790423887379.jpg',
    imageQualityIndex: 94.2,
    sharpnessScore: 96.5,
    exposureScore: 92.1,
    noiseLevelDb: 42.1,
    provenance: 'SIMULATED',
    annotation: 'Rivet cluster 4B-East: Surface patina nominal, no fatigue micro-fissures detected.',
    findingsCount: 1
  },
  {
    id: 'IMAGE-004181',
    flightId: 'FLIGHT-2026-004811',
    missionId: 'MISSION-2026-002',
    timestamp: '2026-09-25T11:38:10Z',
    elapsedSec: 490,
    lat: 51.2785,
    lng: -0.7715,
    altM: 35.0,
    headingDeg: 90.0,
    rollDeg: 0.2,
    pitchDeg: -0.4,
    gimbalPitchDeg: -90.0,
    gimbalYawDeg: 90.0,
    iso: 100,
    shutterSpeed: '1/1250s',
    focalLengthMm: 24.0,
    gpsQualityPct: 99,
    imageUrl: '/src/assets/images/spitfire_roof_inspection_1790423897774.jpg',
    thumbnailUrl: '/src/assets/images/spitfire_roof_inspection_1790423897774.jpg',
    imageQualityIndex: 96.8,
    sharpnessScore: 98.2,
    exposureScore: 95.4,
    noiseLevelDb: 46.8,
    provenance: 'SIMULATED',
    annotation: 'Photovoltaic Array Section C: Module 14 exhibits minor thermal cell discoloration.',
    findingsCount: 1
  },
  {
    id: 'IMAGE-004180',
    flightId: 'FLIGHT-2026-004809',
    missionId: 'MISSION-2026-004',
    timestamp: '2026-09-22T09:28:45Z',
    elapsedSec: 795,
    lat: 51.1780,
    lng: -1.8260,
    altM: 60.0,
    headingDeg: 142.0,
    rollDeg: -0.8,
    pitchDeg: 1.1,
    gimbalPitchDeg: -45.0,
    gimbalYawDeg: 142.0,
    iso: 100,
    shutterSpeed: '1/1600s',
    focalLengthMm: 24.0,
    gpsQualityPct: 100,
    imageUrl: '/src/assets/images/spitfire_heritage_survey_1790423908582.jpg',
    thumbnailUrl: '/src/assets/images/spitfire_heritage_survey_1790423908582.jpg',
    imageQualityIndex: 98.1,
    sharpnessScore: 99.0,
    exposureScore: 97.2,
    noiseLevelDb: 48.2,
    provenance: 'SIMULATED',
    annotation: 'Curtain Wall North Tower: Masonry joint integrity verified.',
    findingsCount: 0
  },
  {
    id: 'IMAGE-004179',
    flightId: 'FLIGHT-2026-004808',
    missionId: 'MISSION-2026-005',
    timestamp: '2026-09-20T13:35:12Z',
    elapsedSec: 912,
    lat: 53.5210,
    lng: 0.8120,
    altM: 85.0,
    headingDeg: 210.0,
    rollDeg: 2.1,
    pitchDeg: -1.8,
    gimbalPitchDeg: -20.0,
    gimbalYawDeg: 210.0,
    iso: 400,
    shutterSpeed: '1/2000s',
    focalLengthMm: 24.0,
    gpsQualityPct: 97,
    imageUrl: '/src/assets/images/spitfire_wind_turbine_1790423920654.jpg',
    thumbnailUrl: '/src/assets/images/spitfire_wind_turbine_1790423920654.jpg',
    imageQualityIndex: 91.5,
    sharpnessScore: 93.0,
    exposureScore: 90.0,
    noiseLevelDb: 39.8,
    provenance: 'SIMULATED',
    annotation: 'Blade 2 Trailing Edge: Minor leading edge erosion noted at 65% radius.',
    findingsCount: 1
  }
];

export const MOCK_PASSPORTS: ComponentPassport[] = [
  {
    id: 'PASSPORT-AIRFRAME',
    name: 'SPITFIRE S1 Carbon Composite Frame',
    type: 'AIRFRAME',
    serialNumber: 'AF-S1-00104',
    firmwareVersion: 'N/A (Structural)',
    hardwareRev: 'Rev D (Molded Carbon)',
    healthStatus: 'NORMAL',
    temperatureC: 22.4,
    runtimeHours: 148.5,
    lastCalibratedDate: '2026-08-15',
    specifications: {
      'Diagonal Wheelbase': '650 mm',
      'Max Takeoff Weight': '4.8 kg',
      'Frame Weight': '920 g',
      'Material': 'Toray T700 3K Carbon Fiber',
      'Ingress Protection': 'IP54 Aerospace Sealed'
    }
  },
  {
    id: 'PASSPORT-FC01',
    name: 'SPITFIRE Flight Controller FC-01',
    type: 'FLIGHT_CONTROLLER',
    serialNumber: 'FC-01-99482',
    firmwareVersion: 'v2.4.1-spitfire-rust',
    hardwareRev: 'FC-01 Hardware v2.0',
    healthStatus: 'NORMAL',
    temperatureC: 36.8,
    runtimeHours: 148.5,
    lastCalibratedDate: '2026-09-01',
    specifications: {
      'MCU': 'Dual STM32H753 @ 480MHz',
      'RTOS Kernel': 'SPITFIRE Rust RTIC System Engine',
      'Control Loop Rate': '1000 Hz',
      'IMU Redundancy': 'Triple Isolated Gyro/Accel',
      'Failsafe Latency': '< 2 ms'
    }
  },
  {
    id: 'PASSPORT-CC01',
    name: 'SPITFIRE Companion Computer CC-01',
    type: 'COMPANION_COMPUTER',
    serialNumber: 'CC-01-44102',
    firmwareVersion: 'v2.4.1-spitfire-linux',
    hardwareRev: 'CC-01 Board Rev B',
    healthStatus: 'NORMAL',
    temperatureC: 42.1,
    runtimeHours: 148.5,
    lastCalibratedDate: '2026-09-01',
    specifications: {
      'SoC': 'Hexa-Core ARM Cortex-A78 + NPU',
      'Memory': '16 GB LPDDR5 ECC',
      'Storage': '256 GB NVMe SSD',
      'Telemetry Bus': 'Encrypted High-Speed CAN / Ethernet'
    }
  },
  {
    id: 'PASSPORT-VISION01',
    name: 'SPITFIRE VISION-01 Optical Payload',
    type: 'CAMERA',
    serialNumber: 'CAM-00418',
    firmwareVersion: 'v2.4.1-vision-fw',
    hardwareRev: 'VISION-01 CMOS Engine',
    healthStatus: 'NORMAL',
    temperatureC: 38.5,
    runtimeHours: 112.0,
    captureCount: 18421,
    lastCalibratedDate: '2026-09-18',
    specifications: {
      'Sensor': 'Large-Format CMOS 48 MP',
      'Lens': '24 mm Equivalent f/2.8 Prime',
      'Video Output': '4K @ 60 FPS RAW Stream',
      'Digital Zoom': '1x to 8x Lossless Pipeline',
      'Dynamic Range': '14.2 stops'
    }
  },
  {
    id: 'PASSPORT-GIMBAL01',
    name: 'SPITFIRE GIMBAL-01 3-Axis Stabiliser',
    type: 'GIMBAL',
    serialNumber: 'GMB-01-8812',
    firmwareVersion: 'v2.1.0-gimbal',
    hardwareRev: 'GIMBAL-01 Direct Drive',
    healthStatus: 'NORMAL',
    temperatureC: 31.0,
    runtimeHours: 112.0,
    lastCalibratedDate: '2026-09-18',
    specifications: {
      'Axis Count': '3-Axis Angular Drive',
      'Pitch Range': '-120° to +30°',
      'Control Precision': '±0.005°',
      'Max Angular Speed': '180°/s'
    }
  },
  {
    id: 'PASSPORT-BATTERY',
    name: 'SPITFIRE Power Cell 4S 8500mAh',
    type: 'BATTERY',
    serialNumber: 'BAT-4S-0891',
    firmwareVersion: 'BMS-v1.4',
    hardwareRev: 'BMS Smart Board',
    healthStatus: 'NORMAL',
    temperatureC: 34.2,
    runtimeHours: 42.0,
    lastCalibratedDate: '2026-09-10',
    specifications: {
      'Chemistry': 'High-Density LiPo 4S',
      'Nominal Voltage': '14.8 V (16.8 V Max)',
      'Capacity': '8500 mAh / 125.8 Wh',
      'Cycle Count': '24 Cycles'
    }
  }
];

export const MOCK_FINDINGS: InspectionFinding[] = [
  {
    id: 'FINDING-101',
    projectId: 'PROJ-BRIDGE-FORTH',
    flightId: 'FLIGHT-2026-004812',
    imageId: 'IMAGE-004182',
    locationName: 'Firth of Forth Rail Bridge - Pier 4 East',
    category: 'SURFACE_DEFECT',
    severity: 'MEDIUM',
    description: 'Minor coating spallation noted near lower gusset plate rivet cluster 4B. No active structural oxidation observed.',
    status: 'UNDER_REVIEW',
    coordPx: { x: 420, y: 310 },
    aiAssessment: 'Gemini Inspection Engine: Coating weathering detected. Corrosion risk: LOW. Recommended maintenance interval: 12 months.'
  },
  {
    id: 'FINDING-102',
    projectId: 'PROJ-ROOF-FARNBOROUGH',
    flightId: 'FLIGHT-2026-004811',
    imageId: 'IMAGE-004181',
    locationName: 'Farnborough Building 4 Solar Array',
    category: 'THERMAL',
    severity: 'LOW',
    description: 'Hot-spot thermal anomaly on PV String 3 Cell 14 (+4.2°C Delta over surrounding cells).',
    status: 'OPEN',
    coordPx: { x: 580, y: 240 },
    aiAssessment: 'Gemini Inspection Engine: Likely bypass diode micro-fault or local dust shading. Clean panel during routine window.'
  }
];

export const MOCK_R_ANALYSIS: RAnalysisResult = {
  flightId: 'FLIGHT-2026-004812',
  analyzedAt: '2026-09-26 14:30:00',
  trajectoryErrorM: 0.12,
  attitudeStabilityIndex: 98.6,
  energyEfficiencyWhKm: 12.3,
  sensorResiduals: {
    imuMPerSec2: 0.038,
    gnssMeters: 0.082,
    baroMeters: 0.11,
    magDegrees: 0.42
  },
  imageQualityStats: {
    avgSharpness: 96.5,
    avgExposure: 92.1,
    motionBlurRiskPct: 1.2,
    noiseFloorDb: 42.1
  },
  batteryDischargeCurve: [
    { socPct: 100, estMinutesRemaining: 28.0, powerWatts: 270.0 },
    { socPct: 90, estMinutesRemaining: 25.2, powerWatts: 272.0 },
    { socPct: 80, estMinutesRemaining: 22.1, powerWatts: 275.0 },
    { socPct: 72, estMinutesRemaining: 18.6, powerWatts: 280.4 },
    { socPct: 50, estMinutesRemaining: 13.0, powerWatts: 285.0 },
    { socPct: 30, estMinutesRemaining: 7.2, powerWatts: 292.0 },
    { socPct: 15, estMinutesRemaining: 3.1, powerWatts: 305.0 }
  ],
  anomaliesDetected: [],
  reportSummary: 'spitfireR Flight Test Engine: Telemetry nominal. Vehicle tracking error < 0.15m. Battery discharge profile aligns with 4S 8500mAh empirical baseline. Optical payload sharpness score 96.5/100.'
};
