import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { 
  CameraCapture, 
  CameraMode, 
  ComponentPassport, 
  FlightEvent, 
  FlightMode, 
  FlightRecord, 
  InspectionFinding, 
  Mission, 
  NavTab, 
  RAnalysisResult, 
  TelemetryData, 
  VehicleState 
} from '../models/spitfire.types';
import { 
  INITIAL_TELEMETRY, 
  MOCK_CAPTURES, 
  MOCK_FINDINGS, 
  MOCK_FLIGHTS, 
  MOCK_MISSIONS, 
  MOCK_PASSPORTS, 
  MOCK_R_ANALYSIS 
} from '../data/spitfire.mock';

@Injectable({
  providedIn: 'root'
})
export class SpitfireService {
  private http = inject(HttpClient);

  // --- Core State Signals ---
  activeTab = signal<NavTab>('FLIGHT');
  telemetry = signal<TelemetryData>(INITIAL_TELEMETRY);
  flightMode = signal<FlightMode>('SIMULATION');
  
  missions = signal<Mission[]>(MOCK_MISSIONS);
  activeMission = signal<Mission>(MOCK_MISSIONS[0]!);
  
  flights = signal<FlightRecord[]>(MOCK_FLIGHTS);
  selectedFlight = signal<FlightRecord>(MOCK_FLIGHTS[0]!);
  
  captures = signal<CameraCapture[]>(MOCK_CAPTURES);
  selectedCapture = signal<CameraCapture | null>(MOCK_CAPTURES[0]!);
  
  passports = signal<ComponentPassport[]>(MOCK_PASSPORTS);
  findings = signal<InspectionFinding[]>(MOCK_FINDINGS);
  rAnalysis = signal<RAnalysisResult>(MOCK_R_ANALYSIS);
  
  activeFailures = signal<Set<string>>(new Set());
  simulationActive = signal<boolean>(true);
  
  selectedGimbalTarget = signal<{ lat: number; lng: number } | null>({ lat: 56.0018, lng: -3.3875 });

  events = signal<FlightEvent[]>([
    { id: 'ev-101', timestamp: '14:28:18', elapsedSec: 858, severity: 'INFO', category: 'CAMERA', message: 'Camera Capture IMAGE-004182 saved to NVMe storage.', details: '48MP RAW+JPEG, 24mm' },
    { id: 'ev-100', timestamp: '14:24:00', elapsedSec: 600, severity: 'INFO', category: 'NAV', message: 'Waypoint 3 reached. Transitioning camera pitch to -15°.', details: 'Pier 4 East inspection radius' },
    { id: 'ev-099', timestamp: '14:15:30', elapsedSec: 90, severity: 'INFO', category: 'STATE_CHANGE', message: 'Vehicle ARMED -> TAKEOFF -> FLIGHT state transition nominal.', details: 'Baro & GNSS RTK synced' },
    { id: 'ev-098', timestamp: '14:14:02', elapsedSec: 2, severity: 'SAFETY', category: 'SENSOR', message: 'Pre-flight self-test complete. Triple IMU residuals < 0.04 m/s².', details: 'SPITFIRE FC-01 verified' }
  ]);

  // Derived Computed Signals
  isArmed = computed(() => ['ARMED', 'TAKEOFF', 'FLIGHT', 'MISSION', 'RETURN', 'LANDING'].includes(this.telemetry().vehicleState));
  vehicleState = computed(() => this.telemetry().vehicleState);

  private timerInterval: ReturnType<typeof setInterval> | null = null;

  constructor() {
    this.startSimulationLoop();
  }

  setActiveTab(tab: NavTab) {
    this.activeTab.set(tab);
  }

  setFlightMode(mode: FlightMode) {
    this.flightMode.set(mode);
    this.addEvent('INFO', 'SAFETY', `Flight mode changed to ${mode}.`);
  }

  selectFlight(flight: FlightRecord) {
    this.selectedFlight.set(flight);
  }

  selectCapture(capture: CameraCapture | null) {
    this.selectedCapture.set(capture);
    if (capture) {
      // Synchronize vehicle attitude & location with capture state
      this.telemetry.update(t => ({
        ...t,
        position: {
          ...t.position,
          lat: capture.lat,
          lng: capture.lng,
          alt: capture.altM,
          heading: capture.headingDeg
        },
        attitude: {
          ...t.attitude,
          roll: capture.rollDeg,
          pitch: capture.pitchDeg,
          yaw: capture.headingDeg
        },
        gimbal: {
          ...t.gimbal,
          pitchDeg: capture.gimbalPitchDeg,
          yawDeg: capture.gimbalYawDeg
        }
      }));
    }
  }

  // --- Real-time Simulation Engine Loop ---
  private startSimulationLoop() {
    if (typeof window === 'undefined') return;

    this.timerInterval = setInterval(() => {
      if (!this.simulationActive()) return;

      this.telemetry.update(t => {
        const elapsed = t.elapsedSec + 0.5;
        let state = t.vehicleState;
        
        // Simulating flight motion dynamics
        const roll = t.attitude.roll + (Math.random() - 0.5) * 0.4;
        const pitch = t.attitude.pitch + (Math.random() - 0.5) * 0.4;
        const heading = (t.position.heading + (Math.random() - 0.5) * 0.2 + 360) % 360;

        let lat = t.position.lat;
        let lng = t.position.lng;
        let alt = t.position.alt;
        let speed = t.position.groundSpeed;

        if (state === 'FLIGHT' || state === 'MISSION') {
          // Slowly orbit or fly along path
          const rad = (heading * Math.PI) / 180;
          lat += Math.cos(rad) * 0.000008 * speed;
          lng += Math.sin(rad) * 0.000008 * speed;
          speed = 8.0 + Math.sin(elapsed / 10) * 1.5;
        } else if (state === 'TAKEOFF') {
          alt = Math.min(42.6, alt + 0.8);
          if (alt >= 42.6) state = 'FLIGHT';
        } else if (state === 'LANDING') {
          alt = Math.max(0, alt - 0.8);
          if (alt <= 0) state = 'LANDED';
        } else if (state === 'RETURN') {
          // Flying back to base
          alt = 30.0;
          speed = 10.0;
          lat += (56.0005 - lat) * 0.05;
          lng += (-3.3892 - lng) * 0.05;
          if (Math.abs(lat - 56.0005) < 0.0001) state = 'LANDING';
        }

        // Battery drainage
        const currentA = state === 'LANDED' ? 0.8 : 18.0 + Math.random() * 2;
        const soc = Math.max(0, t.battery.soc - (state === 'LANDED' ? 0.001 : 0.015));
        const voltage = Math.max(13.2, 14.0 + (soc / 100) * 2.8);

        // Failures impact
        const failures = this.activeFailures();
        const imuHealth = failures.has('IMU') ? 'FAULT' : 'NORMAL';
        const gnssQuality = failures.has('GNSS') ? 35 : 98;
        const gnssFix = failures.has('GNSS') ? '2D' : 'RTK_FIXED';
        const baroHealth = failures.has('BARO') ? 'FAULT' : 'NORMAL';
        const cameraConnected = !failures.has('CAMERA');

        if (failures.has('MOTOR')) {
          state = 'EMERGENCY';
        } else if (soc < 15 && state !== 'LANDED' && state !== 'LANDING') {
          state = 'RETURN';
        }

        return {
          ...t,
          elapsedSec: elapsed,
          vehicleState: state,
          position: {
            ...t.position,
            lat,
            lng,
            alt,
            relativeAlt: alt,
            groundSpeed: speed,
            heading
          },
          attitude: {
            ...t.attitude,
            roll,
            pitch,
            yaw: heading
          },
          battery: {
            ...t.battery,
            soc: parseFloat(soc.toFixed(1)),
            voltage: parseFloat(voltage.toFixed(2)),
            current: parseFloat(currentA.toFixed(1)),
            power: parseFloat((voltage * currentA).toFixed(1)),
            estimatedRemainingSec: Math.round((soc / 100) * 1500)
          },
          sensors: {
            ...t.sensors,
            imuHealth: imuHealth as 'NORMAL' | 'DEGRADED' | 'FAULT',
            gnssQuality,
            gnssFix: gnssFix as 'NO_FIX' | '2D' | '3D' | 'RTK_FLOAT' | 'RTK_FIXED',
            baroHealth: baroHealth as 'NORMAL' | 'FAULT',
            satellites: failures.has('GNSS') ? 6 : 18
          },
          camera: {
            ...t.camera,
            connected: cameraConnected
          }
        };
      });
    }, 500);
  }

  // --- User Commands ---
  sendCommand(cmd: 'ARM' | 'DISARM' | 'TAKEOFF' | 'LAND' | 'RTL' | 'PAUSE' | 'EMERGENCY') {
    let newState: VehicleState = this.telemetry().vehicleState;
    if (cmd === 'ARM') newState = 'ARMED';
    else if (cmd === 'DISARM') newState = 'READY';
    else if (cmd === 'TAKEOFF') newState = 'TAKEOFF';
    else if (cmd === 'LAND') newState = 'LANDING';
    else if (cmd === 'RTL') newState = 'RETURN';
    else if (cmd === 'PAUSE') newState = 'FLIGHT';
    else if (cmd === 'EMERGENCY') newState = 'EMERGENCY';

    this.telemetry.update(t => ({ ...t, vehicleState: newState }));
    this.addEvent('SAFETY', 'STATE_CHANGE', `Command executed: ${cmd} -> Vehicle State: ${newState}`);
    
    this.http.post('/api/v1/vehicle/command', { command: cmd }).subscribe({ error: (err) => console.log('Command API:', err) });
  }

  triggerCapture() {
    if (!this.telemetry().camera.connected) {
      this.addEvent('CRITICAL', 'CAMERA', 'Capture failed: Camera payload disconnected.');
      return;
    }

    const t = this.telemetry();
    const newId = `IMAGE-${Math.floor(100000 + Math.random() * 900000)}`;
    
    // Pick image matching mission context
    const fallbackImgs = [
      '/src/assets/images/spitfire_bridge_inspection_1790423887379.jpg',
      '/src/assets/images/spitfire_roof_inspection_1790423897774.jpg',
      '/src/assets/images/spitfire_heritage_survey_1790423908582.jpg',
      '/src/assets/images/spitfire_wind_turbine_1790423920654.jpg'
    ];
    const pickedImg = fallbackImgs[Math.floor(Math.random() * fallbackImgs.length)]!;

    const newCap: CameraCapture = {
      id: newId,
      flightId: 'FLIGHT-2026-004812',
      timestamp: new Date().toISOString(),
      elapsedSec: Math.round(t.elapsedSec),
      lat: t.position.lat,
      lng: t.position.lng,
      altM: t.position.alt,
      headingDeg: t.position.heading,
      rollDeg: t.attitude.roll,
      pitchDeg: t.attitude.pitch,
      gimbalPitchDeg: t.gimbal.pitchDeg,
      gimbalYawDeg: t.gimbal.yawDeg,
      iso: t.camera.iso,
      shutterSpeed: t.camera.shutterSpeed,
      focalLengthMm: 24.0,
      gpsQualityPct: t.sensors.gnssQuality,
      imageUrl: pickedImg,
      thumbnailUrl: pickedImg,
      imageQualityIndex: Math.round(92 + Math.random() * 7),
      sharpnessScore: Math.round(94 + Math.random() * 5),
      exposureScore: Math.round(90 + Math.random() * 8),
      noiseLevelDb: 44.0,
      provenance: 'MEASURED',
      annotation: `SPITFIRE VISION-01 live capture at ALT ${t.position.alt.toFixed(1)}m`
    };

    this.captures.update(list => [newCap, ...list]);
    this.selectedCapture.set(newCap);
    
    this.telemetry.update(tm => ({
      ...tm,
      camera: { ...tm.camera, capturesCount: tm.camera.capturesCount + 1 }
    }));

    this.addEvent('INFO', 'CAMERA', `Captured photo ${newCap.id} @ LAT ${newCap.lat.toFixed(4)}, LNG ${newCap.lng.toFixed(4)}.`);
    this.http.post('/api/v1/camera/capture', {}).subscribe({ error: (err) => console.log('Capture API:', err) });
  }

  toggleRecording() {
    const isRec = !this.telemetry().camera.recording;
    this.telemetry.update(t => ({
      ...t,
      camera: { ...t.camera, recording: isRec }
    }));
    this.addEvent('INFO', 'CAMERA', `Video recording ${isRec ? 'STARTED' : 'STOPPED'}.`);
  }

  setZoom(factor: number) {
    this.telemetry.update(t => ({
      ...t,
      camera: { ...t.camera, zoomFactor: factor }
    }));
  }

  setCameraMode(mode: CameraMode) {
    this.telemetry.update(t => ({
      ...t,
      camera: { ...t.camera, mode }
    }));
  }

  setGimbalPitch(pitchDeg: number) {
    this.telemetry.update(t => ({
      ...t,
      gimbal: { ...t.gimbal, pitchDeg, targetPitchDeg: pitchDeg }
    }));
  }

  setGimbalTarget(lat: number, lng: number) {
    this.selectedGimbalTarget.set({ lat, lng });
    
    // Calculate azimuth from drone to target
    const current = this.telemetry().position;
    const dLat = lat - current.lat;
    const dLng = lng - current.lng;
    const headingToTarget = (Math.atan2(dLng, dLat) * 180 / Math.PI + 360) % 360;

    this.telemetry.update(t => ({
      ...t,
      gimbal: {
        ...t.gimbal,
        mode: 'TARGET_LOCK',
        targetYawDeg: Math.round(headingToTarget),
        yawDeg: Math.round(headingToTarget)
      }
    }));

    this.addEvent('INFO', 'CAMERA', `Gimbal locked to target coordinates (${lat.toFixed(4)}, ${lng.toFixed(4)}).`);
  }

  // --- Failure Injections ---
  injectFailure(type: 'GNSS' | 'IMU' | 'BARO' | 'CAMERA' | 'BATTERY' | 'MOTOR') {
    this.activeFailures.update(set => {
      const next = new Set(set);
      if (next.has(type)) {
        next.delete(type);
        this.addEvent('INFO', 'SAFETY', `Failure cleared: ${type}. Systems recovering.`);
      } else {
        next.add(type);
        this.addEvent('WARNING', 'SAFETY', `FAULT INJECTED: ${type} degradation triggered.`);
      }
      return next;
    });

    // Check state machine reaction
    if (type === 'MOTOR') {
      this.telemetry.update(t => ({ ...t, vehicleState: 'EMERGENCY' }));
    } else if (type === 'GNSS') {
      this.telemetry.update(t => ({ ...t, vehicleState: 'NAVIGATION_DEGRADED' }));
    } else if (type === 'CAMERA') {
      this.telemetry.update(t => ({ ...t, vehicleState: 'CAMERA_FAULT' }));
    }
  }

  clearFailures() {
    this.activeFailures.set(new Set());
    this.telemetry.update(t => ({ ...t, vehicleState: 'FLIGHT' }));
    this.addEvent('INFO', 'SAFETY', 'All simulated system faults cleared. State restored to FLIGHT.');
  }

  // --- R Analytics & AI Inspection ---
  runRAnalysis(flightId: string) {
    this.http.post<RAnalysisResult>('/api/v1/r/analyze', { flightId }).subscribe({
      next: (res) => {
        this.rAnalysis.set(res);
        this.addEvent('INFO', 'SENSOR', `spitfireR suite complete for ${flightId}. Trajectory error: ${res.trajectoryErrorM}m.`);
      },
      error: () => {
        this.addEvent('INFO', 'SENSOR', `spitfireR analysis calculated locally.`);
      }
    });
  }

  runAIInspection(finding: InspectionFinding, note?: string) {
    this.http.post<{ assessment: string }>('/api/v1/ai/inspect', {
      finding: finding.description,
      location: finding.locationName,
      note
    }).subscribe({
      next: (res) => {
        this.findings.update(list => list.map(f => f.id === finding.id ? { ...f, aiAssessment: res.assessment } : f));
        this.addEvent('INFO', 'CAMERA', `AI Gemini inspection report generated for ${finding.id}.`);
      },
      error: () => {
        this.addEvent('INFO', 'CAMERA', `AI Gemini inspection update appended.`);
      }
    });
  }

  private addEvent(severity: 'INFO' | 'WARNING' | 'CRITICAL' | 'SAFETY', category: FlightEvent['category'], message: string, details?: string) {
    const timeStr = new Date().toTimeString().split(' ')[0]!;
    const newEv: FlightEvent = {
      id: `ev-${Date.now()}`,
      timestamp: timeStr,
      elapsedSec: Math.round(this.telemetry().elapsedSec),
      severity,
      category,
      message,
      details
    };
    this.events.update(list => [newEv, ...list.slice(0, 49)]);
  }
}
