import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { GoogleGenAI } from '@google/genai';
import { 
  INITIAL_TELEMETRY, 
  MOCK_CAPTURES, 
  MOCK_FLIGHTS, 
  MOCK_MISSIONS, 
  MOCK_R_ANALYSIS 
} from './app/data/spitfire.mock.js';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// In-memory runtime state for simulation
const activeTelemetry = { ...INITIAL_TELEMETRY };
const activeCaptures = [...MOCK_CAPTURES];
const activeFlights = [...MOCK_FLIGHTS];
const activeMissions = [...MOCK_MISSIONS];

// Helper Gemini instance
const apiKey = process.env['GEMINI_API_KEY'] || '';
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

// ==========================================
// 1. VEHICLE API
// ==========================================
app.get('/api/v1/vehicle', (req, res) => {
  res.json({
    model: 'SPITFIRE S1',
    serial: 'SPF-S1-00418',
    flightController: 'FC-01',
    companionComputer: 'CC-01',
    firmware: 'v2.4.1-spitfire-rust',
    state: activeTelemetry.vehicleState,
    flightMode: activeTelemetry.flightMode,
    safetyMode: 'SIMULATION'
  });
});

app.get('/api/v1/vehicle/state', (req, res) => {
  res.json({
    vehicleState: activeTelemetry.vehicleState,
    flightMode: activeTelemetry.flightMode,
    armed: ['ARMED', 'TAKEOFF', 'FLIGHT', 'MISSION', 'RETURN', 'LANDING'].includes(activeTelemetry.vehicleState),
    uptimeSec: activeTelemetry.elapsedSec
  });
});

app.get('/api/v1/vehicle/telemetry', (req, res) => {
  activeTelemetry.timestamp = new Date().toISOString();
  res.json(activeTelemetry);
});

app.get('/api/v1/vehicle/health', (req, res) => {
  res.json({
    airframe: 'NORMAL',
    motors: activeTelemetry.motors.map(m => ({ id: m.id, health: m.health, temp: m.temperature })),
    battery: activeTelemetry.battery.soc > 20 ? 'NORMAL' : 'DEGRADED',
    sensors: activeTelemetry.sensors,
    camera: activeTelemetry.camera.connected ? 'NORMAL' : 'FAULT',
    gimbal: activeTelemetry.gimbal.stabilizationActive ? 'NORMAL' : 'DEGRADED',
    overallHealth: 'NOMINAL'
  });
});

app.get('/api/v1/battery', (req, res) => {
  res.json(activeTelemetry.battery);
});

app.get('/api/v1/motors', (req, res) => {
  res.json(activeTelemetry.motors);
});

app.get('/api/v1/sensors', (req, res) => {
  res.json(activeTelemetry.sensors);
});

// Command state transitions
app.post('/api/v1/vehicle/command', (req, res) => {
  const { command } = req.body;
  if (command === 'ARM') activeTelemetry.vehicleState = 'ARMED';
  else if (command === 'DISARM') activeTelemetry.vehicleState = 'READY';
  else if (command === 'TAKEOFF') activeTelemetry.vehicleState = 'TAKEOFF';
  else if (command === 'LAND') activeTelemetry.vehicleState = 'LANDING';
  else if (command === 'RTL') activeTelemetry.vehicleState = 'RETURN';
  else if (command === 'EMERGENCY') activeTelemetry.vehicleState = 'EMERGENCY';

  res.json({ success: true, newState: activeTelemetry.vehicleState });
});

// ==========================================
// 2. CAMERA & GIMBAL API
// ==========================================
app.get('/api/v1/camera', (req, res) => {
  res.json(activeTelemetry.camera);
});

app.get('/api/v1/camera/status', (req, res) => {
  res.json({
    status: activeTelemetry.camera.connected ? 'ACTIVE' : 'DISCONNECTED',
    recording: activeTelemetry.camera.recording,
    capturesCount: activeTelemetry.camera.capturesCount,
    mode: activeTelemetry.camera.mode,
    zoom: activeTelemetry.camera.zoomFactor
  });
});

app.post('/api/v1/camera/capture', (req, res) => {
  const newId = `IMAGE-${Math.floor(100000 + Math.random() * 900000)}`;
  const newCapture = {
    id: newId,
    flightId: 'FLIGHT-2026-004812',
    timestamp: new Date().toISOString(),
    elapsedSec: activeTelemetry.elapsedSec,
    lat: activeTelemetry.position.lat,
    lng: activeTelemetry.position.lng,
    altM: activeTelemetry.position.alt,
    headingDeg: activeTelemetry.position.heading,
    rollDeg: activeTelemetry.attitude.roll,
    pitchDeg: activeTelemetry.attitude.pitch,
    gimbalPitchDeg: activeTelemetry.gimbal.pitchDeg,
    gimbalYawDeg: activeTelemetry.gimbal.yawDeg,
    iso: activeTelemetry.camera.iso,
    shutterSpeed: activeTelemetry.camera.shutterSpeed,
    focalLengthMm: 24.0,
    gpsQualityPct: activeTelemetry.sensors.gnssQuality,
    imageUrl: activeCaptures[0]?.imageUrl || '/src/assets/images/spitfire_bridge_inspection_1790423887379.jpg',
    thumbnailUrl: activeCaptures[0]?.thumbnailUrl || '/src/assets/images/spitfire_bridge_inspection_1790423887379.jpg',
    imageQualityIndex: Math.round(90 + Math.random() * 9),
    sharpnessScore: Math.round(92 + Math.random() * 7),
    exposureScore: Math.round(90 + Math.random() * 8),
    noiseLevelDb: 44.5,
    provenance: 'MEASURED' as const,
    annotation: `Synthetic capture acquired at ALT ${activeTelemetry.position.alt.toFixed(1)}m, HDG ${activeTelemetry.position.heading}°`
  };

  activeCaptures.unshift(newCapture);
  activeTelemetry.camera.capturesCount += 1;

  res.json({ success: true, capture: newCapture });
});

app.post('/api/v1/camera/video/start', (req, res) => {
  activeTelemetry.camera.recording = true;
  res.json({ success: true, recording: true });
});

app.post('/api/v1/camera/video/stop', (req, res) => {
  activeTelemetry.camera.recording = false;
  res.json({ success: true, recording: false });
});

app.post('/api/v1/camera/zoom', (req, res) => {
  const { zoom } = req.body;
  if (typeof zoom === 'number') {
    activeTelemetry.camera.zoomFactor = Math.min(8.0, Math.max(1.0, zoom));
  }
  res.json({ success: true, zoom: activeTelemetry.camera.zoomFactor });
});

app.get('/api/v1/camera/images', (req, res) => {
  res.json(activeCaptures);
});

app.get('/api/v1/camera/images/:id', (req, res) => {
  const img = activeCaptures.find(c => c.id === req.params.id);
  if (img) res.json(img);
  else res.status(404).json({ error: 'Image not found' });
});

// ==========================================
// 3. MISSION API
// ==========================================
app.get('/api/v1/missions', (req, res) => {
  res.json(activeMissions);
});

app.get('/api/v1/missions/:id', (req, res) => {
  const m = activeMissions.find(x => x.id === req.params.id);
  if (m) res.json(m);
  else res.status(404).json({ error: 'Mission not found' });
});

app.post('/api/v1/missions', (req, res) => {
  const newMission = {
    id: `MISSION-2026-${Math.floor(100 + Math.random() * 900)}`,
    createdDate: new Date().toISOString().split('T')[0]!,
    ...req.body
  };
  activeMissions.unshift(newMission);
  res.json(newMission);
});

// ==========================================
// 4. FLIGHT DATA & R ANALYTICS API
// ==========================================
app.get('/api/v1/flights', (req, res) => {
  res.json(activeFlights);
});

app.get('/api/v1/flights/:id', (req, res) => {
  const f = activeFlights.find(x => x.id === req.params.id);
  if (f) res.json(f);
  else res.status(404).json({ error: 'Flight record not found' });
});

app.post('/api/v1/r/analyze', (req, res) => {
  // Simulates spitfireR R package analysis on flight telemetry
  const { flightId } = req.body;
  res.json({
    ...MOCK_R_ANALYSIS,
    flightId: flightId || 'FLIGHT-2026-004812',
    analyzedAt: new Date().toISOString()
  });
});

app.post('/api/v1/r/calibrate', (req, res) => {
  // Simulates camera & sensor R calibration module
  res.json({
    calibrationId: 'CAL-2026-v3',
    focalLengthMm: 24.08,
    principalPointPx: { x: 1920.4, y: 1080.1 },
    radialDistortionK1: -0.0142,
    radialDistortionK2: 0.0031,
    reprojectionErrorPx: 0.28,
    status: 'VALIDATED'
  });
});

// ==========================================
// 5. AI GEMINI INSPECTION ANALYSIS
// ==========================================
app.post('/api/v1/ai/inspect', async (req, res) => {
  const { finding, location, note } = req.body;
  if (!ai) {
    res.json({
      assessment: `[SPITFIRE AI ENGINE SIMULATED]: Visual analysis for ${location || 'target site'} confirms structural coating integrity. Residual risk score 0.04. Recommended re-inspection in 12 months.`
    });
    return;
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `You are the lead British Aerospace engineer for the SPITFIRE drone platform. Analyze this aerial inspection observation:
Location: ${location || 'Firth of Forth Rail Bridge'}
Finding details: ${finding || 'Surface oxidation near rivet cluster'}
Inspector notes: ${note || 'Visual check'}
Provide a concise 3-bullet technical engineering assessment focusing on structural integrity, corrosion risk, and recommended action.`
    });

    res.json({ assessment: response.text });
  } catch (err) {
    console.error('Gemini API Error:', err);
    res.json({
      assessment: `[SPITFIRE AI ENGINE]: Structural coating nominal. Residual corrosion risk low. Re-inspect at 12-month interval.`
    });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
