'use client';

import React, { useState } from 'react';
import { AeroProvider, useAero } from '@/lib/AeroContext';
import Header from '@/components/layout/Header';
import Sidebar from '@/components/layout/Sidebar';
import AeroAiDrawer from '@/components/layout/AeroAiDrawer';

import CommandCentre from '@/components/modules/CommandCentre';
import FleetManagement from '@/components/modules/FleetManagement';
import AirlineCounterpartyView from '@/components/modules/AirlineCounterparty';
import LeaseManagement from '@/components/modules/LeaseManagement';
import LeaseCashflowEngine from '@/components/modules/LeaseCashflowEngine';
import DeliveryControlCentre from '@/components/modules/DeliveryControlCentre';
import TechnicalAssets from '@/components/modules/TechnicalAssets';
import TradingDesk from '@/components/modules/TradingDesk';
import TreasuryDesk from '@/components/modules/TreasuryDesk';
import ValuationLab from '@/components/modules/ValuationLab';
import CreditRiskEngine from '@/components/modules/CreditRiskEngine';
import Portfolio2030Flagship from '@/components/modules/Portfolio2030Flagship';
import DocumentsAndApprovals from '@/components/modules/DocumentsAndApprovals';
import FinanceLedger from '@/components/modules/FinanceLedger';
import LegalEntities from '@/components/modules/LegalEntities';
import InvestorAnalytics from '@/components/modules/InvestorAnalytics';

function MainAppContent() {
  const { activeModule } = useAero();
  const [deviceMode, setDeviceMode] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');

  const renderModuleView = () => {
    switch (activeModule) {
      case 'command-centre':
        return <CommandCentre />;
      case 'fleet':
        return <FleetManagement />;
      case 'airlines':
        return <AirlineCounterpartyView />;
      case 'leases':
        return <LeaseManagement />;
      case 'portfolio-2030':
        return <Portfolio2030Flagship />;
      case 'trading':
        return <TradingDesk />;
      case 'deliveries':
        return <DeliveryControlCentre />;
      case 'technical-assets':
        return <TechnicalAssets />;
      case 'treasury':
        return <TreasuryDesk />;
      case 'valuations':
        return <ValuationLab />;
      case 'credit-risk':
        return <CreditRiskEngine />;
      case 'approvals':
        return <DocumentsAndApprovals />;
      case 'ledger':
        return <FinanceLedger />;
      case 'entities':
        return <LegalEntities />;
      case 'analytics':
        return <InvestorAnalytics />;
      default:
        return <CommandCentre />;
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#070e1b] text-slate-100 selection:bg-blue-600 selection:text-white">
      {/* Executive Header */}
      <Header deviceMode={deviceMode} setDeviceMode={setDeviceMode} />

      {/* Main Workspace Frame with Device View Simulation option */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <Sidebar />

        {/* Main Content Area */}
        <main className={`flex-1 overflow-y-auto p-4 sm:p-6 transition-all ${
          deviceMode === 'tablet'
            ? 'max-w-4xl mx-auto border-x border-[#1d3557] bg-[#070e1b] shadow-2xl my-2 rounded-xl'
            : deviceMode === 'mobile'
              ? 'max-w-md mx-auto border-x border-[#1d3557] bg-[#070e1b] shadow-2xl my-2 rounded-xl'
              : ''
        }`}>
          {renderModuleView()}
        </main>
      </div>

      {/* Grounded Aero Intelligence AI Assistant Drawer */}
      <AeroAiDrawer />
    </div>
  );
}

export default function Page() {
  return (
    <AeroProvider>
      <MainAppContent />
    </AeroProvider>
  );
}
