import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "",
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

export async function POST(req: NextRequest) {
  try {
    const { prompt, portfolioContext } = await req.json();

    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required" }, { status: 400 });
    }

    const systemInstruction = `You are Aero Intelligence, the authoritative executive AI assistant for AVOLON AERO OS, a commercial aircraft leasing and aviation finance operating platform.
You assist senior executive aircraft leasing managers, relationship managers, credit analysts, and treasurers.

Rules for your responses:
1. Always base your answers on actual, grounded facts provided in the current portfolio state.
2. Clearly distinguish between RECORDED FACT, CALCULATED VALUE, FORECAST, and SCENARIO ASSUMPTION.
3. Keep answers concise, highly professional, analytical, and structured with clear key bullet points.
4. Reference aircraft registrations (e.g., EI-GLN, 9V-SMA), MSN numbers, lease IDs, or airline names when discussing specific assets.
5. Do not invent arbitrary prices, ratings, or lease rates. Use the domain metrics provided.

Current Portfolio Grounding Context:
${JSON.stringify(portfolioContext || {}, null, 2)}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.2, // Low temperature for high precision finance responses
      },
    });

    return NextResponse.json({
      text: response.text || "No response generated.",
      timestamp: new Date().toISOString()
    });

  } catch (error: any) {
    console.error("Gemini API Error:", error);
    return NextResponse.json(
      { error: "Failed to generate Aero Intelligence analysis.", details: error.message },
      { status: 500 }
    );
  }
}
