import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Avolon Aero OS | Enterprise Aviation Finance & Asset Management Platform',
  description: 'Unified operating platform for commercial aircraft leasing, aviation finance, fleet analytics, cash flow modeling, risk management, and asset trading.',
  openGraph: {
    title: 'Avolon Aero OS | Enterprise Aviation Finance',
    description: 'Unified operating platform for commercial aircraft leasing and asset management.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Avolon Aero OS',
    description: 'Unified operating platform for commercial aircraft leasing and asset management.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-[#070e1b] text-slate-100 antialiased min-h-screen selection:bg-blue-600 selection:text-white" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
