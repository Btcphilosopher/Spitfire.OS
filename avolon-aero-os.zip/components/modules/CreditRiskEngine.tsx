'use client';

import React from 'react';
import { useAero } from '@/lib/AeroContext';
import { ShieldAlert, AlertTriangle, ShieldCheck, Building2, Globe } from 'lucide-react';

export default function CreditRiskEngine() {
  const { airlines } = useAero();

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-xl bg-[#0a172c] border border-[#1d3557]">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-amber-400" />
            Airline Credit & Counterparty Stress Lab
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Credit limits · Financial leverage · Debt Service Coverage (DSCR) · Concentration limits
          </p>
        </div>

        <div className="text-xs font-mono text-amber-400 bg-[#070e1b] px-3 py-1.5 rounded-lg border border-[#1d3557]">
          2 AIRLINES ON CREDIT WATCHLIST
        </div>
      </div>

      {/* Credit Risk Table */}
      <div className="bg-[#0a172c] border border-[#1d3557] rounded-xl overflow-hidden shadow-sm">
        <div className="p-3 border-b border-[#1d3557] bg-[#070e1b] flex items-center justify-between text-xs font-mono text-slate-400">
          <span>AIRLINE COUNTERPARTY EXPOSURE & CREDIT METRICS</span>
          <span>S&P / FITCH / INTERNAL RATING</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b border-[#1d3557] bg-[#070e1b]/60 text-slate-400 uppercase text-[10px]">
                <th className="p-3">AIRLINE / REGION</th>
                <th className="p-3">CREDIT RATING</th>
                <th className="p-3 text-right">EXPOSURE</th>
                <th className="p-3 text-right">CREDIT LIMIT</th>
                <th className="p-3 text-right">LEVERAGE</th>
                <th className="p-3 text-right">DSCR</th>
                <th className="p-3 text-center">COVENANT STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1d3557]/40">
              {airlines.map((a) => (
                <tr key={a.id} className="hover:bg-[#10223e] text-slate-200">
                  <td className="p-3">
                    <div className="font-bold text-white font-sans">{a.name}</div>
                    <div className="text-[10px] text-slate-400">{a.country} ({a.region})</div>
                  </td>
                  <td className="p-3 text-blue-400 font-bold">{a.creditRating} (Int. {a.internalCreditRating})</td>
                  <td className="p-3 text-right text-emerald-400 font-bold">${a.outstandingExposure}M</td>
                  <td className="p-3 text-right text-slate-300">${a.creditLimit}M</td>
                  <td className="p-3 text-right text-slate-200">{a.financials.leverageRatio}x</td>
                  <td className="p-3 text-right text-white font-bold">{a.financials.dscr}x</td>
                  <td className="p-3 text-center">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                      a.covenantStatus === 'COMPLIANT'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : 'bg-amber-950 text-amber-400 border border-amber-800'
                    }`}>
                      {a.covenantStatus}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
