'use client';

import React, { useState } from 'react';
import { useAero } from '@/lib/AeroContext';
import { Truck, Calendar, AlertTriangle, CheckCircle2, Clock, ShieldCheck, Edit2 } from 'lucide-react';

export default function DeliveryControlCentre() {
  const { deliveries, updateDeliveryDate } = useAero();
  const [selectedDeliveryId, setSelectedDeliveryId] = useState<string>(deliveries[0]?.id || 'DEL-2027-01');
  const [editingDate, setEditingDate] = useState<string>('');

  const delivery = deliveries.find((d) => d.id === selectedDeliveryId) || deliveries[0];

  const handleSaveDateDrift = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingDate && delivery) {
      updateDeliveryDate(delivery.id, editingDate);
      setEditingDate('');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-xl bg-[#0a172c] border border-[#1d3557]">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Truck className="w-5 h-5 text-blue-400" />
            Aircraft Delivery Control Centre
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Manufacturer slot pipeline · Pre-Delivery Payments (PDP) · Technical acceptance checklists · Delivery date drift propagation
          </p>
        </div>

        <div className="text-xs font-mono text-blue-400 bg-[#070e1b] px-3 py-1.5 rounded-lg border border-[#1d3557]">
          {deliveries.length} COMMITTED SLOTS IN PIPELINE
        </div>
      </div>

      {/* Main Grid: Delivery Pipeline Cards & Active Delivery Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 cols): Delivery Slot Cards */}
        <div className="lg:col-span-2 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {deliveries.map((item) => {
              const isSelected = delivery.id === item.id;

              return (
                <div
                  key={item.id}
                  onClick={() => setSelectedDeliveryId(item.id)}
                  className={`bg-[#0a172c] border rounded-xl p-5 cursor-pointer transition-all space-y-3 ${
                    isSelected
                      ? 'border-blue-500 bg-blue-900/20 shadow-md'
                      : 'border-[#1d3557] hover:border-slate-500'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-base font-bold text-white">{item.aircraftFamily}</div>
                      <div className="text-xs font-mono text-slate-400">MSN {item.msn} · {item.manufacturer}</div>
                    </div>

                    <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
                      item.deliveryStatus === 'ON_SCHEDULE'
                        ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                        : 'bg-amber-950 text-amber-400 border-amber-800'
                    }`}>
                      {item.deliveryStatus}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 py-2 border-y border-[#1d3557]/60 text-xs font-mono">
                    <div>
                      <div className="text-[10px] text-slate-500">CUSTOMER AIRLINE</div>
                      <div className="text-slate-200 font-bold">{item.customerAirline}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-500">PDP PAID</div>
                      <div className="text-emerald-400 font-bold">${item.preDeliveryPaymentsMillion}M</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-500">PLANNED DATE</div>
                      <div className="text-slate-300">{item.plannedDeliveryDate}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-500">FORECAST DATE</div>
                      <div className="text-amber-400 font-bold">{item.forecastDeliveryDate}</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400">Acceptance Score:</span>
                    <span className="text-blue-400 font-bold">{item.technicalAcceptanceScore} / 100</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column (1 col): Selected Delivery Inspector & Checklist */}
        <div className="bg-[#0a172c] border border-[#1d3557] rounded-xl p-5 space-y-5">
          {delivery && (
            <>
              <div className="border-b border-[#1d3557] pb-3 space-y-1">
                <div className="flex items-center justify-between">
                  <h2 className="text-base font-bold text-white">{delivery.aircraftFamily}</h2>
                  <span className="text-xs font-mono text-slate-400">MSN {delivery.msn}</span>
                </div>
                <div className="text-xs text-slate-400 font-mono">Airline: <span className="text-white">{delivery.customerAirline}</span></div>
              </div>

              {/* Delivery Schedule & Drift Control */}
              <div className="space-y-2 bg-[#070e1b] p-3 rounded-lg border border-[#1d3557] text-xs font-mono">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Contract Window:</span>
                  <span className="text-slate-200 font-bold">{delivery.contractualDeliveryWindow}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Forecast Delivery:</span>
                  <span className="text-amber-400 font-bold">{delivery.forecastDeliveryDate}</span>
                </div>

                {!editingDate ? (
                  <button
                    onClick={() => setEditingDate(delivery.forecastDeliveryDate)}
                    className="w-full mt-2 py-1.5 rounded bg-blue-600/20 hover:bg-blue-600/40 border border-blue-500/40 text-blue-300 text-xs flex items-center justify-center gap-1 transition-colors"
                  >
                    <Edit2 className="w-3 h-3" />
                    <span>Update Delivery Date Drift</span>
                  </button>
                ) : (
                  <form onSubmit={handleSaveDateDrift} className="mt-2 space-y-2">
                    <input
                      type="date"
                      value={editingDate}
                      onChange={(e) => setEditingDate(e.target.value)}
                      className="w-full bg-[#0a172c] border border-[#1d3557] rounded p-1.5 text-white"
                      required
                    />
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setEditingDate('')}
                        className="w-1/2 py-1 bg-slate-800 text-slate-300 rounded"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="w-1/2 py-1 bg-blue-600 text-white rounded font-bold"
                      >
                        Save
                      </button>
                    </div>
                  </form>
                )}
              </div>

              {/* Delivery Acceptance Checklist */}
              <div className="space-y-2">
                <h3 className="text-xs font-bold text-slate-400 uppercase font-mono">Acceptance Checklist</h3>
                <div className="space-y-2 text-xs font-mono">
                  {delivery.checklists.map((c, idx) => (
                    <div key={idx} className="p-2.5 rounded bg-[#070e1b] border border-[#1d3557] space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-200 font-semibold">{c.item}</span>
                        {c.completed ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        ) : (
                          <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                        )}
                      </div>
                      <div className="text-[10px] text-slate-500">Owner: {c.owner}</div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
