'use client';

import React from 'react';
import { useAero } from '@/lib/AeroContext';
import { Wrench, CheckCircle2, AlertTriangle, Clock, ShieldCheck, FileCheck } from 'lucide-react';

export default function TechnicalAssets() {
  const { aircraft } = useAero();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-xl bg-[#0a172c] border border-[#1d3557]">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Wrench className="w-5 h-5 text-blue-400" />
            Technical Asset Records & Airworthiness Tracking
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Flight Hours (FH) & Cycles (FC) · Engine shop visits · Airworthiness Directives (AD) · Maintenance reserves
          </p>
        </div>

        <div className="text-xs font-mono text-emerald-400 bg-[#070e1b] px-3 py-1.5 rounded-lg border border-[#1d3557]">
          ALL ACTIVE AIRCRAFT AIRWORTHY & CERTIFIED
        </div>
      </div>

      {/* Technical Records Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Technical Hangar Inspection Media Card */}
        <div className="relative rounded-xl overflow-hidden border border-[#1d3557] min-h-[260px] flex flex-col justify-end p-6">
          <img
            src="/src/assets/images/hangar_engine_maintenance_1792913311308.jpg"
            alt="Technical Hangar Overhaul"
            className="absolute inset-0 w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#070e1b] via-[#070e1b]/60 to-transparent" />

          <div className="relative space-y-2">
            <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
              PHYSICAL INSPECTION ACTIVE
            </span>
            <h2 className="text-lg font-bold text-white">Engine Overhaul & Heavy Check Monitoring</h2>
            <p className="text-xs text-slate-300">
              Tracking engine shop visits, CFM LEAP-1A / Pratt & Whitney PW1100G maintenance LLP cycles, and regulatory airworthiness compliance.
            </p>
          </div>
        </div>

        {/* Technical Asset Master List */}
        <div className="lg:col-span-2 bg-[#0a172c] border border-[#1d3557] rounded-xl overflow-hidden shadow-sm">
          <div className="p-3 border-b border-[#1d3557] bg-[#070e1b] flex items-center justify-between text-xs font-mono text-slate-400">
            <span>AIRCRAFT TECHNICAL STATUS REGISTER</span>
            <span>8 ACTIVE ASSETS</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-mono">
              <thead>
                <tr className="border-b border-[#1d3557] bg-[#070e1b]/60 text-slate-400 uppercase text-[10px]">
                  <th className="p-3">AIRCRAFT / REG</th>
                  <th className="p-3 text-right">FLIGHT HOURS (FH)</th>
                  <th className="p-3 text-right">CYCLES (FC)</th>
                  <th className="p-3">ENGINE MODEL</th>
                  <th className="p-3 text-right">MAINT. RESERVE</th>
                  <th className="p-3 text-center">AIRWORTHINESS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1d3557]/40">
                {aircraft.map((a) => (
                  <tr key={a.id} className="hover:bg-[#10223e] text-slate-200">
                    <td className="p-3">
                      <div className="font-bold text-white">{a.registration}</div>
                      <div className="text-[10px] text-slate-400 font-sans">{a.family} (MSN {a.msn})</div>
                    </td>
                    <td className="p-3 text-right text-slate-200">{a.airframeHours.toLocaleString()} hrs</td>
                    <td className="p-3 text-right text-slate-200">{a.airframeCycles.toLocaleString()} cyc</td>
                    <td className="p-3 font-sans text-slate-300">{a.engineManufacturer} {a.engineModel}</td>
                    <td className="p-3 text-right text-emerald-400 font-bold">${a.maintenanceReserveBalance}k</td>
                    <td className="p-3 text-center">
                      <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                        a.technicalStatus === 'AIRWORTHY'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-amber-950 text-amber-400 border border-amber-800'
                      }`}>
                        {a.technicalStatus}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
