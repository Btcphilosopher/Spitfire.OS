'use client';

import React from 'react';
import { useAero } from '@/lib/AeroContext';
import { PieChart, Download, FileSpreadsheet, FileText, ArrowUpRight } from 'lucide-react';

export default function InvestorAnalytics() {
  const { kpis, aircraft, airlines, leases } = useAero();

  const handleExportCsv = () => {
    const csvRows = [
      ['Registration', 'MSN', 'Family', 'Operator', 'Market Value ($M)', 'Monthly Rent ($k)', 'Lease Expiry'],
      ...aircraft.map(a => [a.registration, a.msn, a.family, a.currentOperatorName, a.currentMarketValue, a.monthlyBaseRent, a.leaseExpiry])
    ];

    const csvContent = 'data:text/csv;charset=utf-8,' + csvRows.map(e => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'Avolon_Portfolio_Report_2026.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-xl bg-[#0a172c] border border-[#1d3557]">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <PieChart className="w-5 h-5 text-blue-400" />
            Executive & Institutional Board Reporting
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Automated executive summary generation · PDF, Excel & CSV exports · Methodology disclosure
          </p>
        </div>

        <button
          onClick={handleExportCsv}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-lg shadow transition-all flex items-center gap-2 shrink-0"
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>Export Portfolio CSV</span>
        </button>
      </div>

      {/* Board Summary Report Document View */}
      <div className="p-8 rounded-xl bg-[#0a172c] border border-[#1d3557] space-y-6 text-slate-200">
        <div className="flex items-center justify-between border-b border-[#1d3557] pb-4">
          <div>
            <div className="text-xs font-mono text-blue-400">AVOLON EXECUTIVE BOARD REPORT</div>
            <h2 className="text-xl font-bold text-white mt-1">Q3 2026 Portfolio Performance & Risk Summary</h2>
          </div>
          <div className="text-right font-mono text-xs text-slate-400">
            <div>DATE: OCTOBER 2026</div>
            <div>STATUS: CONFIDENTIAL BOARD MATERIAL</div>
          </div>
        </div>

        <div className="space-y-3 text-xs leading-relaxed font-sans">
          <p>
            As of October 2026, the <strong>Avolon Aero OS</strong> portfolio comprises <strong>{kpis.totalAircraft} commercial aircraft</strong> with a combined Net Asset Value (NAV) of <strong>${kpis.portfolioNavMillions} Million</strong> and an annual lease revenue forecast of <strong>${kpis.forecastLeaseRevenueAnnualMillions} Million</strong>.
          </p>
          <p>
            Fleet utilization stands at <strong>{kpis.fleetUtilizationPct}%</strong> across tier-one airline counterparties including Lufthansa Group, IndiGo, Delta Air Lines, Singapore Airlines, and Emirates. Total available liquidity headroom is maintained at <strong>${kpis.availableLiquidityMillions} Million</strong>.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-lg bg-[#070e1b] border border-[#1d3557] font-mono text-xs">
          <div>
            <div className="text-slate-500 text-[10px]">TOTAL FLEET</div>
            <div className="text-white font-bold text-base">{kpis.totalAircraft} Aircraft</div>
          </div>
          <div>
            <div className="text-slate-500 text-[10px]">PORTFOLIO NAV</div>
            <div className="text-emerald-400 font-bold text-base">${kpis.portfolioNavMillions}M</div>
          </div>
          <div>
            <div className="text-slate-500 text-[10px]">ANNUAL REVENUE</div>
            <div className="text-white font-bold text-base">${kpis.forecastLeaseRevenueAnnualMillions}M</div>
          </div>
          <div>
            <div className="text-slate-500 text-[10px]">TOTAL DEBT</div>
            <div className="text-blue-400 font-bold text-base">${kpis.totalDebtMillions}M</div>
          </div>
        </div>
      </div>
    </div>
  );
}
