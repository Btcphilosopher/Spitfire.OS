'use client';

import React from 'react';
import { useAero } from '@/lib/AeroContext';
import { Boxes, Landmark, Globe, ShieldCheck } from 'lucide-react';

export default function LegalEntities() {
  const { entities } = useAero();

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-xl bg-[#0a172c] border border-[#1d3557]">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Boxes className="w-5 h-5 text-blue-400" />
            Legal Entities & Special Purpose Vehicle (SPV) Register
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Aircraft-owning entities · Borrowing SPVs · Jurisdiction structures (Dublin, Delaware, Singapore)
          </p>
        </div>

        <div className="text-xs font-mono text-emerald-400 bg-[#070e1b] px-3 py-1.5 rounded-lg border border-[#1d3557]">
          3 PRIMARY JURISDICTIONS ACTIVE
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {entities.map((e) => (
          <div key={e.id} className="p-5 rounded-xl bg-[#0a172c] border border-[#1d3557] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-blue-400">{e.id}</span>
              <span className="text-[10px] font-mono font-bold text-slate-400 bg-[#070e1b] px-2 py-0.5 rounded border border-[#1d3557]">
                {e.role.replace('_', ' ')}
              </span>
            </div>

            <div className="text-base font-bold text-white font-sans">{e.entityName}</div>
            <div className="text-xs text-slate-400 font-mono flex items-center gap-1">
              <Globe className="w-3.5 h-3.5 text-blue-400" />
              <span>{e.jurisdiction}</span>
            </div>

            <div className="pt-3 border-t border-[#1d3557] grid grid-cols-2 gap-2 text-xs font-mono">
              <div>
                <div className="text-[10px] text-slate-500">AIRCRAFT COUNT</div>
                <div className="text-white font-bold">{e.aircraftCount} Assets</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-500">ENTITY DEBT</div>
                <div className="text-emerald-400 font-bold">${e.totalDebtMillions}M</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
