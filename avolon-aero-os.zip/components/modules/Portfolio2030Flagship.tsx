'use client';

import React from 'react';
import { useAero } from '@/lib/AeroContext';
import { Compass, ArrowRight, ShieldCheck, TrendingUp, DollarSign, Layers, PieChart, CheckCircle2 } from 'lucide-react';

export default function Portfolio2030Flagship() {
  const { portfolioStrategy, setPortfolioStrategy } = useAero();

  const strategies = [
    {
      id: 'STRATEGY_A' as const,
      name: 'STRATEGY A — MAINTAIN EXISTING PORTFOLIO',
      shortName: 'Strategy A: Maintain Current Fleet',
      tagline: 'Maintain current fleet composition and manage scheduled lease expiries without aggressive fleet expansion.',
      color: 'blue',
      metrics: {
        nav2030: 6450.0,
        annualRevenue2030: 1820.0,
        capexRequired: 420.0,
        debtRequirement: 11200.0,
        unleveredIrr: 7.8,
        equityIrr: 10.5,
        newTechSharePct: 68,
        avgFleetAgeYears: 7.2,
        availableLiquidity: 2950.0
      }
    },
    {
      id: 'STRATEGY_B' as const,
      name: 'STRATEGY B — ACCELERATE FLEET RENEWAL',
      shortName: 'Strategy B: Accelerate Fleet Renewal (Recommended)',
      tagline: 'Acquire new-technology A321neo / 737 MAX / 787 assets, dispose of older generation airframes, maximizing NAV & IRR.',
      color: 'amber',
      metrics: {
        nav2030: 7420.0,
        annualRevenue2030: 2180.0,
        capexRequired: 1850.0,
        debtRequirement: 12400.0,
        unleveredIrr: 8.8,
        equityIrr: 12.8,
        newTechSharePct: 92,
        avgFleetAgeYears: 4.8,
        availableLiquidity: 2650.0
      }
    },
    {
      id: 'STRATEGY_C' as const,
      name: 'STRATEGY C — PRIORITISE LIQUIDITY',
      shortName: 'Strategy C: Preserve Liquidity Headroom',
      tagline: 'Scale down purchase commitments, accelerate selected asset sales, and maximize cash liquidity headroom.',
      color: 'emerald',
      metrics: {
        nav2030: 6100.0,
        annualRevenue2030: 1650.0,
        capexRequired: 150.0,
        debtRequirement: 9800.0,
        unleveredIrr: 7.4,
        equityIrr: 9.8,
        newTechSharePct: 74,
        avgFleetAgeYears: 6.9,
        availableLiquidity: 3850.0
      }
    }
  ];

  const currentStrat = strategies.find(s => s.id === portfolioStrategy) || strategies[1];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="relative rounded-xl overflow-hidden border border-amber-500/30 bg-gradient-to-r from-[#0a172c] via-[#1a1c2e] to-[#0a172c] p-6 sm:p-8 shadow-2xl">
        <div className="space-y-2 max-w-3xl">
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400">
            <Compass className="w-4 h-4 text-amber-400 animate-spin" style={{ animationDuration: '10s' }} />
            FLAGSHIP EXECUTIVE SCENARIO · AERO PORTFOLIO 2030
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-sans">
            AERO PORTFOLIO 2030: Global Fleet Renewal & Capital Allocation
          </h1>
          <p className="text-xs text-slate-300 leading-relaxed font-sans">
            Interactive capital allocation lab. Simulate comparative returns, fleet age profile, debt requirements, and Net Asset Value (NAV) trajectories across three distinct corporate strategies.
          </p>
        </div>
      </div>

      {/* Strategy Selector Deck */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {strategies.map((strat) => {
          const isSelected = portfolioStrategy === strat.id;

          return (
            <div
              key={strat.id}
              onClick={() => setPortfolioStrategy(strat.id)}
              className={`p-5 rounded-xl border cursor-pointer transition-all space-y-3 relative ${
                isSelected
                  ? 'bg-gradient-to-b from-amber-950/40 to-[#0a172c] border-amber-500 shadow-xl'
                  : 'bg-[#0a172c] border-[#1d3557] hover:border-slate-500'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                  isSelected ? 'bg-amber-500 text-slate-950' : 'bg-[#070e1b] text-slate-400 border border-[#1d3557]'
                }`}>
                  {strat.id.replace('_', ' ')}
                </span>
                {isSelected && <CheckCircle2 className="w-4 h-4 text-amber-400" />}
              </div>

              <div className="text-sm font-bold text-white font-sans">{strat.shortName}</div>
              <p className="text-xs text-slate-300 leading-relaxed">{strat.tagline}</p>

              <div className="pt-3 border-t border-[#1d3557] flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">2030 NAV Target:</span>
                <span className="text-emerald-400 font-bold">${strat.metrics.nav2030}M</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Strategy Comparative Projection Dashboard */}
      <div className="bg-[#0a172c] border border-[#1d3557] rounded-xl p-6 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#1d3557] pb-4">
          <div>
            <h2 className="text-base font-bold text-white font-sans">
              Selected Scenario: <span className="text-amber-400">{currentStrat.name}</span>
            </h2>
            <p className="text-xs text-slate-400 font-mono mt-0.5">Comparative 2026-2030 financial & asset metrics</p>
          </div>

          <div className="text-xs font-mono text-emerald-400 bg-[#070e1b] px-3 py-1.5 rounded-lg border border-[#1d3557]">
            2030 PROJECTED EQUALITY IRR: {currentStrat.metrics.equityIrr}%
          </div>
        </div>

        {/* 2030 Metrics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-[#070e1b] border border-[#1d3557] space-y-1 font-mono">
            <div className="text-[11px] text-slate-400">2030 PORTFOLIO NAV</div>
            <div className="text-2xl font-bold text-emerald-400">${currentStrat.metrics.nav2030}M</div>
            <div className="text-[10px] text-slate-500">Net Asset Value Trajectory</div>
          </div>

          <div className="p-4 rounded-xl bg-[#070e1b] border border-[#1d3557] space-y-1 font-mono">
            <div className="text-[11px] text-slate-400">ANNUAL LEASE REVENUE</div>
            <div className="text-2xl font-bold text-white">${currentStrat.metrics.annualRevenue2030}M</div>
            <div className="text-[10px] text-slate-500">Contractual Rental Income</div>
          </div>

          <div className="p-4 rounded-xl bg-[#070e1b] border border-[#1d3557] space-y-1 font-mono">
            <div className="text-[11px] text-slate-400">CAPEX COMMITMENT</div>
            <div className="text-2xl font-bold text-amber-400">${currentStrat.metrics.capexRequired}M</div>
            <div className="text-[10px] text-slate-500">New Aircraft Deliveries</div>
          </div>

          <div className="p-4 rounded-xl bg-[#070e1b] border border-[#1d3557] space-y-1 font-mono">
            <div className="text-[11px] text-slate-400">NEW-TECH FLEET SHARE</div>
            <div className="text-2xl font-bold text-blue-400">{currentStrat.metrics.newTechSharePct}%</div>
            <div className="text-[10px] text-slate-500">A320neo / 737 MAX / 787</div>
          </div>
        </div>

        {/* Strategy Comparison Matrix Table */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold text-slate-400 uppercase font-mono">Side-by-Side Strategy Comparison Matrix</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-mono">
              <thead>
                <tr className="border-b border-[#1d3557] bg-[#070e1b] text-slate-400 uppercase text-[10px]">
                  <th className="p-3">STRATEGY METRIC</th>
                  <th className="p-3 text-right">STRATEGY A (MAINTAIN)</th>
                  <th className="p-3 text-right text-amber-400 font-bold">STRATEGY B (RENEWAL)</th>
                  <th className="p-3 text-right">STRATEGY C (LIQUIDITY)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1d3557]/40">
                <tr className="hover:bg-[#10223e]">
                  <td className="p-3 font-bold text-white">2030 Portfolio NAV ($M)</td>
                  <td className="p-3 text-right text-slate-300">$6,450M</td>
                  <td className="p-3 text-right text-emerald-400 font-bold">$7,420M</td>
                  <td className="p-3 text-right text-slate-300">$6,100M</td>
                </tr>
                <tr className="hover:bg-[#10223e]">
                  <td className="p-3 font-bold text-white">Unlevered Portfolio IRR (%)</td>
                  <td className="p-3 text-right text-slate-300">7.8%</td>
                  <td className="p-3 text-right text-blue-400 font-bold">8.8%</td>
                  <td className="p-3 text-right text-slate-300">7.4%</td>
                </tr>
                <tr className="hover:bg-[#10223e]">
                  <td className="p-3 font-bold text-white">Equity IRR (%)</td>
                  <td className="p-3 text-right text-slate-300">10.5%</td>
                  <td className="p-3 text-right text-indigo-400 font-bold">12.8%</td>
                  <td className="p-3 text-right text-slate-300">9.8%</td>
                </tr>
                <tr className="hover:bg-[#10223e]">
                  <td className="p-3 font-bold text-white">New-Technology Share (%)</td>
                  <td className="p-3 text-right text-slate-300">68%</td>
                  <td className="p-3 text-right text-blue-400 font-bold">92%</td>
                  <td className="p-3 text-right text-slate-300">74%</td>
                </tr>
                <tr className="hover:bg-[#10223e]">
                  <td className="p-3 font-bold text-white">Average Fleet Age (Years)</td>
                  <td className="p-3 text-right text-slate-300">7.2 yrs</td>
                  <td className="p-3 text-right text-emerald-400 font-bold">4.8 yrs</td>
                  <td className="p-3 text-right text-slate-300">6.9 yrs</td>
                </tr>
                <tr className="hover:bg-[#10223e]">
                  <td className="p-3 font-bold text-white">Available Liquidity ($M)</td>
                  <td className="p-3 text-right text-slate-300">$2,950M</td>
                  <td className="p-3 text-right text-slate-300">$2,650M</td>
                  <td className="p-3 text-right text-emerald-400 font-bold">$3,850M</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
