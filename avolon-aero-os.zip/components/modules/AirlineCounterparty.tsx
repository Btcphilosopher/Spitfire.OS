'use client';

import React, { useState } from 'react';
import { useAero } from '@/lib/AeroContext';
import { AirlineCounterparty } from '@/lib/types';
import {
  Building2,
  ShieldCheck,
  AlertTriangle,
  TrendingUp,
  DollarSign,
  Globe,
  PieChart,
  UserCheck,
  FileCheck
} from 'lucide-react';

export default function AirlineCounterpartyView() {
  const { airlines, setSelectedAirlineId, selectedAirlineId, aircraft } = useAero();
  const [regionFilter, setRegionFilter] = useState<string>('ALL');

  const filteredAirlines = airlines.filter(
    (al) => regionFilter === 'ALL' || al.region === regionFilter
  );

  const selectedAirline = airlines.find((al) => al.id === selectedAirlineId) || airlines[0];
  const airlineAircraft = aircraft.filter((a) => a.currentOperatorId === selectedAirline.id);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-xl bg-[#0a172c] border border-[#1d3557]">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Building2 className="w-5 h-5 text-blue-400" />
            Airline Relationship & Credit Counterparty Centre
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Credit risk ratings · Outstanding financial exposure · Covenants · Payment performance tracking
          </p>
        </div>

        <div className="flex items-center gap-2 bg-[#070e1b] p-1 rounded-lg border border-[#1d3557] text-xs font-mono">
          <button
            onClick={() => setRegionFilter('ALL')}
            className={`px-3 py-1 rounded transition-colors ${regionFilter === 'ALL' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            GLOBAL (ALL)
          </button>
          <button
            onClick={() => setRegionFilter('EMEA')}
            className={`px-3 py-1 rounded transition-colors ${regionFilter === 'EMEA' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            EMEA
          </button>
          <button
            onClick={() => setRegionFilter('APAC')}
            className={`px-3 py-1 rounded transition-colors ${regionFilter === 'APAC' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            APAC
          </button>
          <button
            onClick={() => setRegionFilter('AMER')}
            className={`px-3 py-1 rounded transition-colors ${regionFilter === 'AMER' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            AMER
          </button>
        </div>
      </div>

      {/* Main Grid: Airline List & Detailed Airline Credit Profile */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 cols): Counterparty Cards */}
        <div className="lg:col-span-2 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredAirlines.map((item) => {
              const isSelected = selectedAirline.id === item.id;

              return (
                <div
                  key={item.id}
                  onClick={() => setSelectedAirlineId(item.id)}
                  className={`bg-[#0a172c] border rounded-xl p-5 cursor-pointer transition-all space-y-3 ${
                    isSelected
                      ? 'border-blue-500 bg-blue-900/20 shadow-md'
                      : 'border-[#1d3557] hover:border-slate-500'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-base font-bold text-white">{item.name}</span>
                        <span className="text-xs font-mono text-slate-400 bg-[#070e1b] px-1.5 py-0.5 rounded border border-[#1d3557]">
                          {item.iata}
                        </span>
                      </div>
                      <div className="text-xs text-slate-400 flex items-center gap-1 mt-0.5 font-mono">
                        <Globe className="w-3 h-3 text-blue-400" />
                        {item.country} ({item.region})
                      </div>
                    </div>

                    <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
                      item.covenantStatus === 'COMPLIANT'
                        ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                        : 'bg-amber-950 text-amber-400 border-amber-800'
                    }`}>
                      {item.covenantStatus}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 py-2 border-y border-[#1d3557]/60 text-xs font-mono">
                    <div>
                      <div className="text-[10px] text-slate-500">CREDIT RATING</div>
                      <div className="text-white font-bold">{item.creditRating} (Internal {item.internalCreditRating})</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-500">EXPOSURE</div>
                      <div className="text-emerald-400 font-bold">${item.outstandingExposure}M</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-500">LEASED FLEET</div>
                      <div className="text-slate-200">{item.leasedAircraftCount} Aircraft</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-500">PAYMENT SCORE</div>
                      <div className="text-blue-400 font-bold">{item.paymentPerformanceScore} / 100</div>
                    </div>
                  </div>

                  {item.overdueRentals > 0 && (
                    <div className="p-2 rounded bg-amber-950/60 border border-amber-800 text-[11px] font-mono text-amber-400 flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                      <span>Arrears Alert: ${item.overdueRentals}k overdue rental</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column (1 col): Selected Counterparty Credit Deep-Dive */}
        <div className="bg-[#0a172c] border border-[#1d3557] rounded-xl p-5 space-y-5">
          {selectedAirline && (
            <>
              <div className="border-b border-[#1d3557] pb-4 space-y-1">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-bold text-white">{selectedAirline.name}</h2>
                  <span className="text-xs font-mono text-blue-400 font-bold">{selectedAirline.iata}</span>
                </div>
                <div className="text-xs text-slate-400 font-mono">
                  Relationship Manager: <span className="text-slate-200 font-semibold">{selectedAirline.relationshipManager}</span>
                </div>
              </div>

              {/* Financial Metrics & Leverage Ratios */}
              <div className="space-y-2">
                <h3 className="text-xs font-bold text-slate-400 uppercase font-mono">Financial Health & Covenants</h3>
                <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-[#070e1b] p-3 rounded-lg border border-[#1d3557]">
                  <div>
                    <div className="text-[10px] text-slate-500">LEVERAGE RATIO</div>
                    <div className="text-white font-bold">{selectedAirline.financials.leverageRatio}x</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500">INTEREST COVER</div>
                    <div className="text-white font-bold">{selectedAirline.financials.interestCoverage}x</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500">DSCR</div>
                    <div className="text-emerald-400 font-bold">{selectedAirline.financials.dscr}x</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500">LIQUIDITY RATIO</div>
                    <div className="text-white font-bold">{selectedAirline.financials.cashLiquidityRatio}</div>
                  </div>
                </div>
              </div>

              {/* Leased Aircraft Under Counterparty */}
              <div className="space-y-2">
                <h3 className="text-xs font-bold text-slate-400 uppercase font-mono">Leased Fleet ({airlineAircraft.length} Assets)</h3>
                <div className="space-y-2">
                  {airlineAircraft.map((a) => (
                    <div key={a.id} className="p-2.5 rounded bg-[#070e1b] border border-[#1d3557] text-xs font-mono flex items-center justify-between">
                      <div>
                        <div className="font-bold text-white">{a.registration} ({a.family})</div>
                        <div className="text-[10px] text-slate-400">MSN {a.msn}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-emerald-400 font-bold">${a.monthlyBaseRent}k/mo</div>
                        <div className="text-[10px] text-slate-400">Exp {a.leaseExpiry}</div>
                      </div>
                    </div>
                  ))}
                  {airlineAircraft.length === 0 && (
                    <div className="text-xs text-slate-500 p-2 italic">No active assets directly linked in sample dataset.</div>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
