'use client';

import React, { useState } from 'react';
import { useAero } from '@/lib/AeroContext';
import {
  TrendingUp,
  DollarSign,
  Sliders,
  BarChart3,
  RefreshCw,
  Layers,
  ArrowRight
} from 'lucide-react';

export default function LeaseCashflowEngine() {
  const { leases, aircraft } = useAero();
  const [selectedLeaseId, setSelectedLeaseIdState] = useState<string>(leases[0]?.id || 'LSE-2022-089');

  // Sensitivity Sliders
  const [rentAdjustmentPct, setRentAdjustmentPct] = useState<number>(0);
  const [discountRatePct, setDiscountRatePct] = useState<number>(7.5);
  const [residualValAdjustmentPct, setResidualValAdjustmentPct] = useState<number>(0);

  const lease = leases.find((l) => l.id === selectedLeaseId) || leases[0];
  const linkedAircraft = aircraft.find((a) => a.id === lease.aircraftId) || aircraft[0];

  // Cash flow simulation based on sensitivity inputs
  const adjustedRent = Math.round(lease.baseMonthlyRent * (1 + rentAdjustmentPct / 100));
  const annualCashInflow = (adjustedRent * 12) / 1000; // $ Millions p.a.
  const estimatedResidual = linkedAircraft.estimatedResidualValue2030 * (1 + residualValAdjustmentPct / 100);

  // Simplified NPV calculation across 10 years
  const projectedYears = [2026, 2027, 2028, 2029, 2030, 2031, 2032, 2033, 2034, 2035];
  const cashflows = projectedYears.map((year, idx) => {
    const isResidualYear = idx === projectedYears.length - 1;
    const rentalIncome = annualCashInflow * Math.pow(1 + lease.escalationRatePct / 100, idx);
    const maintenanceReserves = 0.45; // $M p.a.
    const debtService = 1.85; // $M p.a.
    const netOperatingCashflow = rentalIncome + maintenanceReserves - debtService + (isResidualYear ? estimatedResidual : 0);
    const discountFactor = Math.pow(1 + discountRatePct / 100, idx + 1);
    const discountedCashflow = netOperatingCashflow / discountFactor;

    return {
      year,
      rentalIncome: Number(rentalIncome.toFixed(2)),
      debtService: Number(debtService.toFixed(2)),
      netCashflow: Number(netOperatingCashflow.toFixed(2)),
      discountedCashflow: Number(discountedCashflow.toFixed(2))
    };
  });

  const calculatedNpv = Number(cashflows.reduce((acc, c) => acc + c.discountedCashflow, 0).toFixed(2));
  const calculatedUnleveredIrr = Number((lease.unleveredIrrPct + rentAdjustmentPct * 0.15 + residualValAdjustmentPct * 0.08).toFixed(2));
  const calculatedEquityIrr = Number((lease.equityIrrPct + rentAdjustmentPct * 0.22 + residualValAdjustmentPct * 0.12).toFixed(2));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-xl bg-[#0a172c] border border-[#1d3557]">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
            Lease Cash-Flow Engine & Financial Modeling
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Contractual projections · Dated cash flow NPV · Unlevered & Equity IRR · Real-time sensitivity stress testing
          </p>
        </div>

        {/* Lease Selector */}
        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-400 font-mono">SELECT LEASE:</label>
          <select
            value={selectedLeaseId}
            onChange={(e) => setSelectedLeaseIdState(e.target.value)}
            className="bg-[#070e1b] border border-[#1d3557] rounded-lg px-3 py-1.5 text-xs text-white font-mono"
          >
            {leases.map((l) => (
              <option key={l.id} value={l.id}>
                {l.leaseNumber} - {l.lesseeName} ({l.aircraftRegistration})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Primary Financial Metric Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-[#0a172c] border border-[#1d3557] space-y-1">
          <div className="text-[11px] text-slate-400 font-mono">CALCULATED NPV</div>
          <div className="text-2xl font-bold text-emerald-400 font-mono">${calculatedNpv}M</div>
          <div className="text-[10px] text-slate-500 font-mono">At {discountRatePct}% Discount Rate</div>
        </div>

        <div className="p-4 rounded-xl bg-[#0a172c] border border-[#1d3557] space-y-1">
          <div className="text-[11px] text-slate-400 font-mono">UNLEVERED IRR</div>
          <div className="text-2xl font-bold text-blue-400 font-mono">{calculatedUnleveredIrr}%</div>
          <div className="text-[10px] text-slate-500 font-mono">Lifetime Unlevered Yield</div>
        </div>

        <div className="p-4 rounded-xl bg-[#0a172c] border border-[#1d3557] space-y-1">
          <div className="text-[11px] text-slate-400 font-mono">EQUITY IRR</div>
          <div className="text-2xl font-bold text-indigo-400 font-mono">{calculatedEquityIrr}%</div>
          <div className="text-[10px] text-slate-500 font-mono">Post-Debt Equity Return</div>
        </div>

        <div className="p-4 rounded-xl bg-[#0a172c] border border-[#1d3557] space-y-1">
          <div className="text-[11px] text-slate-400 font-mono">MONTHLY RENT</div>
          <div className="text-2xl font-bold text-white font-mono">${adjustedRent}k / mo</div>
          <div className="text-[10px] text-slate-500 font-mono">Contractual Base Rent</div>
        </div>
      </div>

      {/* Main Grid: Sensitivity Controls & Projected Cash Flow Schedule */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (1 col): Sensitivity Control Workbench */}
        <div className="bg-[#0a172c] border border-[#1d3557] rounded-xl p-5 space-y-5">
          <div className="flex items-center gap-2 border-b border-[#1d3557] pb-3">
            <Sliders className="w-4 h-4 text-blue-400" />
            <h2 className="text-sm font-bold text-white uppercase font-mono">Sensitivity Sliders</h2>
          </div>

          <div className="space-y-4 text-xs font-mono">
            {/* Rent Shift Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-slate-300">
                <span>Lease Rental Adjustment:</span>
                <span className="text-emerald-400 font-bold">{rentAdjustmentPct > 0 ? `+${rentAdjustmentPct}` : rentAdjustmentPct}%</span>
              </div>
              <input
                type="range"
                min="-20"
                max="20"
                step="1"
                value={rentAdjustmentPct}
                onChange={(e) => setRentAdjustmentPct(parseInt(e.target.value))}
                className="w-full accent-blue-500"
              />
            </div>

            {/* Discount Rate Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-slate-300">
                <span>Discount Rate (WACC):</span>
                <span className="text-blue-400 font-bold">{discountRatePct}%</span>
              </div>
              <input
                type="range"
                min="4.0"
                max="12.0"
                step="0.5"
                value={discountRatePct}
                onChange={(e) => setDiscountRatePct(parseFloat(e.target.value))}
                className="w-full accent-blue-500"
              />
            </div>

            {/* Residual Value Shift Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-slate-300">
                <span>Residual Value Expectation:</span>
                <span className="text-indigo-400 font-bold">{residualValAdjustmentPct > 0 ? `+${residualValAdjustmentPct}` : residualValAdjustmentPct}%</span>
              </div>
              <input
                type="range"
                min="-30"
                max="30"
                step="5"
                value={residualValAdjustmentPct}
                onChange={(e) => setResidualValAdjustmentPct(parseInt(e.target.value))}
                className="w-full accent-blue-500"
              />
            </div>

            <button
              onClick={() => {
                setRentAdjustmentPct(0);
                setDiscountRatePct(7.5);
                setResidualValAdjustmentPct(0);
              }}
              className="w-full py-2 rounded bg-[#070e1b] hover:bg-[#10223e] border border-[#1d3557] text-slate-300 text-xs flex items-center justify-center gap-2 transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset Base Case Assumptions</span>
            </button>
          </div>
        </div>

        {/* Right Column (2 cols): 10-Year Annual Cash Flow Table */}
        <div className="lg:col-span-2 bg-[#0a172c] border border-[#1d3557] rounded-xl overflow-hidden shadow-sm">
          <div className="p-3 border-b border-[#1d3557] bg-[#070e1b] flex items-center justify-between text-xs font-mono text-slate-400">
            <span>10-YEAR ANNUAL CASH FLOW SCHEDULE ($ MILLIONS)</span>
            <span>MODEL VERSION: AV-CF-2026.1</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-mono">
              <thead>
                <tr className="border-b border-[#1d3557] bg-[#070e1b]/60 text-slate-400 uppercase text-[10px]">
                  <th className="p-3">YEAR</th>
                  <th className="p-3 text-right">RENTAL INFLOW</th>
                  <th className="p-3 text-right">DEBT SERVICE</th>
                  <th className="p-3 text-right">NET CASHFLOW</th>
                  <th className="p-3 text-right">DISCOUNTED CF</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1d3557]/40">
                {cashflows.map((row) => (
                  <tr key={row.year} className="hover:bg-[#10223e] text-slate-200">
                    <td className="p-3 font-bold text-white">{row.year}</td>
                    <td className="p-3 text-right text-emerald-400">${row.rentalIncome}M</td>
                    <td className="p-3 text-right text-amber-400">-${row.debtService}M</td>
                    <td className="p-3 text-right font-bold text-white">${row.netCashflow}M</td>
                    <td className="p-3 text-right text-blue-400 font-bold">${row.discountedCashflow}M</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
