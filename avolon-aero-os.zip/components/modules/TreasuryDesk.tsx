'use client';

import React from 'react';
import { useAero } from '@/lib/AeroContext';
import { Landmark, ShieldCheck, DollarSign, TrendingUp, AlertTriangle } from 'lucide-react';

export default function TreasuryDesk() {
  const { financing, kpis } = useAero();

  const totalLimit = financing.reduce((acc, f) => acc + f.totalLimitMillions, 0);
  const totalDrawn = financing.reduce((acc, f) => acc + f.drawnAmountMillions, 0);
  const totalAvailable = financing.reduce((acc, f) => acc + f.availableCommitmentMillions, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-xl bg-[#0a172c] border border-[#1d3557]">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Landmark className="w-5 h-5 text-blue-400" />
            Treasury & Debt Capital Markets
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Secured aircraft debt · Unsecured bonds · Revolvers & Warehouses · Debt maturity ladder · Interest rate hedging
          </p>
        </div>

        <div className="text-xs font-mono text-emerald-400 bg-[#070e1b] px-3 py-1.5 rounded-lg border border-[#1d3557]">
          ${totalAvailable}M LIQUIDITY HEADROOM AVAILABLE
        </div>
      </div>

      {/* Primary Liquidity & Debt Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-[#0a172c] border border-[#1d3557] space-y-1">
          <div className="text-[11px] text-slate-400 font-mono">TOTAL DEBT LIMIT</div>
          <div className="text-2xl font-bold text-white font-mono">${totalLimit}M</div>
          <div className="text-[10px] text-slate-500 font-mono">Across All Credit Facilities</div>
        </div>

        <div className="p-4 rounded-xl bg-[#0a172c] border border-[#1d3557] space-y-1">
          <div className="text-[11px] text-slate-400 font-mono">TOTAL DRAWN DEBT</div>
          <div className="text-2xl font-bold text-blue-400 font-mono">${totalDrawn}M</div>
          <div className="text-[10px] text-slate-500 font-mono">Principal Outstanding</div>
        </div>

        <div className="p-4 rounded-xl bg-[#0a172c] border border-[#1d3557] space-y-1">
          <div className="text-[11px] text-slate-400 font-mono">AVAILABLE REVOLVER/WAREHOUSE</div>
          <div className="text-2xl font-bold text-emerald-400 font-mono">${totalAvailable}M</div>
          <div className="text-[10px] text-slate-500 font-mono">Undrawn Commitment</div>
        </div>

        <div className="p-4 rounded-xl bg-[#0a172c] border border-[#1d3557] space-y-1">
          <div className="text-[11px] text-slate-400 font-mono">AVERAGE MARGIN SPREAD</div>
          <div className="text-2xl font-bold text-indigo-400 font-mono">175 bps</div>
          <div className="text-[10px] text-slate-500 font-mono">Over SOFR Benchmark</div>
        </div>
      </div>

      {/* Debt Facilities List */}
      <div className="bg-[#0a172c] border border-[#1d3557] rounded-xl overflow-hidden shadow-sm">
        <div className="p-3 border-b border-[#1d3557] bg-[#070e1b] flex items-center justify-between text-xs font-mono text-slate-400">
          <span>CREDIT FACILITIES & BOND ISSUANCES</span>
          <span>{financing.length} FACILITIES ACTIVE</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b border-[#1d3557] bg-[#070e1b]/60 text-slate-400 uppercase text-[10px]">
                <th className="p-3">FACILITY NAME</th>
                <th className="p-3">TYPE</th>
                <th className="p-3">ARRANGER / LENDERS</th>
                <th className="p-3 text-right">TOTAL LIMIT</th>
                <th className="p-3 text-right">DRAWN</th>
                <th className="p-3 text-right">AVAILABLE</th>
                <th className="p-3">RATE BASIS</th>
                <th className="p-3 text-center">MATURITY</th>
                <th className="p-3 text-right">COVENANT HEADROOM</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1d3557]/40">
              {financing.map((f) => (
                <tr key={f.id} className="hover:bg-[#10223e] text-slate-200">
                  <td className="p-3 font-bold text-white">{f.facilityName}</td>
                  <td className="p-3 text-blue-400 font-bold">{f.type.replace('_', ' ')}</td>
                  <td className="p-3 font-sans text-slate-300">{f.arranger}</td>
                  <td className="p-3 text-right text-slate-300">${f.totalLimitMillions}M</td>
                  <td className="p-3 text-right text-blue-400 font-bold">${f.drawnAmountMillions}M</td>
                  <td className="p-3 text-right text-emerald-400 font-bold">${f.availableCommitmentMillions}M</td>
                  <td className="p-3">
                    {f.isFloating ? (
                      <span className="text-slate-300">{f.benchmarkRate} + {f.marginSpreadBps} bps</span>
                    ) : (
                      <span className="text-indigo-400 font-bold">{f.fixedRatePct}% Fixed</span>
                    )}
                  </td>
                  <td className="p-3 text-center text-slate-300">{f.maturityDate}</td>
                  <td className="p-3 text-right text-emerald-400 font-bold">{f.covenantHeadroomPct}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
