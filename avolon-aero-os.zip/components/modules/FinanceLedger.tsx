'use client';

import React from 'react';
import { useAero } from '@/lib/AeroContext';
import { BookOpen, DollarSign, CheckCircle2, RefreshCw } from 'lucide-react';

export default function FinanceLedger() {
  const { ledger } = useAero();

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-xl bg-[#0a172c] border border-[#1d3557]">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-blue-400" />
            Double-Entry Aviation Finance Ledger
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Balanced journal entries · Rental invoices · Debt drawdowns · Maintenance reserve accruals
          </p>
        </div>

        <div className="text-xs font-mono text-emerald-400 bg-[#070e1b] px-3 py-1.5 rounded-lg border border-[#1d3557]">
          POSTED BALANCED LEDGER · IFRS 16 ALIGNED
        </div>
      </div>

      <div className="bg-[#0a172c] border border-[#1d3557] rounded-xl overflow-hidden shadow-sm">
        <div className="p-3 border-b border-[#1d3557] bg-[#070e1b] flex items-center justify-between text-xs font-mono text-slate-400">
          <span>POSTED JOURNAL ENTRIES</span>
          <span>{ledger.length} ENTRIES RECORDED</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b border-[#1d3557] bg-[#070e1b]/60 text-slate-400 uppercase text-[10px]">
                <th className="p-3">JOURNAL ID</th>
                <th className="p-3">POSTING DATE</th>
                <th className="p-3">SOURCE TRANSACTION</th>
                <th className="p-3">DEBIT ACCOUNT</th>
                <th className="p-3">CREDIT ACCOUNT</th>
                <th className="p-3 text-right">AMOUNT ($k)</th>
                <th className="p-3 text-center">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1d3557]/40">
              {ledger.map((j) => (
                <tr key={j.id} className="hover:bg-[#10223e] text-slate-200">
                  <td className="p-3 font-bold text-white">{j.id}</td>
                  <td className="p-3 text-slate-400">{j.date}</td>
                  <td className="p-3 font-sans font-medium text-slate-200">{j.sourceTransaction}</td>
                  <td className="p-3 text-blue-400 font-bold">{j.debitAccount}</td>
                  <td className="p-3 text-emerald-400 font-bold">{j.creditAccount}</td>
                  <td className="p-3 text-right font-bold text-white">${j.amountThousands.toLocaleString()}k</td>
                  <td className="p-3 text-center">
                    <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold">
                      {j.postingStatus}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
