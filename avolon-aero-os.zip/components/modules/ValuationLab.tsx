'use client';

import React from 'react';
import { useAero } from '@/lib/AeroContext';
import { Calculator, DollarSign, TrendingUp, ShieldAlert, Award } from 'lucide-react';

export default function ValuationLab() {
  const { valuations, aircraft } = useAero();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-xl bg-[#0a172c] border border-[#1d3557]">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Calculator className="w-5 h-5 text-blue-400" />
            Asset Valuation Lab & Residual-Value Modeling
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Market-comparable valuations · DCF valuation · 2030 Residual Curves · Stressed liquidation haircuts
          </p>
        </div>

        <div className="text-xs font-mono text-emerald-400 bg-[#070e1b] px-3 py-1.5 rounded-lg border border-[#1d3557]">
          INDEPENDENT AUDITOR CERTIFIED (IBA / ASCEND)
        </div>
      </div>

      {/* Valuation Table */}
      <div className="bg-[#0a172c] border border-[#1d3557] rounded-xl overflow-hidden shadow-sm">
        <div className="p-3 border-b border-[#1d3557] bg-[#070e1b] flex items-center justify-between text-xs font-mono text-slate-400">
          <span>VALUATION MASTER REGISTRY ($ MILLIONS)</span>
          <span>VALUATION ENGINE v4.2</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b border-[#1d3557] bg-[#070e1b]/60 text-slate-400 uppercase text-[10px]">
                <th className="p-3">REG / FAMILY</th>
                <th className="p-3">METHOD</th>
                <th className="p-3 text-right">BOOK VALUE</th>
                <th className="p-3 text-right">MARKET VAL</th>
                <th className="p-3 text-right">DCF VAL</th>
                <th className="p-3 text-right">2030 RESIDUAL</th>
                <th className="p-3 text-right">STRESSED LIQUIDATION</th>
                <th className="p-3">AUDITOR / REVIEWER</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1d3557]/40">
              {valuations.map((v) => (
                <tr key={v.id} className="hover:bg-[#10223e] text-slate-200">
                  <td className="p-3">
                    <div className="font-bold text-white">{v.registration}</div>
                    <div className="text-[10px] text-slate-400 font-sans">{v.family} ({v.manufacturingYear})</div>
                  </td>
                  <td className="p-3 text-blue-400 font-bold">{v.method.replace('_', ' ')}</td>
                  <td className="p-3 text-right text-slate-300">${v.bookValueMillions}M</td>
                  <td className="p-3 text-right text-emerald-400 font-bold">${v.marketValuationMillions}M</td>
                  <td className="p-3 text-right text-blue-400">${v.dcfValueMillions}M</td>
                  <td className="p-3 text-right text-indigo-400">${v.estimatedResidual2030Millions}M</td>
                  <td className="p-3 text-right text-amber-400 font-bold">${v.stressedLiquidationValueMillions}M</td>
                  <td className="p-3 font-sans text-slate-400">
                    <div>{v.reviewerName}</div>
                    <div className="text-[10px] text-slate-500 font-mono">{v.valuationDate}</div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
