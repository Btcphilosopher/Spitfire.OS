'use client';

import React, { useState } from 'react';
import { useAero } from '@/lib/AeroContext';
import { AircraftLease } from '@/lib/types';
import {
  FileText,
  DollarSign,
  Calendar,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Edit3,
  TrendingUp,
  X
} from 'lucide-react';

export default function LeaseManagement() {
  const { leases, updateLease, setSelectedLeaseId, selectedLeaseId } = useAero();
  const [editingLease, setEditingLease] = useState<AircraftLease | null>(null);

  const selectedLease = leases.find((l) => l.id === selectedLeaseId) || leases[0];

  const handleSaveAmendment = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingLease) {
      updateLease(editingLease);
      setEditingLease(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-xl bg-[#0a172c] border border-[#1d3557]">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-400" />
            Lease Administration & Contract Engine
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Operating & SLB Contract Engine · Escalation formulas · Rental schedules · Amendments
          </p>
        </div>

        <div className="text-xs font-mono text-emerald-400 bg-[#070e1b] px-3 py-1.5 rounded-lg border border-[#1d3557]">
          {leases.length} CONTRACTUAL LEASES ACTIVE
        </div>
      </div>

      {/* Main Grid: Lease Register & Active Contract Detail View */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 cols): Lease Register */}
        <div className="lg:col-span-2 bg-[#0a172c] border border-[#1d3557] rounded-xl overflow-hidden shadow-sm">
          <div className="p-3 border-b border-[#1d3557] bg-[#070e1b] flex items-center justify-between text-xs font-mono text-slate-400">
            <span>ACTIVE LEASE CONTRACTS</span>
            <span>SHOWING ALL CONTRACTS</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-mono">
              <thead>
                <tr className="border-b border-[#1d3557] bg-[#070e1b]/60 text-slate-400 uppercase text-[10px]">
                  <th className="p-3">LEASE NO</th>
                  <th className="p-3">AIRCRAFT / REG</th>
                  <th className="p-3">LESSEE</th>
                  <th className="p-3 text-right">BASE RENT</th>
                  <th className="p-3 text-right">IRR</th>
                  <th className="p-3 text-center">STATUS</th>
                  <th className="p-3"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1d3557]/40">
                {leases.map((item) => {
                  const isSelected = selectedLease.id === item.id;
                  return (
                    <tr
                      key={item.id}
                      onClick={() => setSelectedLeaseId(item.id)}
                      className={`cursor-pointer transition-colors ${
                        isSelected
                          ? 'bg-blue-900/30 text-white font-semibold'
                          : 'hover:bg-[#10223e] text-slate-300'
                      }`}
                    >
                      <td className="p-3 font-bold text-white">{item.leaseNumber}</td>
                      <td className="p-3">
                        <div className="text-slate-200 font-bold">{item.aircraftRegistration}</div>
                        <div className="text-[10px] text-slate-400 font-sans">{item.aircraftFamily}</div>
                      </td>
                      <td className="p-3 font-sans">{item.lesseeName}</td>
                      <td className="p-3 text-right text-emerald-400 font-bold">${item.baseMonthlyRent}k/mo</td>
                      <td className="p-3 text-right text-blue-400">{item.unleveredIrrPct}%</td>
                      <td className="p-3 text-center">
                        <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                          item.status === 'ACTIVE'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : 'bg-amber-950 text-amber-400 border border-amber-800'
                        }`}>
                          {item.status}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditingLease(item);
                          }}
                          className="p-1 text-slate-400 hover:text-white rounded hover:bg-[#1d3557]"
                          title="Amend Lease"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Column (1 col): Selected Lease Contract Detail & Schedule */}
        <div className="bg-[#0a172c] border border-[#1d3557] rounded-xl p-5 space-y-5">
          {selectedLease && (
            <>
              <div className="border-b border-[#1d3557] pb-4 flex items-center justify-between">
                <div>
                  <h2 className="text-base font-bold text-white font-mono">{selectedLease.leaseNumber}</h2>
                  <p className="text-xs text-slate-400 font-sans">{selectedLease.lesseeName} · {selectedLease.aircraftRegistration}</p>
                </div>
                <button
                  onClick={() => setEditingLease(selectedLease)}
                  className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs rounded transition-colors flex items-center gap-1"
                >
                  <Edit3 className="w-3 h-3" />
                  <span>Amend Lease</span>
                </button>
              </div>

              {/* Economic Summary */}
              <div className="space-y-2">
                <h3 className="text-xs font-bold text-slate-400 uppercase font-mono">Contract Economics</h3>
                <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-[#070e1b] p-3 rounded-lg border border-[#1d3557]">
                  <div>
                    <div className="text-[10px] text-slate-500">BASE MONTHLY RENT</div>
                    <div className="text-emerald-400 font-bold">${selectedLease.baseMonthlyRent}k / mo</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500">ESCALATION RATE</div>
                    <div className="text-white font-bold">{selectedLease.escalationRatePct}% p.a.</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500">COMMENCEMENT</div>
                    <div className="text-slate-300">{selectedLease.commencementDate}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500">EXPIRY DATE</div>
                    <div className="text-slate-300">{selectedLease.expiryDate}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500">UNLEVERED IRR</div>
                    <div className="text-blue-400 font-bold">{selectedLease.unleveredIrrPct}%</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500">SECURITY DEPOSIT</div>
                    <div className="text-slate-200">${selectedLease.securityDeposit}k</div>
                  </div>
                </div>
              </div>

              {/* Payment Schedule History */}
              <div className="space-y-2">
                <h3 className="text-xs font-bold text-slate-400 uppercase font-mono">Contractual Rental Schedule</h3>
                <div className="space-y-2 font-mono text-xs">
                  {selectedLease.paymentHistory.map((p, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded bg-[#070e1b] border border-[#1d3557] flex items-center justify-between"
                    >
                      <div>
                        <div className="text-white font-bold">{p.period} ({p.dueDate})</div>
                        <div className="text-[10px] text-slate-400">Due: ${p.contractualAmount}k</div>
                      </div>

                      <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                        p.status === 'PAID'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : p.status === 'OVERDUE'
                            ? 'bg-amber-950 text-amber-400 border border-amber-800'
                            : 'bg-slate-800 text-slate-300'
                      }`}>
                        {p.status} (${p.amountPaid}k Paid)
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Edit Lease Amendment Modal */}
      {editingLease && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0a172c] border border-[#1d3557] rounded-xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#1d3557] pb-3">
              <h2 className="text-base font-bold text-white">Amend Lease Terms ({editingLease.leaseNumber})</h2>
              <button onClick={() => setEditingLease(null)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveAmendment} className="space-y-3 text-xs font-mono">
              <div>
                <label className="text-slate-400 block mb-1">Base Monthly Rent ($k)</label>
                <input
                  type="number"
                  value={editingLease.baseMonthlyRent}
                  onChange={(e) => setEditingLease({ ...editingLease, baseMonthlyRent: parseInt(e.target.value) || 0 })}
                  className="w-full bg-[#070e1b] border border-[#1d3557] rounded p-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Escalation Rate (% p.a.)</label>
                <input
                  type="number"
                  step="0.1"
                  value={editingLease.escalationRatePct}
                  onChange={(e) => setEditingLease({ ...editingLease, escalationRatePct: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-[#070e1b] border border-[#1d3557] rounded p-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Contract Expiry Date</label>
                <input
                  type="date"
                  value={editingLease.expiryDate}
                  onChange={(e) => setEditingLease({ ...editingLease, expiryDate: e.target.value })}
                  className="w-full bg-[#070e1b] border border-[#1d3557] rounded p-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Lease Status</label>
                <select
                  value={editingLease.status}
                  onChange={(e) => setEditingLease({ ...editingLease, status: e.target.value as any })}
                  className="w-full bg-[#070e1b] border border-[#1d3557] rounded p-2 text-white"
                >
                  <option value="ACTIVE">ACTIVE</option>
                  <option value="AMENDED">AMENDED</option>
                  <option value="EXPIRING">EXPIRING</option>
                  <option value="IN_DEFAULT">IN_DEFAULT</option>
                </select>
              </div>

              <div className="pt-2 flex justify-end gap-2 font-sans">
                <button
                  type="button"
                  onClick={() => setEditingLease(null)}
                  className="px-4 py-2 bg-[#070e1b] text-slate-300 rounded hover:bg-[#10223e]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded"
                >
                  Save Contract Amendment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
