'use client';

import React from 'react';
import { useAero } from '@/lib/AeroContext';
import {
  Plane,
  Building2,
  DollarSign,
  TrendingUp,
  AlertTriangle,
  ArrowUpRight,
  ShieldCheck,
  CheckCircle2,
  PieChart,
  Calendar,
  Layers
} from 'lucide-react';

export default function CommandCentre() {
  const { kpis, aircraft, airlines, leases, deliveries, setActiveModule, setSelectedAircraftId } = useAero();

  return (
    <div className="space-[#1d3557] space-y-6">
      {/* Top Banner Hero with Aviation Visual */}
      <div className="relative rounded-xl overflow-hidden border border-[#1d3557] bg-gradient-to-r from-[#0a172c] via-[#0d213f] to-[#070e1b] shadow-xl">
        <div className="absolute inset-0 opacity-20 bg-cover bg-center mix-blend-overlay" style={{ backgroundImage: "url('/src/assets/images/hero_aircraft_a321neo_1792913311300.jpg')" }} />
        
        <div className="relative p-6 sm:p-8 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-mono text-blue-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              AERO COMMAND CENTRE · LIVE PORTFOLIO STATE
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-sans">
              Global Aviation Portfolio
            </h1>
            <p className="text-xs text-slate-300 leading-relaxed">
              Managing <span className="text-white font-semibold">{kpis.totalAircraft} commercial aircraft</span> valued at <span className="text-emerald-400 font-semibold font-mono">${kpis.portfolioNavMillions}M NAV</span> across {airlines.length} tier-one global airline counterparties in 24 jurisdictions.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setActiveModule('portfolio-2030')}
              className="px-4 py-2 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white font-semibold text-xs rounded-lg shadow-lg border border-amber-400/40 transition-all flex items-center gap-2"
            >
              <span>Aero Portfolio 2030 Scenario</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => setActiveModule('fleet')}
              className="px-4 py-2 bg-[#070e1b] hover:bg-[#10223e] text-slate-200 hover:text-white font-semibold text-xs rounded-lg border border-[#1d3557] transition-all"
            >
              Explore Fleet
            </button>
          </div>
        </div>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-4">
        <div className="p-4 rounded-xl bg-[#0a172c] border border-[#1d3557] space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Total Fleet</span>
            <Plane className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">{kpis.totalAircraft}</div>
          <div className="text-[10px] text-slate-400 font-mono">
            {kpis.ownedAircraft} Owned · {kpis.managedAircraft} Managed
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#0a172c] border border-[#1d3557] space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Annual Revenue</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400 font-mono">${kpis.forecastLeaseRevenueAnnualMillions}M</div>
          <div className="text-[10px] text-emerald-500 font-mono flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />
            +4.2% YoY Growth
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#0a172c] border border-[#1d3557] space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Portfolio NAV</span>
            <PieChart className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">${kpis.portfolioNavMillions}M</div>
          <div className="text-[10px] text-slate-400 font-mono">
            Net Asset Value
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#0a172c] border border-[#1d3557] space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Available Liquidity</span>
            <ShieldCheck className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-blue-400 font-mono">${kpis.availableLiquidityMillions}M</div>
          <div className="text-[10px] text-slate-400 font-mono">
            Cash & Revolver Headroom
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#0a172c] border border-[#1d3557] space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Fleet Utilization</span>
            <Layers className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">{kpis.fleetUtilizationPct}%</div>
          <div className="text-[10px] text-emerald-400 font-mono">
            485 Active Leases
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#0a172c] border border-[#1d3557] space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Overdue Rentals</span>
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-amber-400 font-mono">${kpis.overdueRentalsThousands}k</div>
          <div className="text-[10px] text-amber-500 font-mono">
            1 Counterparty Overdue
          </div>
        </div>
      </div>

      {/* Main Content Grid: Active Aircraft Assets & Actionable Exceptions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 cols): Aircraft Asset Focus */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between p-1 bg-[#0a172c] border border-[#1d3557] rounded-xl px-4 py-3">
            <div>
              <h2 className="text-sm font-bold text-white tracking-wide">Featured Aircraft Assets</h2>
              <p className="text-[11px] text-slate-400 font-mono">Direct asset records & current lease status</p>
            </div>
            <button
              onClick={() => setActiveModule('fleet')}
              className="text-xs text-blue-400 hover:text-blue-300 font-semibold flex items-center gap-1"
            >
              <span>View All 8 Asset Specs</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {aircraft.slice(0, 4).map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  setSelectedAircraftId(item.id);
                  setActiveModule('fleet');
                }}
                className="bg-[#0a172c] border border-[#1d3557] hover:border-blue-500/50 rounded-xl p-4 cursor-pointer transition-all space-y-3 group"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-white font-mono group-hover:text-blue-400 transition-colors">
                        {item.registration}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400 bg-[#070e1b] px-1.5 py-0.5 rounded border border-[#1d3557]">
                        MSN {item.msn}
                      </span>
                    </div>
                    <div className="text-xs text-slate-300 font-medium mt-0.5">{item.family}</div>
                  </div>
                  <span className={`text-[10px] font-bold font-mono px-2 py-0.5 rounded ${
                    item.leaseStatus === 'ACTIVE'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/50'
                      : 'bg-amber-950 text-amber-400 border border-amber-800/50'
                  }`}>
                    {item.leaseStatus}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 py-2 border-y border-[#1d3557]/60 text-xs font-mono">
                  <div>
                    <div className="text-[10px] text-slate-400">OPERATOR</div>
                    <div className="text-slate-200 font-semibold truncate">{item.currentOperatorName}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400">MARKET VAL</div>
                    <div className="text-emerald-400 font-semibold">${item.currentMarketValue}M</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400">MONTHLY RENT</div>
                    <div className="text-slate-200 font-semibold">${item.monthlyBaseRent}k/mo</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400">LEASE EXPIRY</div>
                    <div className="text-slate-300">{item.leaseExpiry}</div>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>Engine: {item.engineManufacturer} {item.engineModel}</span>
                  <span className="text-blue-400 font-semibold group-hover:translate-x-0.5 transition-transform">Inspect →</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column (1 col): Operational Risk & Workflow Queue */}
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-[#0a172c] border border-[#1d3557] space-y-3">
            <div className="flex items-center justify-between border-b border-[#1d3557] pb-2">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <h3 className="text-xs font-bold text-white">Action Exceptions & Risk</h3>
              </div>
              <span className="text-[10px] font-mono text-amber-400 font-bold bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800">
                2 Items
              </span>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="p-3 rounded-lg bg-[#070e1b] border border-amber-800/40 space-y-1">
                <div className="flex items-center justify-between font-bold text-slate-200">
                  <span>LATAM Airlines (EI-EXP)</span>
                  <span className="text-amber-400 font-mono">$370k Overdue</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  September rental unpaid. Lease restructuring proposal pending approval.
                </p>
                <button
                  onClick={() => setActiveModule('approvals')}
                  className="text-[10px] font-mono text-blue-400 hover:underline pt-1 block"
                >
                  Review Restructuring Approval →
                </button>
              </div>

              <div className="p-3 rounded-lg bg-[#070e1b] border border-[#1d3557] space-y-1">
                <div className="flex items-center justify-between font-bold text-slate-200">
                  <span>Boeing 737 MAX 8 Delivery</span>
                  <span className="text-slate-400 font-mono">Delayed +40 Days</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Renton plant assembly drift. PDP payment schedule updated.
                </p>
                <button
                  onClick={() => setActiveModule('deliveries')}
                  className="text-[10px] font-mono text-blue-400 hover:underline pt-1 block"
                >
                  Inspect Delivery Control →
                </button>
              </div>
            </div>
          </div>

          {/* Quick Access Action Deck */}
          <div className="p-4 rounded-xl bg-[#0a172c] border border-[#1d3557] space-y-3">
            <h3 className="text-xs font-bold text-white tracking-wide">Quick Workbench Tools</h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => setActiveModule('leases')}
                className="p-2.5 rounded-lg bg-[#070e1b] hover:bg-[#10223e] border border-[#1d3557] text-slate-200 text-left transition-colors"
              >
                <div className="font-semibold text-white">Lease Pricing</div>
                <div className="text-[10px] text-slate-400">Run cash flows & IRR</div>
              </button>
              <button
                onClick={() => setActiveModule('valuations')}
                className="p-2.5 rounded-lg bg-[#070e1b] hover:bg-[#10223e] border border-[#1d3557] text-slate-200 text-left transition-colors"
              >
                <div className="font-semibold text-white">Valuation Lab</div>
                <div className="text-[10px] text-slate-400">DCF & Residual curves</div>
              </button>
              <button
                onClick={() => setActiveModule('trading')}
                className="p-2.5 rounded-lg bg-[#070e1b] hover:bg-[#10223e] border border-[#1d3557] text-slate-200 text-left transition-colors"
              >
                <div className="font-semibold text-white">Trading Desk</div>
                <div className="text-[10px] text-slate-400">SLB & Disposals</div>
              </button>
              <button
                onClick={() => setActiveModule('ledger')}
                className="p-2.5 rounded-lg bg-[#070e1b] hover:bg-[#10223e] border border-[#1d3557] text-slate-200 text-left transition-colors"
              >
                <div className="font-semibold text-white">Finance Ledger</div>
                <div className="text-[10px] text-slate-400">Double-entry journals</div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
