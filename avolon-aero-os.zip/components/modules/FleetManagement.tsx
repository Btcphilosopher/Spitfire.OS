'use client';

import React, { useState } from 'react';
import { useAero } from '@/lib/AeroContext';
import { AircraftAsset, LeaseStatus } from '@/lib/types';
import {
  Plane,
  Plus,
  Filter,
  Search,
  CheckCircle2,
  AlertCircle,
  Wrench,
  DollarSign,
  Calendar,
  X,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';

export default function FleetManagement() {
  const { aircraft, selectedAircraftId, setSelectedAircraftId, addAircraft, airlines, financing } = useAero();
  const [familyFilter, setFamilyFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // New Aircraft Form State
  const [newReg, setNewReg] = useState('EI-NEW');
  const [newMsn, setNewMsn] = useState('12040');
  const [newFamily, setNewFamily] = useState<'Airbus A321neo' | 'Airbus A320neo' | 'Boeing 737 MAX 8' | 'Boeing 787-9'>('Airbus A321neo');
  const [newOperator, setNewOperator] = useState('Lufthansa Group');
  const [newVal, setNewVal] = useState('65.0');
  const [newRent, setNewRent] = useState('390');

  const filteredAircraft = aircraft.filter((a) => {
    const matchesFamily = familyFilter === 'ALL' || a.family === familyFilter;
    const matchesStatus = statusFilter === 'ALL' || a.leaseStatus === statusFilter;
    const matchesSearch =
      a.registration.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.msn.includes(searchTerm) ||
      a.currentOperatorName.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFamily && matchesStatus && matchesSearch;
  });

  const selectedAsset = aircraft.find((a) => a.id === selectedAircraftId) || aircraft[0];

  const handleCreateAsset = (e: React.FormEvent) => {
    e.preventDefault();
    addAircraft({
      msn: newMsn,
      registration: newReg,
      family: newFamily,
      model: `${newFamily} Standard`,
      manufacturer: newFamily.includes('Airbus') ? 'Airbus' : 'Boeing',
      engineManufacturer: 'CFM International',
      engineModel: 'LEAP-1A',
      manufacturingYear: 2024,
      deliveryDate: '2024-06-01',
      airframeHours: 1200,
      airframeCycles: 450,
      currentOperatorId: 'AL-01',
      currentOperatorName: newOperator,
      ownerEntityId: 'SPV-01',
      ownerEntityName: 'Avolon Ireland Alpha 1 Ltd',
      assetManager: 'Sean O’Connor',
      location: 'Dublin (DUB)',
      leaseStatus: 'ACTIVE',
      technicalStatus: 'AIRWORTHY',
      currentMarketValue: parseFloat(newVal) || 60,
      initialPurchasePrice: parseFloat(newVal) || 60,
      currentNetBookValue: (parseFloat(newVal) || 60) * 0.95,
      estimatedResidualValue2030: (parseFloat(newVal) || 60) * 0.65,
      leaseCommencement: '2024-06-01',
      leaseExpiry: '2036-05-31',
      monthlyBaseRent: parseInt(newRent) || 350,
      securityDeposit: (parseInt(newRent) || 350) * 3,
      maintenanceReserveBalance: 1500,
      financingFacilityId: 'FF-01',
      financingFacilityName: 'Syndicated Term Loan A1',
      imageUrl: '/src/assets/images/hero_aircraft_a321neo_1792913311300.jpg',
      lastValuationDate: '2026-09-30'
    });
    setIsAddModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-xl bg-[#0a172c] border border-[#1d3557]">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Plane className="w-5 h-5 text-blue-400" />
            Aircraft Master Registry & Fleet Management
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Authoritative asset records · Technical specifications · Valuations & Lease ties
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs rounded-lg shadow-sm transition-all flex items-center gap-2 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Register Aircraft Asset</span>
        </button>
      </div>

      {/* Filters Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-[#0a172c] border border-[#1d3557] rounded-xl text-xs">
        <div className="flex flex-wrap items-center gap-2">
          {/* Family Filter */}
          <select
            value={familyFilter}
            onChange={(e) => setFamilyFilter(e.target.value)}
            className="bg-[#070e1b] border border-[#1d3557] rounded-lg px-3 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500 font-mono"
          >
            <option value="ALL">All Aircraft Families</option>
            <option value="Airbus A321neo">Airbus A321neo</option>
            <option value="Airbus A320neo">Airbus A320neo</option>
            <option value="Airbus A330neo">Airbus A330neo</option>
            <option value="Airbus A350-900">Airbus A350-900</option>
            <option value="Boeing 737 MAX 8">Boeing 737 MAX 8</option>
            <option value="Boeing 787-9">Boeing 787-9</option>
            <option value="Embraer E195-E2">Embraer E195-E2</option>
          </select>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-[#070e1b] border border-[#1d3557] rounded-lg px-3 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500 font-mono"
          >
            <option value="ALL">All Lease Statuses</option>
            <option value="ACTIVE">ACTIVE</option>
            <option value="EXPIRING_SOON">EXPIRING_SOON</option>
            <option value="UNDER_REMARKETING">UNDER_REMARKETING</option>
          </select>
        </div>

        {/* Search */}
        <div className="relative w-64">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search Reg, MSN, Airline..."
            className="w-full bg-[#070e1b] border border-[#1d3557] rounded-lg pl-8 pr-3 py-1 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 font-mono"
          />
        </div>
      </div>

      {/* Main Grid: Asset Register Table & Selected Asset Detail Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 cols): Asset Master List */}
        <div className="lg:col-span-2 bg-[#0a172c] border border-[#1d3557] rounded-xl overflow-hidden shadow-sm">
          <div className="p-3 border-b border-[#1d3557] bg-[#070e1b] flex items-center justify-between text-xs font-mono text-slate-400">
            <span>SHOWING {filteredAircraft.length} OF {aircraft.length} ASSETS</span>
            <span>SORTED BY MSN</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-[#1d3557] bg-[#070e1b]/60 text-slate-400 font-mono uppercase text-[10px]">
                  <th className="p-3">REG / MSN</th>
                  <th className="p-3">AIRCRAFT FAMILY</th>
                  <th className="p-3">OPERATOR</th>
                  <th className="p-3 text-right">MARKET VAL</th>
                  <th className="p-3 text-right">MONTHLY RENT</th>
                  <th className="p-3 text-center">STATUS</th>
                  <th className="p-3"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1d3557]/40 font-mono">
                {filteredAircraft.map((item) => {
                  const isSelected = selectedAsset.id === item.id;
                  return (
                    <tr
                      key={item.id}
                      onClick={() => setSelectedAircraftId(item.id)}
                      className={`cursor-pointer transition-colors ${
                        isSelected
                          ? 'bg-blue-900/30 text-white font-semibold'
                          : 'hover:bg-[#10223e] text-slate-300'
                      }`}
                    >
                      <td className="p-3">
                        <div className="font-bold text-white text-xs">{item.registration}</div>
                        <div className="text-[10px] text-slate-400">MSN {item.msn}</div>
                      </td>
                      <td className="p-3">
                        <div className="text-slate-200 font-sans font-medium">{item.family}</div>
                        <div className="text-[10px] text-slate-400">{item.engineManufacturer} {item.engineModel}</div>
                      </td>
                      <td className="p-3 font-sans">{item.currentOperatorName}</td>
                      <td className="p-3 text-right text-emerald-400 font-bold">${item.currentMarketValue}M</td>
                      <td className="p-3 text-right text-slate-200">${item.monthlyBaseRent}k</td>
                      <td className="p-3 text-center">
                        <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                          item.leaseStatus === 'ACTIVE'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/50'
                            : 'bg-amber-950 text-amber-400 border border-amber-800/50'
                        }`}>
                          {item.leaseStatus}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <ChevronRight className="w-4 h-4 text-slate-500 inline" />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Column (1 col): Selected Aircraft Asset Dedicated Inspector Page */}
        <div className="bg-[#0a172c] border border-[#1d3557] rounded-xl overflow-hidden space-y-4 p-5">
          {selectedAsset && (
            <>
              {/* Asset Header Image */}
              <div className="relative h-44 rounded-lg overflow-hidden border border-[#1d3557]">
                <img
                  src={selectedAsset.imageUrl || '/src/assets/images/hero_aircraft_a321neo_1792913311300.jpg'}
                  alt={selectedAsset.registration}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a172c] via-transparent to-transparent" />
                <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between">
                  <div>
                    <div className="text-lg font-bold text-white font-mono">{selectedAsset.registration}</div>
                    <div className="text-xs text-slate-300 font-sans">{selectedAsset.family} (MSN {selectedAsset.msn})</div>
                  </div>
                  <span className="text-xs font-mono text-emerald-400 font-bold bg-[#070e1b]/80 px-2.5 py-1 rounded border border-emerald-800">
                    ${selectedAsset.currentMarketValue}M Market Val
                  </span>
                </div>
              </div>

              {/* Technical Specifications */}
              <div className="space-y-2 border-b border-[#1d3557] pb-4">
                <h3 className="text-xs font-bold text-white tracking-wide uppercase font-mono text-slate-400">Technical Specifications</h3>
                <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-[#070e1b] p-3 rounded-lg border border-[#1d3557]">
                  <div>
                    <div className="text-[10px] text-slate-500">MANUFACTURER</div>
                    <div className="text-slate-200 font-semibold">{selectedAsset.manufacturer}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500">MFG YEAR</div>
                    <div className="text-slate-200 font-semibold">{selectedAsset.manufacturingYear}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500">ENGINE MODEL</div>
                    <div className="text-slate-200 font-semibold">{selectedAsset.engineModel}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500">FLIGHT HOURS (FH)</div>
                    <div className="text-slate-200 font-semibold">{selectedAsset.airframeHours.toLocaleString()} hrs</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500">FLIGHT CYCLES (FC)</div>
                    <div className="text-slate-200 font-semibold">{selectedAsset.airframeCycles.toLocaleString()} cyc</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500">LOCATION</div>
                    <div className="text-slate-200 font-semibold">{selectedAsset.location}</div>
                  </div>
                </div>
              </div>

              {/* Commercial & Lease Details */}
              <div className="space-y-2 border-b border-[#1d3557] pb-4">
                <h3 className="text-xs font-bold text-white tracking-wide uppercase font-mono text-slate-400">Commercial & Lease Terms</h3>
                <div className="space-y-2 text-xs bg-[#070e1b] p-3 rounded-lg border border-[#1d3557]">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Current Operator:</span>
                    <span className="text-white font-bold">{selectedAsset.currentOperatorName}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Monthly Base Rent:</span>
                    <span className="text-emerald-400 font-mono font-bold">${selectedAsset.monthlyBaseRent}k / mo</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Lease Term:</span>
                    <span className="text-slate-300 font-mono">{selectedAsset.leaseCommencement} → {selectedAsset.leaseExpiry}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Security Deposit:</span>
                    <span className="text-slate-200 font-mono">${selectedAsset.securityDeposit}k</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Maint. Reserve Balance:</span>
                    <span className="text-slate-200 font-mono">${selectedAsset.maintenanceReserveBalance}k</span>
                  </div>
                </div>
              </div>

              {/* Lifecycle Timeline */}
              <div className="space-y-2">
                <h3 className="text-xs font-bold text-white tracking-wide uppercase font-mono text-slate-400">Lifecycle Timeline</h3>
                <div className="p-3 rounded-lg bg-[#070e1b] border border-[#1d3557] space-y-2 text-[11px] font-mono">
                  <div className="flex items-center gap-2 text-slate-300">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    <span>MANUFACTURE: Delivered {selectedAsset.deliveryDate}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-300">
                    <span className="w-2 h-2 rounded-full bg-blue-500" />
                    <span>ACTIVE LEASE: {selectedAsset.currentOperatorName}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-400">
                    <span className="w-2 h-2 rounded-full bg-slate-600" />
                    <span>LEASE EXPIRY: {selectedAsset.leaseExpiry}</span>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Add Aircraft Asset Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0a172c] border border-[#1d3557] rounded-xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#1d3557] pb-3">
              <h2 className="text-base font-bold text-white">Register New Aircraft Asset</h2>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateAsset} className="space-y-3 text-xs font-mono">
              <div>
                <label className="text-slate-400 block mb-1">Aircraft Registration</label>
                <input
                  type="text"
                  value={newReg}
                  onChange={(e) => setNewReg(e.target.value)}
                  className="w-full bg-[#070e1b] border border-[#1d3557] rounded p-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">MSN (Manufacturer Serial Number)</label>
                <input
                  type="text"
                  value={newMsn}
                  onChange={(e) => setNewMsn(e.target.value)}
                  className="w-full bg-[#070e1b] border border-[#1d3557] rounded p-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Aircraft Family</label>
                <select
                  value={newFamily}
                  onChange={(e) => setNewFamily(e.target.value as any)}
                  className="w-full bg-[#070e1b] border border-[#1d3557] rounded p-2 text-white"
                >
                  <option value="Airbus A321neo">Airbus A321neo</option>
                  <option value="Airbus A320neo">Airbus A320neo</option>
                  <option value="Boeing 737 MAX 8">Boeing 737 MAX 8</option>
                  <option value="Boeing 787-9">Boeing 787-9</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Lessee Airline Operator</label>
                <input
                  type="text"
                  value={newOperator}
                  onChange={(e) => setNewOperator(e.target.value)}
                  className="w-full bg-[#070e1b] border border-[#1d3557] rounded p-2 text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Market Val ($M)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={newVal}
                    onChange={(e) => setNewVal(e.target.value)}
                    className="w-full bg-[#070e1b] border border-[#1d3557] rounded p-2 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Monthly Rent ($k)</label>
                  <input
                    type="number"
                    value={newRent}
                    onChange={(e) => setNewRent(e.target.value)}
                    className="w-full bg-[#070e1b] border border-[#1d3557] rounded p-2 text-white"
                    required
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2 font-sans">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-[#070e1b] text-slate-300 rounded hover:bg-[#10223e]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded"
                >
                  Confirm & Register Asset
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
