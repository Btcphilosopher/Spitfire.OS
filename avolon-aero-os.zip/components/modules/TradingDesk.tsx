'use client';

import React from 'react';
import { useAero } from '@/lib/AeroContext';
import { ArrowRightLeft, DollarSign, TrendingUp, CheckCircle2, AlertTriangle, ShieldCheck } from 'lucide-react';

export default function TradingDesk() {
  const { trading } = useAero();

  const pipelineStages = ['ORIGINATION', 'DUE_DILIGENCE', 'STRUCTURING', 'CREDIT_APPROVAL', 'CLOSING'];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-xl bg-[#0a172c] border border-[#1d3557]">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <ArrowRightLeft className="w-5 h-5 text-blue-400" />
            Aircraft Trading & Acquisitions Desk
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Acquisitions · Disposals · Sale-and-Leaseback (SLB) transactions · Pipeline return optimization
          </p>
        </div>

        <div className="text-xs font-mono text-emerald-400 bg-[#070e1b] px-3 py-1.5 rounded-lg border border-[#1d3557]">
          ${trading.reduce((acc, t) => acc + t.proposedPriceMillions, 0)}M TOTAL DEAL PIPELINE
        </div>
      </div>

      {/* Pipeline Stage Swimlanes */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
        {pipelineStages.map((stage) => {
          const stageDeals = trading.filter((t) => t.stage === stage);

          return (
            <div key={stage} className="bg-[#0a172c] border border-[#1d3557] rounded-xl p-3 space-y-3">
              <div className="border-b border-[#1d3557] pb-2 flex items-center justify-between font-mono text-xs">
                <span className="font-bold text-slate-300 text-[11px]">{stage.replace('_', ' ')}</span>
                <span className="text-slate-400 bg-[#070e1b] px-1.5 py-0.5 rounded border border-[#1d3557]">
                  {stageDeals.length}
                </span>
              </div>

              <div className="space-y-2">
                {stageDeals.map((deal) => (
                  <div key={deal.id} className="p-3 rounded-lg bg-[#070e1b] border border-[#1d3557] space-y-2 text-xs font-mono">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-blue-400 bg-blue-950 px-1.5 py-0.5 rounded border border-blue-800">
                        {deal.type}
                      </span>
                      <span className="text-emerald-400 font-bold">${deal.proposedPriceMillions}M</span>
                    </div>

                    <div className="font-bold text-white font-sans text-xs">{deal.aircraftOrPortfolioName}</div>
                    <div className="text-[11px] text-slate-400 font-sans">Counterparty: {deal.counterparty}</div>

                    <div className="pt-2 border-t border-[#1d3557]/60 flex items-center justify-between text-[11px]">
                      <span className="text-slate-400">Projected IRR:</span>
                      <span className="text-blue-400 font-bold">{deal.projectedIrrPct}%</span>
                    </div>
                  </div>
                ))}

                {stageDeals.length === 0 && (
                  <div className="text-[11px] text-slate-500 font-mono italic text-center py-6 border border-dashed border-[#1d3557] rounded-lg">
                    No active deals in stage
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Trading Comparison Matrix */}
      <div className="bg-[#0a172c] border border-[#1d3557] rounded-xl p-5 space-y-4">
        <h2 className="text-sm font-bold text-white font-mono uppercase tracking-wide">Active Trading Deals Comparison Matrix</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b border-[#1d3557] bg-[#070e1b]/60 text-slate-400 uppercase text-[10px]">
                <th className="p-3">DEAL ID</th>
                <th className="p-3">TRANSACTION TYPE</th>
                <th className="p-3">TARGET ASSET / PORTFOLIO</th>
                <th className="p-3">COUNTERPARTY</th>
                <th className="p-3 text-right">PROPOSED PRICE</th>
                <th className="p-3 text-right">VALUATION</th>
                <th className="p-3 text-right">PROJECTED IRR</th>
                <th className="p-3 text-center">STAGE</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1d3557]/40">
              {trading.map((item) => (
                <tr key={item.id} className="hover:bg-[#10223e] text-slate-200">
                  <td className="p-3 font-bold text-white">{item.id}</td>
                  <td className="p-3 text-blue-400 font-bold">{item.type}</td>
                  <td className="p-3 font-sans font-medium text-white">{item.aircraftOrPortfolioName}</td>
                  <td className="p-3 font-sans">{item.counterparty}</td>
                  <td className="p-3 text-right text-emerald-400 font-bold">${item.proposedPriceMillions}M</td>
                  <td className="p-3 text-right text-slate-300">${item.valuationMillions}M</td>
                  <td className="p-3 text-right text-blue-400 font-bold">{item.projectedIrrPct}%</td>
                  <td className="p-3 text-center">
                    <span className="text-[10px] px-2 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800">
                      {item.stage}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
