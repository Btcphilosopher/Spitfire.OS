'use client';

import React from 'react';
import { useAero } from '@/lib/AeroContext';
import { CheckSquare, Check, X, ShieldAlert, FileText, UserCheck, Clock } from 'lucide-react';

export default function DocumentsAndApprovals() {
  const { approvals, approveTask } = useAero();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-xl bg-[#0a172c] border border-[#1d3557]">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <CheckSquare className="w-5 h-5 text-blue-400" />
            Transaction Workflow & Approval Task Centre
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Role-based segregation-of-duties · Approval policies · Real-time ledger posting on sign-off
          </p>
        </div>

        <div className="text-xs font-mono text-amber-400 bg-[#070e1b] px-3 py-1.5 rounded-lg border border-[#1d3557]">
          {approvals.filter(a => a.status === 'PENDING').length} PENDING DECISIONS REQUIRING ACTION
        </div>
      </div>

      {/* Approval Tasks Cards */}
      <div className="space-y-4">
        {approvals.map((task) => (
          <div
            key={task.id}
            className={`p-5 rounded-xl border transition-all space-y-3 ${
              task.status === 'PENDING'
                ? 'bg-[#0a172c] border-blue-500/50 shadow-md'
                : 'bg-[#070e1b] border-[#1d3557] opacity-80'
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#1d3557] pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-blue-400">{task.id}</span>
                  <span className="text-xs font-mono font-bold text-slate-400 bg-[#070e1b] px-2 py-0.5 rounded border border-[#1d3557]">
                    {task.category}
                  </span>
                </div>
                <h2 className="text-sm font-bold text-white font-sans mt-1">{task.title}</h2>
              </div>

              <div className="flex items-center gap-2 font-mono">
                <span className="text-emerald-400 font-bold text-sm">${task.amountMillions}M</span>
                <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                  task.status === 'PENDING'
                    ? 'bg-amber-950 text-amber-400 border border-amber-800'
                    : task.status === 'APPROVED'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      : 'bg-red-950 text-red-400 border border-red-800'
                }`}>
                  {task.status}
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">{task.details}</p>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 text-xs font-mono">
              <div className="text-slate-400">
                Requested by: <span className="text-slate-200 font-semibold">{task.requestedBy}</span> · {task.timestamp}
              </div>

              {task.status === 'PENDING' && (
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => approveTask(task.id, 'REJECTED')}
                    className="px-3 py-1.5 bg-red-950 hover:bg-red-900 text-red-200 border border-red-800 rounded font-semibold text-xs transition-colors flex items-center gap-1"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>Reject Request</span>
                  </button>
                  <button
                    onClick={() => approveTask(task.id, 'APPROVED')}
                    className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-bold text-xs shadow transition-all flex items-center gap-1"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Approve & Post</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
