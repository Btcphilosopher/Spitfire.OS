'use client';

import React from 'react';
import { useAero } from '@/lib/AeroContext';
import { Search, Sparkles, Bell, ShieldCheck, Smartphone, Tablet, Monitor } from 'lucide-react';

interface HeaderProps {
  deviceMode: 'desktop' | 'tablet' | 'mobile';
  setDeviceMode: (mode: 'desktop' | 'tablet' | 'mobile') => void;
}

export default function Header({ deviceMode, setDeviceMode }: HeaderProps) {
  const { searchQuery, setSearchQuery, isAiDrawerOpen, setIsAiDrawerOpen, kpis, setActiveModule } = useAero();

  return (
    <header className="h-16 border-b border-[#1d3557] bg-[#0a172c] px-6 flex items-center justify-between gap-6 shrink-0 z-30 shadow-md">
      {/* Zone 1: Brand Wordmark (Compliant with Top Bar Contract: 1 line single element) */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-900 flex items-center justify-center font-bold text-white text-lg tracking-wider border border-blue-400/30 shadow-inner">
          AV
        </div>
        <div>
          <a
            href="#"
            onClick={(e) => { e.preventDefault(); setActiveModule('command-centre'); }}
            className="text-base font-bold tracking-tight text-white hover:text-blue-400 transition-colors whitespace-nowrap block"
          >
            AVOLON AERO OS
          </a>
          <span className="text-[10px] text-slate-400 tracking-wider font-mono block">DUBLIN EXECUTIVE EDITION</span>
        </div>
      </div>

      {/* Zone 2: Universal Search & Operational Context */}
      <div className="flex-1 max-w-xl mx-auto hidden md:block">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Universal Search: Registration (EI-GLN), MSN, Airline, Lease ID, Debt Facility..."
            className="w-full bg-[#070e1b] border border-[#1d3557] rounded-lg pl-10 pr-4 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all font-mono"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Zone 3: Device Mode Selector, Aero Intelligence AI Trigger, Pending Approvals */}
      <div className="flex items-center gap-3 shrink-0">
        {/* Device View Selector for Testing Responsive Tablet & Mobile Companion */}
        <div className="hidden lg:flex items-center bg-[#070e1b] border border-[#1d3557] rounded-lg p-1 text-xs">
          <button
            onClick={() => setDeviceMode('desktop')}
            title="Desktop Mode"
            className={`p-1.5 rounded transition-all ${deviceMode === 'desktop' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <Monitor className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setDeviceMode('tablet')}
            title="Tablet Inspector Mode"
            className={`p-1.5 rounded transition-all ${deviceMode === 'tablet' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <Tablet className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setDeviceMode('mobile')}
            title="Executive Mobile View"
            className={`p-1.5 rounded transition-all ${deviceMode === 'mobile' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <Smartphone className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Pending Approvals Quick Alert */}
        <button
          onClick={() => setActiveModule('approvals')}
          className="relative p-2 text-slate-300 hover:text-white bg-[#070e1b] hover:bg-[#10223e] border border-[#1d3557] rounded-lg transition-colors"
          title="Pending Approval Tasks"
        >
          <Bell className="w-4 h-4" />
          {kpis.pendingApprovalsCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-amber-500 text-slate-950 font-bold text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-mono">
              {kpis.pendingApprovalsCount}
            </span>
          )}
        </button>

        {/* Aero Intelligence Trigger */}
        <button
          onClick={() => setIsAiDrawerOpen(!isAiDrawerOpen)}
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all border shadow-sm ${
            isAiDrawerOpen
              ? 'bg-blue-600 text-white border-blue-400 shadow-blue-900/50'
              : 'bg-gradient-to-r from-blue-900/60 to-indigo-900/60 hover:from-blue-800 hover:to-indigo-800 text-blue-200 border-blue-500/40'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
          <span className="whitespace-nowrap shrink-0">Aero Intelligence</span>
        </button>

        {/* Executive Profile Avatar */}
        <div className="flex items-center gap-2 pl-2 border-l border-[#1d3557]">
          <img
            src="/src/assets/images/avatar_relationship_manager_1792913311000.jpg"
            alt="Sean O'Connor Executive"
            className="w-8 h-8 rounded-full border border-blue-400/40 object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="hidden xl:block text-left">
            <div className="text-xs font-semibold text-white leading-tight">Sean O’Connor</div>
            <div className="text-[10px] text-slate-400 font-mono leading-tight">VP Senior Trader</div>
          </div>
        </div>
      </div>
    </header>
  );
}
