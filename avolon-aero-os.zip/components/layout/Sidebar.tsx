'use client';

import React from 'react';
import { useAero, ActiveModule } from '@/lib/AeroContext';
import {
  LayoutDashboard,
  Plane,
  Building2,
  FileText,
  TrendingUp,
  Truck,
  Wrench,
  ArrowRightLeft,
  Landmark,
  Calculator,
  ShieldAlert,
  Compass,
  CheckSquare,
  BookOpen,
  Boxes,
  PieChart
} from 'lucide-react';

interface NavItem {
  id: ActiveModule;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number | string;
  isFlagship?: boolean;
}

export default function Sidebar() {
  const { activeModule, setActiveModule, kpis } = useAero();

  const primaryNav: NavItem[] = [
    { id: 'command-centre', label: 'Command Centre', icon: LayoutDashboard },
    { id: 'fleet', label: 'Fleet Registry', icon: Plane, badge: kpis.totalAircraft },
    { id: 'airlines', label: 'Airlines & Credit', icon: Building2 },
    { id: 'leases', label: 'Lease Administration', icon: FileText, badge: kpis.activeLeases },
    { id: 'portfolio-2030', label: 'Aero Portfolio 2030', icon: Compass, isFlagship: true },
    { id: 'trading', label: 'Trading & Acquisitions', icon: ArrowRightLeft },
    { id: 'deliveries', label: 'Delivery Control', icon: Truck, badge: kpis.awaitingDelivery },
    { id: 'technical-assets', label: 'Technical Assets', icon: Wrench, badge: kpis.maintenanceAlertsCount },
    { id: 'treasury', label: 'Treasury & Debt', icon: Landmark },
    { id: 'valuations', label: 'Valuation Lab', icon: Calculator },
    { id: 'credit-risk', label: 'Risk & Stress Lab', icon: ShieldAlert },
    { id: 'approvals', label: 'Workflows & Approvals', icon: CheckSquare, badge: kpis.pendingApprovalsCount },
    { id: 'ledger', label: 'Finance Ledger', icon: BookOpen },
    { id: 'entities', label: 'Legal Entities & SPVs', icon: Boxes },
    { id: 'analytics', label: 'Investor Analytics', icon: PieChart }
  ];

  return (
    <aside className="w-64 bg-[#0a172c] border-r border-[#1d3557] flex flex-col shrink-0 overflow-y-auto">
      {/* Platform Title */}
      <div className="p-4 border-b border-[#1d3557]/60">
        <div className="text-[11px] font-mono text-slate-400 uppercase tracking-widest font-semibold">
          AVOLON OPERATING SYSTEM
        </div>
        <div className="text-xs text-blue-400 font-medium mt-0.5">
          Dublin · Singapore · New York
        </div>
      </div>

      {/* Navigation Group */}
      <nav className="flex-1 p-3 space-y-1">
        {primaryNav.map((item) => {
          const Icon = item.icon;
          const isActive = activeModule === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveModule(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all group ${
                isActive
                  ? item.isFlagship
                    ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white font-semibold shadow-md border border-amber-400/40'
                    : 'bg-blue-600/90 text-white font-semibold shadow-sm border border-blue-400/30'
                  : item.isFlagship
                    ? 'text-amber-300 hover:bg-amber-950/40 hover:text-amber-200 border border-amber-500/20'
                    : 'text-slate-300 hover:bg-[#10223e] hover:text-white'
              }`}
            >
              <div className="flex items-center gap-2.5 truncate">
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : item.isFlagship ? 'text-amber-400' : 'text-slate-400 group-hover:text-blue-400'}`} />
                <span className="truncate">{item.label}</span>
              </div>

              {item.badge !== undefined && (
                <span className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                  isActive
                    ? 'bg-white/20 text-white'
                    : 'bg-[#070e1b] text-slate-400 border border-[#1d3557]'
                }`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Bottom System Status */}
      <div className="p-4 border-t border-[#1d3557] bg-[#070e1b]/60 text-xs">
        <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono">
          <span>PORTFOLIO NAV</span>
          <span className="text-emerald-400 font-bold">${kpis.portfolioNavMillions}M</span>
        </div>
        <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono mt-1">
          <span>UTILIZATION</span>
          <span className="text-white font-semibold">{kpis.fleetUtilizationPct}%</span>
        </div>
        <div className="mt-3 text-[10px] text-slate-500 text-center font-mono">
          Avolon Aero OS v4.8 · Production
        </div>
      </div>
    </aside>
  );
}
