'use client';

import React, { useState } from 'react';
import { useAero } from '@/lib/AeroContext';
import { Sparkles, X, Send, Bot, User, CheckCircle2, AlertTriangle, RefreshCw } from 'lucide-react';

export default function AeroAiDrawer() {
  const { isAiDrawerOpen, setIsAiDrawerOpen, aircraft, leases, airlines, kpis, deliveries, financing } = useAero();
  const [messages, setMessages] = useState<{ role: 'user' | 'assistant'; text: string; timestamp: string }[]>([
    {
      role: 'assistant',
      text: "Welcome to **Aero Intelligence**. I am connected directly to Avolon Aero OS domain records.\n\nI can assist you with:\n- Cash flow forecasts and lease rate analysis\n- Portfolio concentration and credit risk alerts\n- Delivery delays and funding requirements\n- Scenario comparisons for Aero Portfolio 2030\n\nHow can I analyze your fleet today?",
      timestamp: '09:00'
    }
  ]);
  const [inputPrompt, setInputPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isAiDrawerOpen) return null;

  const handleSend = async (customText?: string) => {
    const textToSend = customText || inputPrompt;
    if (!textToSend.trim() || isLoading) return;

    const userMsg = {
      role: 'user' as const,
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    if (!customText) setInputPrompt('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: textToSend,
          portfolioContext: {
            kpis,
            aircraftCount: aircraft.length,
            sampleAircraft: aircraft.map(a => ({ reg: a.registration, msn: a.msn, family: a.family, operator: a.currentOperatorName, val: a.currentMarketValue, rent: a.monthlyBaseRent })),
            sampleLeases: leases.map(l => ({ leaseNo: l.leaseNumber, lessee: l.lesseeName, baseRent: l.baseMonthlyRent, expiry: l.expiryDate })),
            airlines: airlines.map(al => ({ name: al.name, rating: al.creditRating, exposure: al.outstandingExposure, overdue: al.overdueRentals })),
            deliveriesCount: deliveries.length,
            totalDebt: financing.reduce((acc, f) => acc + f.drawnAmountMillions, 0)
          }
        })
      });

      const data = await res.json();
      if (data.text) {
        setMessages(prev => [
          ...prev,
          {
            role: 'assistant',
            text: data.text,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
      } else {
        throw new Error(data.error || 'No response text');
      }
    } catch (err: any) {
      setMessages(prev => [
        ...prev,
        {
          role: 'assistant',
          text: `**System Note**: Failed to reach Aero Intelligence server. Error: ${err.message}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const samplePrompts = [
    "Summarise portfolio concentration across narrow-body vs wide-body aircraft.",
    "Which airlines have overdue rentals or elevated credit exposure?",
    "Explain the lease cash flow profile for Lufthansa's A321neo (EI-GLN).",
    "What is the impact if LATAM lease expiry is extended by 24 months?"
  ];

  return (
    <aside className="fixed inset-y-0 right-0 w-96 bg-[#0a172c] border-l border-[#1d3557] z-50 flex flex-col shadow-2xl">
      {/* Header */}
      <div className="p-4 border-b border-[#1d3557] flex items-center justify-between bg-[#070e1b]">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30">
            <Sparkles className="w-4 h-4 text-amber-400" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white tracking-wide">Aero Intelligence</h3>
            <div className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Grounded on Avolon Domain State
            </div>
          </div>
        </div>

        <button
          onClick={() => setIsAiDrawerOpen(false)}
          className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-[#10223e] transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div className="flex items-center gap-1.5 mb-1 text-[10px] text-slate-400 font-mono">
              {msg.role === 'assistant' ? (
                <>
                  <Bot className="w-3 h-3 text-blue-400" />
                  <span>Aero Intelligence</span>
                </>
              ) : (
                <>
                  <span>Executive User</span>
                  <User className="w-3 h-3 text-slate-300" />
                </>
              )}
              <span>·</span>
              <span>{msg.timestamp}</span>
            </div>

            <div
              className={`p-3 rounded-lg leading-relaxed max-w-[92%] whitespace-pre-line ${
                msg.role === 'user'
                  ? 'bg-blue-600 text-white font-medium shadow-sm'
                  : 'bg-[#070e1b] border border-[#1d3557] text-slate-200 shadow-inner'
              }`}
            >
              {msg.text}
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center gap-2 text-slate-400 text-xs font-mono py-2">
            <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-400" />
            <span>Analyzing domain records & modeling cash flows...</span>
          </div>
        )}
      </div>

      {/* Suggested Quick Prompts */}
      <div className="p-3 border-t border-[#1d3557]/60 bg-[#070e1b]/40 space-y-1.5">
        <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Executive Queries:</div>
        <div className="flex flex-col gap-1">
          {samplePrompts.slice(0, 2).map((promptText, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(promptText)}
              className="text-left text-[11px] p-1.5 rounded bg-[#0a172c] hover:bg-[#10223e] border border-[#1d3557] text-slate-300 hover:text-white transition-colors truncate"
            >
              {promptText}
            </button>
          ))}
        </div>
      </div>

      {/* Input Box */}
      <div className="p-3 border-t border-[#1d3557] bg-[#070e1b]">
        <div className="relative">
          <textarea
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Ask Aero Intelligence about fleet, cash flows, airlines, or scenario risk..."
            rows={2}
            className="w-full bg-[#0a172c] border border-[#1d3557] rounded-lg p-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-500 resize-none font-sans"
          />
          <button
            onClick={() => handleSend()}
            disabled={isLoading || !inputPrompt.trim()}
            className="absolute right-2 bottom-3 p-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-md disabled:opacity-40 transition-all"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </aside>
  );
}
