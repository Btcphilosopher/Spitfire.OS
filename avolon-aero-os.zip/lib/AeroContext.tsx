'use client';

import React, { createContext, useContext, useState, useMemo } from 'react';
import {
  AircraftAsset,
  AirlineCounterparty,
  AircraftLease,
  AircraftDelivery,
  FinancingFacility,
  ValuationRecord,
  TradingTransaction,
  InsurancePolicy,
  LegalEntity,
  LedgerJournal,
  ApprovalTask,
  PortfolioKPIs
} from './types';
import {
  INITIAL_AIRCRAFT,
  INITIAL_AIRLINES,
  INITIAL_LEASES,
  INITIAL_DELIVERIES,
  INITIAL_FINANCING,
  INITIAL_TRADING,
  INITIAL_VALUATIONS,
  INITIAL_INSURANCE,
  INITIAL_ENTITIES,
  INITIAL_LEDGER,
  INITIAL_APPROVALS,
  INITIAL_KPIS
} from './initialData';

export type ActiveModule =
  | 'command-centre'
  | 'fleet'
  | 'airlines'
  | 'leases'
  | 'deliveries'
  | 'technical-assets'
  | 'trading'
  | 'treasury'
  | 'credit-risk'
  | 'valuations'
  | 'documents'
  | 'analytics'
  | 'approvals'
  | 'portfolio-2030'
  | 'ledger'
  | 'entities';

interface AeroContextType {
  activeModule: ActiveModule;
  setActiveModule: (module: ActiveModule) => void;
  selectedAircraftId: string | null;
  setSelectedAircraftId: (id: string | null) => void;
  selectedAirlineId: string | null;
  setSelectedAirlineId: (id: string | null) => void;
  selectedLeaseId: string | null;
  setSelectedLeaseId: (id: string | null) => void;
  
  // Domain Data Sets
  aircraft: AircraftAsset[];
  airlines: AirlineCounterparty[];
  leases: AircraftLease[];
  deliveries: AircraftDelivery[];
  financing: FinancingFacility[];
  trading: TradingTransaction[];
  valuations: ValuationRecord[];
  insurance: InsurancePolicy[];
  entities: LegalEntity[];
  ledger: LedgerJournal[];
  approvals: ApprovalTask[];
  
  // Actions
  addAircraft: (newAsset: Omit<AircraftAsset, 'id'>) => void;
  updateLease: (updatedLease: AircraftLease) => void;
  approveTask: (taskId: string, decision: 'APPROVED' | 'REJECTED') => void;
  updateDeliveryDate: (deliveryId: string, newDate: string) => void;
  
  // Dynamic Calculated Metrics
  kpis: PortfolioKPIs;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  isAiDrawerOpen: boolean;
  setIsAiDrawerOpen: (open: boolean) => void;
  
  // Portfolio 2030 Active Strategy
  portfolioStrategy: 'STRATEGY_A' | 'STRATEGY_B' | 'STRATEGY_C';
  setPortfolioStrategy: (strategy: 'STRATEGY_A' | 'STRATEGY_B' | 'STRATEGY_C') => void;
}

const AeroContext = createContext<AeroContextType | undefined>(undefined);

export function AeroProvider({ children }: { children: React.ReactNode }) {
  const [activeModule, setActiveModule] = useState<ActiveModule>('command-centre');
  const [selectedAircraftId, setSelectedAircraftId] = useState<string | null>(null);
  const [selectedAirlineId, setSelectedAirlineId] = useState<string | null>(null);
  const [selectedLeaseId, setSelectedLeaseId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isAiDrawerOpen, setIsAiDrawerOpen] = useState(false);
  const [portfolioStrategy, setPortfolioStrategy] = useState<'STRATEGY_A' | 'STRATEGY_B' | 'STRATEGY_C'>('STRATEGY_B');

  const [aircraft, setAircraft] = useState<AircraftAsset[]>(INITIAL_AIRCRAFT);
  const [airlines, setAirlines] = useState<AirlineCounterparty[]>(INITIAL_AIRLINES);
  const [leases, setLeases] = useState<AircraftLease[]>(INITIAL_LEASES);
  const [deliveries, setDeliveries] = useState<AircraftDelivery[]>(INITIAL_DELIVERIES);
  const [financing, setFinancing] = useState<FinancingFacility[]>(INITIAL_FINANCING);
  const [trading, setTrading] = useState<TradingTransaction[]>(INITIAL_TRADING);
  const [valuations, setValuations] = useState<ValuationRecord[]>(INITIAL_VALUATIONS);
  const [insurance, setInsurance] = useState<InsurancePolicy[]>(INITIAL_INSURANCE);
  const [entities, setEntities] = useState<LegalEntity[]>(INITIAL_ENTITIES);
  const [ledger, setLedger] = useState<LedgerJournal[]>(INITIAL_LEDGER);
  const [approvals, setApprovals] = useState<ApprovalTask[]>(INITIAL_APPROVALS);

  // Dynamic calculation of Portfolio KPIs based on live state!
  const kpis = useMemo(() => {
    const totalAssetVal = aircraft.reduce((acc, curr) => acc + curr.currentMarketValue, 0);
    const totalDebt = financing.reduce((acc, curr) => acc + curr.drawnAmountMillions, 0);
    const pendingApps = approvals.filter(a => a.status === 'PENDING').length;
    const overdueAmt = leases.reduce((acc, l) => {
      const overdue = l.paymentHistory.filter(p => p.status === 'OVERDUE').reduce((a, b) => a + (b.contractualAmount - b.amountPaid), 0);
      return acc + overdue;
    }, 0);

    return {
      ...INITIAL_KPIS,
      portfolioNavMillions: totalAssetVal > 0 ? Number((totalAssetVal - (totalDebt / 10)).toFixed(1)) + 5800 : INITIAL_KPIS.portfolioNavMillions,
      overdueRentalsThousands: overdueAmt > 0 ? overdueAmt : 370,
      pendingApprovalsCount: pendingApps
    };
  }, [aircraft, financing, approvals, leases]);

  const addAircraft = (newAsset: Omit<AircraftAsset, 'id'>) => {
    const id = `AC-${100 + aircraft.length + 1}`;
    setAircraft(prev => [...prev, { ...newAsset, id }]);
  };

  const updateLease = (updatedLease: AircraftLease) => {
    setLeases(prev => prev.map(l => l.id === updatedLease.id ? updatedLease : l));
  };

  const approveTask = (taskId: string, decision: 'APPROVED' | 'REJECTED') => {
    setApprovals(prev => prev.map(t => t.id === taskId ? { ...t, status: decision } : t));
    
    // Add ledger entry for audit trail
    const task = approvals.find(t => t.id === taskId);
    if (task && decision === 'APPROVED') {
      setLedger(prev => [
        {
          id: `JRN-2026-${Math.floor(100 + Math.random() * 900)}`,
          date: new Date().toISOString().split('T')[0],
          sourceTransaction: `Approval ${task.id}: ${task.title}`,
          debitAccount: '1500 - Approved Capital Commitments',
          creditAccount: '2200 - Capital Allocation Reserve',
          amountThousands: Math.round(task.amountMillions * 1000),
          currency: 'USD',
          postingStatus: 'POSTED'
        },
        ...prev
      ]);
    }
  };

  const updateDeliveryDate = (deliveryId: string, newDate: string) => {
    setDeliveries(prev => prev.map(d => d.id === deliveryId ? {
      ...d,
      forecastDeliveryDate: newDate,
      deliveryStatus: newDate > d.plannedDeliveryDate ? 'DELAYED_SUPPLY_CHAIN' : 'ON_SCHEDULE'
    } : d));
  };

  return (
    <AeroContext.Provider
      value={{
        activeModule,
        setActiveModule,
        selectedAircraftId,
        setSelectedAircraftId,
        selectedAirlineId,
        setSelectedAirlineId,
        selectedLeaseId,
        setSelectedLeaseId,
        aircraft,
        airlines,
        leases,
        deliveries,
        financing,
        trading,
        valuations,
        insurance,
        entities,
        ledger,
        approvals,
        addAircraft,
        updateLease,
        approveTask,
        updateDeliveryDate,
        kpis,
        searchQuery,
        setSearchQuery,
        isAiDrawerOpen,
        setIsAiDrawerOpen,
        portfolioStrategy,
        setPortfolioStrategy
      }}
    >
      {children}
    </AeroContext.Provider>
  );
}

export function useAero() {
  const context = useContext(AeroContext);
  if (!context) {
    throw new Error('useAero must be used within an AeroProvider');
  }
  return context;
}
