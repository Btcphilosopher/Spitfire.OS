export type LeaseStatus = 
  | 'ACTIVE' 
  | 'PENDING_DELIVERY' 
  | 'UNDER_REMARKETING' 
  | 'RESTRUCTURED' 
  | 'EXPIRING_SOON'
  | 'IN_DEFAULT';

export type TechnicalStatus = 'AIRWORTHY' | 'SHOP_VISIT_DUE' | 'INSPECTION_PENDING' | 'HEAVY_MAINTENANCE';

export interface AircraftAsset {
  id: string;
  msn: string;
  registration: string;
  family: 'Airbus A320neo' | 'Airbus A321neo' | 'Airbus A330neo' | 'Airbus A350-900' | 'Boeing 737 MAX 8' | 'Boeing 787-9' | 'Embraer E195-E2';
  model: string;
  manufacturer: 'Airbus' | 'Boeing' | 'Embraer';
  engineManufacturer: 'CFM International' | 'Pratt & Whitney' | 'General Electric' | 'Rolls-Royce';
  engineModel: string;
  manufacturingYear: number;
  deliveryDate: string;
  airframeHours: number;
  airframeCycles: number;
  currentOperatorId: string;
  currentOperatorName: string;
  ownerEntityId: string;
  ownerEntityName: string;
  assetManager: string;
  location: string;
  leaseStatus: LeaseStatus;
  technicalStatus: TechnicalStatus;
  currentMarketValue: number; // $ Millions
  initialPurchasePrice: number; // $ Millions
  currentNetBookValue: number; // $ Millions
  estimatedResidualValue2030: number; // $ Millions
  leaseCommencement: string;
  leaseExpiry: string;
  monthlyBaseRent: number; // $ Thousands
  securityDeposit: number; // $ Thousands
  maintenanceReserveBalance: number; // $ Thousands
  financingFacilityId: string;
  financingFacilityName: string;
  imageUrl?: string;
  lastValuationDate: string;
}

export interface AirlineCounterparty {
  id: string;
  name: string;
  iata: string;
  country: string;
  region: 'EMEA' | 'AMER' | 'APAC';
  creditRating: string;
  internalCreditRating: string;
  creditLimit: number; // $ Millions
  outstandingExposure: number; // $ Millions
  leasedAircraftCount: number;
  paymentPerformanceScore: number; // 0-100
  overdueRentals: number; // $ Thousands
  covenantStatus: 'COMPLIANT' | 'WATCHLIST' | 'BREACH';
  financials: {
    leverageRatio: number;
    interestCoverage: number;
    dscr: number;
    cashLiquidityRatio: number;
  };
  relationshipManager: string;
  reviewDate: string;
}

export interface AircraftLease {
  id: string;
  leaseNumber: string;
  aircraftId: string;
  aircraftRegistration: string;
  aircraftFamily: string;
  lesseeId: string;
  lesseeName: string;
  lessorEntity: string;
  leaseType: 'OPERATING_LEASE' | 'SALE_AND_LEASEBACK' | 'MANAGED_PORTFOLIO' | 'FINANCE_LEASE';
  status: 'ACTIVE' | 'DRAFT' | 'PRICED' | 'CREDIT_REVIEW' | 'EXECUTED' | 'EXPIRING' | 'AMENDED' | 'IN_DEFAULT';
  commencementDate: string;
  expiryDate: string;
  leaseTermMonths: number;
  baseMonthlyRent: number; // $ Thousands
  rentalCurrency: 'USD' | 'EUR' | 'GBP';
  paymentFrequency: 'MONTHLY' | 'QUARTERLY';
  escalationRatePct: number;
  securityDeposit: number; // $ Thousands
  maintenanceReserveRateFH: number; // $ per flight hour
  maintenanceReserveRateFC: number; // $ per cycle
  unleveredIrrPct: number;
  equityIrrPct: number;
  npvMillions: number;
  paymentHistory: {
    period: string;
    dueDate: string;
    contractualAmount: number;
    amountPaid: number;
    status: 'PAID' | 'OVERDUE' | 'PARTIAL' | 'PENDING';
  }[];
}

export interface AircraftDelivery {
  id: string;
  aircraftFamily: string;
  model: string;
  msn: string;
  manufacturer: 'Airbus' | 'Boeing' | 'Embraer';
  customerAirline: string;
  plannedDeliveryDate: string;
  contractualDeliveryWindow: string;
  forecastDeliveryDate: string;
  deliveryStatus: 'ON_SCHEDULE' | 'DELAYED_SUPPLY_CHAIN' | 'TECHNICAL_ACCEPTANCE' | 'DELIVERED';
  preDeliveryPaymentsMillion: number;
  technicalAcceptanceScore: number; // 0 - 100
  openDiscrepanciesCount: number;
  riskRating: 'LOW' | 'MEDIUM' | 'HIGH';
  checklists: { item: string; completed: boolean; owner: string }[];
}

export interface TechnicalRecord {
  id: string;
  aircraftId: string;
  registration: string;
  airframeHours: number;
  airframeCycles: number;
  engine1Hours: number;
  engine1Cycles: number;
  engine2Hours: number;
  engine2Cycles: number;
  nextCCheckDue: string;
  nextDCheckDue: string;
  engine1ShopVisitDue: string;
  engine2ShopVisitDue: string;
  landingGearOverhaulDue: string;
  airworthinessDirectivesOpen: number;
  maintenanceReserveBalanceThousand: number;
  recentInspections: {
    date: string;
    type: string;
    inspector: string;
    result: 'PASSED' | 'ACTION_REQUIRED' | 'CONDITIONALLY_APPROVED';
  }[];
}

export interface FinancingFacility {
  id: string;
  facilityName: string;
  type: 'SECURED_SYNDICATED' | 'UNSECURED_BOND' | 'REVOLVING_CREDIT' | 'WAREHOUSE_FACILITY';
  arranger: string;
  totalLimitMillions: number;
  drawnAmountMillions: number;
  availableCommitmentMillions: number;
  benchmarkRate: 'SOFR' | 'EURIBOR';
  marginSpreadBps: number;
  fixedRatePct?: number;
  isFloating: boolean;
  maturityDate: string;
  pledgedAircraftCount: number;
  dscr: number;
  covenantHeadroomPct: number;
  repaymentSchedule: { year: number; principalDueMillions: number; interestEstMillions: number }[];
}

export interface ValuationRecord {
  id: string;
  aircraftId: string;
  registration: string;
  family: string;
  manufacturingYear: number;
  valuationDate: string;
  method: 'MARKET_COMPARABLE' | 'DISCOUNTED_CASH_FLOW' | 'RESIDUAL_CURVE' | 'STRESSED_LIQUIDATION';
  bookValueMillions: number;
  marketValuationMillions: number;
  dcfValueMillions: number;
  estimatedResidual2030Millions: number;
  stressedLiquidationValueMillions: number;
  valuationModelVersion: string;
  reviewerName: string;
}

export interface TradingTransaction {
  id: string;
  type: 'ACQUISITION' | 'DISPOSAL' | 'SALE_AND_LEASEBACK' | 'PORTFOLIO_TRADE';
  aircraftOrPortfolioName: string;
  counterparty: string;
  proposedPriceMillions: number;
  valuationMillions: number;
  leaseStatus: string;
  stage: 'ORIGINATION' | 'DUE_DILIGENCE' | 'STRUCTURING' | 'CREDIT_APPROVAL' | 'CLOSING' | 'COMPLETED';
  expectedCloseDate: string;
  projectedIrrPct: number;
  riskRating: 'LOW' | 'MEDIUM' | 'HIGH';
}

export interface InsurancePolicy {
  id: string;
  aircraftRegistration: string;
  insurerName: string;
  policyNumber: string;
  hullInsuredValueMillions: number;
  liabilityLimitMillions: number;
  effectiveDate: string;
  expiryDate: string;
  certificateStatus: 'VALID' | 'EXPIRING_30D' | 'EXPIRED_ACTION_REQUIRED';
}

export interface LegalEntity {
  id: string;
  entityName: string;
  role: 'SPECIAL_PURPOSE_VEHICLE' | 'BORROWING_ENTITY' | 'MANAGEMENT_CO' | 'PARENT_HOLDING';
  jurisdiction: string;
  aircraftCount: number;
  totalDebtMillions: number;
  cashReserveThousands: number;
}

export interface LedgerJournal {
  id: string;
  date: string;
  sourceTransaction: string;
  debitAccount: string;
  creditAccount: string;
  amountThousands: number;
  currency: 'USD' | 'EUR' | 'GBP';
  postingStatus: 'POSTED' | 'PENDING' | 'REVERSED';
}

export interface ApprovalTask {
  id: string;
  title: string;
  category: 'LEASE_AMENDMENT' | 'ACQUISITION' | 'DISPOSAL' | 'VALUATION_OVERRIDE' | 'CREDIT_EXCEPTION';
  requestedBy: string;
  amountMillions: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  timestamp: string;
  details: string;
}

export interface PortfolioKPIs {
  totalAircraft: number;
  ownedAircraft: number;
  managedAircraft: number;
  onOrderAircraft: number;
  committedDeliveries: number;
  activeLeases: number;
  awaitingDelivery: number;
  approachingExpiry12M: number;
  forecastLeaseRevenueAnnualMillions: number;
  rentalCollectionsYTDMillions: number;
  overdueRentalsThousands: number;
  totalDebtMillions: number;
  availableLiquidityMillions: number;
  portfolioNavMillions: number;
  fleetUtilizationPct: number;
  maintenanceAlertsCount: number;
  creditWatchlistCount: number;
  pendingApprovalsCount: number;
}
