"""Thin FastAPI + WebSocket gateway to the authoritative spitfire_sync coordination core."""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from typing import Any

# Ensure python_sync_core is importable even before pip install -e
CORE_ROOT = Path(__file__).resolve().parents[1] / "python_sync_core"
if str(CORE_ROOT) not in sys.path:
    sys.path.insert(0, str(CORE_ROOT))

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from pydantic import BaseModel, Field

from spitfire_sync import CoordinatorEngine, JobType, LocalPoint3D, SurveyJob, to_dict

app = FastAPI(
    title="SPITFIRE.OS Coordination Gateway",
    version="1.0.0",
    description="Thin FastAPI gateway exposing the authoritative Python spitfire_sync coordination core.",
)

engine = CoordinatorEngine()
ws_clients: set[WebSocket] = set()


class CreateJobRequest(BaseModel):
    job_id: str | None = None
    title: str
    job_type: JobType
    work_area_label: str
    payload_type: str
    timing_window_start_s: int = 120
    timing_window_end_s: int = 480
    responsible_operator: str = "Op. A. Vance"
    operating_conditions: str = "Daylight, wind <= 9.5 m/s"
    required_outputs: list[str] = Field(default_factory=lambda: ["Orthomosaic", "Inspection Report"])
    work_area_polygon: list[dict[str, float]] = Field(default_factory=list)


class AllocationProposalRequest(BaseModel):
    resolve_conflicts: bool = True


class ApprovalRequest(BaseModel):
    mission_version: int
    operator_id: str


class CommandSubmissionRequest(BaseModel):
    request_id: str
    mission_version: int
    coordinator_epoch: int
    control_lease_id: str
    command_type: str
    affected_aircraft: list[str]
    expiry_ms: int
    operator_id: str


class ControlLeaseRequest(BaseModel):
    operator_id: str
    device_id: str


class HandoverRequest(BaseModel):
    action: str  # REQUEST | ACCEPT
    operator_id: str
    device_id: str = "TABLET-UK-OPS-02"


class ExceptionActionRequest(BaseModel):
    action: str  # ACKNOWLEDGE | RESOLVE
    operator_id: str
    resolution_action: str = ""
    note: str = ""


async def _broadcast_events(events: list[Any]) -> None:
    if not ws_clients:
        return
    dead: list[WebSocket] = []
    for client in ws_clients:
        for evt in events:
            try:
                await client.send_json(to_dict(evt))
            except Exception:
                dead.append(client)
                break
    for d in dead:
        ws_clients.discard(d)


@app.get("/v1/capabilities")
def get_capabilities() -> dict[str, Any]:
    return engine.capabilities()


@app.get("/v1/fleet")
def get_fleet() -> list[dict[str, Any]]:
    return [to_dict(ac) for ac in engine.fleet]


@app.get("/v1/fleet/snapshot")
def get_fleet_snapshot() -> dict[str, Any]:
    return {
        "mission": to_dict(engine.mission),
        "fleet": [to_dict(ac) for ac in engine.fleet],
        "stream_sequence": engine.stream_sequence,
    }


@app.post("/v1/jobs")
def create_job(req: CreateJobRequest) -> dict[str, Any]:
    poly = [
        LocalPoint3D(p.get("x_m", 100.0), p.get("y_m", 150.0), p.get("alt_m", 45.0))
        for p in req.work_area_polygon
    ] or [
        LocalPoint3D(120.0, 140.0, 45.0),
        LocalPoint3D(240.0, 140.0, 45.0),
        LocalPoint3D(240.0, 240.0, 45.0),
        LocalPoint3D(120.0, 240.0, 45.0),
    ]
    job = SurveyJob(
        job_id=req.job_id or f"JOB-OP-{len(engine.mission.jobs) + 1:03d}",
        title=req.title,
        job_type=req.job_type,
        work_area_label=req.work_area_label,
        work_area_polygon=poly,
        required_outputs=req.required_outputs,
        payload_type=req.payload_type,
        timing_window_start_s=req.timing_window_start_s,
        timing_window_end_s=req.timing_window_end_s,
        responsible_operator=req.responsible_operator,
        operating_conditions=req.operating_conditions,
    )
    mission = engine.create_job(job)
    return {"job": to_dict(job), "mission": to_dict(mission)}


@app.get("/v1/jobs/{job_id}")
def get_job(job_id: str) -> dict[str, Any]:
    for job in engine.mission.jobs:
        if job.job_id == job_id:
            return to_dict(job)
    raise HTTPException(status_code=404, detail=f"Job {job_id} not found")


@app.post("/v1/missions")
def create_or_reset_mission() -> dict[str, Any]:
    return to_dict(engine.mission)


@app.get("/v1/missions/{mission_id}")
def get_mission(mission_id: str) -> dict[str, Any]:
    if engine.mission.mission_id != mission_id:
        raise HTTPException(status_code=404, detail=f"Mission {mission_id} not found")
    return to_dict(engine.mission)


@app.post("/v1/missions/{mission_id}/allocation-proposals")
def propose_allocation(mission_id: str, req: AllocationProposalRequest) -> dict[str, Any]:
    if engine.mission.mission_id != mission_id:
        raise HTTPException(status_code=404, detail="Mission not found")
    return to_dict(engine.propose_allocation(resolve_conflicts=req.resolve_conflicts))


@app.post("/v1/missions/{mission_id}/validation")
def validate_mission(mission_id: str) -> dict[str, Any]:
    if engine.mission.mission_id != mission_id:
        raise HTTPException(status_code=404, detail="Mission not found")
    return to_dict(engine.validate_mission())


@app.post("/v1/missions/{mission_id}/approvals")
def approve_mission(mission_id: str, req: ApprovalRequest) -> dict[str, Any]:
    if engine.mission.mission_id != mission_id:
        raise HTTPException(status_code=404, detail="Mission not found")
    ok, message, mission = engine.approve_mission(req.mission_version, req.operator_id)
    if not ok:
        raise HTTPException(status_code=409, detail={"reason": message, "mission": to_dict(mission)})
    return {"message": message, "mission": to_dict(mission)}


@app.get("/v1/missions/{mission_id}/sync-readiness")
def get_sync_readiness(mission_id: str) -> list[dict[str, Any]]:
    if engine.mission.mission_id != mission_id:
        raise HTTPException(status_code=404, detail="Mission not found")
    engine.refresh_telemetry(advance_ms=0)
    return [to_dict(s) for s in engine.mission.sync_states]


@app.post("/v1/missions/{mission_id}/dispatch-requests")
def post_dispatch_request(mission_id: str, req: CommandSubmissionRequest) -> dict[str, Any]:
    if engine.mission.mission_id != mission_id:
        raise HTTPException(status_code=404, detail="Mission not found")
    cmd = engine.submit_command(
        request_id=req.request_id,
        mission_version=req.mission_version,
        coordinator_epoch=req.coordinator_epoch,
        control_lease_id=req.control_lease_id,
        command_type=req.command_type,
        affected_aircraft=req.affected_aircraft,
        expiry_ms=req.expiry_ms,
        operator_id=req.operator_id,
    )
    return {"command": to_dict(cmd), "mission": to_dict(engine.mission)}


@app.post("/v1/missions/{mission_id}/action-requests")
def post_action_request(mission_id: str, req: CommandSubmissionRequest) -> dict[str, Any]:
    return post_dispatch_request(mission_id, req)


@app.get("/v1/commands/{request_id}")
def get_command(request_id: str) -> dict[str, Any]:
    for cmd in engine.mission.commands:
        if cmd.request_id == request_id:
            return to_dict(cmd)
    raise HTTPException(status_code=404, detail=f"Command {request_id} not found")


@app.post("/v1/missions/{mission_id}/control-lease")
def post_control_lease(mission_id: str, req: ControlLeaseRequest) -> dict[str, Any]:
    if engine.mission.mission_id != mission_id:
        raise HTTPException(status_code=404, detail="Mission not found")
    return to_dict(engine.acquire_lease(req.operator_id, req.device_id))


@app.post("/v1/missions/{mission_id}/handover-requests")
def post_handover(mission_id: str, req: HandoverRequest) -> dict[str, Any]:
    if engine.mission.mission_id != mission_id:
        raise HTTPException(status_code=404, detail="Mission not found")
    if req.action == "REQUEST":
        return to_dict(engine.request_handover(req.operator_id))
    return to_dict(engine.accept_handover(req.operator_id, req.device_id))


@app.post("/v1/missions/{mission_id}/exceptions/{exception_id}")
def handle_exception(mission_id: str, exception_id: str, req: ExceptionActionRequest) -> dict[str, Any]:
    if engine.mission.mission_id != mission_id:
        raise HTTPException(status_code=404, detail="Mission not found")
    if req.action == "ACKNOWLEDGE":
        exc = engine.acknowledge_exception(exception_id, req.operator_id)
    else:
        exc = engine.resolve_exception(
            exception_id, req.operator_id, req.resolution_action, req.note
        )
    if exc is None:
        raise HTTPException(status_code=404, detail="Exception not found")
    return to_dict(exc)


@app.post("/v1/missions/{mission_id}/sim/inject-delayed-telemetry")
def sim_delayed_telemetry(mission_id: str, aircraft_id: str = "SPIT-02") -> dict[str, Any]:
    return to_dict(engine.inject_delayed_telemetry(aircraft_id=aircraft_id))


@app.post("/v1/missions/{mission_id}/sim/withdraw-aircraft")
def sim_withdraw_aircraft(mission_id: str, aircraft_id: str = "SPIT-04") -> dict[str, Any]:
    return to_dict(engine.withdraw_aircraft_and_reassign(aircraft_id=aircraft_id))


@app.post("/v1/missions/{mission_id}/sim/missing-imagery-followup")
def sim_missing_imagery(mission_id: str) -> dict[str, Any]:
    followup, mission = engine.create_missing_imagery_followup()
    return {"followup_job": to_dict(followup), "mission": to_dict(mission)}


@app.get("/v1/replays")
def list_replays() -> list[dict[str, Any]]:
    return [to_dict(r) for r in engine.replay_sessions.values()]


@app.get("/v1/replays/{replay_id}/events")
def get_replay_events(replay_id: str) -> dict[str, Any]:
    replay = engine.replay_sessions.get(replay_id)
    if replay is None:
        raise HTTPException(status_code=404, detail="Replay session not found")
    return to_dict(replay)


@app.websocket("/v1/events")
async def websocket_events(websocket: WebSocket) -> None:
    await websocket.accept()
    ws_clients.add(websocket)
    try:
        while True:
            await asyncio.sleep(1.5)
            events = engine.refresh_telemetry(advance_ms=1500)
            for evt in events:
                await websocket.send_json(to_dict(evt))
    except WebSocketDisconnect:
        ws_clients.discard(websocket)
    except Exception:
        ws_clients.discard(websocket)
