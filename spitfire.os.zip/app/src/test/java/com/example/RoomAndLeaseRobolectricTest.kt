package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.core.database.SpitfireDatabase
import com.example.core.datastore.PreferencesRepository
import com.example.core.datastore.SecureCredentialStore
import com.example.core.model.ControlLease
import com.example.core.model.ControlLeaseStatus
import com.example.core.network.SpitfireApiClient
import com.example.core.repository.PennineScenarioSeed
import com.example.core.repository.SpitfireRepository
import io.ktor.client.engine.mock.MockEngine
import io.ktor.client.engine.mock.respond
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.http.headersOf
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.encodeToString
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class RoomAndLeaseRobolectricTest {

    @Test
    fun `observer-only tablet cannot issue dispatch when another operator holds lease`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, SpitfireDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        val seed = PennineScenarioSeed.seedSnapshot(System.currentTimeMillis())
        val foreignLeaseMission = seed.mission.copy(
            controlLease = ControlLease(
                leaseId = "LEASE-OTHER-OP",
                missionId = seed.mission.missionId,
                ownerOperatorId = "Op. M. Davies",
                ownerDeviceId = "TABLET-UK-OPS-02",
                coordinatorEpoch = seed.mission.coordinatorEpoch,
                expiresAtMs = System.currentTimeMillis() + 60_000L,
                status = ControlLeaseStatus.HELD,
            ),
        )
        val foreignSnapshot = seed.copy(mission = foreignLeaseMission)

        val apiClient = SpitfireApiClient(
            MockEngine { request ->
                val headers = headersOf(HttpHeaders.ContentType, "application/json")
                when {
                    request.url.encodedPath.endsWith("/v1/capabilities") -> respond(
                        content = SpitfireApiClient().json.encodeToString(PennineScenarioSeed.defaultCapabilities()),
                        status = HttpStatusCode.OK,
                        headers = headers,
                    )
                    request.url.encodedPath.endsWith("/v1/fleet/snapshot") -> respond(
                        content = SpitfireApiClient().json.encodeToString(foreignSnapshot),
                        status = HttpStatusCode.OK,
                        headers = headers,
                    )
                    request.url.encodedPath.endsWith("/v1/replays") -> respond(
                        content = "[]",
                        status = HttpStatusCode.OK,
                        headers = headers,
                    )
                    else -> respond("{}", HttpStatusCode.NotFound, headers)
                }
            },
        )

        val repo = SpitfireRepository(
            context = context,
            apiClient = apiClient,
            dao = db.spitfireDao(),
            preferencesRepository = PreferencesRepository(context),
            credentialStore = SecureCredentialStore(context),
        )
        repo.reconcileWithGateway()
        assertTrue(repo.state.value.gatewayConnected)

        val vm = SpitfireViewModel(repo, androidx.lifecycle.SavedStateHandle())
        // Default operator is "Op. A. Vance", while lease is held by "Op. M. Davies"
        assertFalse(vm.uiState.value.isControlAllowed)
        assertEquals("Op. M. Davies", vm.uiState.value.repoData.mission.controlLease.ownerOperatorId)

        repo.closeAndAwait()
        db.close()
    }
}
