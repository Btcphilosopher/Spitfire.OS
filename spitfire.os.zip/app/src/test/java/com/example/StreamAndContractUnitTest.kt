package com.example

import com.example.core.model.CapabilitiesResponse
import com.example.core.model.CommandState
import com.example.core.model.TelemetryEvent
import com.example.core.network.SpitfireApiClient
import com.example.core.network.StreamEventSequencer
import com.example.core.network.StreamIngestionResult
import com.example.core.repository.PennineScenarioSeed
import io.ktor.client.engine.mock.MockEngine
import io.ktor.client.engine.mock.respond
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.http.headersOf
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.JsonObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StreamAndContractUnitTest {

    @Test
    fun `stream sequencer detects duplicates, out of order, and gaps`() {
        val sequencer = StreamEventSequencer(initialSequence = 10L)

        val ev11 = TelemetryEvent("e11", 11L, "DELTA", 1000L, 1020L, 1, JsonObject(emptyMap()))
        assertTrue(sequencer.ingest(ev11) is StreamIngestionResult.Accepted)

        // Duplicate event_id
        assertTrue(sequencer.ingest(ev11) is StreamIngestionResult.DuplicateIgnored)

        // Out-of-order lower sequence
        val ev09 = TelemetryEvent("e09", 9L, "DELTA", 900L, 1025L, 1, JsonObject(emptyMap()))
        assertTrue(sequencer.ingest(ev09) is StreamIngestionResult.OutOfOrderIgnored)

        // Sequence gap (11 -> 14) triggers snapshot recovery signal
        val ev14 = TelemetryEvent("e14", 14L, "DELTA", 1400L, 1450L, 1, JsonObject(emptyMap()))
        val gapResult = sequencer.ingest(ev14)
        assertTrue(gapResult is StreamIngestionResult.GapDetected)
        assertEquals(12L, (gapResult as StreamIngestionResult.GapDetected).expectedSequence)
    }

    @Test
    fun `ktor api client parses capabilities and queries command status idempotently`() = runTest {
        val mockEngine = MockEngine { request ->
            val path = request.url.encodedPath
            val jsonHeaders = headersOf(HttpHeaders.ContentType, "application/json")
            when {
                path.endsWith("/v1/capabilities") -> respond(
                    content = """
                        {
                          "coordinator_version": "1.4.0-py",
                          "operating_modes": ["SIMULATION", "REPLAY"],
                          "connected_aircraft_enabled": false,
                          "connected_aircraft_gate": "DISABLED_BY_DEFAULT",
                          "sync_tolerances": {
                            "max_clock_uncertainty_ms": 35.0,
                            "max_telemetry_age_ms": 2500,
                            "max_start_deviation_s": 2.0,
                            "readiness_ttl_ms": 30000
                          },
                          "supported_job_types": ["SOLAR_FARM_SURVEY"]
                        }
                    """.trimIndent(),
                    status = HttpStatusCode.OK,
                    headers = jsonHeaders,
                )
                path.endsWith("/v1/commands/CMD-ABC123") -> respond(
                    content = """
                        {
                          "request_id": "CMD-ABC123",
                          "mission_id": "MSN-PENNINE-2026-11",
                          "mission_version": 2,
                          "coordinator_epoch": 4,
                          "control_lease_id": "LEASE-OP-VANCE-01",
                          "command_type": "DISPATCH",
                          "affected_aircraft": ["SPIT-01"],
                          "expiry_ms": 9999999999,
                          "state": "OUTCOME_UNKNOWN",
                          "reason_code": "LINK_LOST_DURING_DISPATCH",
                          "detail": "Link lost after coordinator submission.",
                          "created_at_ms": 1000,
                          "updated_at_ms": 1100
                        }
                    """.trimIndent(),
                    status = HttpStatusCode.OK,
                    headers = jsonHeaders,
                )
                else -> respond("{}", HttpStatusCode.NotFound, jsonHeaders)
            }
        }

        val api = SpitfireApiClient(mockEngine)
        val caps: CapabilitiesResponse = api.getCapabilities("http://10.0.2.2:8000")
        assertFalse(caps.connectedAircraftEnabled)
        assertEquals("1.4.0-py", caps.coordinatorVersion)

        val cmd = api.getCommandStatus("http://10.0.2.2:8000", "CMD-ABC123")
        assertEquals(CommandState.OUTCOME_UNKNOWN, cmd.state)
        assertEquals("LINK_LOST_DURING_DISPATCH", cmd.reasonCode)
        api.close()
    }

    @Test
    fun `pennine seed includes explicit coordinate datum, altitude reference, and replay gap`() {
        val snap = PennineScenarioSeed.seedSnapshot(1_700_000_000_000L)
        assertEquals(6, snap.fleet.size)
        assertTrue(snap.mission.site.coordinateReference.contains("LOCAL_ENU_M"))
        assertTrue(snap.mission.site.altitudeReference.contains("AGL_SITE_DATUM"))
        assertTrue(snap.mission.conflicts.any { it.category == "LAUNCH_SLOT_CONFLICT" })

        val replay = PennineScenarioSeed.seedReplaySession(1_700_000_000_000L)
        assertEquals(1, replay.gapWindows.size)
        assertEquals(42.0, replay.gapWindows.first().startS, 0.01)
    }
}
