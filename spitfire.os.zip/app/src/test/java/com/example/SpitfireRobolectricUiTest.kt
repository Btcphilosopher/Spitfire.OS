package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.lifecycle.SavedStateHandle
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.core.database.SpitfireDatabase
import com.example.core.datastore.PreferencesRepository
import com.example.core.datastore.SecureCredentialStore
import com.example.core.designsystem.SpitfireTheme
import com.example.core.model.JobType
import com.example.core.model.OperatingMode
import com.example.core.network.SpitfireApiClient
import com.example.core.repository.SpitfireRepository
import io.ktor.client.engine.mock.MockEngine
import io.ktor.client.engine.mock.respondError
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w1280dp-h800dp-land")
class SpitfireRobolectricUiTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private fun createOfflineRepo(context: Context): Pair<SpitfireDatabase, SpitfireRepository> {
        val db = Room.inMemoryDatabaseBuilder(context, SpitfireDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val offlineEngine = MockEngine { respondError(HttpStatusCode.ServiceUnavailable) }
        val repo = SpitfireRepository(
            context = context,
            apiClient = SpitfireApiClient(offlineEngine),
            dao = db.spitfireDao(),
            preferencesRepository = PreferencesRepository(context),
            credentialStore = SecureCredentialStore(context),
        )
        return db to repo
    }

    @Test
    fun `offline mode shows banner, protects controls, and isolates replay mode`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val (db, repo) = createOfflineRepo(context)
        val savedState = SavedStateHandle()
        val vm = SpitfireViewModel(repo, savedState)

        composeTestRule.setContent {
            SpitfireTheme {
                SpitfireOperatorApp(viewModel = vm)
            }
        }
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("spitfire_navigation_rail").assertIsDisplayed()
        composeTestRule.onNodeWithTag("operating_mode_badge").assertIsDisplayed()
        composeTestRule.onNodeWithTag("offline_status_banner").assertIsDisplayed()

        vm.navigateTo(SpitfireDestination.REPLAY)
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("replay_screen").assertIsDisplayed()
        composeTestRule.onNodeWithTag("replay_isolation_banner").assertIsDisplayed()
        assertEquals(OperatingMode.REPLAY, vm.uiState.value.repoData.operatingMode)
        assertFalse(vm.uiState.value.isControlAllowed)

        composeTestRule.onNodeWithTag("replay_play_pause_btn").performClick()
        composeTestRule.waitForIdle()
        assertTrue(vm.uiState.value.replayState.isPlaying)

        repo.closeAndAwait()
        db.close()
    }

    @Test
    fun `process recreation restores destination, aircraft selection, and replay scrubber`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val (db, repo) = createOfflineRepo(context)
        val savedState = SavedStateHandle()
        val vm1 = SpitfireViewModel(repo, savedState)

        vm1.navigateTo(SpitfireDestination.SYNCHRONISATION)
        vm1.selectAircraft("SPIT-03")
        vm1.seekReplay(24.5f)

        val vm2 = SpitfireViewModel(repo, savedState)
        assertEquals(SpitfireDestination.SYNCHRONISATION, vm2.uiState.value.currentDestination)
        assertEquals("SPIT-03", vm2.uiState.value.selectedAircraftId)
        assertEquals(24.5f, vm2.uiState.value.replayState.currentTimeS, 0.01f)

        repo.closeAndAwait()
        db.close()
    }

    @Test
    fun `offline drafts persist separately in Room database`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val (db, repo) = createOfflineRepo(context)
        repo.saveOfflineDraft(
            title = "Offline Roof Inspection Draft",
            jobType = JobType.ROOF_INSPECTION,
            workAreaLabel = "Block D",
            payloadType = "ROOF_ZOOM",
            timingStartS = 120,
            timingEndS = 360,
            responsibleOperator = "Op. A. Vance",
            operatingConditions = "Daylight",
        )
        val vm = SpitfireViewModel(repo, SavedStateHandle())
        composeTestRule.setContent {
            SpitfireTheme {
                SpitfireOperatorApp(viewModel = vm)
            }
        }
        vm.navigateTo(SpitfireDestination.JOBS)
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("jobs_screen").assertIsDisplayed()
        composeTestRule.waitUntil(5_000L) {
            vm.drafts.value.any { it.title == "Offline Roof Inspection Draft" }
        }
        composeTestRule.onNodeWithTag("jobs_screen")
            .performScrollToNode(hasText("Offline Roof Inspection Draft", substring = true))
        composeTestRule.onAllNodesWithText("Offline Roof Inspection Draft", substring = true)
            .onFirst()
            .assertIsDisplayed()

        repo.closeAndAwait()
        db.close()
    }

    @Test
    fun `map coordinate and altitude datum labels render explicitly`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val (db, repo) = createOfflineRepo(context)
        val vm = SpitfireViewModel(repo, SavedStateHandle())
        composeTestRule.setContent {
            SpitfireTheme {
                SpitfireOperatorApp(viewModel = vm)
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onAllNodesWithText("LOCAL_ENU_M", substring = true).onFirst().assertIsDisplayed()
        composeTestRule.onAllNodesWithText("AGL_SITE_DATUM", substring = true).onFirst().assertIsDisplayed()

        repo.closeAndAwait()
        db.close()
    }
}
