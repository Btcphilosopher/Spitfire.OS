package com.example

import android.app.Application
import com.example.core.database.SpitfireDatabase
import com.example.core.datastore.PreferencesRepository
import com.example.core.datastore.SecureCredentialStore
import com.example.core.network.SpitfireApiClient
import com.example.core.repository.SpitfireRepository

class SpitfireApp : Application() {
    lateinit var repository: SpitfireRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val database = SpitfireDatabase.getInstance(this)
        val apiClient = SpitfireApiClient()
        val preferencesRepository = PreferencesRepository(this)
        val credentialStore = SecureCredentialStore(this)
        repository = SpitfireRepository(
            context = this,
            apiClient = apiClient,
            dao = database.spitfireDao(),
            preferencesRepository = preferencesRepository,
            credentialStore = credentialStore,
        )
    }
}
