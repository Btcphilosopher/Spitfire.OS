package com.example.core.network

import com.example.core.model.AircraftRecord
import com.example.core.model.AircraftSyncState
import com.example.core.model.AllocationProposalPayload
import com.example.core.model.ApprovalPayload
import com.example.core.model.ApprovalResponse
import com.example.core.model.CapabilitiesResponse
import com.example.core.model.CommandRecord
import com.example.core.model.CommandSubmissionPayload
import com.example.core.model.CommandSubmissionResponse
import com.example.core.model.ControlLease
import com.example.core.model.ControlLeasePayload
import com.example.core.model.CreateJobPayload
import com.example.core.model.CreateJobResponse
import com.example.core.model.ExceptionActionPayload
import com.example.core.model.FleetSnapshotResponse
import com.example.core.model.HandoverPayload
import com.example.core.model.MissionException
import com.example.core.model.MissionRecord
import com.example.core.model.ReplaySession
import com.example.core.model.TelemetryEvent
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.HttpClientEngine
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.websocket.WebSockets
import io.ktor.client.plugins.websocket.webSocket
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.contentType
import io.ktor.serialization.kotlinx.json.json
import io.ktor.websocket.Frame
import io.ktor.websocket.readText
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.json.Json

class SpitfireApiClient(
    engine: HttpClientEngine = OkHttp.create(),
) {
    val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        encodeDefaults = true
    }

    private val client = HttpClient(engine) {
        install(ContentNegotiation) {
            json(this@SpitfireApiClient.json)
        }
        install(WebSockets)
        install(HttpTimeout) {
            requestTimeoutMillis = 4500L
            connectTimeoutMillis = 2500L
            socketTimeoutMillis = 5000L
        }
    }

    private fun String.cleanBase(): String = trimEnd('/')

    suspend fun getCapabilities(baseUrl: String, authToken: String? = null): CapabilitiesResponse =
        client.get("${baseUrl.cleanBase()}/v1/capabilities") {
            authToken?.takeIf { it.isNotBlank() }?.let { header("Authorization", "Bearer $it") }
        }.body()

    suspend fun getFleet(baseUrl: String): List<AircraftRecord> =
        client.get("${baseUrl.cleanBase()}/v1/fleet").body()

    suspend fun getFleetSnapshot(baseUrl: String): FleetSnapshotResponse =
        client.get("${baseUrl.cleanBase()}/v1/fleet/snapshot").body()

    suspend fun createJob(baseUrl: String, payload: CreateJobPayload): CreateJobResponse =
        client.post("${baseUrl.cleanBase()}/v1/jobs") {
            contentType(ContentType.Application.Json)
            setBody(payload)
        }.body()

    suspend fun requestAllocationProposal(
        baseUrl: String,
        missionId: String,
        resolveConflicts: Boolean,
    ): MissionRecord =
        client.post("${baseUrl.cleanBase()}/v1/missions/$missionId/allocation-proposals") {
            contentType(ContentType.Application.Json)
            setBody(AllocationProposalPayload(resolveConflicts))
        }.body()

    suspend fun validateMission(baseUrl: String, missionId: String): MissionRecord =
        client.post("${baseUrl.cleanBase()}/v1/missions/$missionId/validation").body()

    suspend fun approveMission(
        baseUrl: String,
        missionId: String,
        missionVersion: Int,
        operatorId: String,
    ): ApprovalResponse =
        client.post("${baseUrl.cleanBase()}/v1/missions/$missionId/approvals") {
            contentType(ContentType.Application.Json)
            setBody(ApprovalPayload(missionVersion, operatorId))
        }.body()

    suspend fun getSyncReadiness(baseUrl: String, missionId: String): List<AircraftSyncState> =
        client.get("${baseUrl.cleanBase()}/v1/missions/$missionId/sync-readiness").body()

    suspend fun submitDispatchRequest(
        baseUrl: String,
        missionId: String,
        payload: CommandSubmissionPayload,
    ): CommandSubmissionResponse =
        client.post("${baseUrl.cleanBase()}/v1/missions/$missionId/dispatch-requests") {
            contentType(ContentType.Application.Json)
            setBody(payload)
        }.body()

    suspend fun submitActionRequest(
        baseUrl: String,
        missionId: String,
        payload: CommandSubmissionPayload,
    ): CommandSubmissionResponse =
        client.post("${baseUrl.cleanBase()}/v1/missions/$missionId/action-requests") {
            contentType(ContentType.Application.Json)
            setBody(payload)
        }.body()

    suspend fun getCommandStatus(baseUrl: String, requestId: String): CommandRecord =
        client.get("${baseUrl.cleanBase()}/v1/commands/$requestId").body()

    suspend fun acquireControlLease(
        baseUrl: String,
        missionId: String,
        operatorId: String,
        deviceId: String,
    ): ControlLease =
        client.post("${baseUrl.cleanBase()}/v1/missions/$missionId/control-lease") {
            contentType(ContentType.Application.Json)
            setBody(ControlLeasePayload(operatorId, deviceId))
        }.body()

    suspend fun submitHandover(
        baseUrl: String,
        missionId: String,
        payload: HandoverPayload,
    ): ControlLease =
        client.post("${baseUrl.cleanBase()}/v1/missions/$missionId/handover-requests") {
            contentType(ContentType.Application.Json)
            setBody(payload)
        }.body()

    suspend fun handleException(
        baseUrl: String,
        missionId: String,
        exceptionId: String,
        payload: ExceptionActionPayload,
    ): MissionException =
        client.post("${baseUrl.cleanBase()}/v1/missions/$missionId/exceptions/$exceptionId") {
            contentType(ContentType.Application.Json)
            setBody(payload)
        }.body()

    suspend fun injectDelayedTelemetry(baseUrl: String, missionId: String): MissionRecord =
        client.post("${baseUrl.cleanBase()}/v1/missions/$missionId/sim/inject-delayed-telemetry").body()

    suspend fun withdrawAircraft(baseUrl: String, missionId: String, aircraftId: String = "SPIT-04"): MissionRecord =
        client.post("${baseUrl.cleanBase()}/v1/missions/$missionId/sim/withdraw-aircraft?aircraft_id=$aircraftId").body()

    suspend fun triggerMissingImageryFollowup(baseUrl: String, missionId: String): MissionRecord =
        client.post("${baseUrl.cleanBase()}/v1/missions/$missionId/sim/missing-imagery-followup").body()

    suspend fun listReplays(baseUrl: String): List<ReplaySession> =
        client.get("${baseUrl.cleanBase()}/v1/replays").body()

    suspend fun getReplayEvents(baseUrl: String, replayId: String): ReplaySession =
        client.get("${baseUrl.cleanBase()}/v1/replays/$replayId/events").body()

    fun streamTelemetryEvents(baseUrl: String): Flow<TelemetryEvent> = flow {
        val wsUrl = baseUrl.cleanBase()
            .replace("https://", "wss://")
            .replace("http://", "ws://") + "/v1/events"
        client.webSocket(wsUrl) {
            for (frame in incoming) {
                if (frame is Frame.Text) {
                    val event = json.decodeFromString(TelemetryEvent.serializer(), frame.readText())
                    emit(event)
                }
            }
        }
    }

    fun close() {
        client.close()
    }
}
