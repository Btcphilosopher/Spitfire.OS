package com.example.core.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.core.model.AppPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.spitfireDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "spitfire_operator_prefs",
)

class PreferencesRepository(private val context: Context) {
    private object Keys {
        val GATEWAY_URL = stringPreferencesKey("gateway_base_url")
        val OPERATOR_ID = stringPreferencesKey("operator_id")
        val DEVICE_ID = stringPreferencesKey("device_id")
        val CONNECTED_AIRCRAFT_ENABLED = booleanPreferencesKey("connected_aircraft_enabled")
        val TELEMETRY_BATCH_MS = longPreferencesKey("telemetry_batch_ms")
        val SHOW_UNCERTAINTIES = booleanPreferencesKey("show_uncertainties")
    }

    val preferences: Flow<AppPreferences> = context.spitfireDataStore.data.map { prefs ->
        AppPreferences(
            gatewayBaseUrl = prefs[Keys.GATEWAY_URL] ?: "http://10.0.2.2:8000",
            operatorId = prefs[Keys.OPERATOR_ID] ?: "Op. A. Vance",
            deviceId = prefs[Keys.DEVICE_ID] ?: "TABLET-UK-OPS-01",
            connectedAircraftIntegrationEnabled = prefs[Keys.CONNECTED_AIRCRAFT_ENABLED] ?: false,
            telemetryBatchIntervalMs = prefs[Keys.TELEMETRY_BATCH_MS] ?: 500L,
            showUncertaintyRings = prefs[Keys.SHOW_UNCERTAINTIES] ?: true,
        )
    }

    suspend fun updateGatewayUrl(url: String) {
        context.spitfireDataStore.edit { it[Keys.GATEWAY_URL] = url.trim() }
    }

    suspend fun updateOperatorIdentity(operatorId: String, deviceId: String) {
        context.spitfireDataStore.edit {
            it[Keys.OPERATOR_ID] = operatorId.trim().ifBlank { "Op. A. Vance" }
            it[Keys.DEVICE_ID] = deviceId.trim().ifBlank { "TABLET-UK-OPS-01" }
        }
    }

    suspend fun setConnectedAircraftEnabled(enabled: Boolean) {
        context.spitfireDataStore.edit { it[Keys.CONNECTED_AIRCRAFT_ENABLED] = enabled }
    }

    suspend fun setShowUncertaintyRings(show: Boolean) {
        context.spitfireDataStore.edit { it[Keys.SHOW_UNCERTAINTIES] = show }
    }
}
