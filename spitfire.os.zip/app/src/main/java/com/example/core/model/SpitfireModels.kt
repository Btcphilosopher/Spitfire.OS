package com.example.core.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject

@Serializable
enum class OperatingMode {
    SIMULATION,
    REPLAY,
    CONNECTED_AIRCRAFT,
}

@Serializable
enum class JobType {
    AGRICULTURAL_INSPECTION,
    SOLAR_FARM_SURVEY,
    ROOF_INSPECTION,
    STOCKPILE_MAPPING,
    AUTHORISED_DELIVERY,
}

@Serializable
enum class MissionStatus {
    DRAFT,
    VALIDATED_WITH_CONFLICTS,
    VALIDATED_CLEAN,
    APPROVED,
    DISPATCHED,
    IN_FLIGHT,
    PAUSED,
    COMPLETED,
    ABORTED,
}

@Serializable
enum class SyncStage {
    PLAN_PROPOSED,
    AIRCRAFT_VALIDATION,
    READINESS_ACKNOWLEDGED,
    COMMITTED_SCHEDULE,
    EXECUTION_OBSERVED,
}

@Serializable
enum class CommandState {
    DRAFT,
    SUBMITTED,
    ACCEPTED_BY_COORDINATOR,
    SENT_TO_ADAPTER,
    ACKNOWLEDGED_BY_AIRCRAFT,
    OBSERVED_EFFECT,
    REJECTED,
    EXPIRED,
    OUTCOME_UNKNOWN,
}

@Serializable
enum class ExceptionCategory {
    STALE_POSITION,
    LOST_COORDINATION_LINK,
    CLOCK_UNCERTAINTY,
    LOW_OBSERVED_BATTERY,
    ROUTE_DEVIATION,
    AIRCRAFT_UNAVAILABLE,
    COMMAND_REJECTION,
    MISSING_IMAGERY,
    PAYLOAD_UPLOAD_FAILURE,
    RECOVERY_AREA_CONFLICT,
}

@Serializable
enum class ExceptionStatus {
    OPEN,
    ACKNOWLEDGED,
    RESOLVED,
}

@Serializable
enum class ControlLeaseStatus {
    HELD,
    HANDOVER_PENDING,
    EXPIRED,
    OBSERVER_ONLY,
}

@Serializable
data class LocalPoint3D(
    @SerialName("x_m") val xM: Double,
    @SerialName("y_m") val yM: Double,
    @SerialName("alt_m") val altM: Double,
    @SerialName("altitude_reference") val altitudeReference: String = "AGL_SITE_DATUM",
)

@Serializable
data class AircraftRecord(
    @SerialName("aircraft_id") val aircraftId: String,
    @SerialName("callsign") val callsign: String,
    @SerialName("airframe") val airframe: String,
    @SerialName("autopilot_version") val autopilotVersion: String,
    @SerialName("supported_payloads") val supportedPayloads: List<String>,
    @SerialName("configured_max_speed_mps") val configuredMaxSpeedMps: Double,
    @SerialName("configured_max_wind_mps") val configuredMaxWindMps: Double,
    @SerialName("configured_min_reserve_pct") val configuredMinReservePct: Double,
    @SerialName("battery_id") val batteryId: String,
    @SerialName("battery_soc_pct") val batterySocPct: Double,
    @SerialName("battery_voltage_v") val batteryVoltageV: Double,
    @SerialName("battery_observed_at_ms") val batteryObservedAtMs: Long,
    @SerialName("charging_state") val chargingState: String,
    @SerialName("maintenance_restrictions") val maintenanceRestrictions: List<String> = emptyList(),
    @SerialName("maintenance_blocking_reason") val maintenanceBlockingReason: String? = null,
    @SerialName("assigned_task_id") val assignedTaskId: String? = null,
    @SerialName("observed_flight_mode") val observedFlightMode: String,
    @SerialName("link_status") val linkStatus: String,
    @SerialName("position") val position: LocalPoint3D,
    @SerialName("position_observed_at_ms") val positionObservedAtMs: Long,
    @SerialName("position_uncertainty_m") val positionUncertaintyM: Double,
    @SerialName("boot_id") val bootId: String,
    @SerialName("latest_command_outcome") val latestCommandOutcome: String,
    @SerialName("supported_contingencies") val supportedContingencies: List<String> = emptyList(),
    @SerialName("documentation_summary") val documentationSummary: String = "",
    @SerialName("withdrawn") val withdrawn: Boolean = false,
)

@Serializable
data class SurveyJob(
    @SerialName("job_id") val jobId: String,
    @SerialName("title") val title: String,
    @SerialName("job_type") val jobType: JobType,
    @SerialName("work_area_label") val workAreaLabel: String,
    @SerialName("work_area_polygon") val workAreaPolygon: List<LocalPoint3D> = emptyList(),
    @SerialName("required_outputs") val requiredOutputs: List<String> = emptyList(),
    @SerialName("payload_type") val payloadType: String,
    @SerialName("timing_window_start_s") val timingWindowStartS: Int,
    @SerialName("timing_window_end_s") val timingWindowEndS: Int,
    @SerialName("responsible_operator") val responsibleOperator: String,
    @SerialName("operating_conditions") val operatingConditions: String,
    @SerialName("flight_completed") val flightCompleted: Boolean = false,
    @SerialName("coverage_completed") val coverageCompleted: Boolean = false,
    @SerialName("data_accepted") val dataAccepted: Boolean = false,
    @SerialName("parent_job_id") val parentJobId: String? = null,
)

@Serializable
data class NamedZone(
    @SerialName("zone_id") val zoneId: String,
    @SerialName("label") val label: String,
    @SerialName("zone_type") val zoneType: String,
    @SerialName("vertices") val vertices: List<LocalPoint3D> = emptyList(),
)

@Serializable
data class MapSiteConfig(
    @SerialName("site_id") val siteId: String,
    @SerialName("name") val name: String,
    @SerialName("coordinate_reference") val coordinateReference: String,
    @SerialName("altitude_reference") val altitudeReference: String,
    @SerialName("terrain_source") val terrainSource: String,
    @SerialName("map_data_age_s") val mapDataAgeS: Int,
    @SerialName("position_uncertainty_m") val positionUncertaintyM: Double,
    @SerialName("planning_assumptions") val planningAssumptions: String,
    @SerialName("zones") val zones: List<NamedZone> = emptyList(),
)

@Serializable
data class TaskAllocationItem(
    @SerialName("task_id") val taskId: String,
    @SerialName("job_id") val jobId: String,
    @SerialName("aircraft_id") val aircraftId: String,
    @SerialName("payload_id") val payloadId: String,
    @SerialName("area_label") val areaLabel: String,
    @SerialName("proposed_route") val proposedRoute: List<LocalPoint3D> = emptyList(),
    @SerialName("approved_trajectory") val approvedTrajectory: List<LocalPoint3D> = emptyList(),
    @SerialName("observed_track") val observedTrack: List<LocalPoint3D> = emptyList(),
    @SerialName("bounded_predicted_position") val boundedPredictedPosition: LocalPoint3D? = null,
    @SerialName("estimated_duration_s") val estimatedDurationS: Int,
    @SerialName("estimated_energy_wh") val estimatedEnergyWh: Double,
    @SerialName("battery_reserve_pct") val batteryReservePct: Double,
    @SerialName("launch_site_id") val launchSiteId: String,
    @SerialName("launch_slot_s") val launchSlotS: Int,
    @SerialName("recovery_site_id") val recoverySiteId: String,
    @SerialName("recovery_slot_s") val recoverySlotS: Int,
    @SerialName("unresolved_constraints") val unresolvedConstraints: List<String> = emptyList(),
    @SerialName("progress_pct") val progressPct: Double = 0.0,
    @SerialName("completed") val completed: Boolean = false,
)

@Serializable
data class ConflictFinding(
    @SerialName("conflict_id") val conflictId: String,
    @SerialName("severity") val severity: String,
    @SerialName("category") val category: String,
    @SerialName("description") val description: String,
    @SerialName("affected_aircraft") val affectedAircraft: List<String> = emptyList(),
    @SerialName("affected_tasks") val affectedTasks: List<String> = emptyList(),
    @SerialName("location_x_m") val locationXM: Double,
    @SerialName("location_y_m") val locationYM: Double,
    @SerialName("time_window_start_s") val timeWindowStartS: Int,
    @SerialName("time_window_end_s") val timeWindowEndS: Int,
    @SerialName("spatial_buffer_m") val spatialBufferM: Double,
    @SerialName("temporal_buffer_s") val temporalBufferS: Double,
    @SerialName("modelled_scope_note") val modelledScopeNote: String,
)

@Serializable
data class AircraftSyncState(
    @SerialName("aircraft_id") val aircraftId: String,
    @SerialName("plan_version") val planVersion: Int,
    @SerialName("coordinator_epoch") val coordinatorEpoch: Int,
    @SerialName("boot_id") val bootId: String,
    @SerialName("clock_offset_ms") val clockOffsetMs: Double,
    @SerialName("clock_uncertainty_ms") val clockUncertaintyMs: Double,
    @SerialName("telemetry_age_ms") val telemetryAgeMs: Long,
    @SerialName("readiness_acked") val readinessAcked: Boolean,
    @SerialName("readiness_expires_at_ms") val readinessExpiresAtMs: Long,
    @SerialName("task_lease_status") val taskLeaseStatus: String,
    @SerialName("scheduled_start_s") val scheduledStartS: Int,
    @SerialName("actual_observed_start_s") val actualObservedStartS: Int? = null,
    @SerialName("start_deviation_s") val startDeviationS: Double? = null,
    @SerialName("stage") val stage: SyncStage,
    @SerialName("tolerance_exceeded_reason") val toleranceExceededReason: String? = null,
    @SerialName("available_actions") val availableActions: List<String> = emptyList(),
)

@Serializable
data class ApprovalRecord(
    @SerialName("mission_version") val missionVersion: Int,
    @SerialName("approved_by") val approvedBy: String,
    @SerialName("approved_at_ms") val approvedAtMs: Long,
    @SerialName("valid") val valid: Boolean,
    @SerialName("invalidation_reason") val invalidationReason: String? = null,
)

@Serializable
data class ControlLease(
    @SerialName("lease_id") val leaseId: String,
    @SerialName("mission_id") val missionId: String,
    @SerialName("owner_operator_id") val ownerOperatorId: String,
    @SerialName("owner_device_id") val ownerDeviceId: String,
    @SerialName("coordinator_epoch") val coordinatorEpoch: Int,
    @SerialName("expires_at_ms") val expiresAtMs: Long,
    @SerialName("status") val status: ControlLeaseStatus,
    @SerialName("pending_handover_operator_id") val pendingHandoverOperatorId: String? = null,
)

@Serializable
data class CommandRecord(
    @SerialName("request_id") val requestId: String,
    @SerialName("mission_id") val missionId: String,
    @SerialName("mission_version") val missionVersion: Int,
    @SerialName("coordinator_epoch") val coordinatorEpoch: Int,
    @SerialName("control_lease_id") val controlLeaseId: String,
    @SerialName("command_type") val commandType: String,
    @SerialName("affected_aircraft") val affectedAircraft: List<String> = emptyList(),
    @SerialName("expiry_ms") val expiryMs: Long,
    @SerialName("state") val state: CommandState,
    @SerialName("reason_code") val reasonCode: String? = null,
    @SerialName("detail") val detail: String,
    @SerialName("created_at_ms") val createdAtMs: Long,
    @SerialName("updated_at_ms") val updatedAtMs: Long,
    @SerialName("ack_at_ms") val ackAtMs: Long? = null,
    @SerialName("effect_at_ms") val effectAtMs: Long? = null,
)

@Serializable
data class ExceptionResolutionEntry(
    @SerialName("timestamp_ms") val timestampMs: Long,
    @SerialName("operator_id") val operatorId: String,
    @SerialName("action") val action: String,
    @SerialName("note") val note: String,
)

@Serializable
data class MissionException(
    @SerialName("exception_id") val exceptionId: String,
    @SerialName("category") val category: ExceptionCategory,
    @SerialName("severity") val severity: String,
    @SerialName("affected_aircraft") val affectedAircraft: List<String> = emptyList(),
    @SerialName("affected_tasks") val affectedTasks: List<String> = emptyList(),
    @SerialName("source_observations") val sourceObservations: List<String> = emptyList(),
    @SerialName("detected_at_ms") val detectedAtMs: Long,
    @SerialName("status") val status: ExceptionStatus,
    @SerialName("proposed_responses") val proposedResponses: List<String> = emptyList(),
    @SerialName("responsible_operator") val responsibleOperator: String,
    @SerialName("resolution_history") val resolutionHistory: List<ExceptionResolutionEntry> = emptyList(),
)

@Serializable
data class PayloadDataRecord(
    @SerialName("record_id") val recordId: String,
    @SerialName("aircraft_id") val aircraftId: String,
    @SerialName("payload_id") val payloadId: String,
    @SerialName("config_version") val configVersion: String,
    @SerialName("capture_frames_commanded") val captureFramesCommanded: Int,
    @SerialName("capture_frames_observed") val captureFramesObserved: Int,
    @SerialName("upload_progress_pct") val uploadProgressPct: Double,
    @SerialName("coverage_pct") val coveragePct: Double,
    @SerialName("missing_data_findings") val missingDataFindings: List<String> = emptyList(),
    @SerialName("follow_up_job_id") val followUpJobId: String? = null,
    @SerialName("planned_application_rate") val plannedApplicationRate: String? = null,
    @SerialName("observed_delivery_rate") val observedDeliveryRate: String? = null,
)

@Serializable
data class TelemetryEvent(
    @SerialName("event_id") val eventId: String,
    @SerialName("stream_sequence") val streamSequence: Long,
    @SerialName("event_type") val eventType: String,
    @SerialName("observation_time_ms") val observationTimeMs: Long,
    @SerialName("ingestion_time_ms") val ingestionTimeMs: Long,
    @SerialName("mission_version") val missionVersion: Int,
    @SerialName("payload") val payload: JsonObject = JsonObject(emptyMap()),
)

@Serializable
data class ReplayGapWindow(
    @SerialName("start_s") val startS: Double,
    @SerialName("end_s") val endS: Double,
    @SerialName("reason") val reason: String,
)

@Serializable
data class ReplaySession(
    @SerialName("replay_id") val replayId: String,
    @SerialName("mission_id") val missionId: String,
    @SerialName("title") val title: String,
    @SerialName("duration_s") val durationS: Double,
    @SerialName("gap_windows") val gapWindows: List<ReplayGapWindow> = emptyList(),
    @SerialName("events") val events: List<TelemetryEvent> = emptyList(),
)

@Serializable
data class MissionRecord(
    @SerialName("mission_id") val missionId: String,
    @SerialName("name") val name: String,
    @SerialName("mission_version") val missionVersion: Int,
    @SerialName("coordinator_epoch") val coordinatorEpoch: Int,
    @SerialName("status") val status: MissionStatus,
    @SerialName("operating_mode") val operatingMode: OperatingMode,
    @SerialName("site") val site: MapSiteConfig,
    @SerialName("jobs") val jobs: List<SurveyJob> = emptyList(),
    @SerialName("allocations") val allocations: List<TaskAllocationItem> = emptyList(),
    @SerialName("conflicts") val conflicts: List<ConflictFinding> = emptyList(),
    @SerialName("sync_states") val syncStates: List<AircraftSyncState> = emptyList(),
    @SerialName("approval") val approval: ApprovalRecord? = null,
    @SerialName("control_lease") val controlLease: ControlLease,
    @SerialName("commands") val commands: List<CommandRecord> = emptyList(),
    @SerialName("exceptions") val exceptions: List<MissionException> = emptyList(),
    @SerialName("payload_data") val payloadData: List<PayloadDataRecord> = emptyList(),
)

@Serializable
data class FleetSnapshotResponse(
    @SerialName("mission") val mission: MissionRecord,
    @SerialName("fleet") val fleet: List<AircraftRecord>,
    @SerialName("stream_sequence") val streamSequence: Long,
)

@Serializable
data class SyncTolerances(
    @SerialName("max_clock_uncertainty_ms") val maxClockUncertaintyMs: Double,
    @SerialName("max_telemetry_age_ms") val maxTelemetryAgeMs: Long,
    @SerialName("max_start_deviation_s") val maxStartDeviationS: Double,
    @SerialName("readiness_ttl_ms") val readinessTtlMs: Long,
)

@Serializable
data class CapabilitiesResponse(
    @SerialName("coordinator_version") val coordinatorVersion: String,
    @SerialName("operating_modes") val operatingModes: List<String>,
    @SerialName("connected_aircraft_enabled") val connectedAircraftEnabled: Boolean,
    @SerialName("connected_aircraft_gate") val connectedAircraftGate: String,
    @SerialName("sync_tolerances") val syncTolerances: SyncTolerances,
    @SerialName("supported_job_types") val supportedJobTypes: List<String>,
)

@Serializable
data class CreateJobPayload(
    @SerialName("title") val title: String,
    @SerialName("job_type") val jobType: JobType,
    @SerialName("work_area_label") val workAreaLabel: String,
    @SerialName("payload_type") val payloadType: String,
    @SerialName("timing_window_start_s") val timingWindowStartS: Int,
    @SerialName("timing_window_end_s") val timingWindowEndS: Int,
    @SerialName("responsible_operator") val responsibleOperator: String,
    @SerialName("operating_conditions") val operatingConditions: String,
    @SerialName("required_outputs") val requiredOutputs: List<String>,
    @SerialName("work_area_polygon") val workAreaPolygon: List<LocalPoint3D> = emptyList(),
)

@Serializable
data class CreateJobResponse(
    @SerialName("job") val job: SurveyJob,
    @SerialName("mission") val mission: MissionRecord,
)

@Serializable
data class ApprovalPayload(
    @SerialName("mission_version") val missionVersion: Int,
    @SerialName("operator_id") val operatorId: String,
)

@Serializable
data class ApprovalResponse(
    @SerialName("message") val message: String,
    @SerialName("mission") val mission: MissionRecord,
)

@Serializable
data class CommandSubmissionPayload(
    @SerialName("request_id") val requestId: String,
    @SerialName("mission_version") val missionVersion: Int,
    @SerialName("coordinator_epoch") val coordinatorEpoch: Int,
    @SerialName("control_lease_id") val controlLeaseId: String,
    @SerialName("command_type") val commandType: String,
    @SerialName("affected_aircraft") val affectedAircraft: List<String>,
    @SerialName("expiry_ms") val expiryMs: Long,
    @SerialName("operator_id") val operatorId: String,
)

@Serializable
data class CommandSubmissionResponse(
    @SerialName("command") val command: CommandRecord,
    @SerialName("mission") val mission: MissionRecord,
)

@Serializable
data class AllocationProposalPayload(
    @SerialName("resolve_conflicts") val resolveConflicts: Boolean = true,
)

@Serializable
data class ControlLeasePayload(
    @SerialName("operator_id") val operatorId: String,
    @SerialName("device_id") val deviceId: String,
)

@Serializable
data class HandoverPayload(
    @SerialName("action") val action: String,
    @SerialName("operator_id") val operatorId: String,
    @SerialName("device_id") val deviceId: String,
)

@Serializable
data class ExceptionActionPayload(
    @SerialName("action") val action: String,
    @SerialName("operator_id") val operatorId: String,
    @SerialName("resolution_action") val resolutionAction: String = "",
    @SerialName("note") val note: String = "",
)

@Serializable
data class MissionDraft(
    val draftId: String,
    val title: String,
    val jobType: JobType,
    val workAreaLabel: String,
    val payloadType: String,
    val timingStartS: Int,
    val timingEndS: Int,
    val responsibleOperator: String,
    val operatingConditions: String,
    val savedAtElapsedMs: Long,
    val syncedToMissionVersion: Int? = null,
)

data class DownloadedReport(
    val reportId: String,
    val missionId: String,
    val title: String,
    val createdAtMs: Long,
    val summaryText: String,
    val sha256Hex: String,
)

data class AppPreferences(
    val gatewayBaseUrl: String = "http://10.0.2.2:8000",
    val operatorId: String = "Op. A. Vance",
    val deviceId: String = "TABLET-UK-OPS-01",
    val connectedAircraftIntegrationEnabled: Boolean = false,
    val telemetryBatchIntervalMs: Long = 500L,
    val showUncertaintyRings: Boolean = true,
)
