package com.example.core.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.core.database.DownloadedReportEntity
import com.example.core.database.SpitfireDatabase
import com.example.core.model.MissionRecord
import kotlinx.serialization.json.Json
import java.io.File
import java.security.MessageDigest
import java.util.UUID

/**
 * Non-control WorkManager task: exports a verifiable engineering mission report to Room and private storage.
 * Never used for flight-control scheduling.
 */
class ReportExportWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    private val json = Json { ignoreUnknownKeys = true }

    override suspend fun doWork(): Result {
        val db = SpitfireDatabase.getInstance(applicationContext)
        val dao = db.spitfireDao()
        val cached = dao.getLatestMissionCache() ?: return Result.failure()

        val mission = runCatching {
            json.decodeFromString(MissionRecord.serializer(), cached.missionJson)
        }.getOrNull() ?: return Result.failure()

        val reportId = "RPT-${UUID.randomUUID().toString().take(8).uppercase()}"
        val nowMs = System.currentTimeMillis()
        val summary = buildString {
            appendLine("SPITFIRE.OS ENGINEERING MISSION REPORT — $reportId")
            appendLine("Mission: ${mission.name} (${mission.missionId}) v${mission.missionVersion} Epoch ${mission.coordinatorEpoch}")
            appendLine("Site Datum: ${mission.site.coordinateReference} | Alt: ${mission.site.altitudeReference}")
            appendLine("Status: ${mission.status} | Mode: ${mission.operatingMode}")
            appendLine("Jobs: ${mission.jobs.size} | Allocations: ${mission.allocations.size} | Open Exceptions: ${mission.exceptions.count { it.status.name != "RESOLVED" }}")
            mission.payloadData.forEach { pd ->
                appendLine("Payload ${pd.aircraftId}/${pd.payloadId}: commanded=${pd.captureFramesCommanded}, observed=${pd.captureFramesObserved}, coverage=${pd.coveragePct}%")
            }
        }
        val sha256 = MessageDigest.getInstance("SHA-256")
            .digest(summary.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

        val exportDir = File(applicationContext.filesDir, "reports").apply { mkdirs() }
        File(exportDir, "$reportId.txt").writeText(summary)

        dao.insertReport(
            DownloadedReportEntity(
                reportId = reportId,
                missionId = mission.missionId,
                title = "${mission.name} v${mission.missionVersion} Engineering Report",
                createdAtMs = nowMs,
                summaryText = summary,
                sha256Hex = sha256,
            ),
        )

        return Result.success(Data.Builder().putString("report_id", reportId).build())
    }

    companion object {
        fun enqueue(context: Context) {
            val request = OneTimeWorkRequestBuilder<ReportExportWorker>().build()
            WorkManager.getInstance(context).enqueue(request)
        }
    }
}
