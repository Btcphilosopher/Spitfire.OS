package com.example.core.network

import com.example.core.model.TelemetryEvent

sealed class StreamIngestionResult {
    data class Accepted(val event: TelemetryEvent) : StreamIngestionResult()
    data class DuplicateIgnored(val eventId: String, val sequence: Long) : StreamIngestionResult()
    data class OutOfOrderIgnored(val eventId: String, val sequence: Long, val expectedNext: Long) : StreamIngestionResult()
    data class GapDetected(val expectedSequence: Long, val receivedSequence: Long) : StreamIngestionResult()
}

/**
 * Deterministic bounded stream sequencer handling duplicate event IDs, out-of-order arrivals,
 * and sequence gaps requiring snapshot recovery.
 */
class StreamEventSequencer(
    initialSequence: Long = 0L,
    private val maxSeenIds: Int = 256,
) {
    var lastSequence: Long = initialSequence
        private set

    private val seenEventIds = ArrayDeque<String>(maxSeenIds)
    private val seenSet = HashSet<String>(maxSeenIds)

    @Synchronized
    fun reset(newBaselineSequence: Long) {
        lastSequence = newBaselineSequence
        seenEventIds.clear()
        seenSet.clear()
    }

    @Synchronized
    fun ingest(event: TelemetryEvent): StreamIngestionResult {
        if (seenSet.contains(event.eventId)) {
            return StreamIngestionResult.DuplicateIgnored(event.eventId, event.streamSequence)
        }
        if (lastSequence > 0L && event.streamSequence <= lastSequence) {
            return StreamIngestionResult.OutOfOrderIgnored(
                eventId = event.eventId,
                sequence = event.streamSequence,
                expectedNext = lastSequence + 1,
            )
        }
        if (lastSequence > 0L && event.streamSequence > lastSequence + 1) {
            return StreamIngestionResult.GapDetected(
                expectedSequence = lastSequence + 1,
                receivedSequence = event.streamSequence,
            )
        }

        lastSequence = event.streamSequence
        if (seenEventIds.size >= maxSeenIds) {
            val evicted = seenEventIds.removeFirst()
            seenSet.remove(evicted)
        }
        seenEventIds.addLast(event.eventId)
        seenSet.add(event.eventId)
        return StreamIngestionResult.Accepted(event)
    }
}
