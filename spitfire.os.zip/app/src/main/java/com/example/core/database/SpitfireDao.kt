package com.example.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SpitfireDao {
    @Query("SELECT * FROM mission_cache ORDER BY cachedAtWallMs DESC LIMIT 1")
    fun observeLatestMissionCache(): Flow<MissionCacheEntity?>

    @Query("SELECT * FROM mission_cache ORDER BY cachedAtWallMs DESC LIMIT 1")
    suspend fun getLatestMissionCache(): MissionCacheEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMissionCache(entity: MissionCacheEntity)

    @Query("SELECT * FROM mission_drafts ORDER BY savedAtElapsedMs DESC")
    fun observeDrafts(): Flow<List<MissionDraftEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDraft(draft: MissionDraftEntity)

    @Query("DELETE FROM mission_drafts WHERE draftId = :draftId")
    suspend fun deleteDraft(draftId: String)

    @Query("SELECT * FROM replay_sessions ORDER BY storedAtWallMs DESC")
    fun observeReplaySessions(): Flow<List<ReplaySessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertReplaySession(entity: ReplaySessionEntity)

    @Query("SELECT * FROM downloaded_reports ORDER BY createdAtMs DESC")
    fun observeReports(): Flow<List<DownloadedReportEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: DownloadedReportEntity)

    @Query("SELECT * FROM aircraft_docs ORDER BY aircraftId ASC")
    fun observeAircraftDocs(): Flow<List<AircraftDocEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAircraftDocs(docs: List<AircraftDocEntity>)
}
