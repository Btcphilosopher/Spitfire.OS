package com.example.core.repository

import com.example.core.database.AircraftDocEntity
import com.example.core.model.AircraftRecord
import com.example.core.model.AircraftSyncState
import com.example.core.model.CapabilitiesResponse
import com.example.core.model.ConflictFinding
import com.example.core.model.ControlLease
import com.example.core.model.ControlLeaseStatus
import com.example.core.model.ExceptionCategory
import com.example.core.model.ExceptionStatus
import com.example.core.model.FleetSnapshotResponse
import com.example.core.model.JobType
import com.example.core.model.LocalPoint3D
import com.example.core.model.MapSiteConfig
import com.example.core.model.MissionException
import com.example.core.model.MissionRecord
import com.example.core.model.MissionStatus
import com.example.core.model.NamedZone
import com.example.core.model.OperatingMode
import com.example.core.model.PayloadDataRecord
import com.example.core.model.ReplayGapWindow
import com.example.core.model.ReplaySession
import com.example.core.model.SurveyJob
import com.example.core.model.SyncStage
import com.example.core.model.SyncTolerances
import com.example.core.model.TaskAllocationItem
import com.example.core.model.TelemetryEvent
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * Bundled Pennine Solar & Farm Survey local-coordinate site cache & isolated replay archive
 * so offline inspection, map preview, documentation, and replay work without map API keys or internet.
 */
object PennineScenarioSeed {

    fun defaultCapabilities(): CapabilitiesResponse = CapabilitiesResponse(
        coordinatorVersion = "1.4.0-py",
        operatingModes = listOf("SIMULATION", "REPLAY"),
        connectedAircraftEnabled = false,
        connectedAircraftGate = "DISABLED_BY_DEFAULT_REQUIRES_AIRFRAME_CERTIFICATION",
        syncTolerances = SyncTolerances(
            maxClockUncertaintyMs = 35.0,
            maxTelemetryAgeMs = 2500L,
            maxStartDeviationS = 2.0,
            readinessTtlMs = 30000L,
        ),
        supportedJobTypes = JobType.entries.map { it.name },
    )

    fun seedSnapshot(nowMs: Long): FleetSnapshotResponse {
        val site = MapSiteConfig(
            siteId = "SITE-PENNINE-01",
            name = "Pennine Solar & Farm Survey",
            coordinateReference = "LOCAL_ENU_M (Origin: 53.7214N, -1.9482W, Pennine Ridge)",
            altitudeReference = "AGL_SITE_DATUM (Launch Pad Elevation 298.0 m AMSL)",
            terrainSource = "OS Terrain 5m + Pennine Lidar Strip 2025-Q4",
            mapDataAgeS = 142,
            positionUncertaintyM = 1.4,
            planningAssumptions = "Max wind 9.5 m/s WSW; daylight VLOS/EVLOS corridor; 22% reserve floor.",
            zones = listOf(
                NamedZone(
                    zoneId = "BND-PENNINE",
                    label = "Site Boundary",
                    zoneType = "BOUNDARY",
                    vertices = listOf(
                        LocalPoint3D(20.0, 20.0, 0.0),
                        LocalPoint3D(580.0, 20.0, 0.0),
                        LocalPoint3D(580.0, 420.0, 0.0),
                        LocalPoint3D(20.0, 420.0, 0.0),
                    ),
                ),
                NamedZone(
                    zoneId = "EXC-PYLON",
                    label = "HV Pylon Corridor (Exclusion)",
                    zoneType = "EXCLUSION",
                    vertices = listOf(
                        LocalPoint3D(265.0, 205.0, 0.0),
                        LocalPoint3D(330.0, 205.0, 0.0),
                        LocalPoint3D(330.0, 275.0, 0.0),
                        LocalPoint3D(265.0, 275.0, 0.0),
                    ),
                ),
                NamedZone("PAD-NORTH", "North Launch Pad", "LAUNCH", listOf(LocalPoint3D(80.0, 60.0, 0.0))),
                NamedZone("PAD-SOUTH", "South Launch Pad", "LAUNCH", listOf(LocalPoint3D(340.0, 65.0, 0.0))),
                NamedZone("REC-NORTH", "North Recovery Apron", "RECOVERY", listOf(LocalPoint3D(105.0, 60.0, 0.0))),
                NamedZone("CTG-WEST", "West Moor Contingency", "CONTINGENCY", listOf(LocalPoint3D(55.0, 355.0, 0.0))),
            ),
        )

        val fleet = listOf(
            AircraftRecord(
                aircraftId = "SPIT-01",
                callsign = "Kestrel-1",
                airframe = "Spitfire-Q6 Hex Survey",
                autopilotVersion = "PX4-1.15.2-UK",
                supportedPayloads = listOf("THERMAL_EO", "RGB_ORTHO"),
                configuredMaxSpeedMps = 14.0,
                configuredMaxWindMps = 11.0,
                configuredMinReservePct = 22.0,
                batteryId = "BAT-PEN-101",
                batterySocPct = 91.0,
                batteryVoltageV = 49.8,
                batteryObservedAtMs = nowMs - 400,
                chargingState = "DISCHARGING_PREFLIGHT",
                assignedTaskId = "TASK-001",
                observedFlightMode = "ARMED_READY",
                linkStatus = "NOMINAL",
                position = LocalPoint3D(80.0, 60.0, 0.2),
                positionObservedAtMs = nowMs - 350,
                positionUncertaintyM = 1.1,
                bootId = "BOOT-S01-8841",
                latestCommandOutcome = "ACKNOWLEDGED_BY_AIRCRAFT",
                supportedContingencies = listOf("HOLD_POSITION", "RETURN_TO_CONTINGENCY_CTG_WEST", "COORDINATION_ABORT"),
                documentationSummary = "CAA PDRA-01 compliant hexacopter; 240Wh LiHV pack; dual RTK GNSS.",
            ),
            AircraftRecord(
                aircraftId = "SPIT-02",
                callsign = "Kestrel-2",
                airframe = "Spitfire-Q6 Hex Survey",
                autopilotVersion = "PX4-1.15.2-UK",
                supportedPayloads = listOf("THERMAL_EO", "MULTISPECTRAL"),
                configuredMaxSpeedMps = 14.0,
                configuredMaxWindMps = 11.0,
                configuredMinReservePct = 22.0,
                batteryId = "BAT-PEN-102",
                batterySocPct = 88.0,
                batteryVoltageV = 49.3,
                batteryObservedAtMs = nowMs - 480,
                chargingState = "DISCHARGING_PREFLIGHT",
                assignedTaskId = "TASK-002",
                observedFlightMode = "ARMED_READY",
                linkStatus = "NOMINAL",
                position = LocalPoint3D(340.0, 65.0, 0.1),
                positionObservedAtMs = nowMs - 420,
                positionUncertaintyM = 1.2,
                bootId = "BOOT-S02-4419",
                latestCommandOutcome = "ACKNOWLEDGED_BY_AIRCRAFT",
                supportedContingencies = listOf("HOLD_POSITION", "RETURN_TO_LAUNCH_PAD_SOUTH", "COORDINATION_ABORT"),
                documentationSummary = "Thermal & multispectral survey variant; verified gimbal calibration 2026-11.",
            ),
            AircraftRecord(
                aircraftId = "SPIT-03",
                callsign = "Merlin-3",
                airframe = "Spitfire-V4 Quad Inspector",
                autopilotVersion = "ArduPilot-4.5.7",
                supportedPayloads = listOf("RGB_ORTHO", "ROOF_ZOOM"),
                configuredMaxSpeedMps = 12.0,
                configuredMaxWindMps = 9.5,
                configuredMinReservePct = 22.0,
                batteryId = "BAT-PEN-103",
                batterySocPct = 86.0,
                batteryVoltageV = 24.6,
                batteryObservedAtMs = nowMs - 520,
                chargingState = "STANDBY",
                assignedTaskId = "TASK-003",
                observedFlightMode = "STANDBY_ON_PAD",
                linkStatus = "NOMINAL",
                position = LocalPoint3D(95.0, 72.0, 0.0),
                positionObservedAtMs = nowMs - 500,
                positionUncertaintyM = 1.3,
                bootId = "BOOT-S03-9902",
                latestCommandOutcome = "ACKNOWLEDGED_BY_AIRCRAFT",
                supportedContingencies = listOf("HOLD_POSITION", "LAND_AT_RECOVERY_REC_NORTH", "COORDINATION_ABORT"),
                documentationSummary = "Close-range agricultural & roof inspection quadrotor with 40x optical zoom.",
            ),
            AircraftRecord(
                aircraftId = "SPIT-04",
                callsign = "Merlin-4",
                airframe = "Spitfire-V4 Quad Inspector",
                autopilotVersion = "ArduPilot-4.5.7",
                supportedPayloads = listOf("MULTISPECTRAL", "RGB_ORTHO"),
                configuredMaxSpeedMps = 12.0,
                configuredMaxWindMps = 9.5,
                configuredMinReservePct = 22.0,
                batteryId = "BAT-PEN-104",
                batterySocPct = 83.0,
                batteryVoltageV = 24.4,
                batteryObservedAtMs = nowMs - 600,
                chargingState = "STANDBY",
                assignedTaskId = "TASK-004",
                observedFlightMode = "STANDBY_ON_PAD",
                linkStatus = "NOMINAL",
                position = LocalPoint3D(355.0, 74.0, 0.0),
                positionObservedAtMs = nowMs - 580,
                positionUncertaintyM = 1.4,
                bootId = "BOOT-S04-7721",
                latestCommandOutcome = "NONE",
                supportedContingencies = listOf("HOLD_POSITION", "COORDINATION_ABORT"),
                documentationSummary = "Agricultural NDVI multispectral carrier.",
            ),
            AircraftRecord(
                aircraftId = "SPIT-05",
                callsign = "Harrier-5",
                airframe = "Spitfire-L8 Heavy Mapper",
                autopilotVersion = "PX4-1.15.2-UK",
                supportedPayloads = listOf("LIDAR_POD", "CORRIDOR_CARGO"),
                configuredMaxSpeedMps = 15.0,
                configuredMaxWindMps = 12.0,
                configuredMinReservePct = 22.0,
                batteryId = "BAT-PEN-105",
                batterySocPct = 36.0,
                batteryVoltageV = 46.1,
                batteryObservedAtMs = nowMs - 450,
                chargingState = "ON_CHARGER_72W",
                assignedTaskId = null,
                observedFlightMode = "CHARGING_RESERVE_LOW",
                linkStatus = "NOMINAL",
                position = LocalPoint3D(115.0, 48.0, 0.0),
                positionObservedAtMs = nowMs - 450,
                positionUncertaintyM = 1.1,
                bootId = "BOOT-S05-3304",
                latestCommandOutcome = "NONE",
                supportedContingencies = listOf("COORDINATION_ABORT"),
                documentationSummary = "LiDAR stockpile mapper; BAT-PEN-105 on charger (insufficient reserve for dispatch).",
            ),
            AircraftRecord(
                aircraftId = "SPIT-06",
                callsign = "Gannet-6",
                airframe = "Spitfire-D2 Corridor Delivery",
                autopilotVersion = "PX4-1.15.1-UK",
                supportedPayloads = listOf("CORRIDOR_CARGO", "RGB_ORTHO"),
                configuredMaxSpeedMps = 16.0,
                configuredMaxWindMps = 11.0,
                configuredMinReservePct = 22.0,
                batteryId = "BAT-PEN-106",
                batterySocPct = 94.0,
                batteryVoltageV = 50.1,
                batteryObservedAtMs = nowMs - 700,
                chargingState = "STANDBY",
                maintenanceRestrictions = listOf("PROP_HUB_TORQUE_CHECK_DUE"),
                maintenanceBlockingReason = "PROP_HUB_TORQUE_CHECK_DUE (Logged by Eng. R. Patel; requires sign-off before flight)",
                assignedTaskId = null,
                observedFlightMode = "MAINTENANCE_LOCKED",
                linkStatus = "NOMINAL",
                position = LocalPoint3D(370.0, 48.0, 0.0),
                positionObservedAtMs = nowMs - 700,
                positionUncertaintyM = 1.0,
                bootId = "BOOT-S06-1190",
                latestCommandOutcome = "REJECTED",
                supportedContingencies = listOf("COORDINATION_ABORT"),
                documentationSummary = "Blocked by maintenance defect PROP_HUB_TORQUE_CHECK_DUE.",
            ),
        )

        val jobs = listOf(
            SurveyJob(
                jobId = "JOB-SOLAR-N",
                title = "Pennine North Solar Array Thermal",
                jobType = JobType.SOLAR_FARM_SURVEY,
                workAreaLabel = "North Solar Block A",
                workAreaPolygon = listOf(
                    LocalPoint3D(60.0, 120.0, 45.0),
                    LocalPoint3D(230.0, 120.0, 45.0),
                    LocalPoint3D(230.0, 260.0, 45.0),
                    LocalPoint3D(60.0, 260.0, 45.0),
                ),
                requiredOutputs = listOf("Radiometric Thermal Orthomosaic", "String Hot-Spot Table"),
                payloadType = "THERMAL_EO",
                timingWindowStartS = 60,
                timingWindowEndS = 420,
                responsibleOperator = "Op. A. Vance",
                operatingConditions = "Daylight, wind <= 9.5 m/s, VLOS North Ridge",
            ),
            SurveyJob(
                jobId = "JOB-SOLAR-S",
                title = "Pennine East Solar & Inverter Sheds",
                jobType = JobType.SOLAR_FARM_SURVEY,
                workAreaLabel = "East Solar Block B",
                workAreaPolygon = listOf(
                    LocalPoint3D(355.0, 125.0, 55.0),
                    LocalPoint3D(540.0, 125.0, 55.0),
                    LocalPoint3D(540.0, 275.0, 55.0),
                    LocalPoint3D(355.0, 275.0, 55.0),
                ),
                requiredOutputs = listOf("Thermal Strip Map", "RGB Inspection Frames"),
                payloadType = "THERMAL_EO",
                timingWindowStartS = 60,
                timingWindowEndS = 460,
                responsibleOperator = "Op. A. Vance",
                operatingConditions = "Daylight, wind <= 9.5 m/s",
            ),
            SurveyJob(
                jobId = "JOB-AGRI-W",
                title = "Upper Pasture Drainage & Crop Vigour",
                jobType = JobType.AGRICULTURAL_INSPECTION,
                workAreaLabel = "West Pasture Plot 3",
                workAreaPolygon = listOf(
                    LocalPoint3D(50.0, 285.0, 65.0),
                    LocalPoint3D(240.0, 285.0, 65.0),
                    LocalPoint3D(240.0, 395.0, 65.0),
                    LocalPoint3D(50.0, 395.0, 65.0),
                ),
                requiredOutputs = listOf("RGB Orthomosaic", "Drainage Anomaly GeoJSON"),
                payloadType = "RGB_ORTHO",
                timingWindowStartS = 120,
                timingWindowEndS = 520,
                responsibleOperator = "Op. A. Vance",
                operatingConditions = "Cloud ceiling > 120m AGL",
            ),
            SurveyJob(
                jobId = "JOB-AGRI-E",
                title = "East Meadow Multispectral Strip",
                jobType = JobType.AGRICULTURAL_INSPECTION,
                workAreaLabel = "East Meadow Plot 4",
                workAreaPolygon = listOf(
                    LocalPoint3D(360.0, 295.0, 75.0),
                    LocalPoint3D(545.0, 295.0, 75.0),
                    LocalPoint3D(545.0, 395.0, 75.0),
                    LocalPoint3D(360.0, 395.0, 75.0),
                ),
                requiredOutputs = listOf("NDVI Index Map"),
                payloadType = "MULTISPECTRAL",
                timingWindowStartS = 145,
                timingWindowEndS = 560,
                responsibleOperator = "Op. A. Vance",
                operatingConditions = "Diffuse daylight preferred",
            ),
        )

        val allocations = listOf(
            TaskAllocationItem(
                taskId = "TASK-001",
                jobId = "JOB-SOLAR-N",
                aircraftId = "SPIT-01",
                payloadId = "THERMAL_EO",
                areaLabel = "North Solar Block A",
                proposedRoute = listOf(
                    LocalPoint3D(80.0, 60.0, 0.0),
                    LocalPoint3D(75.0, 135.0, 45.0),
                    LocalPoint3D(215.0, 135.0, 45.0),
                    LocalPoint3D(215.0, 190.0, 45.0),
                    LocalPoint3D(75.0, 190.0, 45.0),
                    LocalPoint3D(75.0, 245.0, 45.0),
                    LocalPoint3D(215.0, 245.0, 45.0),
                    LocalPoint3D(105.0, 60.0, 0.0),
                ),
                estimatedDurationS = 240,
                estimatedEnergyWh = 74.0,
                batteryReservePct = 60.2,
                launchSiteId = "PAD-NORTH",
                launchSlotS = 60,
                recoverySiteId = "REC-NORTH",
                recoverySlotS = 300,
            ),
            TaskAllocationItem(
                taskId = "TASK-002",
                jobId = "JOB-SOLAR-S",
                aircraftId = "SPIT-02",
                payloadId = "THERMAL_EO",
                areaLabel = "East Solar Block B",
                proposedRoute = listOf(
                    LocalPoint3D(80.0, 60.0, 0.0),
                    LocalPoint3D(370.0, 140.0, 55.0),
                    LocalPoint3D(525.0, 140.0, 55.0),
                    LocalPoint3D(525.0, 200.0, 55.0),
                    LocalPoint3D(370.0, 200.0, 55.0),
                    LocalPoint3D(370.0, 260.0, 55.0),
                    LocalPoint3D(525.0, 260.0, 55.0),
                    LocalPoint3D(340.0, 65.0, 0.0),
                ),
                estimatedDurationS = 285,
                estimatedEnergyWh = 87.9,
                batteryReservePct = 51.4,
                launchSiteId = "PAD-NORTH",
                launchSlotS = 66,
                recoverySiteId = "REC-SOUTH",
                recoverySlotS = 351,
            ),
            TaskAllocationItem(
                taskId = "TASK-003",
                jobId = "JOB-AGRI-W",
                aircraftId = "SPIT-03",
                payloadId = "RGB_ORTHO",
                areaLabel = "West Pasture Plot 3",
                proposedRoute = listOf(
                    LocalPoint3D(80.0, 60.0, 0.0),
                    LocalPoint3D(65.0, 300.0, 65.0),
                    LocalPoint3D(225.0, 300.0, 65.0),
                    LocalPoint3D(225.0, 340.0, 65.0),
                    LocalPoint3D(65.0, 340.0, 65.0),
                    LocalPoint3D(65.0, 380.0, 65.0),
                    LocalPoint3D(225.0, 380.0, 65.0),
                    LocalPoint3D(105.0, 60.0, 0.0),
                ),
                estimatedDurationS = 330,
                estimatedEnergyWh = 101.8,
                batteryReservePct = 43.6,
                launchSiteId = "PAD-NORTH",
                launchSlotS = 120,
                recoverySiteId = "REC-NORTH",
                recoverySlotS = 450,
            ),
            TaskAllocationItem(
                taskId = "TASK-004",
                jobId = "JOB-AGRI-E",
                aircraftId = "SPIT-04",
                payloadId = "MULTISPECTRAL",
                areaLabel = "East Meadow Plot 4",
                proposedRoute = listOf(
                    LocalPoint3D(340.0, 65.0, 0.0),
                    LocalPoint3D(375.0, 310.0, 75.0),
                    LocalPoint3D(530.0, 310.0, 75.0),
                    LocalPoint3D(530.0, 380.0, 75.0),
                    LocalPoint3D(375.0, 380.0, 75.0),
                    LocalPoint3D(340.0, 65.0, 0.0),
                ),
                estimatedDurationS = 240,
                estimatedEnergyWh = 74.0,
                batteryReservePct = 52.2,
                launchSiteId = "PAD-SOUTH",
                launchSlotS = 145,
                recoverySiteId = "REC-SOUTH",
                recoverySlotS = 385,
            ),
        )

        val conflicts = listOf(
            ConflictFinding(
                conflictId = "CONF-001",
                severity = "CRITICAL",
                category = "LAUNCH_SLOT_CONFLICT",
                description = "SPIT-01 and SPIT-02 share PAD-NORTH with only 6s separation (minimum buffer 15s).",
                affectedAircraft = listOf("SPIT-01", "SPIT-02"),
                affectedTasks = listOf("TASK-001", "TASK-002"),
                locationXM = 80.0,
                locationYM = 60.0,
                timeWindowStartS = 60,
                timeWindowEndS = 81,
                spatialBufferM = 18.0,
                temporalBufferS = 15.0,
                modelledScopeNote = "Evaluated within modelled local Pennine DEM, nominal wind envelope, and reported position uncertainty. Strategic scheduling does NOT replace onboard sense-and-avoid.",
            ),
        )

        val syncStates = fleet.mapIndexed { idx, ac ->
            AircraftSyncState(
                aircraftId = ac.aircraftId,
                planVersion = 1,
                coordinatorEpoch = 4,
                bootId = ac.bootId,
                clockOffsetMs = (idx - 2) * 3.4,
                clockUncertaintyMs = 11.5 + idx * 2.1,
                telemetryAgeMs = nowMs - ac.positionObservedAtMs,
                readinessAcked = idx < 3,
                readinessExpiresAtMs = if (idx < 3) nowMs + 28_000L else 0L,
                taskLeaseStatus = if (idx < 3) "READY_BOUND_TO_V1" else "UNALLOCATED",
                scheduledStartS = allocations.getOrNull(idx)?.launchSlotS ?: 0,
                stage = if (idx < 3) SyncStage.READINESS_ACKNOWLEDGED else SyncStage.PLAN_PROPOSED,
            )
        }

        val mission = MissionRecord(
            missionId = "MSN-PENNINE-2026-11",
            name = "Pennine Solar & Farm Survey",
            missionVersion = 1,
            coordinatorEpoch = 4,
            status = MissionStatus.VALIDATED_WITH_CONFLICTS,
            operatingMode = OperatingMode.SIMULATION,
            site = site,
            jobs = jobs,
            allocations = allocations,
            conflicts = conflicts,
            syncStates = syncStates,
            approval = null,
            controlLease = ControlLease(
                leaseId = "LEASE-OP-VANCE-01",
                missionId = "MSN-PENNINE-2026-11",
                ownerOperatorId = "Op. A. Vance",
                ownerDeviceId = "TABLET-UK-OPS-01",
                coordinatorEpoch = 4,
                expiresAtMs = nowMs + 180_000L,
                status = ControlLeaseStatus.HELD,
            ),
            commands = emptyList(),
            exceptions = listOf(
                MissionException(
                    exceptionId = "EXC-001",
                    category = ExceptionCategory.LOW_OBSERVED_BATTERY,
                    severity = "CAUTION",
                    affectedAircraft = listOf("SPIT-05"),
                    affectedTasks = emptyList(),
                    sourceObservations = listOf("BAT-PEN-105 SoC=36.0% (< 55% dispatch threshold)"),
                    detectedAtMs = nowMs - 5_000L,
                    status = ExceptionStatus.OPEN,
                    proposedResponses = listOf("KEEP_ON_CHARGER", "EXCLUDE_FROM_ALLOCATION"),
                    responsibleOperator = "Op. A. Vance",
                ),
            ),
            payloadData = listOf(
                PayloadDataRecord(
                    recordId = "DATA-001",
                    aircraftId = "SPIT-01",
                    payloadId = "THERMAL_EO",
                    configVersion = "CFG-THM-2.4",
                    captureFramesCommanded = 140,
                    captureFramesObserved = 122,
                    uploadProgressPct = 100.0,
                    coveragePct = 87.1,
                    missingDataFindings = listOf("18 thermal frames missing along North Solar Row 4-6 (12.9% gap)."),
                    followUpJobId = null,
                ),
                PayloadDataRecord(
                    recordId = "DATA-002",
                    aircraftId = "SPIT-04",
                    payloadId = "MULTISPECTRAL",
                    configVersion = "CFG-MS-1.9",
                    captureFramesCommanded = 96,
                    captureFramesObserved = 0,
                    uploadProgressPct = 0.0,
                    coveragePct = 0.0,
                    missingDataFindings = emptyList(),
                    followUpJobId = null,
                    plannedApplicationRate = "Survey only (0 L/ha)",
                    observedDeliveryRate = "N/A",
                ),
            ),
        )

        return FleetSnapshotResponse(mission = mission, fleet = fleet, streamSequence = 100L)
    }

    fun seedReplaySession(nowMs: Long): ReplaySession {
        val baseMs = nowMs - 300_000L
        val events = mutableListOf<TelemetryEvent>()
        var seq = 1L
        for (tS in 0..60 step 3) {
            if (tS in 42..47) continue // Explicit gap window
            events.add(
                TelemetryEvent(
                    eventId = "REP-EVT-%03d".format(seq),
                    streamSequence = seq,
                    eventType = "TELEMETRY_FRAME",
                    observationTimeMs = baseMs + tS * 1000L,
                    ingestionTimeMs = baseMs + tS * 1000L + 85L,
                    missionVersion = 2,
                    payload = buildJsonObject {
                        put("t_s", tS.toDouble())
                        put("spit01_x", 80.0 + (tS * 2.8).coerceAtMost(150.0))
                        put("spit01_y", 130.0 + (tS % 12) * 8.0)
                        put("spit01_alt", if (tS > 3) 45.0 else 0.0)
                        put("spit01_soc", (91.0 - tS * 0.45).coerceAtLeast(48.0))
                        put("spit02_x", 360.0 + (tS * 2.5).coerceAtMost(170.0))
                        put("spit02_y", 140.0 + ((tS + 5) % 10) * 10.0)
                        put("spit02_alt", if (tS > 6) 55.0 else 0.0)
                        put("spit02_soc", (88.0 - tS * 0.40).coerceAtLeast(51.0))
                        if (tS == 24) {
                            put("note", "SPIT-04 withdrawn at t=24s; unfinished lanes reassigned to SPIT-03")
                        }
                    },
                ),
            )
            seq++
        }
        return ReplaySession(
            replayId = "RPL-PENNINE-001",
            missionId = "MSN-PENNINE-2026-11",
            title = "Pennine Solar & Farm Survey — Run #01 (With Reassignment & Gap)",
            durationS = 60.0,
            gapWindows = listOf(
                ReplayGapWindow(
                    startS = 42.0,
                    endS = 47.0,
                    reason = "Telemetry recorder uplink drop (42.0s–47.0s); no synthetic interpolation applied.",
                ),
            ),
            events = events,
        )
    }

    fun seedAircraftDocs(fleet: List<AircraftRecord>): List<AircraftDocEntity> =
        fleet.map { ac ->
            AircraftDocEntity(
                aircraftId = ac.aircraftId,
                callsign = ac.callsign,
                airframe = ac.airframe,
                autopilotVersion = ac.autopilotVersion,
                summary = ac.documentationSummary,
                contingencyRules = ac.supportedContingencies.joinToString(" · "),
            )
        }
}
