package com.example.core.repository

import android.content.Context
import android.os.SystemClock
import com.example.core.database.AircraftDocEntity
import com.example.core.database.MissionCacheEntity
import com.example.core.database.MissionDraftEntity
import com.example.core.database.ReplaySessionEntity
import com.example.core.database.SpitfireDao
import com.example.core.datastore.PreferencesRepository
import com.example.core.datastore.SecureCredentialStore
import com.example.core.model.AircraftRecord
import com.example.core.model.AppPreferences
import com.example.core.model.CapabilitiesResponse
import com.example.core.model.CommandRecord
import com.example.core.model.CommandSubmissionPayload
import com.example.core.model.CreateJobPayload
import com.example.core.model.DownloadedReport
import com.example.core.model.ExceptionActionPayload
import com.example.core.model.FleetSnapshotResponse
import com.example.core.model.HandoverPayload
import com.example.core.model.JobType
import com.example.core.model.MissionDraft
import com.example.core.model.MissionRecord
import com.example.core.model.OperatingMode
import com.example.core.model.ReplaySession
import com.example.core.model.TelemetryEvent
import com.example.core.network.SpitfireApiClient
import com.example.core.network.StreamEventSequencer
import com.example.core.network.StreamIngestionResult
import com.example.core.work.ReportExportWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.builtins.ListSerializer
import java.util.UUID

sealed class ReconciliationStatus {
    data object Synchronised : ReconciliationStatus()
    data object Reconciling : ReconciliationStatus()
    data class OfflineCached(val reason: String) : ReconciliationStatus()
    data class ConflictNeedsReview(val detail: String) : ReconciliationStatus()
}

data class RepositoryUiData(
    val mission: MissionRecord,
    val fleet: List<AircraftRecord>,
    val capabilities: CapabilitiesResponse,
    val gatewayConnected: Boolean,
    val reconciliationStatus: ReconciliationStatus,
    val operatingMode: OperatingMode,
    val lastSyncElapsedMs: Long,
    val telemetryStreamNote: String,
    val pendingCommandIds: Set<String>,
    val lastError: String? = null,
    val lastActionBanner: String? = null,
)

class SpitfireRepository(
    private val context: Context,
    private val apiClient: SpitfireApiClient,
    private val dao: SpitfireDao,
    val preferencesRepository: PreferencesRepository,
    val credentialStore: SecureCredentialStore,
    private val elapsedTimeProvider: () -> Long = { SystemClock.elapsedRealtime() },
) {
    private val repoJob = SupervisorJob()
    private val scope = CoroutineScope(repoJob + Dispatchers.IO)
    private val sequencer = StreamEventSequencer()
    private var streamJob: Job? = null

    private val initialSeed = PennineScenarioSeed.seedSnapshot(System.currentTimeMillis())

    private val _state = MutableStateFlow(
        RepositoryUiData(
            mission = initialSeed.mission,
            fleet = initialSeed.fleet,
            capabilities = PennineScenarioSeed.defaultCapabilities(),
            gatewayConnected = false,
            reconciliationStatus = ReconciliationStatus.OfflineCached("Initialising gateway probe..."),
            operatingMode = OperatingMode.SIMULATION,
            lastSyncElapsedMs = elapsedTimeProvider(),
            telemetryStreamNote = "Awaiting gateway connection",
            pendingCommandIds = emptySet(),
        ),
    )
    val state: StateFlow<RepositoryUiData> = _state.asStateFlow()

    val preferences: StateFlow<AppPreferences> = preferencesRepository.preferences.stateIn(
        scope = scope,
        started = SharingStarted.Eagerly,
        initialValue = AppPreferences(),
    )

    val drafts: StateFlow<List<MissionDraft>> = dao.observeDrafts().map { list ->
        list.map {
            MissionDraft(
                draftId = it.draftId,
                title = it.title,
                jobType = runCatching { JobType.valueOf(it.jobType) }.getOrDefault(JobType.SOLAR_FARM_SURVEY),
                workAreaLabel = it.workAreaLabel,
                payloadType = it.payloadType,
                timingStartS = it.timingStartS,
                timingEndS = it.timingEndS,
                responsibleOperator = it.responsibleOperator,
                operatingConditions = it.operatingConditions,
                savedAtElapsedMs = it.savedAtElapsedMs,
                syncedToMissionVersion = it.syncedToMissionVersion,
            )
        }
    }.stateIn(scope, SharingStarted.WhileSubscribed(5000), emptyList())

    val replaySessions: StateFlow<List<ReplaySession>> = dao.observeReplaySessions().map { entities ->
        entities.mapNotNull {
            runCatching { apiClient.json.decodeFromString(ReplaySession.serializer(), it.replayJson) }.getOrNull()
        }
    }.stateIn(scope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reports: StateFlow<List<DownloadedReport>> = dao.observeReports().map { entities ->
        entities.map {
            DownloadedReport(
                reportId = it.reportId,
                missionId = it.missionId,
                title = it.title,
                createdAtMs = it.createdAtMs,
                summaryText = it.summaryText,
                sha256Hex = it.sha256Hex,
            )
        }
    }.stateIn(scope, SharingStarted.WhileSubscribed(5000), emptyList())

    val aircraftDocs: StateFlow<List<AircraftDocEntity>> = dao.observeAircraftDocs()
        .stateIn(scope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        scope.launch {
            ensureOfflineSeededInRoom()
            reconcileWithGateway()
        }
    }

    fun close() {
        stopWebSocketStream()
        repoJob.cancel()
    }

    suspend fun closeAndAwait() {
        stopWebSocketStream()
        repoJob.cancel()
        repoJob.join()
    }

    private suspend fun ensureOfflineSeededInRoom() {
        val existingCache = dao.getLatestMissionCache()
        if (existingCache == null) {
            val nowWall = System.currentTimeMillis()
            val nowElapsed = elapsedTimeProvider()
            dao.upsertMissionCache(
                MissionCacheEntity(
                    missionId = initialSeed.mission.missionId,
                    missionJson = apiClient.json.encodeToString(MissionRecord.serializer(), initialSeed.mission),
                    fleetJson = apiClient.json.encodeToString(ListSerializer(AircraftRecord.serializer()), initialSeed.fleet),
                    cachedAtWallMs = nowWall,
                    cachedAtElapsedMs = nowElapsed,
                    streamSequence = initialSeed.streamSequence,
                ),
            )
        } else {
            val cachedMission = runCatching {
                apiClient.json.decodeFromString(MissionRecord.serializer(), existingCache.missionJson)
            }.getOrNull()
            val cachedFleet = runCatching {
                apiClient.json.decodeFromString(ListSerializer(AircraftRecord.serializer()), existingCache.fleetJson)
            }.getOrNull()
            if (cachedMission != null && cachedFleet != null) {
                _state.update {
                    it.copy(
                        mission = cachedMission,
                        fleet = cachedFleet,
                        lastSyncElapsedMs = existingCache.cachedAtElapsedMs,
                    )
                }
            }
        }

        val existingReplays = dao.observeReplaySessions().first()
        if (existingReplays.isEmpty()) {
            val replay = PennineScenarioSeed.seedReplaySession(System.currentTimeMillis())
            dao.upsertReplaySession(
                ReplaySessionEntity(
                    replayId = replay.replayId,
                    missionId = replay.missionId,
                    title = replay.title,
                    durationS = replay.durationS,
                    replayJson = apiClient.json.encodeToString(ReplaySession.serializer(), replay),
                    storedAtWallMs = System.currentTimeMillis(),
                ),
            )
        }

        dao.upsertAircraftDocs(PennineScenarioSeed.seedAircraftDocs(initialSeed.fleet))
    }

    suspend fun reconcileWithGateway() {
        val baseUrl = preferences.value.gatewayBaseUrl
        val token = credentialStore.readGatewayToken()
        _state.update { it.copy(reconciliationStatus = ReconciliationStatus.Reconciling, lastError = null) }

        runCatching {
            val caps = apiClient.getCapabilities(baseUrl, token)
            val snapshot = apiClient.getFleetSnapshot(baseUrl)
            val replays = runCatching { apiClient.listReplays(baseUrl) }.getOrDefault(emptyList())
            Triple(caps, snapshot, replays)
        }.onSuccess { (caps, snapshot, replays) ->
            sequencer.reset(snapshot.streamSequence)
            persistSnapshot(snapshot)
            replays.forEach { replay ->
                dao.upsertReplaySession(
                    ReplaySessionEntity(
                        replayId = replay.replayId,
                        missionId = replay.missionId,
                        title = replay.title,
                        durationS = replay.durationS,
                        replayJson = apiClient.json.encodeToString(ReplaySession.serializer(), replay),
                        storedAtWallMs = System.currentTimeMillis(),
                    ),
                )
            }
            dao.upsertAircraftDocs(PennineScenarioSeed.seedAircraftDocs(snapshot.fleet))
            _state.update {
                it.copy(
                    mission = snapshot.mission,
                    fleet = snapshot.fleet,
                    capabilities = caps,
                    gatewayConnected = true,
                    reconciliationStatus = ReconciliationStatus.Synchronised,
                    lastSyncElapsedMs = elapsedTimeProvider(),
                    telemetryStreamNote = "Snapshot v${snapshot.mission.missionVersion} · seq=${snapshot.streamSequence}",
                    lastError = null,
                    lastActionBanner = "Reconciled with Python gateway (v${snapshot.mission.missionVersion}).",
                )
            }
            startWebSocketStream(baseUrl)
        }.onFailure { err ->
            stopWebSocketStream()
            _state.update {
                it.copy(
                    gatewayConnected = false,
                    reconciliationStatus = ReconciliationStatus.OfflineCached(
                        err.message ?: "Python gateway unreachable",
                    ),
                    telemetryStreamNote = "Offline cache active; live telemetry stream paused",
                )
            }
        }
    }

    private suspend fun persistSnapshot(snapshot: FleetSnapshotResponse) {
        dao.upsertMissionCache(
            MissionCacheEntity(
                missionId = snapshot.mission.missionId,
                missionJson = apiClient.json.encodeToString(MissionRecord.serializer(), snapshot.mission),
                fleetJson = apiClient.json.encodeToString(ListSerializer(AircraftRecord.serializer()), snapshot.fleet),
                cachedAtWallMs = System.currentTimeMillis(),
                cachedAtElapsedMs = elapsedTimeProvider(),
                streamSequence = snapshot.streamSequence,
            ),
        )
    }

    private fun startWebSocketStream(baseUrl: String) {
        streamJob?.cancel()
        streamJob = scope.launch {
            while (isActive) {
                apiClient.streamTelemetryEvents(baseUrl)
                    .catch { _ ->
                        _state.update {
                            it.copy(
                                gatewayConnected = false,
                                reconciliationStatus = ReconciliationStatus.OfflineCached("WebSocket stream interrupted"),
                            )
                        }
                    }
                    .collect { event ->
                        handleIncomingStreamEvent(event)
                    }
                delay(2000L)
            }
        }
    }

    private fun stopWebSocketStream() {
        streamJob?.cancel()
        streamJob = null
    }

    private suspend fun handleIncomingStreamEvent(event: TelemetryEvent) {
        when (val result = sequencer.ingest(event)) {
            is StreamIngestionResult.Accepted -> {
                val baseUrl = preferences.value.gatewayBaseUrl
                runCatching { apiClient.getFleetSnapshot(baseUrl) }.onSuccess { snap ->
                    persistSnapshot(snap)
                    _state.update {
                        it.copy(
                            mission = snap.mission,
                            fleet = snap.fleet,
                            lastSyncElapsedMs = elapsedTimeProvider(),
                            telemetryStreamNote = "Live WS seq=${result.event.streamSequence} · ${result.event.eventType}",
                        )
                    }
                }
            }
            is StreamIngestionResult.DuplicateIgnored -> {
                _state.update {
                    it.copy(telemetryStreamNote = "Duplicate event ${result.eventId} dropped safely")
                }
            }
            is StreamIngestionResult.OutOfOrderIgnored -> {
                _state.update {
                    it.copy(telemetryStreamNote = "Out-of-order seq=${result.sequence} ignored")
                }
            }
            is StreamIngestionResult.GapDetected -> {
                _state.update {
                    it.copy(
                        telemetryStreamNote = "Stream gap (${result.expectedSequence}..${result.receivedSequence}) — fetching snapshot",
                    )
                }
                reconcileWithGateway()
            }
        }
    }

    fun setOperatingMode(mode: OperatingMode) {
        if (mode == OperatingMode.CONNECTED_AIRCRAFT &&
            (!_state.value.capabilities.connectedAircraftEnabled || !preferences.value.connectedAircraftIntegrationEnabled)
        ) {
            _state.update {
                it.copy(
                    lastError = "CONNECTED AIRCRAFT is disabled by default in backend capabilities and Settings.",
                )
            }
            return
        }
        _state.update { it.copy(operatingMode = mode, lastError = null) }
    }

    suspend fun saveOfflineDraft(
        title: String,
        jobType: JobType,
        workAreaLabel: String,
        payloadType: String,
        timingStartS: Int,
        timingEndS: Int,
        responsibleOperator: String,
        operatingConditions: String,
    ) {
        val draft = MissionDraftEntity(
            draftId = "DRF-${UUID.randomUUID().toString().take(6).uppercase()}",
            title = title,
            jobType = jobType.name,
            workAreaLabel = workAreaLabel,
            payloadType = payloadType,
            timingStartS = timingStartS,
            timingEndS = timingEndS,
            responsibleOperator = responsibleOperator,
            operatingConditions = operatingConditions,
            savedAtElapsedMs = elapsedTimeProvider(),
            syncedToMissionVersion = null,
        )
        dao.upsertDraft(draft)
        _state.update { it.copy(lastActionBanner = "Saved editable draft ${draft.draftId} locally in Room.") }
    }

    suspend fun deleteDraft(draftId: String) {
        dao.deleteDraft(draftId)
    }

    suspend fun submitDraftToGateway(draft: MissionDraft) {
        if (!requireLiveControl()) return
        val baseUrl = preferences.value.gatewayBaseUrl
        runCatching {
            apiClient.createJob(
                baseUrl,
                CreateJobPayload(
                    title = draft.title,
                    jobType = draft.jobType,
                    workAreaLabel = draft.workAreaLabel,
                    payloadType = draft.payloadType,
                    timingWindowStartS = draft.timingStartS,
                    timingWindowEndS = draft.timingEndS,
                    responsibleOperator = draft.responsibleOperator,
                    operatingConditions = draft.operatingConditions,
                    requiredOutputs = listOf("Orthomosaic", "Inspection Report"),
                ),
            )
        }.onSuccess { res ->
            dao.upsertDraft(
                MissionDraftEntity(
                    draftId = draft.draftId,
                    title = draft.title,
                    jobType = draft.jobType.name,
                    workAreaLabel = draft.workAreaLabel,
                    payloadType = draft.payloadType,
                    timingStartS = draft.timingStartS,
                    timingEndS = draft.timingEndS,
                    responsibleOperator = draft.responsibleOperator,
                    operatingConditions = draft.operatingConditions,
                    savedAtElapsedMs = draft.savedAtElapsedMs,
                    syncedToMissionVersion = res.mission.missionVersion,
                ),
            )
            updateMissionFromGateway(res.mission, "Submitted ${draft.title} -> mission v${res.mission.missionVersion}.")
        }.onFailure { err ->
            _state.update { it.copy(lastError = "Job creation failed: ${err.message}") }
        }
    }

    suspend fun createJobOnline(payload: CreateJobPayload) {
        if (!requireLiveControl()) return
        runCatching {
            apiClient.createJob(preferences.value.gatewayBaseUrl, payload)
        }.onSuccess { res ->
            updateMissionFromGateway(res.mission, "Created job ${res.job.jobId} (mission v${res.mission.missionVersion}).")
        }.onFailure { err ->
            _state.update { it.copy(lastError = "Create job error: ${err.message}") }
        }
    }

    suspend fun requestAllocationProposal(resolveConflicts: Boolean) {
        if (!requireLiveControl()) return
        val missionId = _state.value.mission.missionId
        runCatching {
            apiClient.requestAllocationProposal(preferences.value.gatewayBaseUrl, missionId, resolveConflicts)
        }.onSuccess { m ->
            updateMissionFromGateway(m, "Allocation proposal generated for v${m.missionVersion}.")
        }.onFailure { err ->
            _state.update { it.copy(lastError = "Allocation failed: ${err.message}") }
        }
    }

    suspend fun requestValidation() {
        if (!requireLiveControl()) return
        val missionId = _state.value.mission.missionId
        runCatching {
            apiClient.validateMission(preferences.value.gatewayBaseUrl, missionId)
        }.onSuccess { m ->
            updateMissionFromGateway(m, "Validation completed for v${m.missionVersion}: ${m.conflicts.size} finding(s).")
        }.onFailure { err ->
            _state.update { it.copy(lastError = "Validation failed: ${err.message}") }
        }
    }

    suspend fun approveMissionVersion(version: Int) {
        if (!requireLiveControl()) return
        val missionId = _state.value.mission.missionId
        val operatorId = preferences.value.operatorId
        runCatching {
            apiClient.approveMission(preferences.value.gatewayBaseUrl, missionId, version, operatorId)
        }.onSuccess { res ->
            updateMissionFromGateway(res.mission, res.message)
        }.onFailure { err ->
            _state.update { it.copy(lastError = "Approval rejected: ${err.message}") }
        }
    }

    suspend fun submitCommand(
        commandType: String,
        affectedAircraft: List<String>,
        isDispatch: Boolean = false,
    ) {
        if (!requireLiveControl()) return
        val current = _state.value
        val mission = current.mission
        val prefs = preferences.value
        val requestId = "CMD-${UUID.randomUUID().toString().take(8).uppercase()}"
        val payload = CommandSubmissionPayload(
            requestId = requestId,
            missionVersion = mission.missionVersion,
            coordinatorEpoch = mission.coordinatorEpoch,
            controlLeaseId = mission.controlLease.leaseId,
            commandType = commandType,
            affectedAircraft = affectedAircraft,
            expiryMs = System.currentTimeMillis() + 30_000L,
            operatorId = prefs.operatorId,
        )
        _state.update { it.copy(pendingCommandIds = it.pendingCommandIds + requestId) }

        runCatching {
            if (isDispatch) {
                apiClient.submitDispatchRequest(prefs.gatewayBaseUrl, mission.missionId, payload)
            } else {
                apiClient.submitActionRequest(prefs.gatewayBaseUrl, mission.missionId, payload)
            }
        }.onSuccess { res ->
            _state.update { it.copy(pendingCommandIds = it.pendingCommandIds - requestId) }
            updateMissionFromGateway(
                res.mission,
                "Command ${res.command.requestId}: ${res.command.state} (${res.command.detail})",
            )
        }.onFailure { _ ->
            // Do NOT automatically repeat execution after timeout; query status using same request_id!
            val statusResult = runCatching {
                apiClient.getCommandStatus(prefs.gatewayBaseUrl, requestId)
            }.getOrNull()
            _state.update {
                it.copy(
                    pendingCommandIds = it.pendingCommandIds - requestId,
                    lastError = statusResult?.let { cmd ->
                        "Command ${cmd.requestId} status reconciled: ${cmd.state}"
                    } ?: "Command $requestId timed out — outcome UNKNOWN; query $requestId rather than re-sending.",
                )
            }
        }
    }

    suspend fun queryCommandStatus(requestId: String): CommandRecord? {
        return runCatching {
            apiClient.getCommandStatus(preferences.value.gatewayBaseUrl, requestId)
        }.onSuccess { cmd ->
            _state.update {
                it.copy(lastActionBanner = "Queried $requestId: ${cmd.state} (${cmd.detail})")
            }
        }.getOrNull()
    }

    suspend fun acquireOrRenewControlLease() {
        if (!requireConnected()) return
        val mission = _state.value.mission
        val prefs = preferences.value
        runCatching {
            apiClient.acquireControlLease(prefs.gatewayBaseUrl, mission.missionId, prefs.operatorId, prefs.deviceId)
        }.onSuccess { lease ->
            _state.update {
                it.copy(
                    mission = it.mission.copy(controlLease = lease),
                    lastActionBanner = "Control lease ${lease.leaseId} held by ${lease.ownerOperatorId}.",
                )
            }
        }.onFailure { err ->
            _state.update { it.copy(lastError = "Lease acquisition failed: ${err.message}") }
        }
    }

    suspend fun requestOrAcceptHandover(action: String, targetOperator: String) {
        if (!requireConnected()) return
        val mission = _state.value.mission
        val prefs = preferences.value
        runCatching {
            apiClient.submitHandover(
                prefs.gatewayBaseUrl,
                mission.missionId,
                HandoverPayload(action = action, operatorId = targetOperator, deviceId = prefs.deviceId),
            )
        }.onSuccess { lease ->
            _state.update {
                it.copy(
                    mission = it.mission.copy(controlLease = lease),
                    lastActionBanner = "Handover $action processed -> ${lease.status} (${lease.ownerOperatorId}).",
                )
            }
        }.onFailure { err ->
            _state.update { it.copy(lastError = "Handover error: ${err.message}") }
        }
    }

    suspend fun handleExceptionAction(
        exceptionId: String,
        action: String,
        resolutionAction: String = "",
        note: String = "",
    ) {
        if (!requireLiveControl()) return
        val mission = _state.value.mission
        val prefs = preferences.value
        runCatching {
            apiClient.handleException(
                prefs.gatewayBaseUrl,
                mission.missionId,
                exceptionId,
                ExceptionActionPayload(
                    action = action,
                    operatorId = prefs.operatorId,
                    resolutionAction = resolutionAction,
                    note = note,
                ),
            )
        }.onSuccess { updatedExc ->
            _state.update {
                it.copy(
                    mission = it.mission.copy(
                        exceptions = it.mission.exceptions.map { e ->
                            if (e.exceptionId == updatedExc.exceptionId) updatedExc else e
                        },
                    ),
                    lastActionBanner = "Exception $exceptionId -> ${updatedExc.status}.",
                )
            }
        }.onFailure { err ->
            _state.update { it.copy(lastError = "Exception action failed: ${err.message}") }
        }
    }

    suspend fun triggerSimDelayedTelemetry() {
        if (!requireLiveControl()) return
        runCatching {
            apiClient.injectDelayedTelemetry(preferences.value.gatewayBaseUrl, _state.value.mission.missionId)
        }.onSuccess { m ->
            updateMissionFromGateway(m, "Injected delayed telemetry on SPIT-02; readiness & exception updated.")
        }
    }

    suspend fun triggerSimWithdrawAircraft(aircraftId: String = "SPIT-04") {
        if (!requireLiveControl()) return
        runCatching {
            apiClient.withdrawAircraft(preferences.value.gatewayBaseUrl, _state.value.mission.missionId, aircraftId)
        }.onSuccess { m ->
            updateMissionFromGateway(m, "Withdrew $aircraftId; unfinished work reassigned in v${m.missionVersion}.")
        }
    }

    suspend fun triggerSimMissingImageryFollowup() {
        if (!requireLiveControl()) return
        runCatching {
            apiClient.triggerMissingImageryFollowup(preferences.value.gatewayBaseUrl, _state.value.mission.missionId)
        }.onSuccess { m ->
            updateMissionFromGateway(m, "Recorded missing thermal frames and proposed follow-up job.")
        }
    }

    fun exportMissionReport() {
        ReportExportWorker.enqueue(context)
        _state.update { it.copy(lastActionBanner = "Enqueued background report export via WorkManager.") }
    }

    fun clearBannerOrError() {
        _state.update { it.copy(lastError = null, lastActionBanner = null) }
    }

    private suspend fun updateMissionFromGateway(mission: MissionRecord, banner: String) {
        val fleet = runCatching { apiClient.getFleet(preferences.value.gatewayBaseUrl) }
            .getOrDefault(_state.value.fleet)
        persistSnapshot(FleetSnapshotResponse(mission, fleet, sequencer.lastSequence))
        _state.update {
            it.copy(
                mission = mission,
                fleet = fleet,
                lastSyncElapsedMs = elapsedTimeProvider(),
                lastActionBanner = banner,
                lastError = null,
            )
        }
    }

    private fun requireConnected(): Boolean {
        if (!_state.value.gatewayConnected) {
            _state.update {
                it.copy(lastError = "Gateway offline — reconcile connectivity before issuing coordinator requests.")
            }
            return false
        }
        return true
    }

    private fun requireLiveControl(): Boolean {
        if (_state.value.operatingMode == OperatingMode.REPLAY) {
            _state.update {
                it.copy(lastError = "REPLAY — CONTROLS DISABLED. Exit Replay mode before issuing commands.")
            }
            return false
        }
        if (!requireConnected()) return false
        val lease = _state.value.mission.controlLease
        if (lease.ownerOperatorId != preferences.value.operatorId) {
            _state.update {
                it.copy(
                    lastError = "Observer-only tablet: control lease held by ${lease.ownerOperatorId}. Request handover first.",
                )
            }
            return false
        }
        return true
    }
}
