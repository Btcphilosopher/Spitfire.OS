package com.example.core.designsystem

import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val SpitfireDarkColorScheme = darkColorScheme(
    primary = TelemetryCyan,
    onPrimary = MidnightNavy,
    primaryContainer = TelemetryCyanMuted,
    onPrimaryContainer = IvoryPrimary,
    secondary = IvorySecondary,
    onSecondary = MidnightNavy,
    secondaryContainer = GraphiteInteractive,
    onSecondaryContainer = IvoryPrimary,
    tertiary = CautionAmber,
    onTertiary = MidnightNavy,
    tertiaryContainer = CautionAmberBg,
    onTertiaryContainer = CautionAmber,
    error = CriticalRed,
    onError = IvoryPrimary,
    errorContainer = CriticalRedBg,
    onErrorContainer = CriticalRed,
    background = MidnightNavy,
    onBackground = IvoryPrimary,
    surface = DeepSlateNavy,
    onSurface = IvoryPrimary,
    surfaceVariant = GraphitePanel,
    onSurfaceVariant = IvorySecondary,
    surfaceContainerLow = DeepSlateNavy,
    surfaceContainer = GraphitePanel,
    surfaceContainerHigh = GraphiteElevated,
    surfaceContainerHighest = GraphiteInteractive,
    outline = HairlineBorder,
    outlineVariant = MutedSteel,
)

// Restrained wing-inspired chamfered precision geometry
val SpitfireShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = CutCornerShape(topEnd = 6.dp, bottomStart = 6.dp),
    medium = CutCornerShape(topEnd = 10.dp),
    large = CutCornerShape(topEnd = 14.dp),
    extraLarge = RoundedCornerShape(16.dp),
)

@Composable
fun SpitfireTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = SpitfireDarkColorScheme,
        typography = SpitfireTypography,
        shapes = SpitfireShapes,
        content = content,
    )
}
