package com.example.core.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "mission_cache")
data class MissionCacheEntity(
    @PrimaryKey val missionId: String,
    val missionJson: String,
    val fleetJson: String,
    val cachedAtWallMs: Long,
    val cachedAtElapsedMs: Long,
    val streamSequence: Long,
)

@Entity(tableName = "mission_drafts")
data class MissionDraftEntity(
    @PrimaryKey val draftId: String,
    val title: String,
    val jobType: String,
    val workAreaLabel: String,
    val payloadType: String,
    val timingStartS: Int,
    val timingEndS: Int,
    val responsibleOperator: String,
    val operatingConditions: String,
    val savedAtElapsedMs: Long,
    val syncedToMissionVersion: Int?,
)

@Entity(tableName = "replay_sessions")
data class ReplaySessionEntity(
    @PrimaryKey val replayId: String,
    val missionId: String,
    val title: String,
    val durationS: Double,
    val replayJson: String,
    val storedAtWallMs: Long,
)

@Entity(tableName = "downloaded_reports")
data class DownloadedReportEntity(
    @PrimaryKey val reportId: String,
    val missionId: String,
    val title: String,
    val createdAtMs: Long,
    val summaryText: String,
    val sha256Hex: String,
)

@Entity(tableName = "aircraft_docs")
data class AircraftDocEntity(
    @PrimaryKey val aircraftId: String,
    val callsign: String,
    val airframe: String,
    val autopilotVersion: String,
    val summary: String,
    val contingencyRules: String,
)
