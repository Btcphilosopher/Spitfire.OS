package com.example.core.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        MissionCacheEntity::class,
        MissionDraftEntity::class,
        ReplaySessionEntity::class,
        DownloadedReportEntity::class,
        AircraftDocEntity::class,
    ],
    version = 2,
    exportSchema = false,
)
abstract class SpitfireDatabase : RoomDatabase() {
    abstract fun spitfireDao(): SpitfireDao

    companion object {
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `aircraft_docs` (
                        `aircraftId` TEXT NOT NULL,
                        `callsign` TEXT NOT NULL,
                        `airframe` TEXT NOT NULL,
                        `autopilotVersion` TEXT NOT NULL,
                        `summary` TEXT NOT NULL,
                        `contingencyRules` TEXT NOT NULL,
                        PRIMARY KEY(`aircraftId`)
                    )
                    """.trimIndent(),
                )
                db.execSQL(
                    "ALTER TABLE `downloaded_reports` ADD COLUMN `sha256Hex` TEXT NOT NULL DEFAULT ''",
                )
            }
        }

        @Volatile
        private var INSTANCE: SpitfireDatabase? = null

        fun getInstance(context: Context): SpitfireDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    SpitfireDatabase::class.java,
                    "spitfire_operator.db",
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
