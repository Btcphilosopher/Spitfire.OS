package com.example.core.designsystem

import androidx.compose.ui.graphics.Color

// Precision British Aerospace Palette
val MidnightNavy = Color(0xFF080E18)
val DeepSlateNavy = Color(0xFF0B1320)
val GraphitePanel = Color(0xFF121B2B)
val GraphiteElevated = Color(0xFF182336)
val GraphiteInteractive = Color(0xFF1E2B42)
val HairlineBorder = Color(0xFF283752)

val IvoryPrimary = Color(0xFFF4F1EA)
val IvorySecondary = Color(0xFFB7C1D1)
val MutedSteel = Color(0xFF7B89A0)

val TelemetryCyan = Color(0xFF38BDF8)
val TelemetryCyanMuted = Color(0xFF0C4A6E)
val CautionAmber = Color(0xFFF59E0B)
val CautionAmberBg = Color(0xFF3A2807)
val CriticalRed = Color(0xFFEF4444)
val CriticalRedBg = Color(0xFF3F1218)
val NominalEmerald = Color(0xFF10B981)
val NominalEmeraldBg = Color(0xFF0B3527)
val ReplayViolet = Color(0xFFA78BFA)
val ReplayVioletBg = Color(0xFF281D46)
