package com.example.core.designsystem

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.core.model.OperatingMode

enum class ConditionSeverity {
    NOMINAL,
    INFO,
    CAUTION,
    CRITICAL,
    MUTED,
}

@Composable
fun ConditionBadge(
    label: String,
    severity: ConditionSeverity,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
) {
    val (bg, fg, defaultIcon) = when (severity) {
        ConditionSeverity.NOMINAL -> Triple(NominalEmeraldBg, NominalEmerald, Icons.Filled.CheckCircle)
        ConditionSeverity.INFO -> Triple(TelemetryCyanMuted, TelemetryCyan, Icons.Filled.Info)
        ConditionSeverity.CAUTION -> Triple(CautionAmberBg, CautionAmber, Icons.Filled.Warning)
        ConditionSeverity.CRITICAL -> Triple(CriticalRedBg, CriticalRed, Icons.Filled.Error)
        ConditionSeverity.MUTED -> Triple(GraphiteInteractive, IvorySecondary, Icons.Filled.Info)
    }
    Surface(
        modifier = modifier.semantics(mergeDescendants = true) {},
        color = bg,
        shape = MaterialTheme.shapes.extraSmall,
        border = BorderStroke(1.dp, fg.copy(alpha = 0.55f)),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Icon(
                imageVector = icon ?: defaultIcon,
                contentDescription = label,
                tint = fg,
                modifier = Modifier.size(13.dp),
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = fg,
            )
        }
    }
}

@Composable
fun OperatingModeIndicator(
    mode: OperatingMode,
    connectedAircraftEnabled: Boolean,
    modifier: Modifier = Modifier,
) {
    val (label, bg, fg, icon) = when (mode) {
        OperatingMode.SIMULATION -> Quad("MODE: SIMULATION", TelemetryCyanMuted, TelemetryCyan, Icons.Filled.Science)
        OperatingMode.REPLAY -> Quad("MODE: REPLAY — CONTROLS DISABLED", ReplayVioletBg, ReplayViolet, Icons.Filled.History)
        OperatingMode.CONNECTED_AIRCRAFT -> Quad(
            if (connectedAircraftEnabled) "MODE: CONNECTED AIRCRAFT" else "CONNECTED AIRCRAFT (LOCKED)",
            CautionAmberBg,
            CautionAmber,
            Icons.Filled.Sensors,
        )
    }
    Surface(
        modifier = modifier.testTag("operating_mode_badge"),
        color = bg,
        shape = MaterialTheme.shapes.small,
        border = BorderStroke(1.dp, fg),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = fg,
                modifier = Modifier.size(16.dp),
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = fg,
            )
        }
    }
}

@Composable
fun OfflineStatusBanner(
    cachedAgeText: String,
    gatewayUrl: String,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("offline_status_banner"),
        color = CautionAmberBg,
        border = BorderStroke(1.dp, CautionAmber),
        shape = MaterialTheme.shapes.small,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Icon(
                imageVector = Icons.Filled.WifiOff,
                contentDescription = "Offline cache active",
                tint = CautionAmber,
                modifier = Modifier.size(20.dp),
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "OFFLINE CACHE — AUTHORITATIVE GATEWAY UNREACHABLE ($gatewayUrl)",
                    style = MaterialTheme.typography.labelLarge,
                    color = CautionAmber,
                )
                Text(
                    text = "Observation age: $cachedAgeText · Live dispatch disabled; editable drafts saved locally for reconciliation.",
                    style = MaterialTheme.typography.bodySmall,
                    color = IvoryPrimary,
                )
            }
        }
    }
}

@Composable
fun ReplayIsolationBanner(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("replay_isolation_banner"),
        color = ReplayVioletBg,
        border = BorderStroke(1.5.dp, ReplayViolet),
        shape = MaterialTheme.shapes.small,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Icon(
                imageVector = Icons.Filled.History,
                contentDescription = "Replay mode isolated",
                tint = ReplayViolet,
                modifier = Modifier.size(20.dp),
            )
            Text(
                text = "REPLAY — CONTROLS DISABLED · Replayed telemetry is isolated from the live command gateway.",
                style = MaterialTheme.typography.labelLarge,
                color = ReplayViolet,
            )
        }
    }
}

@Composable
fun WingAccentHeader(
    title: String,
    subtitle: String? = null,
    modifier: Modifier = Modifier,
    trailing: @Composable (() -> Unit)? = null,
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Canvas(modifier = Modifier.size(width = 16.dp, height = 22.dp)) {
                    val path = Path().apply {
                        moveTo(0f, size.height)
                        lineTo(size.width * 0.65f, 0f)
                        lineTo(size.width, 0f)
                        lineTo(size.width * 0.35f, size.height)
                        close()
                    }
                    drawPath(path, color = TelemetryCyan)
                }
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.headlineSmall,
                        color = IvoryPrimary,
                    )
                    if (subtitle != null) {
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = IvorySecondary,
                        )
                    }
                }
            }
            if (trailing != null) {
                trailing()
            }
        }
        Spacer(Modifier.height(6.dp))
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(2.dp),
        ) {
            drawLine(
                color = TelemetryCyan.copy(alpha = 0.7f),
                start = Offset(0f, 1f),
                end = Offset(size.width * 0.25f, 1f),
                strokeWidth = 2f,
            )
            drawLine(
                color = HairlineBorder,
                start = Offset(size.width * 0.25f, 1f),
                end = Offset(size.width, 1f),
                strokeWidth = 1f,
            )
        }
    }
}

@Composable
fun AeroPanel(
    modifier: Modifier = Modifier,
    borderColor: Color = HairlineBorder,
    backgroundColor: Color = GraphitePanel,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = modifier
            .background(backgroundColor, MaterialTheme.shapes.medium)
            .border(1.dp, borderColor, MaterialTheme.shapes.medium)
            .padding(12.dp),
    ) {
        content()
    }
}

@Composable
fun TelemetryMetricTile(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    valueColor: Color = IvoryPrimary,
    sublabel: String? = null,
) {
    Column(
        modifier = modifier
            .background(GraphiteElevated, MaterialTheme.shapes.extraSmall)
            .border(1.dp, HairlineBorder, MaterialTheme.shapes.extraSmall)
            .padding(horizontal = 10.dp, vertical = 8.dp),
    ) {
        Text(
            text = label.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = MutedSteel,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.labelLarge,
            color = valueColor,
        )
        if (sublabel != null) {
            Text(
                text = sublabel,
                style = MaterialTheme.typography.labelSmall,
                color = IvorySecondary,
            )
        }
    }
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
