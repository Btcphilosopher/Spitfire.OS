package com.example.feature.replay

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.SpitfireUiState
import com.example.core.designsystem.AeroPanel
import com.example.core.designsystem.CautionAmber
import com.example.core.designsystem.ConditionBadge
import com.example.core.designsystem.ConditionSeverity
import com.example.core.designsystem.IvoryPrimary
import com.example.core.designsystem.IvorySecondary
import com.example.core.designsystem.MutedSteel
import com.example.core.designsystem.ReplayViolet
import com.example.core.designsystem.TelemetryMetricTile
import com.example.core.designsystem.WingAccentHeader
import com.example.core.model.LocalPoint3D
import com.example.core.model.ReplaySession
import com.example.feature.planning.LocalPennineMapAdapter
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonPrimitive

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReplayScreen(
    uiState: SpitfireUiState,
    replaySessions: List<ReplaySession>,
    onTogglePlayPause: () -> Unit,
    onSetSpeed: (Float) -> Unit,
    onSeek: (Float) -> Unit,
    onSetAircraftFilter: (String?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val replayState = uiState.replayState
    val session = replaySessions.firstOrNull { it.replayId == replayState.selectedReplayId } ?: replaySessions.firstOrNull()
    val currentTimeS = replayState.currentTimeS
    val activeGap = session?.gapWindows?.firstOrNull { currentTimeS >= it.startS && currentTimeS <= it.endS }

    // Find latest recorded event at or before currentTimeS without inventing data inside gaps
    val activeEvent = session?.events
        ?.filter { evt -> (evt.payload["t_s"]?.jsonPrimitive?.doubleOrNull ?: 0.0) <= currentTimeS }
        ?.maxByOrNull { it.streamSequence }

    // Derive replayed aircraft positions solely from recorded event frames (never modifying live fleet)
    val replayedFleet = uiState.repoData.fleet.map { ac ->
        if (activeGap != null) {
            ac.copy(observedFlightMode = "DATA_GAP_NO_OBSERVATION")
        } else if (activeEvent != null && ac.aircraftId == "SPIT-01") {
            val x = activeEvent.payload["spit01_x"]?.jsonPrimitive?.doubleOrNull ?: ac.position.xM
            val y = activeEvent.payload["spit01_y"]?.jsonPrimitive?.doubleOrNull ?: ac.position.yM
            val alt = activeEvent.payload["spit01_alt"]?.jsonPrimitive?.doubleOrNull ?: ac.position.altM
            val soc = activeEvent.payload["spit01_soc"]?.jsonPrimitive?.doubleOrNull ?: ac.batterySocPct
            ac.copy(position = LocalPoint3D(x, y, alt), batterySocPct = soc, observedFlightMode = "REPLAY_SURVEY")
        } else if (activeEvent != null && ac.aircraftId == "SPIT-02") {
            val x = activeEvent.payload["spit02_x"]?.jsonPrimitive?.doubleOrNull ?: ac.position.xM
            val y = activeEvent.payload["spit02_y"]?.jsonPrimitive?.doubleOrNull ?: ac.position.yM
            val alt = activeEvent.payload["spit02_alt"]?.jsonPrimitive?.doubleOrNull ?: ac.position.altM
            val soc = activeEvent.payload["spit02_soc"]?.jsonPrimitive?.doubleOrNull ?: ac.batterySocPct
            ac.copy(position = LocalPoint3D(x, y, alt), batterySocPct = soc, observedFlightMode = "REPLAY_SURVEY")
        } else {
            ac
        }
    }.filter { replayState.aircraftFilterId == null || it.aircraftId == replayState.aircraftFilterId }

    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("replay_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            WingAccentHeader(
                title = session?.title ?: "Mission Replay Archive",
                subtitle = "Replay time T+${"%.1f".format(currentTimeS)}s / ${session?.durationS ?: 60.0}s · Separate from live monotonic clock",
            )
        }

        item {
            AeroPanel(borderColor = ReplayViolet) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Button(
                            onClick = onTogglePlayPause,
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("replay_play_pause_btn"),
                        ) {
                            Icon(if (replayState.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, contentDescription = null)
                            Text(if (replayState.isPlaying) "Pause" else "Play")
                        }
                        listOf(0.5f, 1.0f, 2.0f, 4.0f).forEach { spd ->
                            FilterChip(
                                selected = replayState.speedMultiplier == spd,
                                onClick = { onSetSpeed(spd) },
                                label = { Text("${spd}x") },
                                modifier = Modifier.minimumInteractiveComponentSize(),
                            )
                        }
                    }

                    Slider(
                        value = currentTimeS,
                        onValueChange = onSeek,
                        valueRange = 0f..(session?.durationS?.toFloat() ?: 60f),
                        modifier = Modifier.fillMaxWidth().testTag("replay_scrubber"),
                    )

                    if (activeGap != null) {
                        ConditionBadge(
                            label = "RECORDED DATA GAP (${activeGap.startS}s–${activeGap.endS}s): ${activeGap.reason}",
                            severity = ConditionSeverity.CAUTION,
                        )
                    } else if (activeEvent != null) {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TelemetryMetricTile("Frame Seq", "#${activeEvent.streamSequence}")
                            TelemetryMetricTile("Event ID", activeEvent.eventId)
                            TelemetryMetricTile("Mission Ver", "v${activeEvent.missionVersion}")
                        }
                    }

                    // Aircraft Filter
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = replayState.aircraftFilterId == null,
                            onClick = { onSetAircraftFilter(null) },
                            label = { Text("ALL AIRCRAFT") },
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        )
                        uiState.repoData.fleet.forEach { ac ->
                            FilterChip(
                                selected = replayState.aircraftFilterId == ac.aircraftId,
                                onClick = { onSetAircraftFilter(ac.aircraftId) },
                                label = { Text(ac.aircraftId) },
                                modifier = Modifier.minimumInteractiveComponentSize(),
                            )
                        }
                    }
                }
            }
        }

        item {
            LocalPennineMapAdapter.RenderMap(
                mission = uiState.repoData.mission,
                fleet = replayedFleet,
                selectedAircraftId = replayState.aircraftFilterId,
                showUncertaintyRings = uiState.preferences.showUncertaintyRings,
                editedWaypoints = emptyList(),
                editedExclusions = emptyList(),
                editedContingencies = emptyList(),
                interactiveEditEnabled = false,
                onMapTapLocalCoord = { _, _ -> },
                onSelectAircraft = { onSetAircraftFilter(it) },
                modifier = Modifier.fillMaxWidth(),
            )
        }

        item {
            Text("RECORDED EVENT LOG & GAPS (${session?.events?.size ?: 0} frames)", style = MaterialTheme.typography.titleSmall, color = IvoryPrimary)
        }

        items(session?.gapWindows ?: emptyList()) { gap ->
            AeroPanel(borderColor = CautionAmber) {
                Text(
                    text = "GAP [${gap.startS}s .. ${gap.endS}s]: ${gap.reason}",
                    style = MaterialTheme.typography.bodySmall,
                    color = CautionAmber,
                )
            }
        }

        items(session?.events?.takeLast(12)?.reversed() ?: emptyList(), key = { it.eventId }) { evt ->
            AeroPanel {
                val note = evt.payload["note"]?.jsonPrimitive?.content
                Column {
                    Text("${evt.eventId} (seq=${evt.streamSequence}) @ T+${evt.payload["t_s"]}s", style = MaterialTheme.typography.labelLarge, color = IvoryPrimary)
                    if (note != null) {
                        Text("Operator/Sync Event: $note", style = MaterialTheme.typography.bodySmall, color = ReplayViolet)
                    } else {
                        Text("Telemetry snapshot recorded (v${evt.missionVersion})", style = MaterialTheme.typography.bodySmall, color = MutedSteel)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}
