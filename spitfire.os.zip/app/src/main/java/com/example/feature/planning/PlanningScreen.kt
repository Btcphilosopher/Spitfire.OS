package com.example.feature.planning

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.MapEditorTool
import com.example.R
import com.example.SpitfireUiState
import com.example.core.designsystem.AeroPanel
import com.example.core.designsystem.CautionAmber
import com.example.core.designsystem.ConditionBadge
import com.example.core.designsystem.ConditionSeverity
import com.example.core.designsystem.CriticalRed
import com.example.core.designsystem.DeepSlateNavy
import com.example.core.designsystem.HairlineBorder
import com.example.core.designsystem.IvoryPrimary
import com.example.core.designsystem.IvorySecondary
import com.example.core.designsystem.MutedSteel
import com.example.core.designsystem.NominalEmerald
import com.example.core.designsystem.TelemetryCyan
import com.example.core.designsystem.TelemetryMetricTile
import com.example.core.designsystem.WingAccentHeader
import com.example.core.model.CommandRecord

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PlanningScreen(
    uiState: SpitfireUiState,
    queriedCommand: CommandRecord?,
    onSelectAircraft: (String) -> Unit,
    onSetMapTool: (MapEditorTool) -> Unit,
    onMapTap: (Double, Double) -> Unit,
    onClearMapEdits: () -> Unit,
    onRequestAllocation: (Boolean) -> Unit,
    onRequestValidation: () -> Unit,
    onApproveVersion: () -> Unit,
    onRequestDispatch: () -> Unit,
    onRequestPause: () -> Unit,
    onRequestCancel: () -> Unit,
    onRequestContingency: (String, String) -> Unit,
    onAcquireLease: () -> Unit,
    onRequestHandover: (String) -> Unit,
    onAcceptHandover: () -> Unit,
    onQueryCommandStatus: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val mission = uiState.repoData.mission
    val fleet = uiState.repoData.fleet
    val approvalValid = mission.approval?.valid == true && mission.approval.missionVersion == mission.missionVersion
    val isOwner = mission.controlLease.ownerOperatorId == uiState.preferences.operatorId
    val selectedAc = fleet.firstOrNull { it.aircraftId == uiState.selectedAircraftId } ?: fleet.firstOrNull()

    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("missions_planning_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            WingAccentHeader(
                title = "Mission Planning, Map Editor & Approvals",
                subtitle = "Mission v${mission.missionVersion} · Epoch ${mission.coordinatorEpoch} · Status: ${mission.status}",
            )
        }

        // Control Ownership & Handover Lease Bar
        item {
            AeroPanel(borderColor = if (isOwner) NominalEmerald else CautionAmber) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(
                                text = "Control Lease: ${mission.controlLease.leaseId}",
                                style = MaterialTheme.typography.titleSmall,
                                color = IvoryPrimary,
                            )
                            Text(
                                text = "Owner: ${mission.controlLease.ownerOperatorId} (${mission.controlLease.ownerDeviceId}) · Status: ${mission.controlLease.status}",
                                style = MaterialTheme.typography.bodySmall,
                                color = IvorySecondary,
                            )
                        }
                        ConditionBadge(
                            label = if (isOwner) "ACTIVE CONTROLLER" else "READ-ONLY OBSERVER",
                            severity = if (isOwner) ConditionSeverity.NOMINAL else ConditionSeverity.CAUTION,
                        )
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = onAcquireLease,
                            enabled = uiState.repoData.gatewayConnected,
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                            Text("Renew / Acquire Lease")
                        }
                        OutlinedButton(
                            onClick = { onRequestHandover("Op. M. Davies") },
                            enabled = uiState.repoData.gatewayConnected && isOwner,
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                            Text("Request Handover -> Davies")
                        }
                        OutlinedButton(
                            onClick = onAcceptHandover,
                            enabled = uiState.repoData.gatewayConnected,
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                            Text("Accept Handover (${uiState.preferences.operatorId})")
                        }
                    }
                }
            }
        }

        // Map Editor & Live Canvas
        item {
            AeroPanel {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Interactive Site Map Editor (Local ENU Metres)", style = MaterialTheme.typography.titleMedium, color = IvoryPrimary)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        MapEditorTool.entries.forEach { tool ->
                            FilterChip(
                                selected = uiState.mapEditorTool == tool,
                                onClick = { onSetMapTool(tool) },
                                label = { Text(tool.name.replace('_', ' '), style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.minimumInteractiveComponentSize(),
                            )
                        }
                        if (uiState.hasUncommittedMapEdits) {
                            OutlinedButton(onClick = onClearMapEdits, modifier = Modifier.minimumInteractiveComponentSize()) {
                                Text("Clear Map Edits (${uiState.localEditedWaypoints.size + uiState.localEditedExclusions.size + uiState.localEditedContingencies.size})")
                            }
                        }
                    }

                    LocalPennineMapAdapter.RenderMap(
                        mission = mission,
                        fleet = fleet,
                        selectedAircraftId = uiState.selectedAircraftId,
                        showUncertaintyRings = uiState.preferences.showUncertaintyRings,
                        editedWaypoints = uiState.localEditedWaypoints,
                        editedExclusions = uiState.localEditedExclusions,
                        editedContingencies = uiState.localEditedContingencies,
                        interactiveEditEnabled = uiState.mapEditorTool != MapEditorTool.INSPECT,
                        onMapTapLocalCoord = onMapTap,
                        onSelectAircraft = onSelectAircraft,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }

        // Distinct Approval & Command Actions
        item {
            AeroPanel {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Authoritative Planning, Approval & Dispatch Controls", style = MaterialTheme.typography.titleMedium, color = IvoryPrimary)
                    if (mission.approval?.invalidationReason != null && !approvalValid) {
                        ConditionBadge(
                            label = "APPROVAL INVALIDATED: ${mission.approval.invalidationReason}",
                            severity = ConditionSeverity.CAUTION,
                        )
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = { onRequestAllocation(false) },
                            enabled = uiState.isControlAllowed,
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                            Text("Propose Allocation (With Conflict Demo)")
                        }
                        Button(
                            onClick = { onRequestAllocation(true) },
                            enabled = uiState.isControlAllowed,
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("recalculate_clean_btn"),
                        ) {
                            Text("Recalculate Clean Plan")
                        }
                        OutlinedButton(
                            onClick = onRequestValidation,
                            enabled = uiState.isControlAllowed,
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                            Text(stringResource(R.string.action_request_validation))
                        }
                        Button(
                            onClick = onApproveVersion,
                            enabled = uiState.isControlAllowed && !approvalValid && mission.conflicts.none { it.severity == "CRITICAL" },
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("approve_plan_btn"),
                        ) {
                            Text("Approve v${mission.missionVersion}")
                        }
                        Button(
                            onClick = onRequestDispatch,
                            enabled = uiState.isControlAllowed && approvalValid,
                            colors = ButtonDefaults.buttonColors(containerColor = TelemetryCyan),
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("dispatch_plan_btn"),
                        ) {
                            Text(stringResource(R.string.action_request_dispatch))
                        }
                        OutlinedButton(
                            onClick = onRequestPause,
                            enabled = uiState.isControlAllowed,
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                            Text(stringResource(R.string.action_request_pause))
                        }
                        OutlinedButton(
                            onClick = onRequestCancel,
                            enabled = uiState.isControlAllowed,
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                            Text("Coordination Abort")
                        }
                        if (selectedAc != null && selectedAc.supportedContingencies.isNotEmpty()) {
                            OutlinedButton(
                                onClick = {
                                    onRequestContingency(selectedAc.aircraftId, selectedAc.supportedContingencies.first())
                                },
                                enabled = uiState.isControlAllowed,
                                modifier = Modifier.minimumInteractiveComponentSize(),
                            ) {
                                Text("${selectedAc.aircraftId}: ${selectedAc.supportedContingencies.first()}")
                            }
                        }
                    }
                }
            }
        }

        // Schedule Timeline & Conflict Scope
        item {
            AeroPanel {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Schedule Timeline & Modelled Conflict Scope", style = MaterialTheme.typography.titleMedium, color = IvoryPrimary)
                    Text(
                        text = stringResource(R.string.disclaimer_conflict_scope),
                        style = MaterialTheme.typography.bodySmall,
                        color = CautionAmber,
                    )
                    ScheduleTimelineCanvas(mission = mission)
                }
            }
        }

        // Allocation Proposals Comparison
        items(mission.allocations, key = { it.taskId }) { alloc ->
            AeroPanel {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${alloc.taskId} -> ${alloc.aircraftId} (${alloc.areaLabel})", style = MaterialTheme.typography.titleSmall, color = IvoryPrimary)
                        ConditionBadge(
                            label = "RESERVE ${alloc.batteryReservePct}%",
                            severity = if (alloc.batteryReservePct < 22.0) ConditionSeverity.CRITICAL else ConditionSeverity.NOMINAL,
                        )
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        TelemetryMetricTile("Payload", alloc.payloadId)
                        TelemetryMetricTile("Duration / Energy", "${alloc.estimatedDurationS}s / ${alloc.estimatedEnergyWh} Wh")
                        TelemetryMetricTile("Launch Slot", "${alloc.launchSiteId} @ T+${alloc.launchSlotS}s")
                        TelemetryMetricTile("Recovery Slot", "${alloc.recoverySiteId} @ T+${alloc.recoverySlotS}s")
                    }
                    if (alloc.unresolvedConstraints.isNotEmpty()) {
                        ConditionBadge(alloc.unresolvedConstraints.joinToString("; "), ConditionSeverity.CAUTION)
                    }
                }
            }
        }

        // Command Lifecycle Ledger (all 9 backend-evidenced states)
        if (mission.commands.isNotEmpty()) {
            item {
                Text("Command Lifecycle Ledger (Idempotent by request_id)", style = MaterialTheme.typography.titleSmall, color = IvoryPrimary)
            }
            items(mission.commands, key = { it.requestId }) { cmd ->
                AeroPanel {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${cmd.requestId} · ${cmd.commandType} (v${cmd.missionVersion} / Ep${cmd.coordinatorEpoch})", style = MaterialTheme.typography.labelLarge, color = IvoryPrimary)
                            Text("State: ${cmd.state} · ${cmd.detail}", style = MaterialTheme.typography.bodySmall, color = IvorySecondary)
                            cmd.reasonCode?.let { Text("Reason: $it", style = MaterialTheme.typography.labelSmall, color = CriticalRed) }
                        }
                        OutlinedButton(
                            onClick = { onQueryCommandStatus(cmd.requestId) },
                            enabled = uiState.repoData.gatewayConnected,
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                            Text("Query")
                        }
                    }
                }
            }
        }

        if (queriedCommand != null) {
            item {
                ConditionBadge(
                    label = "LAST QUERIED ${queriedCommand.requestId}: ${queriedCommand.state}",
                    severity = ConditionSeverity.INFO,
                )
            }
        }
    }
}

@Composable
private fun ScheduleTimelineCanvas(mission: com.example.core.model.MissionRecord) {
    val maxTime = (mission.allocations.maxOfOrNull { it.recoverySlotS } ?: 600).coerceAtLeast(300).toFloat()
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DeepSlateNavy, MaterialTheme.shapes.small)
            .border(1.dp, HairlineBorder, MaterialTheme.shapes.small)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        mission.allocations.forEach { alloc ->
            val hasConflict = mission.conflicts.any { alloc.taskId in it.affectedTasks }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "${alloc.aircraftId}/${alloc.taskId}",
                    style = MaterialTheme.typography.labelSmall,
                    color = IvorySecondary,
                    modifier = Modifier.weight(0.28f),
                )
                Canvas(modifier = Modifier.weight(0.72f).height(18.dp)) {
                    val startX = (alloc.launchSlotS / maxTime) * size.width
                    val endX = (alloc.recoverySlotS / maxTime) * size.width
                    drawRect(
                        color = if (hasConflict) CriticalRed.copy(alpha = 0.85f) else TelemetryCyan.copy(alpha = 0.85f),
                        topLeft = Offset(startX, 2f),
                        size = Size((endX - startX).coerceAtLeast(8f), size.height - 4f),
                    )
                }
            }
        }
        Text(
            text = "Timeline 0s — ${maxTime.toInt()}s · Temporal buffer: ±15s · Spatial buffer: ±18m + sensor uncertainty",
            style = MaterialTheme.typography.labelSmall,
            color = MutedSteel,
        )
    }
}
