package com.example.feature.planning

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.core.designsystem.CautionAmber
import com.example.core.designsystem.ConditionBadge
import com.example.core.designsystem.ConditionSeverity
import com.example.core.designsystem.CriticalRed
import com.example.core.designsystem.DeepSlateNavy
import com.example.core.designsystem.GraphiteElevated
import com.example.core.designsystem.GraphitePanel
import com.example.core.designsystem.HairlineBorder
import com.example.core.designsystem.IvoryPrimary
import com.example.core.designsystem.IvorySecondary
import com.example.core.designsystem.JetBrainsMonoFontFamily
import com.example.core.designsystem.MutedSteel
import com.example.core.designsystem.NominalEmerald
import com.example.core.designsystem.ReplayViolet
import com.example.core.designsystem.TelemetryCyan
import com.example.core.model.AircraftRecord
import com.example.core.model.ConflictFinding
import com.example.core.model.LocalPoint3D
import com.example.core.model.MapSiteConfig
import com.example.core.model.MissionRecord
import kotlin.math.min

/**
 * Replaceable map adapter abstraction so the local Pennine ENU engineering canvas
 * can be swapped with a licensed GIS/tile engine without touching feature ViewModels.
 */
interface MissionMapAdapter {
    @Composable
    fun RenderMap(
        mission: MissionRecord,
        fleet: List<AircraftRecord>,
        selectedAircraftId: String?,
        showUncertaintyRings: Boolean,
        editedWaypoints: List<LocalPoint3D>,
        editedExclusions: List<LocalPoint3D>,
        editedContingencies: List<LocalPoint3D>,
        interactiveEditEnabled: Boolean,
        onMapTapLocalCoord: (Double, Double) -> Unit,
        onSelectAircraft: (String) -> Unit,
        modifier: Modifier,
    )
}

object LocalPennineMapAdapter : MissionMapAdapter {
    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    override fun RenderMap(
        mission: MissionRecord,
        fleet: List<AircraftRecord>,
        selectedAircraftId: String?,
        showUncertaintyRings: Boolean,
        editedWaypoints: List<LocalPoint3D>,
        editedExclusions: List<LocalPoint3D>,
        editedContingencies: List<LocalPoint3D>,
        interactiveEditEnabled: Boolean,
        onMapTapLocalCoord: (Double, Double) -> Unit,
        onSelectAircraft: (String) -> Unit,
        modifier: Modifier,
    ) {
        val site = mission.site
        val textMeasurer = rememberTextMeasurer()

        Column(
            modifier = modifier
                .background(GraphitePanel, MaterialTheme.shapes.medium)
                .border(1.dp, HairlineBorder, MaterialTheme.shapes.medium)
                .padding(10.dp),
        ) {
            // Explicit datum, altitude reference, terrain, uncertainty & age header
            SiteMetadataHeader(site = site)
            Spacer(Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false)
                    .height(340.dp)
                    .background(DeepSlateNavy, MaterialTheme.shapes.small)
                    .border(1.dp, HairlineBorder, MaterialTheme.shapes.small)
                    .testTag("mission_map_canvas"),
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_pennine_aerial_1795792519908),
                    contentDescription = "Pennine Solar and Farm local survey basemap",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    alpha = 0.24f,
                )

                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(fleet, interactiveEditEnabled) {
                            detectTapGestures { tapOffset ->
                                val worldW = 600f
                                val worldH = 440f
                                val scale = min(size.width / worldW, size.height / worldH)
                                val padX = (size.width - worldW * scale) / 2f
                                val padY = (size.height - worldH * scale) / 2f
                                val xM = ((tapOffset.x - padX) / scale).toDouble().coerceIn(0.0, 600.0)
                                val yM = ((tapOffset.y - padY) / scale).toDouble().coerceIn(0.0, 440.0)

                                // Check if user tapped near an aircraft first when inspecting
                                val nearest = fleet.minByOrNull { ac ->
                                    val ax = padX + ac.position.xM.toFloat() * scale
                                    val ay = padY + ac.position.yM.toFloat() * scale
                                    kotlin.math.hypot(ax - tapOffset.x, ay - tapOffset.y)
                                }
                                val nearestDist = nearest?.let { ac ->
                                    val ax = padX + ac.position.xM.toFloat() * scale
                                    val ay = padY + ac.position.yM.toFloat() * scale
                                    kotlin.math.hypot(ax - tapOffset.x, ay - tapOffset.y)
                                } ?: Float.MAX_VALUE

                                if (!interactiveEditEnabled || nearestDist < 34f) {
                                    nearest?.let { onSelectAircraft(it.aircraftId) }
                                } else {
                                    onMapTapLocalCoord(
                                        kotlin.math.round(xM * 10.0) / 10.0,
                                        kotlin.math.round(yM * 10.0) / 10.0,
                                    )
                                }
                            }
                        },
                ) {
                    val worldW = 600f
                    val worldH = 440f
                    val scale = min(size.width / worldW, size.height / worldH)
                    val padX = (size.width - worldW * scale) / 2f
                    val padY = (size.height - worldH * scale) / 2f
                    fun toScreen(x: Double, y: Double): Offset =
                        Offset(padX + x.toFloat() * scale, padY + y.toFloat() * scale)

                    // Local 100m engineering grid
                    for (gx in 0..600 step 100) {
                        val sx = padX + gx * scale
                        drawLine(
                            color = HairlineBorder.copy(alpha = 0.5f),
                            start = Offset(sx, padY),
                            end = Offset(sx, padY + worldH * scale),
                            strokeWidth = 1f,
                        )
                    }
                    for (gy in 0..400 step 100) {
                        val sy = padY + gy * scale
                        drawLine(
                            color = HairlineBorder.copy(alpha = 0.5f),
                            start = Offset(padX, sy),
                            end = Offset(padX + worldW * scale, sy),
                            strokeWidth = 1f,
                        )
                    }

                    // Site Zones
                    site.zones.forEach { zone ->
                        when (zone.zoneType) {
                            "BOUNDARY" -> drawPolygon(zone.vertices, ::toScreen, MutedSteel, filled = false, dashed = true)
                            "EXCLUSION" -> drawPolygon(zone.vertices, ::toScreen, CriticalRed, filled = true, dashed = false)
                            "LAUNCH" -> zone.vertices.firstOrNull()?.let { pt ->
                                val p = toScreen(pt.xM, pt.yM)
                                drawCircle(TelemetryCyan, radius = 7f, center = p)
                                drawLabel(textMeasurer, zone.zoneId, p + Offset(8f, -8f), TelemetryCyan)
                            }
                            "RECOVERY" -> zone.vertices.firstOrNull()?.let { pt ->
                                val p = toScreen(pt.xM, pt.yM)
                                drawRect(NominalEmerald, topLeft = p - Offset(5f, 5f), size = androidx.compose.ui.geometry.Size(10f, 10f))
                            }
                            "CONTINGENCY" -> zone.vertices.firstOrNull()?.let { pt ->
                                val p = toScreen(pt.xM, pt.yM)
                                drawCircle(CautionAmber, radius = 6f, center = p, style = Stroke(2.5f))
                                drawLabel(textMeasurer, zone.zoneId, p + Offset(8f, -8f), CautionAmber)
                            }
                        }
                    }

                    // Work Area Polygons
                    mission.jobs.forEach { job ->
                        drawPolygon(job.workAreaPolygon, ::toScreen, TelemetryCyan.copy(alpha = 0.45f), filled = true, dashed = false)
                    }

                    // Routes & Tracks with distinct line styles
                    mission.allocations.forEach { alloc ->
                        // 1. Proposed route: dashed cyan
                        drawRoutePolyline(alloc.proposedRoute, ::toScreen, TelemetryCyan.copy(alpha = 0.75f), dashed = true, width = 2.2f)
                        // 2. Approved trajectory: solid cyan
                        drawRoutePolyline(alloc.approvedTrajectory, ::toScreen, TelemetryCyan, dashed = false, width = 3.2f)
                        // 3. Observed track: solid emerald
                        drawRoutePolyline(alloc.observedTrack, ::toScreen, NominalEmerald, dashed = false, width = 3.5f)
                        // 4. Bounded predicted position
                        alloc.boundedPredictedPosition?.let { pred ->
                            val c = toScreen(pred.xM, pred.yM)
                            drawCircle(TelemetryCyan.copy(alpha = 0.25f), radius = 14f, center = c)
                            drawCircle(TelemetryCyan, radius = 14f, center = c, style = Stroke(1.5f))
                        }
                    }

                    // Conflict markers
                    mission.conflicts.forEach { conflict ->
                        drawConflictMarker(conflict, ::toScreen, scale, textMeasurer)
                    }

                    // Operator local edits
                    editedWaypoints.forEachIndexed { idx, pt ->
                        val p = toScreen(pt.xM, pt.yM)
                        drawCircle(ReplayViolet, radius = 6f, center = p)
                        drawLabel(textMeasurer, "EDIT-WP${idx + 1}", p + Offset(6f, -6f), ReplayViolet)
                    }
                    editedExclusions.forEachIndexed { idx, pt ->
                        val p = toScreen(pt.xM, pt.yM)
                        drawCircle(CriticalRed, radius = 16f, center = p, style = Stroke(2f))
                        drawLabel(textMeasurer, "NEW-EXC${idx + 1}", p + Offset(12f, -6f), CriticalRed)
                    }
                    editedContingencies.forEachIndexed { idx, pt ->
                        val p = toScreen(pt.xM, pt.yM)
                        drawCircle(CautionAmber, radius = 9f, center = p, style = Stroke(2f))
                        drawLabel(textMeasurer, "NEW-CTG${idx + 1}", p + Offset(8f, -6f), CautionAmber)
                    }

                    // Aircraft markers
                    fleet.forEach { ac ->
                        val pos = toScreen(ac.position.xM, ac.position.yM)
                        val isSelected = ac.aircraftId == selectedAircraftId
                        val acColor = when {
                            ac.withdrawn || ac.maintenanceBlockingReason != null -> CriticalRed
                            ac.batterySocPct < 50.0 || ac.linkStatus != "NOMINAL" -> CautionAmber
                            else -> IvoryPrimary
                        }
                        if (showUncertaintyRings) {
                            drawCircle(
                                color = acColor.copy(alpha = 0.22f),
                                radius = (ac.positionUncertaintyM.toFloat() * scale * 4f).coerceAtLeast(10f),
                                center = pos,
                            )
                        }
                        if (isSelected) {
                            drawCircle(TelemetryCyan, radius = 16f, center = pos, style = Stroke(2.2f))
                        }
                        // Wing-inspired delta icon
                        val wing = Path().apply {
                            moveTo(pos.x, pos.y - 9f)
                            lineTo(pos.x + 9f, pos.y + 7f)
                            lineTo(pos.x, pos.y + 3f)
                            lineTo(pos.x - 9f, pos.y + 7f)
                            close()
                        }
                        drawPath(wing, color = acColor)
                        drawLabel(
                            textMeasurer,
                            "${ac.aircraftId} ${ac.position.altM.toInt()}m AGL",
                            pos + Offset(10f, -10f),
                            acColor,
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                MapLegendItem("Proposed (Dashed Cyan)", TelemetryCyan)
                MapLegendItem("Approved (Solid Cyan)", TelemetryCyan)
                MapLegendItem("Observed (Emerald)", NominalEmerald)
                MapLegendItem("Exclusion", CriticalRed)
                MapLegendItem("Contingency", CautionAmber)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SiteMetadataHeader(site: MapSiteConfig) {
    Surface(
        color = GraphiteElevated,
        shape = MaterialTheme.shapes.extraSmall,
        border = BorderStroke(1.dp, HairlineBorder),
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                ConditionBadge("COORD: ${site.coordinateReference}", ConditionSeverity.INFO)
                ConditionBadge("ALT: ${site.altitudeReference}", ConditionSeverity.CAUTION)
                ConditionBadge("UNCERT: ±${site.positionUncertaintyM} m", ConditionSeverity.MUTED)
                ConditionBadge("MAP AGE: ${site.mapDataAgeS}s", ConditionSeverity.MUTED)
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = "Terrain: ${site.terrainSource} · Assumptions: ${site.planningAssumptions}",
                style = MaterialTheme.typography.bodySmall,
                color = IvorySecondary,
            )
        }
    }
}

@Composable
private fun MapLegendItem(label: String, color: Color) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Box(
            modifier = Modifier
                .height(3.dp)
                .padding(top = 1.dp)
                .background(color)
                .padding(horizontal = 6.dp),
        )
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = IvorySecondary)
    }
}

private fun DrawScope.drawPolygon(
    points: List<LocalPoint3D>,
    toScreen: (Double, Double) -> Offset,
    color: Color,
    filled: Boolean,
    dashed: Boolean,
) {
    if (points.size < 3) return
    val path = Path().apply {
        val p0 = toScreen(points[0].xM, points[0].yM)
        moveTo(p0.x, p0.y)
        points.drop(1).forEach { pt ->
            val p = toScreen(pt.xM, pt.yM)
            lineTo(p.x, p.y)
        }
        close()
    }
    if (filled) {
        drawPath(path, color = color.copy(alpha = 0.14f))
    }
    drawPath(
        path = path,
        color = color,
        style = Stroke(
            width = 1.8f,
            pathEffect = if (dashed) PathEffect.dashPathEffect(floatArrayOf(10f, 8f)) else null,
        ),
    )
}

private fun DrawScope.drawRoutePolyline(
    points: List<LocalPoint3D>,
    toScreen: (Double, Double) -> Offset,
    color: Color,
    dashed: Boolean,
    width: Float,
) {
    if (points.size < 2) return
    val path = Path().apply {
        val p0 = toScreen(points[0].xM, points[0].yM)
        moveTo(p0.x, p0.y)
        points.drop(1).forEach { pt ->
            val p = toScreen(pt.xM, pt.yM)
            lineTo(p.x, p.y)
        }
    }
    drawPath(
        path = path,
        color = color,
        style = Stroke(
            width = width,
            pathEffect = if (dashed) PathEffect.dashPathEffect(floatArrayOf(12f, 8f)) else null,
        ),
    )
}

private fun DrawScope.drawConflictMarker(
    conflict: ConflictFinding,
    toScreen: (Double, Double) -> Offset,
    scale: Float,
    textMeasurer: TextMeasurer,
) {
    val c = toScreen(conflict.locationXM, conflict.locationYM)
    val col = if (conflict.severity == "CRITICAL") CriticalRed else CautionAmber
    drawCircle(
        color = col.copy(alpha = 0.16f),
        radius = (conflict.spatialBufferM.toFloat() * scale).coerceAtLeast(14f),
        center = c,
    )
    drawCircle(
        color = col,
        radius = (conflict.spatialBufferM.toFloat() * scale).coerceAtLeast(14f),
        center = c,
        style = Stroke(2f),
    )
    drawLabel(textMeasurer, conflict.conflictId, c + Offset(10f, 8f), col)
}

private fun DrawScope.drawLabel(
    textMeasurer: TextMeasurer,
    text: String,
    topLeft: Offset,
    color: Color,
) {
    val layout = textMeasurer.measure(
        text = text,
        style = TextStyle(
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = 9.sp,
            color = color,
        ),
    )
    if (topLeft.x >= 0 && topLeft.y >= 0 && topLeft.x + layout.size.width <= size.width && topLeft.y + layout.size.height <= size.height) {
        drawText(layout, topLeft = topLeft)
    }
}
