package com.example.feature.data

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.SpitfireUiState
import com.example.core.designsystem.AeroPanel
import com.example.core.designsystem.CautionAmber
import com.example.core.designsystem.ConditionBadge
import com.example.core.designsystem.ConditionSeverity
import com.example.core.designsystem.CriticalRed
import com.example.core.designsystem.IvoryPrimary
import com.example.core.designsystem.IvorySecondary
import com.example.core.designsystem.MutedSteel
import com.example.core.designsystem.TelemetryMetricTile
import com.example.core.designsystem.WingAccentHeader
import com.example.core.model.DownloadedReport

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PayloadsScreen(
    uiState: SpitfireUiState,
    modifier: Modifier = Modifier,
) {
    val mission = uiState.repoData.mission
    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("payloads_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            WingAccentHeader(
                title = "Payloads, Configuration & Capture Telemetry",
                subtitle = "Observed capture counts and upload progress are reported independently of commanded schedules",
            )
        }
        items(mission.payloadData, key = { it.recordId }) { pd ->
            AeroPanel {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${pd.aircraftId} · ${pd.payloadId}", style = MaterialTheme.typography.titleMedium, color = IvoryPrimary)
                        ConditionBadge("CONFIG ${pd.configVersion}", ConditionSeverity.INFO)
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        TelemetryMetricTile("Commanded Captures", "${pd.captureFramesCommanded} frames")
                        TelemetryMetricTile(
                            "Observed Captures",
                            "${pd.captureFramesObserved} frames",
                            valueColor = if (pd.captureFramesObserved < pd.captureFramesCommanded) CautionAmber else IvoryPrimary,
                        )
                        TelemetryMetricTile("Upload Progress", "${pd.uploadProgressPct}%")
                        TelemetryMetricTile("Observed Coverage", "${pd.coveragePct}%")
                        if (pd.plannedApplicationRate != null || pd.observedDeliveryRate != null) {
                            TelemetryMetricTile(
                                "Application vs Delivery",
                                "Plan: ${pd.plannedApplicationRate ?: "N/A"}",
                                sublabel = "Observed: ${pd.observedDeliveryRate ?: "N/A"}",
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MaintenanceScreen(
    uiState: SpitfireUiState,
    onRejectTestDispatchSpit06: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val fleet = uiState.repoData.fleet
    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("maintenance_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            WingAccentHeader(
                title = "Maintenance Defects & Battery Health",
                subtitle = "Backend maintenance rules block non-compliant airframes from allocation and dispatch",
            )
        }
        items(fleet, key = { it.aircraftId }) { ac ->
            val blocked = ac.maintenanceBlockingReason != null
            val lowReserve = ac.batterySocPct < 55.0
            AeroPanel(borderColor = if (blocked) CriticalRed else if (lowReserve) CautionAmber else MutedSteel) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${ac.aircraftId} (${ac.callsign}) · ${ac.airframe}", style = MaterialTheme.typography.titleMedium, color = IvoryPrimary)
                        ConditionBadge(
                            label = if (blocked) "BLOCKED" else if (lowReserve) "LOW BATTERY RESERVE" else "AIRWORTHY",
                            severity = if (blocked) ConditionSeverity.CRITICAL else if (lowReserve) ConditionSeverity.CAUTION else ConditionSeverity.NOMINAL,
                        )
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TelemetryMetricTile("Battery Pack", ac.batteryId, sublabel = "${ac.batterySocPct}% · ${ac.batteryVoltageV}V")
                        TelemetryMetricTile("Charging Observation", ac.chargingState, sublabel = "Min Reserve Policy: ${ac.configuredMinReservePct}%")
                    }
                    if (blocked) {
                        Text(
                            text = "Blocking Rule & Authorised Resolution: ${ac.maintenanceBlockingReason}. Authorised engineer must inspect hub torque and record sign-off in maintenance log before coordinator clears flight lock.",
                            style = MaterialTheme.typography.bodySmall,
                            color = CriticalRed,
                        )
                        OutlinedButton(
                            onClick = onRejectTestDispatchSpit06,
                            enabled = uiState.isControlAllowed,
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                            Text("Verify Backend Rejection on ${ac.aircraftId}")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DataScreen(
    uiState: SpitfireUiState,
    reports: List<DownloadedReport>,
    onTriggerMissingImageryFollowup: () -> Unit,
    onExportReport: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val mission = uiState.repoData.mission
    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("data_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            WingAccentHeader(
                title = "Coverage Review, Missing Data & Reports",
                subtitle = "Review missing-data findings, propose follow-up jobs, and export WorkManager engineering reports",
            )
        }

        item {
            AeroPanel {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onTriggerMissingImageryFollowup,
                        enabled = uiState.isControlAllowed,
                        modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("create_followup_job_btn"),
                    ) {
                        Text("Detect Missing Imagery & Propose Follow-Up")
                    }
                    Button(
                        onClick = onExportReport,
                        modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("export_report_btn"),
                    ) {
                        Text("Export Report (WorkManager)")
                    }
                }
            }
        }

        items(mission.payloadData, key = { it.recordId }) { pd ->
            AeroPanel {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${pd.recordId} · ${pd.aircraftId} (${pd.payloadId}) — Coverage ${pd.coveragePct}%", style = MaterialTheme.typography.titleSmall, color = IvoryPrimary)
                    if (pd.missingDataFindings.isEmpty()) {
                        Text("No missing-data findings recorded.", style = MaterialTheme.typography.bodySmall, color = IvorySecondary)
                    } else {
                        pd.missingDataFindings.forEach { finding ->
                            ConditionBadge(finding, ConditionSeverity.CAUTION)
                        }
                    }
                    pd.followUpJobId?.let { fId ->
                        ConditionBadge("FOLLOW-UP JOB CREATED: $fId", ConditionSeverity.INFO)
                    }
                }
            }
        }

        item {
            Text("DOWNLOADED REPORTS (${reports.size}) — Available Offline", style = MaterialTheme.typography.titleSmall, color = IvoryPrimary)
        }

        items(reports, key = { it.reportId }) { report ->
            AeroPanel {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${report.reportId} · ${report.title}", style = MaterialTheme.typography.titleSmall, color = IvoryPrimary)
                    Text("SHA-256: ${report.sha256Hex.take(24)}...", style = MaterialTheme.typography.labelSmall, color = MutedSteel)
                    Text(report.summaryText, style = MaterialTheme.typography.bodySmall, color = IvorySecondary)
                }
            }
        }
    }
}
