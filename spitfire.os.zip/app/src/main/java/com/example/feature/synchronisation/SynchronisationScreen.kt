package com.example.feature.synchronisation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.SpitfireUiState
import com.example.core.designsystem.AeroPanel
import com.example.core.designsystem.CautionAmber
import com.example.core.designsystem.ConditionBadge
import com.example.core.designsystem.ConditionSeverity
import com.example.core.designsystem.CriticalRed
import com.example.core.designsystem.IvoryPrimary
import com.example.core.designsystem.IvorySecondary
import com.example.core.designsystem.NominalEmerald
import com.example.core.designsystem.TelemetryCyan
import com.example.core.designsystem.TelemetryMetricTile
import com.example.core.designsystem.WingAccentHeader
import com.example.core.model.SyncStage
import kotlin.math.max

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SynchronisationScreen(
    uiState: SpitfireUiState,
    onInjectDelayedTelemetry: () -> Unit,
    onWithdrawSpit04: () -> Unit,
    onRequestRecalculation: () -> Unit,
    onRequestCoordinationAbort: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val mission = uiState.repoData.mission
    val tolerances = uiState.repoData.capabilities.syncTolerances

    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("synchronisation_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            WingAccentHeader(
                title = "Python Synchronisation Engine",
                subtitle = "Plan v${mission.missionVersion} · Epoch ${mission.coordinatorEpoch} · Max Uncertainty ±${tolerances.maxClockUncertaintyMs}ms · Telemetry TTL ${tolerances.maxTelemetryAgeMs}ms",
            )
        }

        // Simulation fault injection & tolerance controls
        item {
            AeroPanel {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Synchronisation Pipeline & Simulator Fault Triggers",
                        style = MaterialTheme.typography.titleMedium,
                        color = IvoryPrimary,
                    )
                    Text(
                        "Readiness expires automatically when underlying evidence TTL (${tolerances.readinessTtlMs / 1000}s) or telemetry freshness expires. Network HTTP 200 receipt never implies aircraft readiness.",
                        style = MaterialTheme.typography.bodySmall,
                        color = IvorySecondary,
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = onInjectDelayedTelemetry,
                            enabled = uiState.isControlAllowed,
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("inject_delayed_telemetry_btn"),
                        ) {
                            Text("Inject Delayed Telemetry (SPIT-02)")
                        }
                        OutlinedButton(
                            onClick = onWithdrawSpit04,
                            enabled = uiState.isControlAllowed,
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("withdraw_spit04_btn"),
                        ) {
                            Text("Withdraw SPIT-04 & Reassign")
                        }
                        Button(
                            onClick = onRequestRecalculation,
                            enabled = uiState.isControlAllowed,
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                            Text("Reschedule / Recalculate")
                        }
                    }
                }
            }
        }

        items(mission.syncStates, key = { it.aircraftId }) { sync ->
            val effectiveAgeMs = max(sync.telemetryAgeMs, uiState.cachedAgeSeconds * 1000L)
            val readinessStillValid = sync.readinessAcked &&
                effectiveAgeMs <= tolerances.maxTelemetryAgeMs &&
                sync.clockUncertaintyMs <= tolerances.maxClockUncertaintyMs

            AeroPanel(
                borderColor = when {
                    sync.toleranceExceededReason != null -> CriticalRed
                    !readinessStillValid -> CautionAmber
                    else -> NominalEmerald.copy(alpha = 0.6f)
                },
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${sync.aircraftId} · Boot ${sync.bootId}", style = MaterialTheme.typography.titleMedium, color = IvoryPrimary)
                            Text("Plan v${sync.planVersion} · Coordinator Epoch ${sync.coordinatorEpoch} · Lease: ${sync.taskLeaseStatus}", style = MaterialTheme.typography.bodySmall, color = IvorySecondary)
                        }
                        ConditionBadge(
                            label = if (readinessStillValid) "READINESS VALID" else "READINESS EXPIRED / UNACKED",
                            severity = if (readinessStillValid) ConditionSeverity.NOMINAL else ConditionSeverity.CAUTION,
                        )
                    }

                    // 5-Stage Pipeline Visualisation
                    SyncStagePipeline(currentStage = sync.stage)

                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        TelemetryMetricTile("Clock Offset", "${"%+.1f".format(sync.clockOffsetMs)} ms")
                        TelemetryMetricTile(
                            "Clock Uncertainty",
                            "±${"%.1f".format(sync.clockUncertaintyMs)} ms",
                            valueColor = if (sync.clockUncertaintyMs > tolerances.maxClockUncertaintyMs) CriticalRed else IvoryPrimary,
                        )
                        TelemetryMetricTile(
                            "Telemetry Age",
                            "${effectiveAgeMs} ms",
                            valueColor = if (effectiveAgeMs > tolerances.maxTelemetryAgeMs) CautionAmber else NominalEmerald,
                        )
                        TelemetryMetricTile(
                            "Start Schedule / Obs",
                            "T+${sync.scheduledStartS}s / ${sync.actualObservedStartS?.let { "T+${it}s" } ?: "--"}",
                            sublabel = "Deviation: ${sync.startDeviationS?.let { "${"%+.2f".format(it)}s" } ?: "N/A"}",
                        )
                    }

                    if (sync.toleranceExceededReason != null) {
                        ConditionBadge(
                            label = "TOLERANCE EXCEEDED: ${sync.toleranceExceededReason}",
                            severity = ConditionSeverity.CRITICAL,
                        )
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            sync.availableActions.forEach { act ->
                                OutlinedButton(
                                    onClick = {
                                        if (act == "CANCEL_TASK") onRequestCoordinationAbort() else onRequestRecalculation()
                                    },
                                    enabled = uiState.isControlAllowed,
                                    modifier = Modifier.minimumInteractiveComponentSize(),
                                ) {
                                    Text(act.replace('_', ' '))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SyncStagePipeline(currentStage: SyncStage) {
    val stages = listOf(
        SyncStage.PLAN_PROPOSED to "1. Plan Proposed",
        SyncStage.AIRCRAFT_VALIDATION to "2. Aircraft Validation",
        SyncStage.READINESS_ACKNOWLEDGED to "3. Readiness Ack",
        SyncStage.COMMITTED_SCHEDULE to "4. Committed Schedule",
        SyncStage.EXECUTION_OBSERVED to "5. Execution Obs",
    )
    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        stages.forEach { (stage, label) ->
            val reached = stage.ordinal <= currentStage.ordinal
            ConditionBadge(
                label = label,
                severity = if (stage == currentStage) ConditionSeverity.INFO else if (reached) ConditionSeverity.NOMINAL else ConditionSeverity.MUTED,
            )
        }
    }
}
