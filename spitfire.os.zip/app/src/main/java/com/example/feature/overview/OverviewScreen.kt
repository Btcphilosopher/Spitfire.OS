package com.example.feature.overview

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.SpitfireUiState
import com.example.core.designsystem.AeroPanel
import com.example.core.designsystem.CautionAmber
import com.example.core.designsystem.ConditionBadge
import com.example.core.designsystem.ConditionSeverity
import com.example.core.designsystem.CriticalRed
import com.example.core.designsystem.GraphiteElevated
import com.example.core.designsystem.GraphitePanel
import com.example.core.designsystem.HairlineBorder
import com.example.core.designsystem.IvoryPrimary
import com.example.core.designsystem.IvorySecondary
import com.example.core.designsystem.MutedSteel
import com.example.core.designsystem.NominalEmerald
import com.example.core.designsystem.TelemetryCyan
import com.example.core.designsystem.TelemetryMetricTile
import com.example.core.designsystem.WingAccentHeader
import com.example.core.model.AircraftRecord
import com.example.core.model.AircraftSyncState
import com.example.core.model.CommandState
import com.example.core.model.ExceptionStatus
import com.example.feature.planning.LocalPennineMapAdapter
import kotlin.math.max

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OverviewScreen(
    uiState: SpitfireUiState,
    onSelectAircraft: (String) -> Unit,
    onNavigateToSync: () -> Unit,
    onNavigateToExceptions: () -> Unit,
    onNavigateToPlanning: () -> Unit,
    onApprovePlan: () -> Unit,
    onDispatchMission: () -> Unit,
    onAcknowledgeException: (String) -> Unit,
    onResolveException: (String, String, String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val mission = uiState.repoData.mission
    val fleet = uiState.repoData.fleet
    val selectedAircraft = fleet.firstOrNull { it.aircraftId == uiState.selectedAircraftId } ?: fleet.firstOrNull()
    val selectedSync = mission.syncStates.firstOrNull { it.aircraftId == selectedAircraft?.aircraftId }

    val openExceptions = mission.exceptions.filter { it.status != ExceptionStatus.RESOLVED }
    val pendingAcks = mission.commands.count {
        it.state in setOf(CommandState.SUBMITTED, CommandState.ACCEPTED_BY_COORDINATOR, CommandState.SENT_TO_ADAPTER, CommandState.OUTCOME_UNKNOWN)
    }
    val maxClockUncertaintyMs = mission.syncStates.maxOfOrNull { it.clockUncertaintyMs }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val isWideTablet = maxWidth >= 900.dp

        if (isWideTablet) {
            // Adaptive three-panel tablet workspace: Mission & Aircraft List | Map | Selected-Item Inspector
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Column(
                    modifier = Modifier
                        .weight(0.32f)
                        .fillMaxSize(),
                ) {
                    MissionSummaryBlock(
                        uiState = uiState,
                        maxClockUncertaintyMs = maxClockUncertaintyMs,
                        pendingAcks = pendingAcks,
                        openExceptionCount = openExceptions.size,
                    )
                    Spacer(Modifier.height(10.dp))
                    FleetBriefList(
                        fleet = fleet,
                        missionSync = mission.syncStates,
                        allocations = mission.allocations,
                        selectedId = selectedAircraft?.aircraftId,
                        cachedAgeSeconds = uiState.cachedAgeSeconds,
                        onSelectAircraft = onSelectAircraft,
                        modifier = Modifier.weight(1f),
                    )
                }

                Column(
                    modifier = Modifier
                        .weight(0.40f)
                        .fillMaxSize(),
                ) {
                    LocalPennineMapAdapter.RenderMap(
                        mission = mission,
                        fleet = fleet,
                        selectedAircraftId = selectedAircraft?.aircraftId,
                        showUncertaintyRings = uiState.preferences.showUncertaintyRings,
                        editedWaypoints = uiState.localEditedWaypoints,
                        editedExclusions = uiState.localEditedExclusions,
                        editedContingencies = uiState.localEditedContingencies,
                        interactiveEditEnabled = false,
                        onMapTapLocalCoord = { _, _ -> },
                        onSelectAircraft = onSelectAircraft,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(10.dp))
                    AttentionQueuePanel(
                        exceptions = openExceptions,
                        conflicts = mission.conflicts,
                        onAcknowledgeException = onAcknowledgeException,
                        onResolveException = onResolveException,
                        onNavigateToExceptions = onNavigateToExceptions,
                        modifier = Modifier.weight(1f),
                    )
                }

                SelectedItemInspector(
                    uiState = uiState,
                    aircraft = selectedAircraft,
                    syncState = selectedSync,
                    onNavigateToSync = onNavigateToSync,
                    onNavigateToPlanning = onNavigateToPlanning,
                    onApprovePlan = onApprovePlan,
                    onDispatchMission = onDispatchMission,
                    modifier = Modifier
                        .weight(0.28f)
                        .fillMaxSize(),
                )
            }
        } else {
            // Responsive phone / compact portrait layout
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item {
                    MissionSummaryBlock(
                        uiState = uiState,
                        maxClockUncertaintyMs = maxClockUncertaintyMs,
                        pendingAcks = pendingAcks,
                        openExceptionCount = openExceptions.size,
                    )
                }
                item {
                    LocalPennineMapAdapter.RenderMap(
                        mission = mission,
                        fleet = fleet,
                        selectedAircraftId = selectedAircraft?.aircraftId,
                        showUncertaintyRings = uiState.preferences.showUncertaintyRings,
                        editedWaypoints = uiState.localEditedWaypoints,
                        editedExclusions = uiState.localEditedExclusions,
                        editedContingencies = uiState.localEditedContingencies,
                        interactiveEditEnabled = false,
                        onMapTapLocalCoord = { _, _ -> },
                        onSelectAircraft = onSelectAircraft,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                item {
                    SelectedItemInspector(
                        uiState = uiState,
                        aircraft = selectedAircraft,
                        syncState = selectedSync,
                        onNavigateToSync = onNavigateToSync,
                        onNavigateToPlanning = onNavigateToPlanning,
                        onApprovePlan = onApprovePlan,
                        onDispatchMission = onDispatchMission,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                items(fleet, key = { it.aircraftId }) { ac ->
                    val sync = mission.syncStates.firstOrNull { it.aircraftId == ac.aircraftId }
                    val task = mission.allocations.firstOrNull { it.aircraftId == ac.aircraftId }
                    AircraftStatusCard(
                        aircraft = ac,
                        syncState = sync,
                        assignedTaskLabel = task?.let { "${it.taskId} · ${it.areaLabel}" } ?: "UNASSIGNED",
                        approvalValid = mission.approval?.valid == true && mission.approval.missionVersion == mission.missionVersion,
                        selected = ac.aircraftId == selectedAircraft?.aircraftId,
                        cachedAgeSeconds = uiState.cachedAgeSeconds,
                        onClick = { onSelectAircraft(ac.aircraftId) },
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MissionSummaryBlock(
    uiState: SpitfireUiState,
    maxClockUncertaintyMs: Double?,
    pendingAcks: Int,
    openExceptionCount: Int,
) {
    val mission = uiState.repoData.mission
    val approvalValid = mission.approval?.valid == true && mission.approval.missionVersion == mission.missionVersion

    AeroPanel {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            WingAccentHeader(
                title = mission.name,
                subtitle = "${mission.missionId} · Plan v${mission.missionVersion} · Epoch ${mission.coordinatorEpoch}",
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                TelemetryMetricTile(
                    label = "Coordination",
                    value = mission.status.name,
                    valueColor = if (mission.conflicts.any { it.severity == "CRITICAL" }) CriticalRed else TelemetryCyan,
                )
                TelemetryMetricTile(
                    label = "Control Owner",
                    value = mission.controlLease.ownerOperatorId,
                    sublabel = mission.controlLease.status.name,
                    valueColor = if (mission.controlLease.ownerOperatorId == uiState.preferences.operatorId) NominalEmerald else CautionAmber,
                )
                TelemetryMetricTile(
                    label = "Telemetry Age",
                    value = "${uiState.cachedAgeSeconds}s",
                    valueColor = if (uiState.cachedAgeSeconds > 5L) CautionAmber else NominalEmerald,
                )
                TelemetryMetricTile(
                    label = "Clock Uncert.",
                    value = maxClockUncertaintyMs?.let { "±${"%.1f".format(it)} ms" } ?: "UNAVAILABLE",
                    valueColor = if ((maxClockUncertaintyMs ?: 999.0) > 35.0) CriticalRed else IvoryPrimary,
                )
                TelemetryMetricTile(
                    label = "Approval",
                    value = if (approvalValid) "v${mission.missionVersion} APPROVED" else "REQUIRED",
                    valueColor = if (approvalValid) NominalEmerald else CautionAmber,
                )
                TelemetryMetricTile(
                    label = "Cmd Await Ack",
                    value = "$pendingAcks",
                    sublabel = "Open Exc: $openExceptionCount",
                    valueColor = if (openExceptionCount > 0) CautionAmber else IvoryPrimary,
                )
            }
        }
    }
}

@Composable
private fun FleetBriefList(
    fleet: List<AircraftRecord>,
    missionSync: List<AircraftSyncState>,
    allocations: List<com.example.core.model.TaskAllocationItem>,
    selectedId: String?,
    cachedAgeSeconds: Long,
    onSelectAircraft: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(fleet, key = { it.aircraftId }) { ac ->
            val sync = missionSync.firstOrNull { it.aircraftId == ac.aircraftId }
            val task = allocations.firstOrNull { it.aircraftId == ac.aircraftId }
            AircraftStatusCard(
                aircraft = ac,
                syncState = sync,
                assignedTaskLabel = task?.let { "${it.taskId} · ${it.areaLabel}" } ?: "UNASSIGNED",
                approvalValid = false,
                selected = ac.aircraftId == selectedId,
                cachedAgeSeconds = cachedAgeSeconds,
                onClick = { onSelectAircraft(ac.aircraftId) },
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AircraftStatusCard(
    aircraft: AircraftRecord,
    syncState: AircraftSyncState?,
    assignedTaskLabel: String,
    approvalValid: Boolean,
    selected: Boolean,
    cachedAgeSeconds: Long,
    onClick: () -> Unit,
) {
    val borderColor = when {
        selected -> TelemetryCyan
        aircraft.maintenanceBlockingReason != null || aircraft.withdrawn -> CriticalRed.copy(alpha = 0.7f)
        aircraft.batterySocPct < 50.0 -> CautionAmber.copy(alpha = 0.7f)
        else -> HairlineBorder
    }
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .clickable(onClick = onClick)
            .testTag("aircraft_card_${aircraft.aircraftId}"),
        color = if (selected) GraphiteElevated else GraphitePanel,
        shape = MaterialTheme.shapes.medium,
        border = BorderStroke(if (selected) 1.5.dp else 1.dp, borderColor),
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column {
                    Text(
                        text = "${aircraft.aircraftId} · ${aircraft.callsign}",
                        style = MaterialTheme.typography.titleMedium,
                        color = IvoryPrimary,
                    )
                    Text(
                        text = "Mode: ${aircraft.observedFlightMode} · Task: $assignedTaskLabel",
                        style = MaterialTheme.typography.bodySmall,
                        color = IvorySecondary,
                    )
                }
                ConditionBadge(
                    label = aircraft.linkStatus,
                    severity = if (aircraft.linkStatus == "NOMINAL") ConditionSeverity.NOMINAL else ConditionSeverity.CRITICAL,
                )
            }

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                val battSeverity = when {
                    aircraft.batterySocPct < 45.0 -> ConditionSeverity.CRITICAL
                    aircraft.batterySocPct < 60.0 -> ConditionSeverity.CAUTION
                    else -> ConditionSeverity.NOMINAL
                }
                ConditionBadge(
                    label = "BAT ${aircraft.batterySocPct.toInt()}% (${aircraft.batteryVoltageV}V · +${cachedAgeSeconds}s)",
                    severity = battSeverity,
                    icon = Icons.Filled.BatteryAlert,
                )
                val posAgeS = max(cachedAgeSeconds, (syncState?.telemetryAgeMs ?: 0L) / 1000L)
                ConditionBadge(
                    label = "POS AGE ${posAgeS}s",
                    severity = if (posAgeS > 3L) ConditionSeverity.CAUTION else ConditionSeverity.INFO,
                )
                ConditionBadge(
                    label = if (syncState?.readinessAcked == true) "READY" else "READINESS UNCONFIRMED",
                    severity = if (syncState?.readinessAcked == true) ConditionSeverity.NOMINAL else ConditionSeverity.CAUTION,
                )
                ConditionBadge(
                    label = "CMD: ${aircraft.latestCommandOutcome}",
                    severity = if (aircraft.latestCommandOutcome == "REJECTED") ConditionSeverity.CRITICAL else ConditionSeverity.MUTED,
                )
            }

            if (aircraft.maintenanceBlockingReason != null) {
                ConditionBadge(
                    label = "LOCKED: ${aircraft.maintenanceBlockingReason}",
                    severity = ConditionSeverity.CRITICAL,
                    icon = Icons.Filled.Lock,
                )
            }
            Text(
                text = "Cap: ${aircraft.supportedPayloads.joinToString("/")} · Auth: ${if (approvalValid) "PLAN APPROVED" else "UNAPPROVED"}",
                style = MaterialTheme.typography.labelSmall,
                color = MutedSteel,
            )
        }
    }
}

@Composable
private fun SelectedItemInspector(
    uiState: SpitfireUiState,
    aircraft: AircraftRecord?,
    syncState: AircraftSyncState?,
    onNavigateToSync: () -> Unit,
    onNavigateToPlanning: () -> Unit,
    onApprovePlan: () -> Unit,
    onDispatchMission: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val mission = uiState.repoData.mission
    val approvalValid = mission.approval?.valid == true && mission.approval.missionVersion == mission.missionVersion

    AeroPanel(modifier = modifier) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            WingAccentHeader(
                title = aircraft?.let { "Inspector: ${it.aircraftId}" } ?: "Inspector",
                subtitle = aircraft?.airframe ?: "Select an aircraft on map or list",
            )
            if (aircraft != null) {
                TelemetryMetricTile(
                    label = "1. Configured Capability",
                    value = "${aircraft.supportedPayloads.joinToString(", ")} · Max ${aircraft.configuredMaxSpeedMps} m/s",
                    sublabel = "Reserve floor: ${aircraft.configuredMinReservePct}% · Autopilot ${aircraft.autopilotVersion}",
                )
                TelemetryMetricTile(
                    label = "2. Observed Readiness",
                    value = when {
                        aircraft.maintenanceBlockingReason != null -> "BLOCKED (${aircraft.maintenanceBlockingReason})"
                        syncState?.readinessAcked == true -> "VALID (Boot ${aircraft.bootId})"
                        else -> "NOT READY / EXPIRED"
                    },
                    valueColor = if (syncState?.readinessAcked == true) NominalEmerald else CautionAmber,
                    sublabel = syncState?.toleranceExceededReason ?: "Clock uncert: ±${syncState?.clockUncertaintyMs ?: "--"} ms",
                )
                TelemetryMetricTile(
                    label = "3. Operator Authorisation",
                    value = if (approvalValid) "APPROVED v${mission.missionVersion} by ${mission.approval?.approvedBy}" else "NOT AUTHORISED",
                    valueColor = if (approvalValid) NominalEmerald else CautionAmber,
                    sublabel = "Lease: ${mission.controlLease.leaseId} (${mission.controlLease.ownerOperatorId})",
                )
                TelemetryMetricTile(
                    label = "Observed Position & Datum",
                    value = "X=${aircraft.position.xM.toInt()}m Y=${aircraft.position.yM.toInt()}m Z=${aircraft.position.altM}m",
                    sublabel = "${aircraft.position.altitudeReference} · ±${aircraft.positionUncertaintyM}m",
                )
            }

            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = onNavigateToPlanning,
                    modifier = Modifier.weight(1f).minimumInteractiveComponentSize(),
                ) {
                    Text("Plan & Map")
                }
                OutlinedButton(
                    onClick = onNavigateToSync,
                    modifier = Modifier.weight(1f).minimumInteractiveComponentSize(),
                ) {
                    Text("Sync State")
                }
            }
            Button(
                onClick = onApprovePlan,
                enabled = uiState.isControlAllowed && !approvalValid && mission.conflicts.none { it.severity == "CRITICAL" },
                modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("inspector_approve_btn"),
            ) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Approve Plan v${mission.missionVersion}")
            }
            Button(
                onClick = onDispatchMission,
                enabled = uiState.isControlAllowed && approvalValid,
                colors = ButtonDefaults.buttonColors(containerColor = TelemetryCyan),
                modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("inspector_dispatch_btn"),
            ) {
                Icon(Icons.Filled.FlightTakeoff, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Request Simulated Dispatch")
            }
        }
    }
}

@Composable
private fun AttentionQueuePanel(
    exceptions: List<com.example.core.model.MissionException>,
    conflicts: List<com.example.core.model.ConflictFinding>,
    onAcknowledgeException: (String) -> Unit,
    onResolveException: (String, String, String) -> Unit,
    onNavigateToExceptions: () -> Unit,
    modifier: Modifier = Modifier,
) {
    AeroPanel(modifier = modifier) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "ATTENTION QUEUE (${exceptions.size} exceptions · ${conflicts.size} conflicts)",
                    style = MaterialTheme.typography.titleSmall,
                    color = IvoryPrimary,
                )
                OutlinedButton(onClick = onNavigateToExceptions, modifier = Modifier.minimumInteractiveComponentSize()) {
                    Text("Exception Centre")
                }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(conflicts, key = { it.conflictId }) { conflict ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        ConditionBadge(
                            label = conflict.category,
                            severity = if (conflict.severity == "CRITICAL") ConditionSeverity.CRITICAL else ConditionSeverity.CAUTION,
                            icon = if (conflict.severity == "CRITICAL") Icons.Filled.Error else Icons.Filled.Warning,
                        )
                        Text(
                            text = conflict.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = IvorySecondary,
                        )
                    }
                }
                items(exceptions, key = { it.exceptionId }) { exc ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${exc.exceptionId}: ${exc.category} (${exc.status})",
                                style = MaterialTheme.typography.labelMedium,
                                color = CautionAmber,
                            )
                            Text(
                                text = exc.sourceObservations.firstOrNull() ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = IvorySecondary,
                            )
                        }
                        if (exc.status == ExceptionStatus.OPEN) {
                            OutlinedButton(
                                onClick = { onAcknowledgeException(exc.exceptionId) },
                                modifier = Modifier.minimumInteractiveComponentSize(),
                            ) {
                                Text("Ack")
                            }
                        } else {
                            OutlinedButton(
                                onClick = {
                                    val act = exc.proposedResponses.firstOrNull() ?: "OPERATOR_RESOLVED"
                                    onResolveException(exc.exceptionId, act, "Resolved from overview queue")
                                },
                                modifier = Modifier.minimumInteractiveComponentSize(),
                            ) {
                                Text("Resolve")
                            }
                        }
                    }
                }
            }
        }
    }
}
