package com.example.feature.jobs

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.SpitfireUiState
import com.example.core.designsystem.AeroPanel
import com.example.core.designsystem.ConditionBadge
import com.example.core.designsystem.ConditionSeverity
import com.example.core.designsystem.IvoryPrimary
import com.example.core.designsystem.IvorySecondary
import com.example.core.designsystem.MutedSteel
import com.example.core.designsystem.WingAccentHeader
import com.example.core.model.CreateJobPayload
import com.example.core.model.JobType
import com.example.core.model.MissionDraft

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun JobsScreen(
    uiState: SpitfireUiState,
    drafts: List<MissionDraft>,
    onSaveDraft: (
        title: String,
        jobType: JobType,
        workAreaLabel: String,
        payloadType: String,
        timingStartS: Int,
        timingEndS: Int,
        responsibleOperator: String,
        operatingConditions: String,
    ) -> Unit,
    onSubmitDraft: (String) -> Unit,
    onDeleteDraft: (String) -> Unit,
    onCreateJobOnline: (CreateJobPayload) -> Unit,
    modifier: Modifier = Modifier,
) {
    var title by remember { mutableStateOf("Barn Roof Thermal & Tile Survey") }
    var selectedType by remember { mutableStateOf(JobType.ROOF_INSPECTION) }
    var workArea by remember { mutableStateOf("Pennine Farmstead Roof Block C") }
    var payload by remember { mutableStateOf("ROOF_ZOOM") }
    var timingStart by remember { mutableStateOf("180") }
    var timingEnd by remember { mutableStateOf("540") }
    var operatingConditions by remember { mutableStateOf("Daylight, wind <= 9.0 m/s, VLOS South Pad") }

    val availablePayloads = listOf("THERMAL_EO", "RGB_ORTHO", "MULTISPECTRAL", "ROOF_ZOOM", "LIDAR_POD", "CORRIDOR_CARGO")

    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("jobs_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            WingAccentHeader(
                title = "Survey & Authorised Delivery Jobs",
                subtitle = "Create jobs, store offline editable drafts, and track Flight / Coverage / Data Acceptance separately",
            )
        }

        item {
            AeroPanel {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Create Survey / Delivery Job", style = MaterialTheme.typography.titleMedium, color = IvoryPrimary)

                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        JobType.entries.forEach { jt ->
                            FilterChip(
                                selected = selectedType == jt,
                                onClick = {
                                    selectedType = jt
                                    payload = when (jt) {
                                        JobType.AGRICULTURAL_INSPECTION -> "MULTISPECTRAL"
                                        JobType.SOLAR_FARM_SURVEY -> "THERMAL_EO"
                                        JobType.ROOF_INSPECTION -> "ROOF_ZOOM"
                                        JobType.STOCKPILE_MAPPING -> "LIDAR_POD"
                                        JobType.AUTHORISED_DELIVERY -> "CORRIDOR_CARGO"
                                    }
                                },
                                label = { Text(jt.name.replace('_', ' '), style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.minimumInteractiveComponentSize(),
                            )
                        }
                    }

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Job Title") },
                        modifier = Modifier.fillMaxWidth().testTag("job_title_input"),
                    )
                    OutlinedTextField(
                        value = workArea,
                        onValueChange = { workArea = it },
                        label = { Text("Work Area / Predefined Route") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        availablePayloads.forEach { p ->
                            FilterChip(
                                selected = payload == p,
                                onClick = { payload = p },
                                label = { Text(p, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.minimumInteractiveComponentSize(),
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = timingStart,
                            onValueChange = { timingStart = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Start Window (s)") },
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = timingEnd,
                            onValueChange = { timingEnd = it.filter { ch -> ch.isDigit() } },
                            label = { Text("End Window (s)") },
                            modifier = Modifier.weight(1f),
                        )
                    }
                    OutlinedTextField(
                        value = operatingConditions,
                        onValueChange = { operatingConditions = it },
                        label = { Text("Documented Operating Conditions") },
                        modifier = Modifier.fillMaxWidth(),
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = {
                                onSaveDraft(
                                    title,
                                    selectedType,
                                    workArea,
                                    payload,
                                    timingStart.toIntOrNull() ?: 180,
                                    timingEnd.toIntOrNull() ?: 540,
                                    uiState.preferences.operatorId,
                                    operatingConditions,
                                )
                            },
                            modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("save_job_draft_btn"),
                        ) {
                            Text("Save Local Draft")
                        }
                        Button(
                            onClick = {
                                onCreateJobOnline(
                                    CreateJobPayload(
                                        title = title,
                                        jobType = selectedType,
                                        workAreaLabel = workArea,
                                        payloadType = payload,
                                        timingWindowStartS = timingStart.toIntOrNull() ?: 180,
                                        timingWindowEndS = timingEnd.toIntOrNull() ?: 540,
                                        responsibleOperator = uiState.preferences.operatorId,
                                        operatingConditions = operatingConditions,
                                        requiredOutputs = listOf("Orthomosaic", "Inspection Report"),
                                    ),
                                )
                            },
                            enabled = uiState.isControlAllowed,
                            modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("submit_job_gateway_btn"),
                        ) {
                            Text("Submit to Coordinator")
                        }
                    }
                }
            }
        }

        if (drafts.isNotEmpty()) {
            item {
                Text(
                    text = "LOCAL EDITABLE DRAFTS (${drafts.size}) — Persisted separately from authoritative mission",
                    style = MaterialTheme.typography.titleSmall,
                    color = IvoryPrimary,
                )
            }
            items(drafts, key = { it.draftId }) { draft ->
                AeroPanel {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${draft.draftId}: ${draft.title}", style = MaterialTheme.typography.titleSmall, color = IvoryPrimary)
                            Text(
                                "${draft.jobType} · ${draft.payloadType} · ${draft.workAreaLabel}",
                                style = MaterialTheme.typography.bodySmall,
                                color = IvorySecondary,
                            )
                            Text(
                                text = draft.syncedToMissionVersion?.let { "Synced in mission v$it" } ?: "Not yet submitted for validation",
                                style = MaterialTheme.typography.labelSmall,
                                color = MutedSteel,
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = { onSubmitDraft(draft.draftId) },
                                enabled = uiState.isControlAllowed,
                                modifier = Modifier.minimumInteractiveComponentSize(),
                            ) {
                                Text("Submit")
                            }
                            OutlinedButton(
                                onClick = { onDeleteDraft(draft.draftId) },
                                modifier = Modifier.minimumInteractiveComponentSize(),
                            ) {
                                Text("Delete")
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(Modifier.height(4.dp))
            Text(
                text = "AUTHORITATIVE MISSION JOBS (${uiState.repoData.mission.jobs.size})",
                style = MaterialTheme.typography.titleSmall,
                color = IvoryPrimary,
            )
        }

        items(uiState.repoData.mission.jobs, key = { it.jobId }) { job ->
            AeroPanel {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${job.jobId}: ${job.title}", style = MaterialTheme.typography.titleMedium, color = IvoryPrimary)
                    Text(
                        "${job.jobType} · Area: ${job.workAreaLabel} · Payload: ${job.payloadType} · Window: ${job.timingWindowStartS}s–${job.timingWindowEndS}s",
                        style = MaterialTheme.typography.bodySmall,
                        color = IvorySecondary,
                    )
                    Text(
                        "Operator: ${job.responsibleOperator} · Conditions: ${job.operatingConditions}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedSteel,
                    )
                    if (job.parentJobId != null) {
                        ConditionBadge("FOLLOW-UP TO ${job.parentJobId}", ConditionSeverity.INFO)
                    }
                    // Keep flight completed, coverage completed, and data accepted strictly separate!
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        ConditionBadge(
                            label = if (job.flightCompleted) "FLIGHT: COMPLETED" else "FLIGHT: PENDING",
                            severity = if (job.flightCompleted) ConditionSeverity.NOMINAL else ConditionSeverity.MUTED,
                        )
                        ConditionBadge(
                            label = if (job.coverageCompleted) "COVERAGE: COMPLETE" else "COVERAGE: INCOMPLETE",
                            severity = if (job.coverageCompleted) ConditionSeverity.NOMINAL else ConditionSeverity.CAUTION,
                        )
                        ConditionBadge(
                            label = if (job.dataAccepted) "DATA: ACCEPTED" else "DATA: UNREVIEWED",
                            severity = if (job.dataAccepted) ConditionSeverity.NOMINAL else ConditionSeverity.MUTED,
                        )
                    }
                }
            }
        }
    }
}
