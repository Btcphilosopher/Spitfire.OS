package com.example.feature.exceptions

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.SpitfireUiState
import com.example.core.designsystem.AeroPanel
import com.example.core.designsystem.CautionAmber
import com.example.core.designsystem.ConditionBadge
import com.example.core.designsystem.ConditionSeverity
import com.example.core.designsystem.CriticalRed
import com.example.core.designsystem.IvoryPrimary
import com.example.core.designsystem.IvorySecondary
import com.example.core.designsystem.MutedSteel
import com.example.core.designsystem.WingAccentHeader
import com.example.core.model.ExceptionStatus

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ExceptionsScreen(
    uiState: SpitfireUiState,
    onAcknowledgeException: (String) -> Unit,
    onResolveException: (String, String, String) -> Unit,
    onRequestCoordinationAbort: () -> Unit,
    onRequestAircraftContingency: (String, String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val mission = uiState.repoData.mission

    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("exceptions_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            WingAccentHeader(
                title = "Exception & Contingency Centre",
                subtitle = "Acknowledgement and resolution are strictly separated · Only backend-supplied, aircraft-supported contingencies are offered",
            )
        }

        item {
            AeroPanel(borderColor = CautionAmber) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Coordination Abort vs Aircraft Emergency Action", style = MaterialTheme.typography.titleSmall, color = CautionAmber)
                    Text(
                        "COORDINATION ABORT terminates coordinator tasking across the mission. Emergency flight actions (such as Hold or Contingency Site) execute only on airframes declaring capability in their configured registry.",
                        style = MaterialTheme.typography.bodySmall,
                        color = IvorySecondary,
                    )
                    OutlinedButton(
                        onClick = onRequestCoordinationAbort,
                        enabled = uiState.isControlAllowed,
                        modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                        Text("Issue Mission Coordination Abort")
                    }
                }
            }
        }

        items(mission.exceptions, key = { it.exceptionId }) { exc ->
            val severity = when {
                exc.status == ExceptionStatus.RESOLVED -> ConditionSeverity.NOMINAL
                exc.severity == "CRITICAL" -> ConditionSeverity.CRITICAL
                else -> ConditionSeverity.CAUTION
            }
            AeroPanel(
                borderColor = if (exc.severity == "CRITICAL" && exc.status != ExceptionStatus.RESOLVED) CriticalRed else CautionAmber.copy(alpha = 0.6f),
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${exc.exceptionId} · ${exc.category}", style = MaterialTheme.typography.titleMedium, color = IvoryPrimary)
                        ConditionBadge(label = "${exc.severity} / ${exc.status}", severity = severity)
                    }
                    Text(
                        text = "Affected Aircraft: ${exc.affectedAircraft.joinToString().ifBlank { "NONE" }} · Tasks: ${exc.affectedTasks.joinToString().ifBlank { "NONE" }} · Operator: ${exc.responsibleOperator}",
                        style = MaterialTheme.typography.bodySmall,
                        color = IvorySecondary,
                    )
                    exc.sourceObservations.forEach { obs ->
                        Text("Source Observation: $obs", style = MaterialTheme.typography.bodySmall, color = IvoryPrimary)
                    }
                    Text("Backend-Proposed Responses: ${exc.proposedResponses.joinToString(" · ")}", style = MaterialTheme.typography.labelMedium, color = MutedSteel)

                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (exc.status == ExceptionStatus.OPEN) {
                            OutlinedButton(
                                onClick = { onAcknowledgeException(exc.exceptionId) },
                                enabled = uiState.isControlAllowed,
                                modifier = Modifier.minimumInteractiveComponentSize().testTag("ack_exc_${exc.exceptionId}"),
                            ) {
                                Text("Acknowledge (Distinct from Resolve)")
                            }
                        }
                        if (exc.status != ExceptionStatus.RESOLVED) {
                            exc.proposedResponses.forEach { resp ->
                                Button(
                                    onClick = {
                                        onResolveException(exc.exceptionId, resp, "Operator executed $resp")
                                    },
                                    enabled = uiState.isControlAllowed,
                                    colors = ButtonDefaults.buttonColors(containerColor = CautionAmber),
                                    modifier = Modifier.minimumInteractiveComponentSize().testTag("resolve_exc_${exc.exceptionId}_$resp"),
                                ) {
                                    Text("Resolve: ${resp.replace('_', ' ')}")
                                }
                            }
                        }
                        // Aircraft-supported contingency actions only
                        exc.affectedAircraft.forEach { acId ->
                            val ac = uiState.repoData.fleet.firstOrNull { it.aircraftId == acId }
                            ac?.supportedContingencies?.firstOrNull { it != "COORDINATION_ABORT" }?.let { cont ->
                                OutlinedButton(
                                    onClick = { onRequestAircraftContingency(acId, cont) },
                                    enabled = uiState.isControlAllowed,
                                    modifier = Modifier.minimumInteractiveComponentSize(),
                                ) {
                                    Text("$acId: $cont")
                                }
                            }
                        }
                    }

                    if (exc.resolutionHistory.isNotEmpty()) {
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text("Resolution History:", style = MaterialTheme.typography.labelSmall, color = MutedSteel)
                            exc.resolutionHistory.forEach { entry ->
                                Text(
                                    "• ${entry.action} by ${entry.operatorId}: ${entry.note}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = IvorySecondary,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
