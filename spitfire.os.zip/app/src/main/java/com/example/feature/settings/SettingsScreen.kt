package com.example.feature.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.SpitfireUiState
import com.example.core.designsystem.AeroPanel
import com.example.core.designsystem.CautionAmber
import com.example.core.designsystem.ConditionBadge
import com.example.core.designsystem.ConditionSeverity
import com.example.core.designsystem.IvoryPrimary
import com.example.core.designsystem.IvorySecondary
import com.example.core.designsystem.WingAccentHeader
import com.example.core.model.OperatingMode

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    uiState: SpitfireUiState,
    onUpdateGatewayUrl: (String) -> Unit,
    onUpdateOperatorIdentity: (String, String) -> Unit,
    onSetConnectedAircraftEnabled: (Boolean) -> Unit,
    onSetShowUncertaintyRings: (Boolean) -> Unit,
    onSaveToken: (String) -> Unit,
    onSetOperatingMode: (OperatingMode) -> Unit,
    onReconnect: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var gatewayUrl by remember(uiState.preferences.gatewayBaseUrl) { mutableStateOf(uiState.preferences.gatewayBaseUrl) }
    var operatorId by remember(uiState.preferences.operatorId) { mutableStateOf(uiState.preferences.operatorId) }
    var deviceId by remember(uiState.preferences.deviceId) { mutableStateOf(uiState.preferences.deviceId) }
    var bearerToken by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("settings_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            WingAccentHeader(
                title = "Gateway, Operating Mode & Security",
                subtitle = "Real-aircraft integration is separately configured and disabled by default",
            )
        }

        item {
            AeroPanel {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Operating Mode", style = MaterialTheme.typography.titleMedium, color = IvoryPrimary)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OperatingMode.entries.forEach { mode ->
                            val enabled = mode != OperatingMode.CONNECTED_AIRCRAFT ||
                                (uiState.repoData.capabilities.connectedAircraftEnabled && uiState.preferences.connectedAircraftIntegrationEnabled)
                            FilterChip(
                                selected = uiState.repoData.operatingMode == mode,
                                enabled = enabled,
                                onClick = { onSetOperatingMode(mode) },
                                label = { Text(mode.name.replace('_', ' ')) },
                                modifier = Modifier.minimumInteractiveComponentSize(),
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Enable Real-Aircraft Integration Gate", style = MaterialTheme.typography.bodyLarge, color = IvoryPrimary)
                            Text(
                                "Backend gate: ${uiState.repoData.capabilities.connectedAircraftGate}",
                                style = MaterialTheme.typography.bodySmall,
                                color = CautionAmber,
                            )
                        }
                        Switch(
                            checked = uiState.preferences.connectedAircraftIntegrationEnabled,
                            onCheckedChange = onSetConnectedAircraftEnabled,
                        )
                    }
                }
            }
        }

        item {
            AeroPanel {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Python FastAPI Gateway Connection", style = MaterialTheme.typography.titleMedium, color = IvoryPrimary)
                    OutlinedTextField(
                        value = gatewayUrl,
                        onValueChange = { gatewayUrl = it },
                        label = { Text("Gateway Base URL") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = operatorId,
                            onValueChange = { operatorId = it },
                            label = { Text("Operator ID") },
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = deviceId,
                            onValueChange = { deviceId = it },
                            label = { Text("Tablet Device ID") },
                            modifier = Modifier.weight(1f),
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                onUpdateGatewayUrl(gatewayUrl)
                                onUpdateOperatorIdentity(operatorId, deviceId)
                                onReconnect()
                            },
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("reconnect_gateway_btn"),
                        ) {
                            Text("Save & Reconcile Gateway")
                        }
                        OutlinedButton(
                            onClick = onReconnect,
                            modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                            Text("Probe Now")
                        }
                    }
                }
            }
        }

        item {
            AeroPanel {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Android KeyStore Encrypted Token", style = MaterialTheme.typography.titleMedium, color = IvoryPrimary)
                        ConditionBadge(
                            label = if (uiState.hasStoredToken) "TOKEN VAULTED" else "NO TOKEN",
                            severity = if (uiState.hasStoredToken) ConditionSeverity.NOMINAL else ConditionSeverity.MUTED,
                        )
                    }
                    OutlinedTextField(
                        value = bearerToken,
                        onValueChange = { bearerToken = it },
                        label = { Text("Bearer Token (AES-GCM KeyStore Encrypted)") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Button(
                        onClick = {
                            onSaveToken(bearerToken)
                            bearerToken = ""
                        },
                        modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                        Text("Encrypt & Store Token")
                    }
                }
            }
        }

        item {
            AeroPanel {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("Render Position Uncertainty Rings on Map", style = MaterialTheme.typography.bodyLarge, color = IvoryPrimary)
                        Switch(
                            checked = uiState.preferences.showUncertaintyRings,
                            onCheckedChange = onSetShowUncertaintyRings,
                        )
                    }
                    Text(
                        text = "Pre-flight Regulatory Notice: Before proposing real flights, verify intended jurisdiction (e.g., UK CAA PDRA-01 / Operational Authorisation), airspace permissions, aircraft capabilities, and operator responsibilities through current official sources.",
                        style = MaterialTheme.typography.bodySmall,
                        color = IvorySecondary,
                    )
                }
            }
        }
    }
}
