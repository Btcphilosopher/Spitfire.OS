package com.example.feature.fleet

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.SpitfireUiState
import com.example.core.database.AircraftDocEntity
import com.example.core.designsystem.AeroPanel
import com.example.core.designsystem.CautionAmber
import com.example.core.designsystem.ConditionBadge
import com.example.core.designsystem.ConditionSeverity
import com.example.core.designsystem.CriticalRed
import com.example.core.designsystem.IvoryPrimary
import com.example.core.designsystem.IvorySecondary
import com.example.core.designsystem.MutedSteel
import com.example.core.designsystem.TelemetryCyan
import com.example.core.designsystem.TelemetryMetricTile
import com.example.core.designsystem.WingAccentHeader

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FleetScreen(
    uiState: SpitfireUiState,
    aircraftDocs: List<AircraftDocEntity>,
    onSelectAircraft: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val fleet = uiState.repoData.fleet

    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("fleet_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            WingAccentHeader(
                title = "Fleet Registry & Airframe Limits",
                subtitle = "${fleet.size} aircraft registered · Cached age: ${uiState.cachedAgeSeconds}s · Offline documentation available",
            )
        }

        items(fleet, key = { it.aircraftId }) { ac ->
            val doc = aircraftDocs.firstOrNull { it.aircraftId == ac.aircraftId }
            AeroPanel(
                borderColor = when {
                    ac.maintenanceBlockingReason != null || ac.withdrawn -> CriticalRed
                    ac.batterySocPct < 50.0 -> CautionAmber
                    else -> TelemetryCyan.copy(alpha = 0.4f)
                },
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column {
                            Text(
                                text = "${ac.aircraftId} — ${ac.callsign} (${ac.airframe})",
                                style = MaterialTheme.typography.titleMedium,
                                color = IvoryPrimary,
                            )
                            Text(
                                text = "Autopilot: ${ac.autopilotVersion} · Boot ID: ${ac.bootId}",
                                style = MaterialTheme.typography.bodySmall,
                                color = IvorySecondary,
                            )
                        }
                        ConditionBadge(
                            label = ac.observedFlightMode,
                            severity = when {
                                ac.withdrawn || ac.maintenanceBlockingReason != null -> ConditionSeverity.CRITICAL
                                ac.batterySocPct < 50.0 -> ConditionSeverity.CAUTION
                                else -> ConditionSeverity.NOMINAL
                            },
                        )
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        TelemetryMetricTile("Payloads", ac.supportedPayloads.joinToString(", "))
                        TelemetryMetricTile(
                            "Configured Limits",
                            "Max ${ac.configuredMaxSpeedMps} m/s · Wind ${ac.configuredMaxWindMps} m/s",
                            sublabel = "Min Reserve: ${ac.configuredMinReservePct}%",
                        )
                        TelemetryMetricTile(
                            "Battery (${ac.batteryId})",
                            "${ac.batterySocPct}% · ${ac.batteryVoltageV}V",
                            sublabel = "${ac.chargingState} · Obs +${uiState.cachedAgeSeconds}s ago",
                            valueColor = if (ac.batterySocPct < 50.0) CautionAmber else IvoryPrimary,
                        )
                        TelemetryMetricTile(
                            "Assignment & Comm",
                            ac.assignedTaskId ?: "UNASSIGNED",
                            sublabel = "Link: ${ac.linkStatus} · Last cmd: ${ac.latestCommandOutcome}",
                        )
                    }

                    if (ac.maintenanceRestrictions.isNotEmpty() || ac.maintenanceBlockingReason != null) {
                        ConditionBadge(
                            label = "MAINTENANCE BLOCK: ${ac.maintenanceBlockingReason ?: ac.maintenanceRestrictions.joinToString()}",
                            severity = ConditionSeverity.CRITICAL,
                        )
                    }

                    Text(
                        text = "Docs: ${doc?.summary ?: ac.documentationSummary}",
                        style = MaterialTheme.typography.bodySmall,
                        color = IvorySecondary,
                    )
                    Text(
                        text = "Supported Contingencies: ${ac.supportedContingencies.joinToString(" · ")}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MutedSteel,
                    )
                }
            }
        }
    }
}
