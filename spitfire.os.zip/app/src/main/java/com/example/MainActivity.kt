package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.designsystem.CautionAmber
import com.example.core.designsystem.ConditionBadge
import com.example.core.designsystem.ConditionSeverity
import com.example.core.designsystem.CriticalRed
import com.example.core.designsystem.CriticalRedBg
import com.example.core.designsystem.DeepSlateNavy
import com.example.core.designsystem.GraphitePanel
import com.example.core.designsystem.HairlineBorder
import com.example.core.designsystem.IvoryPrimary
import com.example.core.designsystem.IvorySecondary
import com.example.core.designsystem.MidnightNavy
import com.example.core.designsystem.OfflineStatusBanner
import com.example.core.designsystem.OperatingModeIndicator
import com.example.core.designsystem.ReplayIsolationBanner
import com.example.core.designsystem.SpitfireTheme
import com.example.core.designsystem.TelemetryCyan
import com.example.core.designsystem.TelemetryCyanMuted
import com.example.core.model.ExceptionStatus
import com.example.core.model.OperatingMode
import com.example.feature.data.DataScreen
import com.example.feature.data.MaintenanceScreen
import com.example.feature.data.PayloadsScreen
import com.example.feature.exceptions.ExceptionsScreen
import com.example.feature.fleet.FleetScreen
import com.example.feature.jobs.JobsScreen
import com.example.feature.overview.OverviewScreen
import com.example.feature.planning.PlanningScreen
import com.example.feature.replay.ReplayScreen
import com.example.feature.settings.SettingsScreen
import com.example.feature.synchronisation.SynchronisationScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SpitfireTheme {
                val viewModel: SpitfireViewModel = viewModel(factory = SpitfireViewModel.Factory)
                SpitfireOperatorApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun SpitfireOperatorApp(
    viewModel: SpitfireViewModel,
    modifier: Modifier = Modifier,
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val drafts by viewModel.drafts.collectAsStateWithLifecycle()
    val replaySessions by viewModel.replaySessions.collectAsStateWithLifecycle()
    val reports by viewModel.reports.collectAsStateWithLifecycle()
    val aircraftDocs by viewModel.aircraftDocs.collectAsStateWithLifecycle()
    val queriedCommand by viewModel.queriedCommand.collectAsStateWithLifecycle()

    var showingExceptionsModalScreen by rememberSaveable { mutableStateOf(false) }

    if (showingExceptionsModalScreen) {
        BackHandler { showingExceptionsModalScreen = false }
    } else if (uiState.currentDestination != SpitfireDestination.OVERVIEW) {
        BackHandler { viewModel.navigateTo(SpitfireDestination.OVERVIEW) }
    }

    val openExceptionsCount = uiState.repoData.mission.exceptions.count {
        it.status != ExceptionStatus.RESOLVED
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightNavy),
        containerColor = MidnightNavy,
        contentWindowInsets = WindowInsets.safeDrawing,
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            val useNavigationRail = maxWidth >= 600.dp

            Row(modifier = Modifier.fillMaxSize()) {
                if (useNavigationRail) {
                    NavigationRail(
                        modifier = Modifier
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState())
                            .testTag("spitfire_navigation_rail"),
                        containerColor = DeepSlateNavy,
                        contentColor = IvoryPrimary,
                    ) {
                        SpitfireDestination.entries.forEach { dest ->
                            val selected = !showingExceptionsModalScreen && uiState.currentDestination == dest
                            NavigationRailItem(
                                selected = selected,
                                onClick = {
                                    showingExceptionsModalScreen = false
                                    viewModel.navigateTo(dest)
                                },
                                icon = {
                                    Icon(
                                        imageVector = dest.icon(),
                                        contentDescription = stringResource(dest.labelRes),
                                    )
                                },
                                label = {
                                    Text(
                                        text = stringResource(dest.labelRes),
                                        style = MaterialTheme.typography.labelSmall,
                                    )
                                },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("nav_${dest.route}"),
                            )
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    // Persistent Top Operational Status Strip
                    TopOperationalBar(
                        uiState = uiState,
                        openExceptionsCount = openExceptionsCount,
                        showingExceptions = showingExceptionsModalScreen,
                        onOpenExceptions = { showingExceptionsModalScreen = !showingExceptionsModalScreen },
                        onReconnect = viewModel::reconnectAndReconcile,
                    )

                    if (!useNavigationRail) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            SpitfireDestination.entries.forEach { dest ->
                                FilterChip(
                                    selected = !showingExceptionsModalScreen && uiState.currentDestination == dest,
                                    onClick = {
                                        showingExceptionsModalScreen = false
                                        viewModel.navigateTo(dest)
                                    },
                                    label = { Text(stringResource(dest.labelRes)) },
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("nav_chip_${dest.route}"),
                                )
                            }
                        }
                    }

                    // Prominent Mode & Connectivity Banners
                    if (!uiState.repoData.gatewayConnected && uiState.repoData.operatingMode != OperatingMode.REPLAY) {
                        OfflineStatusBanner(
                            cachedAgeText = "${uiState.cachedAgeSeconds}s ago",
                            gatewayUrl = uiState.preferences.gatewayBaseUrl,
                        )
                    }
                    if (uiState.repoData.operatingMode == OperatingMode.REPLAY) {
                        ReplayIsolationBanner()
                    }

                    uiState.repoData.lastError?.let { err ->
                        FeedbackStrip(
                            message = err,
                            isError = true,
                            onDismiss = viewModel::dismissBanner,
                        )
                    }
                    uiState.repoData.lastActionBanner?.let { msg ->
                        FeedbackStrip(
                            message = msg,
                            isError = false,
                            onDismiss = viewModel::dismissBanner,
                        )
                    }

                    // Active Workspace Screen
                    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        if (showingExceptionsModalScreen) {
                            ExceptionsScreen(
                                uiState = uiState,
                                onAcknowledgeException = viewModel::acknowledgeException,
                                onResolveException = viewModel::resolveException,
                                onRequestCoordinationAbort = viewModel::requestCoordinationAbort,
                                onRequestAircraftContingency = viewModel::requestAircraftContingency,
                            )
                        } else {
                            when (uiState.currentDestination) {
                                SpitfireDestination.OVERVIEW -> OverviewScreen(
                                    uiState = uiState,
                                    onSelectAircraft = viewModel::selectAircraft,
                                    onNavigateToSync = { viewModel.navigateTo(SpitfireDestination.SYNCHRONISATION) },
                                    onNavigateToExceptions = { showingExceptionsModalScreen = true },
                                    onNavigateToPlanning = { viewModel.navigateTo(SpitfireDestination.MISSIONS) },
                                    onApprovePlan = viewModel::approveCurrentMissionVersion,
                                    onDispatchMission = viewModel::requestDispatch,
                                    onAcknowledgeException = viewModel::acknowledgeException,
                                    onResolveException = viewModel::resolveException,
                                )
                                SpitfireDestination.FLEET -> FleetScreen(
                                    uiState = uiState,
                                    aircraftDocs = aircraftDocs,
                                    onSelectAircraft = viewModel::selectAircraft,
                                )
                                SpitfireDestination.JOBS -> JobsScreen(
                                    uiState = uiState,
                                    drafts = drafts,
                                    onSaveDraft = viewModel::saveOfflineDraft,
                                    onSubmitDraft = viewModel::submitDraft,
                                    onDeleteDraft = viewModel::deleteDraft,
                                    onCreateJobOnline = viewModel::createJobOnline,
                                )
                                SpitfireDestination.MISSIONS -> PlanningScreen(
                                    uiState = uiState,
                                    queriedCommand = queriedCommand,
                                    onSelectAircraft = viewModel::selectAircraft,
                                    onSetMapTool = viewModel::setMapEditorTool,
                                    onMapTap = viewModel::onMapTapLocalCoord,
                                    onClearMapEdits = viewModel::clearLocalMapEdits,
                                    onRequestAllocation = viewModel::requestAllocationProposal,
                                    onRequestValidation = viewModel::requestValidation,
                                    onApproveVersion = viewModel::approveCurrentMissionVersion,
                                    onRequestDispatch = viewModel::requestDispatch,
                                    onRequestPause = viewModel::requestPause,
                                    onRequestCancel = viewModel::requestCoordinationAbort,
                                    onRequestContingency = viewModel::requestAircraftContingency,
                                    onAcquireLease = viewModel::acquireOrRenewLease,
                                    onRequestHandover = viewModel::requestHandover,
                                    onAcceptHandover = viewModel::acceptHandover,
                                    onQueryCommandStatus = viewModel::queryCommandStatus,
                                )
                                SpitfireDestination.SYNCHRONISATION -> SynchronisationScreen(
                                    uiState = uiState,
                                    onInjectDelayedTelemetry = viewModel::triggerDelayedTelemetrySim,
                                    onWithdrawSpit04 = viewModel::triggerWithdrawSpit04,
                                    onRequestRecalculation = { viewModel.requestAllocationProposal(true) },
                                    onRequestCoordinationAbort = viewModel::requestCoordinationAbort,
                                )
                                SpitfireDestination.PAYLOADS -> PayloadsScreen(uiState = uiState)
                                SpitfireDestination.MAINTENANCE -> MaintenanceScreen(
                                    uiState = uiState,
                                    onRejectTestDispatchSpit06 = {
                                        viewModel.requestAircraftContingency("SPIT-06", "DISPATCH")
                                    },
                                )
                                SpitfireDestination.DATA -> DataScreen(
                                    uiState = uiState,
                                    reports = reports,
                                    onTriggerMissingImageryFollowup = viewModel::triggerMissingImageryFollowup,
                                    onExportReport = viewModel::exportMissionReport,
                                )
                                SpitfireDestination.REPLAY -> ReplayScreen(
                                    uiState = uiState,
                                    replaySessions = replaySessions,
                                    onTogglePlayPause = viewModel::toggleReplayPlayPause,
                                    onSetSpeed = viewModel::setReplaySpeed,
                                    onSeek = viewModel::seekReplay,
                                    onSetAircraftFilter = viewModel::setReplayAircraftFilter,
                                )
                                SpitfireDestination.SETTINGS -> SettingsScreen(
                                    uiState = uiState,
                                    onUpdateGatewayUrl = viewModel::updateGatewayUrl,
                                    onUpdateOperatorIdentity = viewModel::updateOperatorIdentity,
                                    onSetConnectedAircraftEnabled = viewModel::setConnectedAircraftEnabled,
                                    onSetShowUncertaintyRings = viewModel::setShowUncertaintyRings,
                                    onSaveToken = viewModel::saveGatewayToken,
                                    onSetOperatingMode = viewModel::setOperatingMode,
                                    onReconnect = viewModel::reconnectAndReconcile,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TopOperationalBar(
    uiState: SpitfireUiState,
    openExceptionsCount: Int,
    showingExceptions: Boolean,
    onOpenExceptions: () -> Unit,
    onReconnect: () -> Unit,
) {
    Surface(
        color = GraphitePanel,
        shape = MaterialTheme.shapes.small,
        border = BorderStroke(1.dp, HairlineBorder),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    text = "SPITFIRE.OS",
                    style = MaterialTheme.typography.titleMedium,
                    color = IvoryPrimary,
                )
                OperatingModeIndicator(
                    mode = uiState.repoData.operatingMode,
                    connectedAircraftEnabled = uiState.repoData.capabilities.connectedAircraftEnabled &&
                        uiState.preferences.connectedAircraftIntegrationEnabled,
                )
                ConditionBadge(
                    label = if (uiState.repoData.gatewayConnected) "GATEWAY LIVE" else "GATEWAY OFFLINE",
                    severity = if (uiState.repoData.gatewayConnected) ConditionSeverity.NOMINAL else ConditionSeverity.CAUTION,
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    text = uiState.repoData.telemetryStreamNote,
                    style = MaterialTheme.typography.labelSmall,
                    color = IvorySecondary,
                )
                OutlinedButton(
                    onClick = onOpenExceptions,
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("top_exceptions_btn"),
                ) {
                    Icon(
                        Icons.Filled.Warning,
                        contentDescription = "Exceptions",
                        tint = if (openExceptionsCount > 0) CautionAmber else IvorySecondary,
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(if (showingExceptions) "Close Exceptions" else "Exceptions ($openExceptionsCount)")
                }
                IconButton(
                    onClick = onReconnect,
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("top_reconcile_btn"),
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = "Reconnect and reconcile",
                        tint = TelemetryCyan,
                    )
                }
            }
        }
    }
}

@Composable
private fun FeedbackStrip(
    message: String,
    isError: Boolean,
    onDismiss: () -> Unit,
) {
    Surface(
        color = if (isError) CriticalRedBg else TelemetryCyanMuted,
        border = BorderStroke(1.dp, if (isError) CriticalRed else TelemetryCyan),
        shape = MaterialTheme.shapes.extraSmall,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall,
                color = IvoryPrimary,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = onDismiss, modifier = Modifier.minimumInteractiveComponentSize()) {
                Text("Dismiss", color = IvoryPrimary)
            }
        }
    }
}

private fun SpitfireDestination.icon(): ImageVector = when (this) {
    SpitfireDestination.OVERVIEW -> Icons.Filled.Dashboard
    SpitfireDestination.FLEET -> Icons.Filled.Flight
    SpitfireDestination.JOBS -> Icons.Filled.Work
    SpitfireDestination.MISSIONS -> Icons.Filled.Map
    SpitfireDestination.SYNCHRONISATION -> Icons.Filled.Sync
    SpitfireDestination.PAYLOADS -> Icons.Filled.PhotoCamera
    SpitfireDestination.MAINTENANCE -> Icons.Filled.Build
    SpitfireDestination.DATA -> Icons.Filled.FolderOpen
    SpitfireDestination.REPLAY -> Icons.Filled.History
    SpitfireDestination.SETTINGS -> Icons.Filled.Settings
}
