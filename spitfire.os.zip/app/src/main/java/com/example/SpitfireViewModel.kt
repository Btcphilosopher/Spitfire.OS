package com.example

import android.os.SystemClock
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.createSavedStateHandle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.core.model.AppPreferences
import com.example.core.model.CommandRecord
import com.example.core.model.CreateJobPayload
import com.example.core.model.JobType
import com.example.core.model.LocalPoint3D
import com.example.core.model.OperatingMode
import com.example.core.repository.ReconciliationStatus
import com.example.core.repository.RepositoryUiData
import com.example.core.repository.SpitfireRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class SpitfireDestination(val route: String, val labelRes: Int) {
    OVERVIEW("overview", R.string.nav_overview),
    FLEET("fleet", R.string.nav_fleet),
    JOBS("jobs", R.string.nav_jobs),
    MISSIONS("missions", R.string.nav_missions),
    SYNCHRONISATION("synchronisation", R.string.nav_synchronisation),
    PAYLOADS("payloads", R.string.nav_payloads),
    MAINTENANCE("maintenance", R.string.nav_maintenance),
    DATA("data", R.string.nav_data),
    REPLAY("replay", R.string.nav_replay),
    SETTINGS("settings", R.string.nav_settings),
}

enum class MapEditorTool {
    INSPECT,
    ADD_WAYPOINT,
    ADD_EXCLUSION,
    ADD_CONTINGENCY,
}

data class ReplayPlaybackState(
    val selectedReplayId: String = "RPL-PENNINE-001",
    val isPlaying: Boolean = false,
    val speedMultiplier: Float = 1.0f,
    val currentTimeS: Float = 0.0f,
    val aircraftFilterId: String? = null,
)

data class SpitfireUiState(
    val repoData: RepositoryUiData,
    val preferences: AppPreferences,
    val currentDestination: SpitfireDestination,
    val selectedAircraftId: String?,
    val selectedTaskId: String?,
    val mapEditorTool: MapEditorTool,
    val localEditedWaypoints: List<LocalPoint3D>,
    val localEditedExclusions: List<LocalPoint3D>,
    val localEditedContingencies: List<LocalPoint3D>,
    val hasUncommittedMapEdits: Boolean,
    val monotonicClockTickMs: Long,
    val replayState: ReplayPlaybackState,
    val hasStoredToken: Boolean,
) {
    val cachedAgeSeconds: Long
        get() = ((monotonicClockTickMs - repoData.lastSyncElapsedMs).coerceAtLeast(0L)) / 1000L

    val isControlAllowed: Boolean
        get() = repoData.gatewayConnected &&
            repoData.operatingMode != OperatingMode.REPLAY &&
            repoData.reconciliationStatus == ReconciliationStatus.Synchronised &&
            repoData.mission.controlLease.ownerOperatorId == preferences.operatorId
}

class SpitfireViewModel(
    private val repository: SpitfireRepository,
    private val savedStateHandle: SavedStateHandle,
) : ViewModel() {

    private val _destination = MutableStateFlow(
        runCatching {
            SpitfireDestination.valueOf(
                savedStateHandle.get<String>(KEY_DESTINATION) ?: SpitfireDestination.OVERVIEW.name,
            )
        }.getOrDefault(SpitfireDestination.OVERVIEW),
    )

    private val _selectedAircraftId = MutableStateFlow(
        savedStateHandle.get<String>(KEY_SELECTED_AIRCRAFT) ?: "SPIT-01",
    )

    private val _selectedTaskId = MutableStateFlow(
        savedStateHandle.get<String>(KEY_SELECTED_TASK) ?: "TASK-001",
    )

    private val _mapTool = MutableStateFlow(MapEditorTool.INSPECT)
    private val _editedWaypoints = MutableStateFlow<List<LocalPoint3D>>(emptyList())
    private val _editedExclusions = MutableStateFlow<List<LocalPoint3D>>(emptyList())
    private val _editedContingencies = MutableStateFlow<List<LocalPoint3D>>(emptyList())
    private val _monotonicTick = MutableStateFlow(SystemClock.elapsedRealtime())

    private val _replayState = MutableStateFlow(
        ReplayPlaybackState(
            currentTimeS = savedStateHandle.get<Float>(KEY_REPLAY_TIME) ?: 0f,
        ),
    )

    private val _hasStoredToken = MutableStateFlow(repository.credentialStore.hasToken())

    val drafts = repository.drafts
    val replaySessions = repository.replaySessions
    val reports = repository.reports
    val aircraftDocs = repository.aircraftDocs

    val uiState: StateFlow<SpitfireUiState> = combine(
        repository.state,
        repository.preferences,
        _destination,
        _selectedAircraftId,
        _selectedTaskId,
        _mapTool,
        _editedWaypoints,
        _editedExclusions,
        _editedContingencies,
        _monotonicTick,
        _replayState,
        _hasStoredToken,
    ) { values ->
        val repo = values[0] as RepositoryUiData
        val prefs = values[1] as AppPreferences
        val dest = values[2] as SpitfireDestination
        val acId = values[3] as String?
        val taskId = values[4] as String?
        val tool = values[5] as MapEditorTool
        @Suppress("UNCHECKED_CAST")
        val wps = values[6] as List<LocalPoint3D>
        @Suppress("UNCHECKED_CAST")
        val excs = values[7] as List<LocalPoint3D>
        @Suppress("UNCHECKED_CAST")
        val ctgs = values[8] as List<LocalPoint3D>
        val tick = values[9] as Long
        val replay = values[10] as ReplayPlaybackState
        val hasTok = values[11] as Boolean

        SpitfireUiState(
            repoData = repo,
            preferences = prefs,
            currentDestination = dest,
            selectedAircraftId = acId,
            selectedTaskId = taskId,
            mapEditorTool = tool,
            localEditedWaypoints = wps,
            localEditedExclusions = excs,
            localEditedContingencies = ctgs,
            hasUncommittedMapEdits = wps.isNotEmpty() || excs.isNotEmpty() || ctgs.isNotEmpty(),
            monotonicClockTickMs = tick,
            replayState = replay,
            hasStoredToken = hasTok,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SpitfireUiState(
            repoData = repository.state.value,
            preferences = repository.preferences.value,
            currentDestination = _destination.value,
            selectedAircraftId = _selectedAircraftId.value,
            selectedTaskId = _selectedTaskId.value,
            mapEditorTool = MapEditorTool.INSPECT,
            localEditedWaypoints = emptyList(),
            localEditedExclusions = emptyList(),
            localEditedContingencies = emptyList(),
            hasUncommittedMapEdits = false,
            monotonicClockTickMs = SystemClock.elapsedRealtime(),
            replayState = _replayState.value,
            hasStoredToken = _hasStoredToken.value,
        ),
    )

    private val _queriedCommand = MutableStateFlow<CommandRecord?>(null)
    val queriedCommand: StateFlow<CommandRecord?> = _queriedCommand.asStateFlow()

    init {
        // Local monotonic clock ticker so telemetry freshness & cache age visibly increment every second
        viewModelScope.launch {
            while (isActive) {
                _monotonicTick.value = SystemClock.elapsedRealtime()
                delay(1000L)
            }
        }

        // Isolated Replay playback loop (never touches live gateway!)
        viewModelScope.launch {
            while (isActive) {
                delay(250L)
                val rs = _replayState.value
                if (rs.isPlaying) {
                    val session = replaySessions.value.firstOrNull { it.replayId == rs.selectedReplayId }
                    val maxS = (session?.durationS ?: 60.0).toFloat()
                    val next = rs.currentTimeS + (0.25f * rs.speedMultiplier)
                    val wrapped = if (next > maxS) 0f else next
                    savedStateHandle[KEY_REPLAY_TIME] = wrapped
                    _replayState.update { it.copy(currentTimeS = wrapped) }
                }
            }
        }
    }

    fun navigateTo(destination: SpitfireDestination) {
        savedStateHandle[KEY_DESTINATION] = destination.name
        _destination.value = destination
        if (destination == SpitfireDestination.REPLAY) {
            repository.setOperatingMode(OperatingMode.REPLAY)
        } else if (repository.state.value.operatingMode == OperatingMode.REPLAY) {
            repository.setOperatingMode(OperatingMode.SIMULATION)
        }
    }

    fun selectAircraft(aircraftId: String) {
        savedStateHandle[KEY_SELECTED_AIRCRAFT] = aircraftId
        _selectedAircraftId.value = aircraftId
    }

    fun selectTask(taskId: String) {
        savedStateHandle[KEY_SELECTED_TASK] = taskId
        _selectedTaskId.value = taskId
    }

    fun setMapEditorTool(tool: MapEditorTool) {
        _mapTool.value = tool
    }

    fun onMapTapLocalCoord(xMeters: Double, yMeters: Double) {
        when (_mapTool.value) {
            MapEditorTool.ADD_WAYPOINT ->
                _editedWaypoints.update { it + LocalPoint3D(xMeters, yMeters, 50.0) }
            MapEditorTool.ADD_EXCLUSION ->
                _editedExclusions.update { it + LocalPoint3D(xMeters, yMeters, 0.0) }
            MapEditorTool.ADD_CONTINGENCY ->
                _editedContingencies.update { it + LocalPoint3D(xMeters, yMeters, 0.0) }
            MapEditorTool.INSPECT -> Unit
        }
    }

    fun clearLocalMapEdits() {
        _editedWaypoints.value = emptyList()
        _editedExclusions.value = emptyList()
        _editedContingencies.value = emptyList()
    }

    fun reconnectAndReconcile() {
        viewModelScope.launch { repository.reconcileWithGateway() }
    }

    fun setOperatingMode(mode: OperatingMode) {
        repository.setOperatingMode(mode)
    }

    fun saveOfflineDraft(
        title: String,
        jobType: JobType,
        workAreaLabel: String,
        payloadType: String,
        timingStartS: Int,
        timingEndS: Int,
        responsibleOperator: String,
        operatingConditions: String,
    ) {
        viewModelScope.launch {
            repository.saveOfflineDraft(
                title = title,
                jobType = jobType,
                workAreaLabel = workAreaLabel,
                payloadType = payloadType,
                timingStartS = timingStartS,
                timingEndS = timingEndS,
                responsibleOperator = responsibleOperator,
                operatingConditions = operatingConditions,
            )
        }
    }

    fun deleteDraft(draftId: String) {
        viewModelScope.launch { repository.deleteDraft(draftId) }
    }

    fun submitDraft(draftId: String) {
        val draft = drafts.value.firstOrNull { it.draftId == draftId } ?: return
        viewModelScope.launch { repository.submitDraftToGateway(draft) }
    }

    fun createJobOnline(payload: CreateJobPayload) {
        viewModelScope.launch { repository.createJobOnline(payload) }
    }

    fun requestAllocationProposal(resolveConflicts: Boolean) {
        viewModelScope.launch { repository.requestAllocationProposal(resolveConflicts) }
    }

    fun requestValidation() {
        viewModelScope.launch { repository.requestValidation() }
    }

    fun approveCurrentMissionVersion() {
        val v = uiState.value.repoData.mission.missionVersion
        viewModelScope.launch { repository.approveMissionVersion(v) }
    }

    fun requestDispatch() {
        val affected = uiState.value.repoData.mission.allocations.map { it.aircraftId }.distinct()
        viewModelScope.launch { repository.submitCommand("DISPATCH", affected, isDispatch = true) }
    }

    fun requestPause() {
        val affected = uiState.value.repoData.mission.allocations.map { it.aircraftId }.distinct()
        viewModelScope.launch { repository.submitCommand("PAUSE", affected, isDispatch = false) }
    }

    fun requestCoordinationAbort() {
        val affected = uiState.value.repoData.mission.allocations.map { it.aircraftId }.distinct()
        viewModelScope.launch { repository.submitCommand("COORDINATION_ABORT", affected, isDispatch = false) }
    }

    fun requestAircraftContingency(aircraftId: String, contingencyAction: String) {
        viewModelScope.launch {
            repository.submitCommand(contingencyAction, listOf(aircraftId), isDispatch = false)
        }
    }

    fun queryCommandStatus(requestId: String) {
        viewModelScope.launch {
            _queriedCommand.value = repository.queryCommandStatus(requestId)
        }
    }

    fun acquireOrRenewLease() {
        viewModelScope.launch { repository.acquireOrRenewControlLease() }
    }

    fun requestHandover(toOperator: String) {
        viewModelScope.launch { repository.requestOrAcceptHandover("REQUEST", toOperator) }
    }

    fun acceptHandover() {
        val op = uiState.value.preferences.operatorId
        viewModelScope.launch { repository.requestOrAcceptHandover("ACCEPT", op) }
    }

    fun acknowledgeException(exceptionId: String) {
        viewModelScope.launch { repository.handleExceptionAction(exceptionId, "ACKNOWLEDGE") }
    }

    fun resolveException(exceptionId: String, action: String, note: String) {
        viewModelScope.launch { repository.handleExceptionAction(exceptionId, "RESOLVE", action, note) }
    }

    fun triggerDelayedTelemetrySim() {
        viewModelScope.launch { repository.triggerSimDelayedTelemetry() }
    }

    fun triggerWithdrawSpit04() {
        viewModelScope.launch { repository.triggerSimWithdrawAircraft("SPIT-04") }
    }

    fun triggerMissingImageryFollowup() {
        viewModelScope.launch { repository.triggerSimMissingImageryFollowup() }
    }

    fun exportMissionReport() {
        repository.exportMissionReport()
    }

    fun toggleReplayPlayPause() {
        _replayState.update { it.copy(isPlaying = !it.isPlaying) }
    }

    fun setReplaySpeed(speed: Float) {
        _replayState.update { it.copy(speedMultiplier = speed) }
    }

    fun seekReplay(timeS: Float) {
        savedStateHandle[KEY_REPLAY_TIME] = timeS
        _replayState.update { it.copy(currentTimeS = timeS) }
    }

    fun setReplayAircraftFilter(aircraftId: String?) {
        _replayState.update { it.copy(aircraftFilterId = aircraftId) }
    }

    fun updateGatewayUrl(url: String) {
        viewModelScope.launch { repository.preferencesRepository.updateGatewayUrl(url) }
    }

    fun updateOperatorIdentity(operatorId: String, deviceId: String) {
        viewModelScope.launch { repository.preferencesRepository.updateOperatorIdentity(operatorId, deviceId) }
    }

    fun setConnectedAircraftEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.preferencesRepository.setConnectedAircraftEnabled(enabled) }
    }

    fun setShowUncertaintyRings(show: Boolean) {
        viewModelScope.launch { repository.preferencesRepository.setShowUncertaintyRings(show) }
    }

    fun saveGatewayToken(token: String) {
        repository.credentialStore.saveGatewayToken(token)
        _hasStoredToken.value = repository.credentialStore.hasToken()
    }

    fun dismissBanner() {
        repository.clearBannerOrError()
    }

    companion object {
        private const val KEY_DESTINATION = "dest"
        private const val KEY_SELECTED_AIRCRAFT = "ac_id"
        private const val KEY_SELECTED_TASK = "task_id"
        private const val KEY_REPLAY_TIME = "replay_t"

        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as SpitfireApp
                SpitfireViewModel(
                    repository = app.repository,
                    savedStateHandle = createSavedStateHandle(),
                )
            }
        }
    }
}
