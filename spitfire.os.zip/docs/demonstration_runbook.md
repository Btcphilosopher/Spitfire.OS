# Pennine Solar & Farm Survey — 16-Step Demonstration Runbook

1. **Fleet Overview**: Open **Overview** or **Fleet** to inspect `SPIT-01`..`SPIT-06`, observing `SPIT-05` low battery reserve (`36%`, on charger) and `SPIT-06` maintenance lock (`PROP_HUB_TORQUE_CHECK_DUE`).
2. **Create Survey Job**: Open **Jobs**, select template or custom parameters (e.g., Roof Inspection or Stockpile Mapping), and submit.
3. **Request Task Allocation**: Open **Missions** and inspect the initial Python allocation proposal (`v1`).
4. **Inspect Launch-Time Conflict**: Review `CONF-001` (`PAD-NORTH` 6s separation violation between `SPIT-01` and `SPIT-02`) on both map and timeline.
5. **Review Corrected Plan**: Trigger **Recalculate (Resolve Conflicts)** to receive `v2` (`VALIDATED_CLEAN`).
6. **Check Clock Uncertainty & Readiness**: Open **Synchronisation** to inspect `plan_version`, `coordinator_epoch`, `boot_id`, clock offset, uncertainty bounds, and readiness pipeline.
7. **Approve & Dispatch**: Approve `v2`, then issue **Request Dispatch** (`request_id`, lease, epoch bound) and verify `ACKNOWLEDGED_BY_AIRCRAFT`.
8. **Monitor Aircraft & Progress**: Watch live tracks, bounded predicted positions, and telemetry freshness age in real time.
9. **Inject Delayed Telemetry**: Trigger **Inject Delayed Telemetry** (`SPIT-02`) to observe telemetry age inflation, expired readiness, and `STALE_POSITION` exception.
10. **Withdraw Aircraft**: Withdraw `SPIT-04` and observe Python automatic reassignment of unfinished work.
11. **Review Reassignment**: Verify `mission_version` bumped and previous approval invalidated.
12. **Approve Revised Plan**: Re-approve revised version.
13. **Review Missing Imagery**: Open **Data** to inspect 18 missing thermal frames (`12.9%` gap) distinctly from commanded capture frames.
14. **Create Follow-Up Job**: Generate the linked follow-up capture job (`parent_job_id = JOB-SOLAR-N`).
15. **Replay Mission**: Open **Replay** (`REPLAY — CONTROLS DISABLED`), scrub timeline, switch speed, filter aircraft, and inspect the explicit `[42.0s–47.0s]` telemetry gap.
16. **Export Report**: Trigger **Export Report** (WorkManager `ReportExportWorker`) and verify downloaded report persistence in Room.
