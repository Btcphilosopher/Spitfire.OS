# SPITFIRE.OS Backend Contract & Setup

## Running the Python Coordination Gateway
```bash
python3 -m pip install -r python_gateway/requirements.txt
bash scripts/run_gateway.sh
```
Default Android Emulator gateway endpoint: `http://10.0.2.2:8000` (WebSocket: `ws://10.0.2.2:8000/v1/events`).

## Key Contract Invariants
1. **Optimistic Concurrency & Version-Bound Approvals**: Approvals bind to `mission_version`. Editing jobs, allocations, or aircraft assignments increments `mission_version` and invalidates prior approvals (`409` on stale approval).
2. **Idempotent Commands**: Dispatch, pause, coordination abort, and airframe-supported contingencies supply a client-generated `request_id`. Timeouts never auto-retry execution; the tablet queries `GET /v1/commands/{request_id}`.
3. **Readiness != Network ACK**: `readiness_acked` expires when `readiness_expires_at_ms` passes, telemetry ages past `2500ms`, or `boot_id` / `coordinator_epoch` changes.
4. **Control Ownership**: Single-tablet control via expiring `ControlLease` and explicit `REQUEST` / `ACCEPT` handover.
5. **Pre-Flight Real Operations Notice**: Before proposing any real flights, verify the intended UK CAA / local jurisdiction, operating permissions (PDRA / Operational Authorisation), aircraft airworthiness capabilities, and operator responsibilities through current official sources.
