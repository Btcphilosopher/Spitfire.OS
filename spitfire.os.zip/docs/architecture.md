# SPITFIRE.OS Architecture

## Authoritative Separation of Concerns
- **Authoritative Coordination Core (`python_sync_core/spitfire_sync`)**: Owns task allocation, energy-reserve budgeting, spatial/temporal conflict detection, clock-offset/uncertainty bounds, readiness expiry, control-lease validation, command FSM, and deterministic 6-drone Pennine simulation.
- **Thin Gateway (`python_gateway/main.py`)**: FastAPI REST & WebSocket adapter exposing `/v1/*` and `WS /v1/events`.
- **Android Operator Frontend (`app/`)**:
  - `core/model`: `@Serializable` immutable data models mirroring `contracts/openapi.yaml`.
  - `core/network`: Ktor Client (`OkHttp` engine) with REST + WebSocket streaming, sequence gap detection, deduplication, and bounded update batching.
  - `core/database`: Room database with explicit `Migration(1, 2)` storing mission caches, editable offline drafts (separate from authoritative missions), aircraft documentation, downloaded reports, and replay sessions.
  - `core/datastore`: DataStore preferences + Android Keystore AES-GCM encrypted credential/token storage.
  - `core/work`: WorkManager `ReportExportWorker` & `CacheRefreshWorker` for non-control background tasks only.
  - `core/designsystem`: British aerospace theme (`MidnightNavy`, `GraphitePanel`, `Ivory`, `TelemetryCyan`, `CautionAmber`, `CriticalRed`), local Google Fonts (`Space Grotesk`, `IBM Plex Sans`, `JetBrains Mono`), and restrained wing geometry.
  - `feature/*`: Modular feature screens for Overview (adaptive 3-panel workspace), Fleet, Jobs, Planning/Map, Synchronisation, Monitoring, Exceptions, Payloads/Maintenance/Data, Replay, and Settings.

## Operating Modes & Safety Gates
- `SIMULATION`: Default mode connected to the Python simulator.
- `REPLAY`: Strictly isolated playback (`REPLAY — CONTROLS DISABLED`) with zero network command egress.
- `CONNECTED AIRCRAFT`: Disabled by default behind backend capability gate (`connected_aircraft_enabled = false`) and explicit settings toggle.
