#!/usr/bin/env bash
set -euo pipefail
export PYTHONPATH="$(pwd)/python_sync_core:${PYTHONPATH:-}"
uvicorn python_gateway.main:app --host 0.0.0.0 --port 8000 --reload
