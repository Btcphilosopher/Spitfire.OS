#!/usr/bin/env bash
set -euo pipefail
python3 -m unittest discover -s python_sync_core/tests -v
