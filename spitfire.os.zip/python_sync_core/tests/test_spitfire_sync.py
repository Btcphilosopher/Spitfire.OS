"""Unit tests for the authoritative Python spitfire_sync coordination core."""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from spitfire_sync import (
    CommandState,
    ControlLeaseStatus,
    CoordinatorEngine,
    ExceptionStatus,
    MissionStatus,
    SyncStage,
    evaluate_sync_state,
)


class SpitfireSyncCoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.engine = CoordinatorEngine()

    def test_initial_pennine_has_six_aircraft_and_launch_conflict(self) -> None:
        self.assertEqual(len(self.engine.fleet), 6)
        categories = {c.category for c in self.engine.mission.conflicts}
        self.assertIn("LAUNCH_SLOT_CONFLICT", categories)
        self.assertEqual(
            self.engine.mission.status, MissionStatus.VALIDATED_WITH_CONFLICTS
        )

    def test_recalculation_resolves_conflict_and_allows_approval_and_dispatch(self) -> None:
        mission = self.engine.propose_allocation(resolve_conflicts=True)
        self.assertEqual(mission.status, MissionStatus.VALIDATED_CLEAN)
        self.assertEqual(mission.mission_version, 2)

        ok, msg, mission = self.engine.approve_mission(2, "Op. A. Vance")
        self.assertTrue(ok, msg)
        self.assertEqual(mission.status, MissionStatus.APPROVED)

        cmd = self.engine.submit_command(
            request_id="REQ-DISP-001",
            mission_version=2,
            coordinator_epoch=mission.coordinator_epoch,
            control_lease_id=mission.control_lease.lease_id,
            command_type="DISPATCH",
            affected_aircraft=["SPIT-01", "SPIT-02"],
            expiry_ms=mission.control_lease.expires_at_ms,
            operator_id="Op. A. Vance",
        )
        self.assertEqual(cmd.state, CommandState.ACKNOWLEDGED_BY_AIRCRAFT)

        # Idempotent re-query with same request_id returns identical command
        cmd_dup = self.engine.submit_command(
            request_id="REQ-DISP-001",
            mission_version=2,
            coordinator_epoch=mission.coordinator_epoch,
            control_lease_id=mission.control_lease.lease_id,
            command_type="DISPATCH",
            affected_aircraft=["SPIT-01", "SPIT-02"],
            expiry_ms=mission.control_lease.expires_at_ms,
            operator_id="Op. A. Vance",
        )
        self.assertEqual(cmd.request_id, cmd_dup.request_id)
        self.assertEqual(len(self.engine.mission.commands), 1)

    def test_maintenance_locked_aircraft_command_rejected(self) -> None:
        self.engine.propose_allocation(resolve_conflicts=True)
        self.engine.approve_mission(self.engine.mission.mission_version, "Op. A. Vance")
        cmd = self.engine.submit_command(
            request_id="REQ-MAINT-REJECT",
            mission_version=self.engine.mission.mission_version,
            coordinator_epoch=self.engine.mission.coordinator_epoch,
            control_lease_id=self.engine.mission.control_lease.lease_id,
            command_type="DISPATCH",
            affected_aircraft=["SPIT-06"],
            expiry_ms=self.engine.mission.control_lease.expires_at_ms,
            operator_id="Op. A. Vance",
        )
        self.assertEqual(cmd.state, CommandState.REJECTED)
        self.assertEqual(cmd.reason_code, "MAINTENANCE_RESTRICTION")

    def test_withdrawn_aircraft_reassigns_and_invalidates_approval(self) -> None:
        self.engine.propose_allocation(resolve_conflicts=True)
        self.engine.approve_mission(self.engine.mission.mission_version, "Op. A. Vance")
        v_before = self.engine.mission.mission_version

        mission = self.engine.withdraw_aircraft_and_reassign("SPIT-04")
        self.assertEqual(mission.mission_version, v_before + 1)
        self.assertFalse(mission.approval.valid)
        self.assertTrue(all(a.aircraft_id != "SPIT-04" for a in mission.allocations))

    def test_expired_readiness_downgrades_sync_stage(self) -> None:
        self.engine.propose_allocation(resolve_conflicts=True)
        self.engine.approve_mission(self.engine.mission.mission_version, "Op. A. Vance")
        ac = self.engine.fleet[0]
        sync = self.engine.mission.sync_states[0]
        expired_eval = evaluate_sync_state(
            sync,
            ac,
            now_ms=sync.readiness_expires_at_ms + 5000,
            plan_version=self.engine.mission.mission_version,
            coordinator_epoch=self.engine.mission.coordinator_epoch,
        )
        self.assertFalse(expired_eval.readiness_acked)
        self.assertEqual(expired_eval.stage, SyncStage.AIRCRAFT_VALIDATION)
        self.assertIn("READINESS_EVIDENCE_EXPIRED", expired_eval.tolerance_exceeded_reason or "")

    def test_exception_ack_distinct_from_resolution(self) -> None:
        exc = self.engine.acknowledge_exception("EXC-001", "Op. A. Vance")
        self.assertIsNotNone(exc)
        self.assertEqual(exc.status, ExceptionStatus.ACKNOWLEDGED)
        exc_res = self.engine.resolve_exception(
            "EXC-001", "Op. A. Vance", "KEEP_ON_CHARGER", "Charged to 85%."
        )
        self.assertEqual(exc_res.status, ExceptionStatus.RESOLVED)
        self.assertEqual(len(exc_res.resolution_history), 2)

    def test_replay_contains_explicit_gap_window(self) -> None:
        replay = self.engine.replay_sessions["RPL-PENNINE-001"]
        self.assertEqual(len(replay.gap_windows), 1)
        self.assertEqual(replay.gap_windows[0].start_s, 42.0)
        self.assertEqual(replay.gap_windows[0].end_s, 47.0)


if __name__ == "__main__":
    unittest.main()
