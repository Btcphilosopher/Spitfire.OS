"""Authoritative command lifecycle state machine, lease verification, and idempotency."""

from __future__ import annotations

from dataclasses import replace

from .models import (
    CommandRecord,
    CommandState,
    ControlLease,
    ControlLeaseStatus,
    MissionRecord,
    MissionStatus,
)


def validate_and_submit_command(
    mission: MissionRecord,
    fleet_map: dict,
    request_id: str,
    mission_version: int,
    coordinator_epoch: int,
    control_lease_id: str,
    command_type: str,
    affected_aircraft: list[str],
    expiry_ms: int,
    operator_id: str,
    now_ms: int,
) -> tuple[CommandRecord, MissionRecord]:
    # Idempotency: return existing command status on duplicate request_id
    for existing in mission.commands:
        if existing.request_id == request_id:
            return existing, mission

    def make_rejected(reason_code: str, detail: str) -> CommandRecord:
        return CommandRecord(
            request_id=request_id,
            mission_id=mission.mission_id,
            mission_version=mission_version,
            coordinator_epoch=coordinator_epoch,
            control_lease_id=control_lease_id,
            command_type=command_type,
            affected_aircraft=affected_aircraft,
            expiry_ms=expiry_ms,
            state=CommandState.REJECTED,
            reason_code=reason_code,
            detail=detail,
            created_at_ms=now_ms,
            updated_at_ms=now_ms,
        )

    # 1. Check expiry
    if now_ms > expiry_ms:
        cmd = CommandRecord(
            request_id=request_id,
            mission_id=mission.mission_id,
            mission_version=mission_version,
            coordinator_epoch=coordinator_epoch,
            control_lease_id=control_lease_id,
            command_type=command_type,
            affected_aircraft=affected_aircraft,
            expiry_ms=expiry_ms,
            state=CommandState.EXPIRED,
            reason_code="COMMAND_EXPIRED_BEFORE_COORDINATOR",
            detail="Request expiry elapsed before coordinator acceptance.",
            created_at_ms=now_ms,
            updated_at_ms=now_ms,
        )
        mission.commands.append(cmd)
        return cmd, mission

    # 2. Check control lease
    lease = mission.control_lease
    if (
        lease.lease_id != control_lease_id
        or lease.owner_operator_id != operator_id
        or lease.status == ControlLeaseStatus.OBSERVER_ONLY
        or now_ms > lease.expires_at_ms
    ):
        cmd = make_rejected(
            "CONTROL_LEASE_INVALID",
            "Active control lease required; tablet is observer-only or lease expired.",
        )
        mission.commands.append(cmd)
        return cmd, mission

    # 3. Check mission version & coordinator epoch
    if mission_version != mission.mission_version:
        cmd = make_rejected(
            "MISSION_VERSION_CONFLICT",
            f"Submitted version v{mission_version} != authoritative v{mission.mission_version}.",
        )
        mission.commands.append(cmd)
        return cmd, mission

    if coordinator_epoch != mission.coordinator_epoch:
        cmd = make_rejected(
            "COORDINATOR_EPOCH_STALE",
            f"Submitted epoch {coordinator_epoch} != current epoch {mission.coordinator_epoch}.",
        )
        mission.commands.append(cmd)
        return cmd, mission

    # 4. Dispatch requires valid approval & no unresolved critical conflicts
    if command_type == "DISPATCH":
        if mission.approval is None or not mission.approval.valid or mission.approval.mission_version != mission.mission_version:
            cmd = make_rejected(
                "APPROVAL_REQUIRED_FOR_VERSION",
                f"Plan v{mission.mission_version} has no valid operator approval.",
            )
            mission.commands.append(cmd)
            return cmd, mission
        critical = [c for c in mission.conflicts if c.severity == "CRITICAL"]
        if critical:
            cmd = make_rejected(
                "CRITICAL_CONFLICTS_UNRESOLVED",
                f"{len(critical)} critical conflict(s) block dispatch: {critical[0].category}.",
            )
            mission.commands.append(cmd)
            return cmd, mission

    # 5. Aircraft maintenance / withdrawal / link checks
    for ac_id in affected_aircraft:
        ac = fleet_map.get(ac_id)
        if ac is None:
            cmd = make_rejected("UNKNOWN_AIRCRAFT", f"Aircraft {ac_id} not in fleet registry.")
            mission.commands.append(cmd)
            return cmd, mission
        if ac.maintenance_blocking_reason:
            cmd = make_rejected(
                "MAINTENANCE_RESTRICTION",
                f"{ac_id} blocked by maintenance: {ac.maintenance_blocking_reason}.",
            )
            mission.commands.append(cmd)
            return cmd, mission
        if ac.withdrawn and command_type == "DISPATCH":
            cmd = make_rejected(
                "AIRCRAFT_WITHDRAWN",
                f"{ac_id} is withdrawn from active tasking.",
            )
            mission.commands.append(cmd)
            return cmd, mission
        if ac.link_status == "LOST" and command_type not in ("COORDINATION_ABORT",):
            cmd = CommandRecord(
                request_id=request_id,
                mission_id=mission.mission_id,
                mission_version=mission_version,
                coordinator_epoch=coordinator_epoch,
                control_lease_id=control_lease_id,
                command_type=command_type,
                affected_aircraft=affected_aircraft,
                expiry_ms=expiry_ms,
                state=CommandState.OUTCOME_UNKNOWN,
                reason_code="LINK_LOST_DURING_DISPATCH",
                detail=f"{ac_id} coordination link lost after coordinator submission; outcome unknown until link recovery.",
                created_at_ms=now_ms,
                updated_at_ms=now_ms,
            )
            mission.commands.append(cmd)
            return cmd, mission

    # 6. Accepted -> Sent to adapter -> Acknowledged by aircraft -> Observed effect (in sim)
    cmd = CommandRecord(
        request_id=request_id,
        mission_id=mission.mission_id,
        mission_version=mission_version,
        coordinator_epoch=coordinator_epoch,
        control_lease_id=control_lease_id,
        command_type=command_type,
        affected_aircraft=affected_aircraft,
        expiry_ms=expiry_ms,
        state=CommandState.ACKNOWLEDGED_BY_AIRCRAFT,
        reason_code=None,
        detail=f"{command_type} acknowledged by simulated aircraft adapter for v{mission_version}.",
        created_at_ms=now_ms,
        updated_at_ms=now_ms,
        ack_at_ms=now_ms,
        effect_at_ms=None,
    )
    mission.commands.append(cmd)

    if command_type == "DISPATCH":
        mission.status = MissionStatus.IN_FLIGHT
        for alloc in mission.allocations:
            alloc.approved_trajectory = list(alloc.proposed_route)
    elif command_type == "PAUSE":
        mission.status = MissionStatus.PAUSED
    elif command_type == "COORDINATION_ABORT":
        mission.status = MissionStatus.ABORTED

    return cmd, mission


def refresh_lease(
    lease: ControlLease,
    operator_id: str,
    device_id: str,
    coordinator_epoch: int,
    now_ms: int,
    ttl_ms: int = 120_000,
) -> ControlLease:
    if lease.status == ControlLeaseStatus.EXPIRED or lease.owner_operator_id == operator_id:
        return replace(
            lease,
            owner_operator_id=operator_id,
            owner_device_id=device_id,
            coordinator_epoch=coordinator_epoch,
            expires_at_ms=now_ms + ttl_ms,
            status=ControlLeaseStatus.HELD,
            pending_handover_operator_id=None,
        )
    return lease
