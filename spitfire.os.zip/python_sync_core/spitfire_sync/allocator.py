"""Authoritative task allocator and aircraft-withdrawal reassignment solver."""

from __future__ import annotations

from dataclasses import replace

from .models import AircraftRecord, LocalPoint3D, SurveyJob, TaskAllocationItem

ENERGY_PER_MIN_WH = 18.5
NOMINAL_PACK_WH = 240.0


def _build_lawnmower_route(
    polygon: list[LocalPoint3D],
    alt_m: float,
    launch_pt: LocalPoint3D,
    recovery_pt: LocalPoint3D,
    lane_index: int = 0,
) -> list[LocalPoint3D]:
    if not polygon:
        return [
            launch_pt,
            LocalPoint3D(launch_pt.x_m + 60.0 + lane_index * 35.0, launch_pt.y_m + 90.0, alt_m),
            LocalPoint3D(launch_pt.x_m + 120.0 + lane_index * 35.0, launch_pt.y_m + 90.0, alt_m),
            recovery_pt,
        ]
    xs = [p.x_m for p in polygon]
    ys = [p.y_m for p in polygon]
    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)
    mid_y = (min_y + max_y) / 2.0
    return [
        launch_pt,
        LocalPoint3D(min_x + 15.0, min_y + 15.0, alt_m),
        LocalPoint3D(max_x - 15.0, min_y + 15.0, alt_m),
        LocalPoint3D(max_x - 15.0, mid_y, alt_m),
        LocalPoint3D(min_x + 15.0, mid_y, alt_m),
        LocalPoint3D(min_x + 15.0, max_y - 15.0, alt_m),
        LocalPoint3D(max_x - 15.0, max_y - 15.0, alt_m),
        recovery_pt,
    ]


def propose_allocations(
    jobs: list[SurveyJob],
    fleet: list[AircraftRecord],
    introduce_launch_conflict: bool = False,
    resolve_conflicts: bool = True,
) -> list[TaskAllocationItem]:
    eligible = [
        ac for ac in fleet if not ac.withdrawn and ac.maintenance_blocking_reason is None
    ]
    allocations: list[TaskAllocationItem] = []

    pad_north = LocalPoint3D(80.0, 60.0, 0.0, "AGL_SITE_DATUM")
    pad_south = LocalPoint3D(340.0, 65.0, 0.0, "AGL_SITE_DATUM")

    for idx, job in enumerate(jobs):
        matching = [
            ac
            for ac in eligible
            if job.payload_type in ac.supported_payloads and ac.battery_soc_pct >= 55.0
        ]
        if not matching:
            matching = eligible[:1]
        if not matching:
            continue

        ac = matching[idx % len(matching)]
        duration_s = 240 + (idx % 3) * 45
        energy_wh = round((duration_s / 60.0) * ENERGY_PER_MIN_WH, 1)
        reserve_pct = round(
            max(0.0, ac.battery_soc_pct - (energy_wh / NOMINAL_PACK_WH) * 100.0), 1
        )
        use_north = idx % 2 == 0
        launch_id = "PAD-NORTH" if use_north else "PAD-SOUTH"
        recovery_id = "REC-NORTH" if use_north else "REC-SOUTH"
        launch_pt = pad_north if use_north else pad_south

        if introduce_launch_conflict and idx in (0, 1):
            # Deliberately schedule first two tasks on PAD-NORTH 6s apart for conflict demo
            launch_id = "PAD-NORTH"
            launch_pt = pad_north
            launch_slot = job.timing_window_start_s + (idx * 6)
        elif resolve_conflicts:
            launch_slot = job.timing_window_start_s + (idx * 25)
        else:
            launch_slot = job.timing_window_start_s + (idx * 10)

        recovery_slot = launch_slot + duration_s
        alt_m = 45.0 + (idx * 10.0)
        route = _build_lawnmower_route(
            job.work_area_polygon, alt_m, launch_pt, launch_pt, lane_index=idx
        )
        constraints: list[str] = []
        if reserve_pct < ac.configured_min_reserve_pct:
            constraints.append(
                f"LOW_RESERVE:{reserve_pct:.1f}% < {ac.configured_min_reserve_pct:.0f}%"
            )

        allocations.append(
            TaskAllocationItem(
                task_id=f"TASK-{idx + 1:03d}",
                job_id=job.job_id,
                aircraft_id=ac.aircraft_id,
                payload_id=job.payload_type,
                area_label=job.work_area_label,
                proposed_route=route,
                approved_trajectory=[],
                observed_track=[],
                bounded_predicted_position=None,
                estimated_duration_s=duration_s,
                estimated_energy_wh=energy_wh,
                battery_reserve_pct=reserve_pct,
                launch_site_id=launch_id,
                launch_slot_s=launch_slot,
                recovery_site_id=recovery_id,
                recovery_slot_s=recovery_slot,
                unresolved_constraints=constraints,
            )
        )
    return allocations


def reassign_withdrawn_aircraft(
    allocations: list[TaskAllocationItem],
    fleet: list[AircraftRecord],
    withdrawn_aircraft_id: str,
) -> list[TaskAllocationItem]:
    healthy = [
        ac
        for ac in fleet
        if ac.aircraft_id != withdrawn_aircraft_id
        and not ac.withdrawn
        and ac.maintenance_blocking_reason is None
        and ac.battery_soc_pct >= 55.0
    ]
    if not healthy:
        return allocations

    updated: list[TaskAllocationItem] = []
    max_recovery_end = max((a.recovery_slot_s for a in allocations), default=120)
    reassigned_offset = 0

    for alloc in allocations:
        if alloc.aircraft_id == withdrawn_aircraft_id and not alloc.completed:
            replacement = next(
                (ac for ac in healthy if alloc.payload_id in ac.supported_payloads),
                healthy[0],
            )
            new_launch = max_recovery_end + 25 + (reassigned_offset * 25)
            new_recovery = new_launch + alloc.estimated_duration_s
            reassigned_offset += 1
            updated.append(
                replace(
                    alloc,
                    aircraft_id=replacement.aircraft_id,
                    launch_slot_s=new_launch,
                    recovery_slot_s=new_recovery,
                    approved_trajectory=[],
                    unresolved_constraints=[
                        f"REASSIGNED_FROM_{withdrawn_aircraft_id}_REQUIRES_APPROVAL"
                    ],
                )
            )
        else:
            updated.append(alloc)
    return updated
