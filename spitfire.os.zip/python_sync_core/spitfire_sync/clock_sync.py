"""Authoritative clock-offset estimation, readiness expiry, and tolerance checking."""

from __future__ import annotations

from dataclasses import replace

from .models import AircraftRecord, AircraftSyncState, SyncStage

MAX_CLOCK_UNCERTAINTY_MS = 35.0
MAX_TELEMETRY_AGE_MS = 2500
MAX_START_DEVIATION_S = 2.0
READINESS_TTL_MS = 30_000


def evaluate_sync_state(
    existing: AircraftSyncState,
    aircraft: AircraftRecord,
    now_ms: int,
    plan_version: int,
    coordinator_epoch: int,
) -> AircraftSyncState:
    telemetry_age_ms = max(0, now_ms - aircraft.position_observed_at_ms)

    # Uncertainty inflates conservatively with telemetry staleness (drift bound ~2 ms/s).
    effective_uncertainty_ms = round(
        existing.clock_uncertainty_ms + (telemetry_age_ms / 1000.0) * 1.8, 2
    )

    # Readiness expires strictly when underlying evidence expires or epoch/version/boot changes.
    evidence_valid = (
        existing.readiness_acked
        and now_ms <= existing.readiness_expires_at_ms
        and existing.plan_version == plan_version
        and existing.coordinator_epoch == coordinator_epoch
        and existing.boot_id == aircraft.boot_id
        and not aircraft.withdrawn
        and aircraft.maintenance_blocking_reason is None
    )

    tolerance_reasons: list[str] = []
    available_actions: list[str] = []

    if aircraft.withdrawn:
        tolerance_reasons.append("AIRCRAFT_WITHDRAWN")
        available_actions.append("REASSIGN_WORK")
    if aircraft.maintenance_blocking_reason:
        tolerance_reasons.append(f"MAINTENANCE_LOCK:{aircraft.maintenance_blocking_reason}")
        available_actions.append("CLEAR_OR_REASSIGN")
    if effective_uncertainty_ms > MAX_CLOCK_UNCERTAINTY_MS:
        tolerance_reasons.append(
            f"CLOCK_UNCERTAINTY_EXCEEDED ({effective_uncertainty_ms:.1f}ms > {MAX_CLOCK_UNCERTAINTY_MS:.1f}ms)"
        )
        available_actions.extend(["RESYNC_CLOCK", "RESCHEDULE_SLOT"])
    if telemetry_age_ms > MAX_TELEMETRY_AGE_MS:
        tolerance_reasons.append(
            f"TELEMETRY_STALE ({telemetry_age_ms}ms > {MAX_TELEMETRY_AGE_MS}ms)"
        )
        available_actions.extend(["REFRESH_TELEMETRY", "HOLD_OR_RESCHEDULE"])
    if existing.readiness_acked and now_ms > existing.readiness_expires_at_ms:
        tolerance_reasons.append("READINESS_EVIDENCE_EXPIRED")
        available_actions.append("REVALIDATE_AIRCRAFT")
    if (
        existing.start_deviation_s is not None
        and abs(existing.start_deviation_s) > MAX_START_DEVIATION_S
    ):
        tolerance_reasons.append(
            f"START_DEVIATION_EXCEEDED ({existing.start_deviation_s:+.2f}s)"
        )
        available_actions.extend(["RESCHEDULE_SLOT", "CANCEL_TASK"])

    stage = existing.stage
    if not evidence_valid and stage in (
        SyncStage.READINESS_ACKNOWLEDGED,
        SyncStage.COMMITTED_SCHEDULE,
    ):
        stage = SyncStage.AIRCRAFT_VALIDATION

    return replace(
        existing,
        plan_version=plan_version,
        coordinator_epoch=coordinator_epoch,
        boot_id=aircraft.boot_id,
        clock_uncertainty_ms=effective_uncertainty_ms,
        telemetry_age_ms=telemetry_age_ms,
        readiness_acked=evidence_valid,
        stage=stage,
        tolerance_exceeded_reason="; ".join(tolerance_reasons) if tolerance_reasons else None,
        available_actions=sorted(set(available_actions)),
    )


def issue_readiness_acknowledgement(
    sync_state: AircraftSyncState,
    aircraft: AircraftRecord,
    now_ms: int,
    plan_version: int,
    coordinator_epoch: int,
) -> AircraftSyncState:
    if aircraft.withdrawn or aircraft.maintenance_blocking_reason:
        return replace(
            sync_state,
            readiness_acked=False,
            stage=SyncStage.PLAN_PROPOSED,
            tolerance_exceeded_reason="AIRCRAFT_INELIGIBLE_FOR_READINESS",
            available_actions=["REASSIGN_WORK"],
        )
    return replace(
        sync_state,
        plan_version=plan_version,
        coordinator_epoch=coordinator_epoch,
        boot_id=aircraft.boot_id,
        readiness_acked=True,
        readiness_expires_at_ms=now_ms + READINESS_TTL_MS,
        task_lease_status="READY_BOUND_TO_V" + str(plan_version),
        stage=SyncStage.READINESS_ACKNOWLEDGED,
        tolerance_exceeded_reason=None,
        available_actions=[],
    )
