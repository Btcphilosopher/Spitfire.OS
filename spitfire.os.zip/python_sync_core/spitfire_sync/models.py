"""Authoritative domain models and enums for SPITFIRE.OS coordination core."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any


class OperatingMode(str, Enum):
    SIMULATION = "SIMULATION"
    REPLAY = "REPLAY"
    CONNECTED_AIRCRAFT = "CONNECTED_AIRCRAFT"


class JobType(str, Enum):
    AGRICULTURAL_INSPECTION = "AGRICULTURAL_INSPECTION"
    SOLAR_FARM_SURVEY = "SOLAR_FARM_SURVEY"
    ROOF_INSPECTION = "ROOF_INSPECTION"
    STOCKPILE_MAPPING = "STOCKPILE_MAPPING"
    AUTHORISED_DELIVERY = "AUTHORISED_DELIVERY"


class MissionStatus(str, Enum):
    DRAFT = "DRAFT"
    VALIDATED_WITH_CONFLICTS = "VALIDATED_WITH_CONFLICTS"
    VALIDATED_CLEAN = "VALIDATED_CLEAN"
    APPROVED = "APPROVED"
    DISPATCHED = "DISPATCHED"
    IN_FLIGHT = "IN_FLIGHT"
    PAUSED = "PAUSED"
    COMPLETED = "COMPLETED"
    ABORTED = "ABORTED"


class SyncStage(str, Enum):
    PLAN_PROPOSED = "PLAN_PROPOSED"
    AIRCRAFT_VALIDATION = "AIRCRAFT_VALIDATION"
    READINESS_ACKNOWLEDGED = "READINESS_ACKNOWLEDGED"
    COMMITTED_SCHEDULE = "COMMITTED_SCHEDULE"
    EXECUTION_OBSERVED = "EXECUTION_OBSERVED"


class CommandState(str, Enum):
    DRAFT = "DRAFT"
    SUBMITTED = "SUBMITTED"
    ACCEPTED_BY_COORDINATOR = "ACCEPTED_BY_COORDINATOR"
    SENT_TO_ADAPTER = "SENT_TO_ADAPTER"
    ACKNOWLEDGED_BY_AIRCRAFT = "ACKNOWLEDGED_BY_AIRCRAFT"
    OBSERVED_EFFECT = "OBSERVED_EFFECT"
    REJECTED = "REJECTED"
    EXPIRED = "EXPIRED"
    OUTCOME_UNKNOWN = "OUTCOME_UNKNOWN"


class ExceptionCategory(str, Enum):
    STALE_POSITION = "STALE_POSITION"
    LOST_COORDINATION_LINK = "LOST_COORDINATION_LINK"
    CLOCK_UNCERTAINTY = "CLOCK_UNCERTAINTY"
    LOW_OBSERVED_BATTERY = "LOW_OBSERVED_BATTERY"
    ROUTE_DEVIATION = "ROUTE_DEVIATION"
    AIRCRAFT_UNAVAILABLE = "AIRCRAFT_UNAVAILABLE"
    COMMAND_REJECTION = "COMMAND_REJECTION"
    MISSING_IMAGERY = "MISSING_IMAGERY"
    PAYLOAD_UPLOAD_FAILURE = "PAYLOAD_UPLOAD_FAILURE"
    RECOVERY_AREA_CONFLICT = "RECOVERY_AREA_CONFLICT"


class ExceptionStatus(str, Enum):
    OPEN = "OPEN"
    ACKNOWLEDGED = "ACKNOWLEDGED"
    RESOLVED = "RESOLVED"


class ControlLeaseStatus(str, Enum):
    HELD = "HELD"
    HANDOVER_PENDING = "HANDOVER_PENDING"
    EXPIRED = "EXPIRED"
    OBSERVER_ONLY = "OBSERVER_ONLY"


@dataclass(frozen=True)
class LocalPoint3D:
    x_m: float
    y_m: float
    alt_m: float
    altitude_reference: str = "AGL_SITE_DATUM"


@dataclass
class AircraftRecord:
    aircraft_id: str
    callsign: str
    airframe: str
    autopilot_version: str
    supported_payloads: list[str]
    configured_max_speed_mps: float
    configured_max_wind_mps: float
    configured_min_reserve_pct: float
    battery_id: str
    battery_soc_pct: float
    battery_voltage_v: float
    battery_observed_at_ms: int
    charging_state: str
    maintenance_restrictions: list[str]
    maintenance_blocking_reason: str | None
    assigned_task_id: str | None
    observed_flight_mode: str
    link_status: str
    position: LocalPoint3D
    position_observed_at_ms: int
    position_uncertainty_m: float
    boot_id: str
    latest_command_outcome: str
    supported_contingencies: list[str]
    documentation_summary: str
    withdrawn: bool = False


@dataclass
class SurveyJob:
    job_id: str
    title: str
    job_type: JobType
    work_area_label: str
    work_area_polygon: list[LocalPoint3D]
    required_outputs: list[str]
    payload_type: str
    timing_window_start_s: int
    timing_window_end_s: int
    responsible_operator: str
    operating_conditions: str
    flight_completed: bool = False
    coverage_completed: bool = False
    data_accepted: bool = False
    parent_job_id: str | None = None


@dataclass
class NamedZone:
    zone_id: str
    label: str
    zone_type: str  # BOUNDARY | EXCLUSION | LAUNCH | RECOVERY | CONTINGENCY | WORK_AREA
    vertices: list[LocalPoint3D]


@dataclass
class MapSiteConfig:
    site_id: str
    name: str
    coordinate_reference: str
    altitude_reference: str
    terrain_source: str
    map_data_age_s: int
    position_uncertainty_m: float
    planning_assumptions: str
    zones: list[NamedZone]


@dataclass
class TaskAllocationItem:
    task_id: str
    job_id: str
    aircraft_id: str
    payload_id: str
    area_label: str
    proposed_route: list[LocalPoint3D]
    approved_trajectory: list[LocalPoint3D]
    observed_track: list[LocalPoint3D]
    bounded_predicted_position: LocalPoint3D | None
    estimated_duration_s: int
    estimated_energy_wh: float
    battery_reserve_pct: float
    launch_site_id: str
    launch_slot_s: int
    recovery_site_id: str
    recovery_slot_s: int
    unresolved_constraints: list[str] = field(default_factory=list)
    progress_pct: float = 0.0
    completed: bool = False


@dataclass
class ConflictFinding:
    conflict_id: str
    severity: str  # CRITICAL | CAUTION | INFO
    category: str
    description: str
    affected_aircraft: list[str]
    affected_tasks: list[str]
    location_x_m: float
    location_y_m: float
    time_window_start_s: int
    time_window_end_s: int
    spatial_buffer_m: float
    temporal_buffer_s: float
    modelled_scope_note: str


@dataclass
class AircraftSyncState:
    aircraft_id: str
    plan_version: int
    coordinator_epoch: int
    boot_id: str
    clock_offset_ms: float
    clock_uncertainty_ms: float
    telemetry_age_ms: int
    readiness_acked: bool
    readiness_expires_at_ms: int
    task_lease_status: str
    scheduled_start_s: int
    actual_observed_start_s: int | None
    start_deviation_s: float | None
    stage: SyncStage
    tolerance_exceeded_reason: str | None
    available_actions: list[str]


@dataclass
class ApprovalRecord:
    mission_version: int
    approved_by: str
    approved_at_ms: int
    valid: bool
    invalidation_reason: str | None = None


@dataclass
class ControlLease:
    lease_id: str
    mission_id: str
    owner_operator_id: str
    owner_device_id: str
    coordinator_epoch: int
    expires_at_ms: int
    status: ControlLeaseStatus
    pending_handover_operator_id: str | None = None


@dataclass
class CommandRecord:
    request_id: str
    mission_id: str
    mission_version: int
    coordinator_epoch: int
    control_lease_id: str
    command_type: str
    affected_aircraft: list[str]
    expiry_ms: int
    state: CommandState
    reason_code: str | None
    detail: str
    created_at_ms: int
    updated_at_ms: int
    ack_at_ms: int | None = None
    effect_at_ms: int | None = None


@dataclass
class ExceptionResolutionEntry:
    timestamp_ms: int
    operator_id: str
    action: str
    note: str


@dataclass
class MissionException:
    exception_id: str
    category: ExceptionCategory
    severity: str  # CRITICAL | CAUTION
    affected_aircraft: list[str]
    affected_tasks: list[str]
    source_observations: list[str]
    detected_at_ms: int
    status: ExceptionStatus
    proposed_responses: list[str]
    responsible_operator: str
    resolution_history: list[ExceptionResolutionEntry] = field(default_factory=list)


@dataclass
class PayloadDataRecord:
    record_id: str
    aircraft_id: str
    payload_id: str
    config_version: str
    capture_frames_commanded: int
    capture_frames_observed: int
    upload_progress_pct: float
    coverage_pct: float
    missing_data_findings: list[str]
    follow_up_job_id: str | None
    planned_application_rate: str | None = None
    observed_delivery_rate: str | None = None


@dataclass
class TelemetryEvent:
    event_id: str
    stream_sequence: int
    event_type: str
    observation_time_ms: int
    ingestion_time_ms: int
    mission_version: int
    payload: dict[str, Any]


@dataclass
class ReplayGapWindow:
    start_s: float
    end_s: float
    reason: str


@dataclass
class ReplaySession:
    replay_id: str
    mission_id: str
    title: str
    duration_s: float
    gap_windows: list[ReplayGapWindow]
    events: list[TelemetryEvent]


@dataclass
class MissionRecord:
    mission_id: str
    name: str
    mission_version: int
    coordinator_epoch: int
    status: MissionStatus
    operating_mode: OperatingMode
    site: MapSiteConfig
    jobs: list[SurveyJob]
    allocations: list[TaskAllocationItem]
    conflicts: list[ConflictFinding]
    sync_states: list[AircraftSyncState]
    approval: ApprovalRecord | None
    control_lease: ControlLease
    commands: list[CommandRecord]
    exceptions: list[MissionException]
    payload_data: list[PayloadDataRecord]


def to_dict(obj: Any) -> Any:
    if isinstance(obj, Enum):
        return obj.value
    if hasattr(obj, "__dataclass_fields__"):
        return {k: to_dict(v) for k, v in asdict(obj).items()}
    if isinstance(obj, list):
        return [to_dict(v) for v in obj]
    if isinstance(obj, dict):
        return {k: to_dict(v) for k, v in obj.items()}
    return obj
