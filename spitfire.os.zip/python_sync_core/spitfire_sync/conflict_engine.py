"""Authoritative spatial and temporal conflict detection within modelled operational scope."""

from __future__ import annotations

import math

from .models import (
    AircraftRecord,
    ConflictFinding,
    LocalPoint3D,
    MapSiteConfig,
    TaskAllocationItem,
)

DEFAULT_SPATIAL_BUFFER_M = 18.0
DEFAULT_TEMPORAL_BUFFER_S = 15.0
MIN_BATTERY_RESERVE_PCT = 22.0
MODELLED_SCOPE_NOTE = (
    "Evaluated within modelled local Pennine DEM, nominal wind envelope, and reported position "
    "uncertainty. Strategic scheduling does NOT replace onboard sense-and-avoid."
)


def _dist_2d(a: LocalPoint3D, b: LocalPoint3D) -> float:
    return math.hypot(a.x_m - b.x_m, a.y_m - b.y_m)


def _point_in_polygon(pt: LocalPoint3D, poly: list[LocalPoint3D]) -> bool:
    if len(poly) < 3:
        return False
    inside = False
    j = len(poly) - 1
    for i in range(len(poly)):
        xi, yi = poly[i].x_m, poly[i].y_m
        xj, yj = poly[j].x_m, poly[j].y_m
        intersect = ((yi > pt.y_m) != (yj > pt.y_m)) and (
            pt.x_m < (xj - xi) * (pt.y_m - yi) / ((yj - yi) or 1e-9) + xi
        )
        if intersect:
            inside = not inside
        j = i
    return inside


def detect_conflicts(
    allocations: list[TaskAllocationItem],
    aircraft_by_id: dict[str, AircraftRecord],
    site: MapSiteConfig,
) -> list[ConflictFinding]:
    findings: list[ConflictFinding] = []
    idx = 1

    # 1. Launch & recovery temporal slot separation
    for i in range(len(allocations)):
        a = allocations[i]
        for j in range(i + 1, len(allocations)):
            b = allocations[j]
            if a.launch_site_id == b.launch_site_id:
                dt = abs(a.launch_slot_s - b.launch_slot_s)
                if dt < DEFAULT_TEMPORAL_BUFFER_S:
                    findings.append(
                        ConflictFinding(
                            conflict_id=f"CONF-{idx:03d}",
                            severity="CRITICAL",
                            category="LAUNCH_SLOT_CONFLICT",
                            description=(
                                f"{a.aircraft_id} and {b.aircraft_id} share {a.launch_site_id} "
                                f"with only {dt}s separation (minimum buffer {int(DEFAULT_TEMPORAL_BUFFER_S)}s)."
                            ),
                            affected_aircraft=[a.aircraft_id, b.aircraft_id],
                            affected_tasks=[a.task_id, b.task_id],
                            location_x_m=a.proposed_route[0].x_m if a.proposed_route else 0.0,
                            location_y_m=a.proposed_route[0].y_m if a.proposed_route else 0.0,
                            time_window_start_s=min(a.launch_slot_s, b.launch_slot_s),
                            time_window_end_s=max(a.launch_slot_s, b.launch_slot_s)
                            + int(DEFAULT_TEMPORAL_BUFFER_S),
                            spatial_buffer_m=DEFAULT_SPATIAL_BUFFER_M,
                            temporal_buffer_s=DEFAULT_TEMPORAL_BUFFER_S,
                            modelled_scope_note=MODELLED_SCOPE_NOTE,
                        )
                    )
                    idx += 1

            if a.recovery_site_id == b.recovery_site_id:
                dt_rec = abs(a.recovery_slot_s - b.recovery_slot_s)
                if dt_rec < DEFAULT_TEMPORAL_BUFFER_S:
                    findings.append(
                        ConflictFinding(
                            conflict_id=f"CONF-{idx:03d}",
                            severity="CAUTION",
                            category="RECOVERY_AREA_CONFLICT",
                            description=(
                                f"{a.aircraft_id} and {b.aircraft_id} converge on {a.recovery_site_id} "
                                f"within {dt_rec}s (minimum buffer {int(DEFAULT_TEMPORAL_BUFFER_S)}s)."
                            ),
                            affected_aircraft=[a.aircraft_id, b.aircraft_id],
                            affected_tasks=[a.task_id, b.task_id],
                            location_x_m=a.proposed_route[-1].x_m if a.proposed_route else 0.0,
                            location_y_m=a.proposed_route[-1].y_m if a.proposed_route else 0.0,
                            time_window_start_s=min(a.recovery_slot_s, b.recovery_slot_s),
                            time_window_end_s=max(a.recovery_slot_s, b.recovery_slot_s)
                            + int(DEFAULT_TEMPORAL_BUFFER_S),
                            spatial_buffer_m=DEFAULT_SPATIAL_BUFFER_M,
                            temporal_buffer_s=DEFAULT_TEMPORAL_BUFFER_S,
                            modelled_scope_note=MODELLED_SCOPE_NOTE,
                        )
                    )
                    idx += 1

    # 2. Spatial trajectory proximity + uncertainty envelope
    for i in range(len(allocations)):
        a = allocations[i]
        ac_a = aircraft_by_id.get(a.aircraft_id)
        unc_a = ac_a.position_uncertainty_m if ac_a else site.position_uncertainty_m
        for j in range(i + 1, len(allocations)):
            b = allocations[j]
            # Check time overlap
            overlap_start = max(a.launch_slot_s, b.launch_slot_s)
            overlap_end = min(a.recovery_slot_s, b.recovery_slot_s)
            if overlap_end <= overlap_start:
                continue
            ac_b = aircraft_by_id.get(b.aircraft_id)
            unc_b = ac_b.position_uncertainty_m if ac_b else site.position_uncertainty_m
            required_sep = DEFAULT_SPATIAL_BUFFER_M + unc_a + unc_b
            min_sep = float("inf")
            conflict_pt: LocalPoint3D | None = None
            for pa in a.proposed_route:
                for pb in b.proposed_route:
                    if abs(pa.alt_m - pb.alt_m) < 8.0:
                        d = _dist_2d(pa, pb)
                        if d < min_sep:
                            min_sep = d
                            conflict_pt = pa
            if conflict_pt is not None and min_sep < required_sep:
                findings.append(
                    ConflictFinding(
                        conflict_id=f"CONF-{idx:03d}",
                        severity="CAUTION",
                        category="CORRIDOR_PROXIMITY",
                        description=(
                            f"{a.aircraft_id} and {b.aircraft_id} waypoints approach {min_sep:.1f}m "
                            f"(< {required_sep:.1f}m buffered threshold including position uncertainty)."
                        ),
                        affected_aircraft=[a.aircraft_id, b.aircraft_id],
                        affected_tasks=[a.task_id, b.task_id],
                        location_x_m=conflict_pt.x_m,
                        location_y_m=conflict_pt.y_m,
                        time_window_start_s=overlap_start,
                        time_window_end_s=overlap_end,
                        spatial_buffer_m=required_sep,
                        temporal_buffer_s=DEFAULT_TEMPORAL_BUFFER_S,
                        modelled_scope_note=MODELLED_SCOPE_NOTE,
                    )
                )
                idx += 1

    # 3. Exclusion zones & battery reserve checks
    exclusions = [z for z in site.zones if z.zone_type == "EXCLUSION"]
    for alloc in allocations:
        for zone in exclusions:
            for pt in alloc.proposed_route:
                if _point_in_polygon(pt, zone.vertices):
                    findings.append(
                        ConflictFinding(
                            conflict_id=f"CONF-{idx:03d}",
                            severity="CRITICAL",
                            category="EXCLUSION_AREA_VIOLATION",
                            description=(
                                f"{alloc.aircraft_id} route intersects exclusion zone {zone.label}."
                            ),
                            affected_aircraft=[alloc.aircraft_id],
                            affected_tasks=[alloc.task_id],
                            location_x_m=pt.x_m,
                            location_y_m=pt.y_m,
                            time_window_start_s=alloc.launch_slot_s,
                            time_window_end_s=alloc.recovery_slot_s,
                            spatial_buffer_m=DEFAULT_SPATIAL_BUFFER_M,
                            temporal_buffer_s=DEFAULT_TEMPORAL_BUFFER_S,
                            modelled_scope_note=MODELLED_SCOPE_NOTE,
                        )
                    )
                    idx += 1
                    break

        if alloc.battery_reserve_pct < MIN_BATTERY_RESERVE_PCT:
            findings.append(
                ConflictFinding(
                    conflict_id=f"CONF-{idx:03d}",
                    severity="CRITICAL",
                    category="INSUFFICIENT_BATTERY_RESERVE",
                    description=(
                        f"{alloc.aircraft_id} projected landing reserve {alloc.battery_reserve_pct:.1f}% "
                        f"is below {MIN_BATTERY_RESERVE_PCT:.0f}% policy reserve."
                    ),
                    affected_aircraft=[alloc.aircraft_id],
                    affected_tasks=[alloc.task_id],
                    location_x_m=alloc.proposed_route[-1].x_m if alloc.proposed_route else 0.0,
                    location_y_m=alloc.proposed_route[-1].y_m if alloc.proposed_route else 0.0,
                    time_window_start_s=alloc.launch_slot_s,
                    time_window_end_s=alloc.recovery_slot_s,
                    spatial_buffer_m=DEFAULT_SPATIAL_BUFFER_M,
                    temporal_buffer_s=DEFAULT_TEMPORAL_BUFFER_S,
                    modelled_scope_note=MODELLED_SCOPE_NOTE,
                )
            )
            idx += 1

    return findings
