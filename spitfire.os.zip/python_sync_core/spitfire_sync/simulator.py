"""Pennine Solar & Farm Survey 6-drone deterministic simulator & CoordinatorEngine."""

from __future__ import annotations

import copy
import time
import uuid
from dataclasses import replace

from .allocator import propose_allocations, reassign_withdrawn_aircraft
from .clock_sync import evaluate_sync_state, issue_readiness_acknowledgement
from .command_fsm import refresh_lease, validate_and_submit_command
from .conflict_engine import detect_conflicts
from .models import (
    AircraftRecord,
    AircraftSyncState,
    ApprovalRecord,
    CommandState,
    ControlLease,
    ControlLeaseStatus,
    ExceptionCategory,
    ExceptionResolutionEntry,
    ExceptionStatus,
    JobType,
    LocalPoint3D,
    MapSiteConfig,
    MissionException,
    MissionRecord,
    MissionStatus,
    NamedZone,
    OperatingMode,
    PayloadDataRecord,
    ReplayGapWindow,
    ReplaySession,
    SurveyJob,
    SyncStage,
    TelemetryEvent,
)


def _now_ms() -> int:
    return int(time.time() * 1000)


def build_pennine_site() -> MapSiteConfig:
    return MapSiteConfig(
        site_id="SITE-PENNINE-01",
        name="Pennine Solar & Farm Survey",
        coordinate_reference="LOCAL_ENU_M (Origin: 53.7214N, -1.9482W, Pennine Ridge)",
        altitude_reference="AGL_SITE_DATUM (Launch Pad Elevation 298.0 m AMSL)",
        terrain_source="OS Terrain 5m + Pennine Lidar Strip 2025-Q4",
        map_data_age_s=142,
        position_uncertainty_m=1.4,
        planning_assumptions="Max wind 9.5 m/s WSW; daylight VLOS/EVLOS corridor; 22% reserve floor.",
        zones=[
            NamedZone(
                zone_id="BND-PENNINE",
                label="Site Boundary",
                zone_type="BOUNDARY",
                vertices=[
                    LocalPoint3D(20.0, 20.0, 0.0),
                    LocalPoint3D(580.0, 20.0, 0.0),
                    LocalPoint3D(580.0, 420.0, 0.0),
                    LocalPoint3D(20.0, 420.0, 0.0),
                ],
            ),
            NamedZone(
                zone_id="EXC-PYLON",
                label="HV Pylon Corridor (Exclusion)",
                zone_type="EXCLUSION",
                vertices=[
                    LocalPoint3D(265.0, 205.0, 0.0),
                    LocalPoint3D(330.0, 205.0, 0.0),
                    LocalPoint3D(330.0, 275.0, 0.0),
                    LocalPoint3D(265.0, 275.0, 0.0),
                ],
            ),
            NamedZone(
                zone_id="PAD-NORTH",
                label="North Launch Pad",
                zone_type="LAUNCH",
                vertices=[LocalPoint3D(80.0, 60.0, 0.0)],
            ),
            NamedZone(
                zone_id="PAD-SOUTH",
                label="South Launch Pad",
                zone_type="LAUNCH",
                vertices=[LocalPoint3D(340.0, 65.0, 0.0)],
            ),
            NamedZone(
                zone_id="REC-NORTH",
                label="North Recovery Apron",
                zone_type="RECOVERY",
                vertices=[LocalPoint3D(105.0, 60.0, 0.0)],
            ),
            NamedZone(
                zone_id="CTG-WEST",
                label="West Moor Contingency",
                zone_type="CONTINGENCY",
                vertices=[LocalPoint3D(55.0, 355.0, 0.0)],
            ),
        ],
    )


def build_pennine_fleet(now_ms: int) -> list[AircraftRecord]:
    return [
        AircraftRecord(
            aircraft_id="SPIT-01",
            callsign="Kestrel-1",
            airframe="Spitfire-Q6 Hex Survey",
            autopilot_version="PX4-1.15.2-UK",
            supported_payloads=["THERMAL_EO", "RGB_ORTHO"],
            configured_max_speed_mps=14.0,
            configured_max_wind_mps=11.0,
            configured_min_reserve_pct=22.0,
            battery_id="BAT-PEN-101",
            battery_soc_pct=91.0,
            battery_voltage_v=49.8,
            battery_observed_at_ms=now_ms - 400,
            charging_state="DISCHARGING_PREFLIGHT",
            maintenance_restrictions=[],
            maintenance_blocking_reason=None,
            assigned_task_id="TASK-001",
            observed_flight_mode="ARMED_READY",
            link_status="NOMINAL",
            position=LocalPoint3D(80.0, 60.0, 0.2),
            position_observed_at_ms=now_ms - 350,
            position_uncertainty_m=1.1,
            boot_id="BOOT-S01-8841",
            latest_command_outcome="ACKNOWLEDGED_BY_AIRCRAFT",
            supported_contingencies=["HOLD_POSITION", "RETURN_TO_CONTINGENCY_CTG_WEST", "COORDINATION_ABORT"],
            documentation_summary="CAA PDRA-01 compliant hexacopter; 240Wh LiHV pack; dual RTK GNSS.",
        ),
        AircraftRecord(
            aircraft_id="SPIT-02",
            callsign="Kestrel-2",
            airframe="Spitfire-Q6 Hex Survey",
            autopilot_version="PX4-1.15.2-UK",
            supported_payloads=["THERMAL_EO", "MULTISPECTRAL"],
            configured_max_speed_mps=14.0,
            configured_max_wind_mps=11.0,
            configured_min_reserve_pct=22.0,
            battery_id="BAT-PEN-102",
            battery_soc_pct=88.0,
            battery_voltage_v=49.3,
            battery_observed_at_ms=now_ms - 480,
            charging_state="DISCHARGING_PREFLIGHT",
            maintenance_restrictions=[],
            maintenance_blocking_reason=None,
            assigned_task_id="TASK-002",
            observed_flight_mode="ARMED_READY",
            link_status="NOMINAL",
            position=LocalPoint3D(340.0, 65.0, 0.1),
            position_observed_at_ms=now_ms - 420,
            position_uncertainty_m=1.2,
            boot_id="BOOT-S02-4419",
            latest_command_outcome="ACKNOWLEDGED_BY_AIRCRAFT",
            supported_contingencies=["HOLD_POSITION", "RETURN_TO_LAUNCH_PAD_SOUTH", "COORDINATION_ABORT"],
            documentation_summary="Thermal & multispectral survey variant; verified gimbal calibration 2026-11.",
        ),
        AircraftRecord(
            aircraft_id="SPIT-03",
            callsign="Merlin-3",
            airframe="Spitfire-V4 Quad Inspector",
            autopilot_version="ArduPilot-4.5.7",
            supported_payloads=["RGB_ORTHO", "ROOF_ZOOM"],
            configured_max_speed_mps=12.0,
            configured_max_wind_mps=9.5,
            configured_min_reserve_pct=22.0,
            battery_id="BAT-PEN-103",
            battery_soc_pct=86.0,
            battery_voltage_v=24.6,
            battery_observed_at_ms=now_ms - 520,
            charging_state="STANDBY",
            maintenance_restrictions=[],
            maintenance_blocking_reason=None,
            assigned_task_id="TASK-003",
            observed_flight_mode="STANDBY_ON_PAD",
            link_status="NOMINAL",
            position=LocalPoint3D(95.0, 72.0, 0.0),
            position_observed_at_ms=now_ms - 500,
            position_uncertainty_m=1.3,
            boot_id="BOOT-S03-9902",
            latest_command_outcome="ACKNOWLEDGED_BY_AIRCRAFT",
            supported_contingencies=["HOLD_POSITION", "LAND_AT_RECOVERY_REC_NORTH", "COORDINATION_ABORT"],
            documentation_summary="Close-range agricultural & roof inspection quadrotor with 40x optical zoom.",
        ),
        AircraftRecord(
            aircraft_id="SPIT-04",
            callsign="Merlin-4",
            airframe="Spitfire-V4 Quad Inspector",
            autopilot_version="ArduPilot-4.5.7",
            supported_payloads=["MULTISPECTRAL", "RGB_ORTHO"],
            configured_max_speed_mps=12.0,
            configured_max_wind_mps=9.5,
            configured_min_reserve_pct=22.0,
            battery_id="BAT-PEN-104",
            battery_soc_pct=83.0,
            battery_voltage_v=24.4,
            battery_observed_at_ms=now_ms - 600,
            charging_state="STANDBY",
            maintenance_restrictions=[],
            maintenance_blocking_reason=None,
            assigned_task_id="TASK-004",
            observed_flight_mode="STANDBY_ON_PAD",
            link_status="NOMINAL",
            position=LocalPoint3D(355.0, 74.0, 0.0),
            position_observed_at_ms=now_ms - 580,
            position_uncertainty_m=1.4,
            boot_id="BOOT-S04-7721",
            latest_command_outcome="NONE",
            supported_contingencies=["HOLD_POSITION", "COORDINATION_ABORT"],
            documentation_summary="Agricultural NDVI multispectral carrier.",
        ),
        AircraftRecord(
            aircraft_id="SPIT-05",
            callsign="Harrier-5",
            airframe="Spitfire-L8 Heavy Mapper",
            autopilot_version="PX4-1.15.2-UK",
            supported_payloads=["LIDAR_POD", "CORRIDOR_CARGO"],
            configured_max_speed_mps=15.0,
            configured_max_wind_mps=12.0,
            configured_min_reserve_pct=22.0,
            battery_id="BAT-PEN-105",
            battery_soc_pct=36.0,  # Triggers insufficient battery reserve warning if assigned long task!
            battery_voltage_v=46.1,
            battery_observed_at_ms=now_ms - 450,
            charging_state="ON_CHARGER_72W",
            maintenance_restrictions=[],
            maintenance_blocking_reason=None,
            assigned_task_id=None,
            observed_flight_mode="CHARGING_RESERVE_LOW",
            link_status="NOMINAL",
            position=LocalPoint3D(115.0, 48.0, 0.0),
            position_observed_at_ms=now_ms - 450,
            position_uncertainty_m=1.1,
            boot_id="BOOT-S05-3304",
            latest_command_outcome="NONE",
            supported_contingencies=["COORDINATION_ABORT"],
            documentation_summary="LiDAR stockpile mapper; pack BAT-PEN-105 currently charging (insufficient reserve for dispatch).",
        ),
        AircraftRecord(
            aircraft_id="SPIT-06",
            callsign="Gannet-6",
            airframe="Spitfire-D2 Corridor Delivery",
            autopilot_version="PX4-1.15.1-UK",
            supported_payloads=["CORRIDOR_CARGO", "RGB_ORTHO"],
            configured_max_speed_mps=16.0,
            configured_max_wind_mps=11.0,
            configured_min_reserve_pct=22.0,
            battery_id="BAT-PEN-106",
            battery_soc_pct=94.0,
            battery_voltage_v=50.1,
            battery_observed_at_ms=now_ms - 700,
            charging_state="STANDBY",
            maintenance_restrictions=["PROP_HUB_TORQUE_CHECK_DUE"],
            maintenance_blocking_reason="PROP_HUB_TORQUE_CHECK_DUE (Logged by Eng. R. Patel; requires sign-off before flight)",
            assigned_task_id=None,
            observed_flight_mode="MAINTENANCE_LOCKED",
            link_status="NOMINAL",
            position=LocalPoint3D(370.0, 48.0, 0.0),
            position_observed_at_ms=now_ms - 700,
            position_uncertainty_m=1.0,
            boot_id="BOOT-S06-1190",
            latest_command_outcome="REJECTED",
            supported_contingencies=["COORDINATION_ABORT"],
            documentation_summary="Blocked by maintenance defect PROP_HUB_TORQUE_CHECK_DUE.",
        ),
    ]


class CoordinatorEngine:
    """Single shared authoritative coordination & simulator engine."""

    def __init__(self) -> None:
        self._now_ms = _now_ms()
        self.site = build_pennine_site()
        self.fleet: list[AircraftRecord] = build_pennine_fleet(self._now_ms)
        self.stream_sequence = 100
        self.event_log: list[TelemetryEvent] = []
        self.mission = self._create_initial_pennine_mission()
        self.replay_sessions: dict[str, ReplaySession] = self._build_initial_replays()

    def _create_initial_pennine_mission(self) -> MissionRecord:
        jobs = [
            SurveyJob(
                job_id="JOB-SOLAR-N",
                title="Pennine North Solar Array Thermal",
                job_type=JobType.SOLAR_FARM_SURVEY,
                work_area_label="North Solar Block A",
                work_area_polygon=[
                    LocalPoint3D(60.0, 120.0, 45.0),
                    LocalPoint3D(230.0, 120.0, 45.0),
                    LocalPoint3D(230.0, 260.0, 45.0),
                    LocalPoint3D(60.0, 260.0, 45.0),
                ],
                required_outputs=["Radiometric Thermal Orthomosaic", "String Hot-Spot Table"],
                payload_type="THERMAL_EO",
                timing_window_start_s=60,
                timing_window_end_s=420,
                responsible_operator="Op. A. Vance",
                operating_conditions="Daylight, wind <= 9.5 m/s, VLOS North Ridge",
            ),
            SurveyJob(
                job_id="JOB-SOLAR-S",
                title="Pennine East Solar & Inverter Sheds",
                job_type=JobType.SOLAR_FARM_SURVEY,
                work_area_label="East Solar Block B",
                work_area_polygon=[
                    LocalPoint3D(355.0, 125.0, 55.0),
                    LocalPoint3D(540.0, 125.0, 55.0),
                    LocalPoint3D(540.0, 275.0, 55.0),
                    LocalPoint3D(355.0, 275.0, 55.0),
                ],
                required_outputs=["Thermal Strip Map", "RGB Inspection Frames"],
                payload_type="THERMAL_EO",
                timing_window_start_s=60,
                timing_window_end_s=460,
                responsible_operator="Op. A. Vance",
                operating_conditions="Daylight, wind <= 9.5 m/s",
            ),
            SurveyJob(
                job_id="JOB-AGRI-W",
                title="Upper Pasture Drainage & Crop Vigour",
                job_type=JobType.AGRICULTURAL_INSPECTION,
                work_area_label="West Pasture Plot 3",
                work_area_polygon=[
                    LocalPoint3D(50.0, 285.0, 65.0),
                    LocalPoint3D(240.0, 285.0, 65.0),
                    LocalPoint3D(240.0, 395.0, 65.0),
                    LocalPoint3D(50.0, 395.0, 65.0),
                ],
                required_outputs=["RGB Orthomosaic", "Drainage Anomaly GeoJSON"],
                payload_type="RGB_ORTHO",
                timing_window_start_s=120,
                timing_window_end_s=520,
                responsible_operator="Op. A. Vance",
                operating_conditions="Cloud ceiling > 120m AGL",
            ),
            SurveyJob(
                job_id="JOB-AGRI-E",
                title="East Meadow Multispectral Strip",
                job_type=JobType.AGRICULTURAL_INSPECTION,
                work_area_label="East Meadow Plot 4",
                work_area_polygon=[
                    LocalPoint3D(360.0, 295.0, 75.0),
                    LocalPoint3D(545.0, 295.0, 75.0),
                    LocalPoint3D(545.0, 395.0, 75.0),
                    LocalPoint3D(360.0, 395.0, 75.0),
                ],
                required_outputs=["NDVI Index Map"],
                payload_type="MULTISPECTRAL",
                timing_window_start_s=145,
                timing_window_end_s=560,
                responsible_operator="Op. A. Vance",
                operating_conditions="Diffuse daylight preferred",
            ),
        ]
        # Start with intentional launch conflict on PAD-NORTH so operator can inspect & resolve it!
        allocations = propose_allocations(
            jobs, self.fleet, introduce_launch_conflict=True, resolve_conflicts=False
        )
        fleet_map = {a.aircraft_id: a for a in self.fleet}
        conflicts = detect_conflicts(allocations, fleet_map, self.site)
        sync_states = [
            AircraftSyncState(
                aircraft_id=ac.aircraft_id,
                plan_version=1,
                coordinator_epoch=4,
                boot_id=ac.boot_id,
                clock_offset_ms=round((idx - 2) * 3.4, 1),
                clock_uncertainty_ms=11.5 + idx * 2.1,
                telemetry_age_ms=self._now_ms - ac.position_observed_at_ms,
                readiness_acked=idx < 3,
                readiness_expires_at_ms=self._now_ms + 28_000 if idx < 3 else 0,
                task_lease_status="READY_BOUND_TO_V1" if idx < 3 else "UNALLOCATED",
                scheduled_start_s=allocations[idx].launch_slot_s if idx < len(allocations) else 0,
                actual_observed_start_s=None,
                start_deviation_s=None,
                stage=SyncStage.READINESS_ACKNOWLEDGED if idx < 3 else SyncStage.PLAN_PROPOSED,
                tolerance_exceeded_reason=None,
                available_actions=[],
            )
            for idx, ac in enumerate(self.fleet)
        ]

        return MissionRecord(
            mission_id="MSN-PENNINE-2026-11",
            name="Pennine Solar & Farm Survey",
            mission_version=1,
            coordinator_epoch=4,
            status=MissionStatus.VALIDATED_WITH_CONFLICTS,
            operating_mode=OperatingMode.SIMULATION,
            site=self.site,
            jobs=jobs,
            allocations=allocations,
            conflicts=conflicts,
            sync_states=sync_states,
            approval=None,
            control_lease=ControlLease(
                lease_id="LEASE-OP-VANCE-01",
                mission_id="MSN-PENNINE-2026-11",
                owner_operator_id="Op. A. Vance",
                owner_device_id="TABLET-UK-OPS-01",
                coordinator_epoch=4,
                expires_at_ms=self._now_ms + 180_000,
                status=ControlLeaseStatus.HELD,
            ),
            commands=[],
            exceptions=[
                MissionException(
                    exception_id="EXC-001",
                    category=ExceptionCategory.LOW_OBSERVED_BATTERY,
                    severity="CAUTION",
                    affected_aircraft=["SPIT-05"],
                    affected_tasks=[],
                    source_observations=["BAT-PEN-105 SoC=36.0% (< 55% dispatch threshold)"],
                    detected_at_ms=self._now_ms - 5_000,
                    status=ExceptionStatus.OPEN,
                    proposed_responses=["KEEP_ON_CHARGER", "EXCLUDE_FROM_ALLOCATION"],
                    responsible_operator="Op. A. Vance",
                )
            ],
            payload_data=[
                PayloadDataRecord(
                    record_id="DATA-001",
                    aircraft_id="SPIT-01",
                    payload_id="THERMAL_EO",
                    config_version="CFG-THM-2.4",
                    capture_frames_commanded=140,
                    capture_frames_observed=0,
                    upload_progress_pct=0.0,
                    coverage_pct=0.0,
                    missing_data_findings=[],
                    follow_up_job_id=None,
                ),
                PayloadDataRecord(
                    record_id="DATA-002",
                    aircraft_id="SPIT-04",
                    payload_id="MULTISPECTRAL",
                    config_version="CFG-MS-1.9",
                    capture_frames_commanded=96,
                    capture_frames_observed=0,
                    upload_progress_pct=0.0,
                    coverage_pct=0.0,
                    missing_data_findings=[],
                    follow_up_job_id=None,
                    planned_application_rate="Survey only (0 L/ha)",
                    observed_delivery_rate="N/A",
                ),
            ],
        )

    def _build_initial_replays(self) -> dict[str, ReplaySession]:
        base_ms = self._now_ms - 300_000
        events: list[TelemetryEvent] = []
        seq = 1
        # Generate deterministic 60s Pennine mission replay with a real 5s recording gap at [42s..47s]
        for t_s in range(0, 61, 3):
            if 42 <= t_s <= 47:
                continue  # Deliberate gap in recorded telemetry!
            events.append(
                TelemetryEvent(
                    event_id=f"REP-EVT-{seq:03d}",
                    stream_sequence=seq,
                    event_type="TELEMETRY_FRAME",
                    observation_time_ms=base_ms + t_s * 1000,
                    ingestion_time_ms=base_ms + t_s * 1000 + 85,
                    mission_version=2,
                    payload={
                        "t_s": float(t_s),
                        "aircraft": {
                            "SPIT-01": {
                                "x_m": 80.0 + min(150.0, t_s * 2.8),
                                "y_m": 130.0 + (t_s % 12) * 8.0,
                                "alt_m": 45.0 if t_s > 3 else 0.0,
                                "soc_pct": max(48.0, 91.0 - t_s * 0.45),
                                "mode": "SURVEY_AUTO" if t_s > 3 else "LAUNCH_CLIMB",
                            },
                            "SPIT-02": {
                                "x_m": 360.0 + min(170.0, t_s * 2.5),
                                "y_m": 140.0 + ((t_s + 5) % 10) * 10.0,
                                "alt_m": 55.0 if t_s > 6 else 0.0,
                                "soc_pct": max(51.0, 88.0 - t_s * 0.4),
                                "mode": "SURVEY_AUTO" if t_s > 6 else "STANDBY",
                            },
                        },
                        "note": (
                            "SPIT-04 withdrawn at t=24s; unfinished lanes reassigned to SPIT-03"
                            if t_s == 24
                            else None
                        ),
                    },
                )
            )
            seq += 1

        return {
            "RPL-PENNINE-001": ReplaySession(
                replay_id="RPL-PENNINE-001",
                mission_id="MSN-PENNINE-2026-11",
                title="Pennine Solar & Farm Survey — Run #01 (With Reassignment & Gap)",
                duration_s=60.0,
                gap_windows=[
                    ReplayGapWindow(
                        start_s=42.0,
                        end_s=47.0,
                        reason="Telemetry recorder uplink drop (42.0s–47.0s); no synthetic interpolation applied.",
                    )
                ],
                events=events,
            )
        }

    def capabilities(self) -> dict:
        return {
            "coordinator_version": "1.4.0-py",
            "operating_modes": [OperatingMode.SIMULATION.value, OperatingMode.REPLAY.value],
            "connected_aircraft_enabled": False,
            "connected_aircraft_gate": "DISABLED_BY_DEFAULT_REQUIRES_AIRFRAME_CERTIFICATION",
            "sync_tolerances": {
                "max_clock_uncertainty_ms": 35.0,
                "max_telemetry_age_ms": 2500,
                "max_start_deviation_s": 2.0,
                "readiness_ttl_ms": 30000,
            },
            "supported_job_types": [j.value for j in JobType],
        }

    def refresh_telemetry(self, advance_ms: int = 1000) -> list[TelemetryEvent]:
        self._now_ms = max(self._now_ms + advance_ms, _now_ms())
        fleet_map = {a.aircraft_id: a for a in self.fleet}
        new_events: list[TelemetryEvent] = []

        if self.mission.status == MissionStatus.IN_FLIGHT:
            for alloc in self.mission.allocations:
                ac = fleet_map.get(alloc.aircraft_id)
                if ac is None or ac.withdrawn or not alloc.proposed_route:
                    continue
                alloc.progress_pct = min(100.0, alloc.progress_pct + 12.5)
                pt_idx = min(
                    len(alloc.proposed_route) - 1,
                    int((alloc.progress_pct / 100.0) * (len(alloc.proposed_route) - 1)),
                )
                pt = alloc.proposed_route[pt_idx]
                ac.position = pt
                ac.position_observed_at_ms = self._now_ms
                ac.battery_soc_pct = max(18.0, round(ac.battery_soc_pct - 0.9, 1))
                ac.battery_observed_at_ms = self._now_ms
                ac.observed_flight_mode = "SURVEY_AUTO" if alloc.progress_pct < 100.0 else "RECOVERED"
                alloc.observed_track.append(pt)
                next_pt = alloc.proposed_route[min(len(alloc.proposed_route) - 1, pt_idx + 1)]
                alloc.bounded_predicted_position = next_pt
                if alloc.progress_pct >= 100.0:
                    alloc.completed = True

        self.mission.sync_states = [
            evaluate_sync_state(
                s,
                fleet_map[s.aircraft_id],
                self._now_ms,
                self.mission.mission_version,
                self.mission.coordinator_epoch,
            )
            for s in self.mission.sync_states
            if s.aircraft_id in fleet_map
        ]

        self.stream_sequence += 1
        evt = TelemetryEvent(
            event_id=f"EVT-{self.stream_sequence}",
            stream_sequence=self.stream_sequence,
            event_type="FLEET_SNAPSHOT_DELTA",
            observation_time_ms=self._now_ms - 40,
            ingestion_time_ms=self._now_ms,
            mission_version=self.mission.mission_version,
            payload={
                "mission_status": self.mission.status.value,
                "aircraft_count": len(self.fleet),
            },
        )
        self.event_log.append(evt)
        new_events.append(evt)
        return new_events

    def create_job(self, job: SurveyJob) -> MissionRecord:
        self.mission.jobs.append(job)
        self.mission.mission_version += 1
        if self.mission.approval:
            self.mission.approval = replace(
                self.mission.approval,
                valid=False,
                invalidation_reason="New job added; prior plan approval invalidated.",
            )
        return self.mission

    def propose_allocation(self, resolve_conflicts: bool = True) -> MissionRecord:
        self.mission.allocations = propose_allocations(
            self.mission.jobs,
            self.fleet,
            introduce_launch_conflict=not resolve_conflicts,
            resolve_conflicts=resolve_conflicts,
        )
        self.mission.mission_version += 1
        if self.mission.approval:
            self.mission.approval = replace(
                self.mission.approval,
                valid=False,
                invalidation_reason="Allocation recalculated; prior approval invalidated.",
            )
        return self.validate_mission()

    def validate_mission(self) -> MissionRecord:
        fleet_map = {a.aircraft_id: a for a in self.fleet}
        self.mission.conflicts = detect_conflicts(self.mission.allocations, fleet_map, self.site)
        has_critical = any(c.severity == "CRITICAL" for c in self.mission.conflicts)
        self.mission.status = (
            MissionStatus.VALIDATED_WITH_CONFLICTS if has_critical else MissionStatus.VALIDATED_CLEAN
        )
        self.mission.sync_states = [
            evaluate_sync_state(
                s,
                fleet_map[s.aircraft_id],
                self._now_ms,
                self.mission.mission_version,
                self.mission.coordinator_epoch,
            )
            for s in self.mission.sync_states
            if s.aircraft_id in fleet_map
        ]
        return self.mission

    def approve_mission(self, mission_version: int, operator_id: str) -> tuple[bool, str, MissionRecord]:
        if mission_version != self.mission.mission_version:
            return (
                False,
                f"VERSION_CONFLICT: Requested approval for v{mission_version}, current is v{self.mission.mission_version}.",
                self.mission,
            )
        critical = [c for c in self.mission.conflicts if c.severity == "CRITICAL"]
        if critical:
            return (
                False,
                f"CRITICAL_CONFLICT_PRESENT: Resolve {critical[0].conflict_id} before approving.",
                self.mission,
            )
        self.mission.approval = ApprovalRecord(
            mission_version=mission_version,
            approved_by=operator_id,
            approved_at_ms=self._now_ms,
            valid=True,
        )
        self.mission.status = MissionStatus.APPROVED
        fleet_map = {a.aircraft_id: a for a in self.fleet}
        new_sync = []
        for s in self.mission.sync_states:
            ac = fleet_map[s.aircraft_id]
            if any(a.aircraft_id == ac.aircraft_id for a in self.mission.allocations):
                new_sync.append(
                    issue_readiness_acknowledgement(
                        s, ac, self._now_ms, self.mission.mission_version, self.mission.coordinator_epoch
                    )
                )
            else:
                new_sync.append(s)
        self.mission.sync_states = new_sync
        return True, f"Plan v{mission_version} approved by {operator_id}.", self.mission

    def submit_command(
        self,
        request_id: str,
        mission_version: int,
        coordinator_epoch: int,
        control_lease_id: str,
        command_type: str,
        affected_aircraft: list[str],
        expiry_ms: int,
        operator_id: str,
    ):
        fleet_map = {a.aircraft_id: a for a in self.fleet}
        cmd, self.mission = validate_and_submit_command(
            self.mission,
            fleet_map,
            request_id=request_id,
            mission_version=mission_version,
            coordinator_epoch=coordinator_epoch,
            control_lease_id=control_lease_id,
            command_type=command_type,
            affected_aircraft=affected_aircraft,
            expiry_ms=expiry_ms,
            operator_id=operator_id,
            now_ms=self._now_ms,
        )
        return cmd

    def inject_delayed_telemetry(self, aircraft_id: str = "SPIT-02", delay_ms: int = 4800) -> MissionRecord:
        self._now_ms = _now_ms()
        for ac in self.fleet:
            if ac.aircraft_id == aircraft_id:
                ac.position_observed_at_ms = self._now_ms - delay_ms
        self.mission.exceptions.append(
            MissionException(
                exception_id=f"EXC-{len(self.mission.exceptions) + 1:03d}",
                category=ExceptionCategory.STALE_POSITION,
                severity="CAUTION",
                affected_aircraft=[aircraft_id],
                affected_tasks=[t.task_id for t in self.mission.allocations if t.aircraft_id == aircraft_id],
                source_observations=[f"Telemetry age {delay_ms}ms > 2500ms tolerance"],
                detected_at_ms=self._now_ms,
                status=ExceptionStatus.OPEN,
                proposed_responses=["HOLD_OR_RESCHEDULE", "REFRESH_TELEMETRY"],
                responsible_operator=self.mission.control_lease.owner_operator_id,
            )
        )
        return self.validate_mission()

    def withdraw_aircraft_and_reassign(self, aircraft_id: str = "SPIT-04") -> MissionRecord:
        self._now_ms = _now_ms()
        for ac in self.fleet:
            if ac.aircraft_id == aircraft_id:
                ac.withdrawn = True
                ac.observed_flight_mode = "WITHDRAWN_BY_OPERATOR"
                ac.assigned_task_id = None
        self.mission.allocations = reassign_withdrawn_aircraft(
            self.mission.allocations, self.fleet, aircraft_id
        )
        self.mission.mission_version += 1
        if self.mission.approval:
            self.mission.approval = replace(
                self.mission.approval,
                valid=False,
                invalidation_reason=f"Aircraft {aircraft_id} withdrawn and tasks reassigned; re-approval required for v{self.mission.mission_version}.",
            )
        self.mission.exceptions.append(
            MissionException(
                exception_id=f"EXC-{len(self.mission.exceptions) + 1:03d}",
                category=ExceptionCategory.AIRCRAFT_UNAVAILABLE,
                severity="CRITICAL",
                affected_aircraft=[aircraft_id],
                affected_tasks=[],
                source_observations=[f"{aircraft_id} withdrawn; unfinished work reassigned in v{self.mission.mission_version}."],
                detected_at_ms=self._now_ms,
                status=ExceptionStatus.OPEN,
                proposed_responses=["REVIEW_REASSIGNMENT_AND_APPROVE", "COORDINATION_ABORT"],
                responsible_operator=self.mission.control_lease.owner_operator_id,
            )
        )
        return self.validate_mission()

    def create_missing_imagery_followup(self) -> tuple[SurveyJob, MissionRecord]:
        followup = SurveyJob(
            job_id=f"JOB-FOLLOWUP-{len(self.mission.jobs) + 1:02d}",
            title="Pennine Missing Thermal Strip Re-Capture",
            job_type=JobType.SOLAR_FARM_SURVEY,
            work_area_label="North Solar Row 4-6 Gap",
            work_area_polygon=[
                LocalPoint3D(110.0, 175.0, 42.0),
                LocalPoint3D(210.0, 175.0, 42.0),
                LocalPoint3D(210.0, 215.0, 42.0),
                LocalPoint3D(110.0, 215.0, 42.0),
            ],
            required_outputs=["Missing Thermal Frames (18 frames)"],
            payload_type="THERMAL_EO",
            timing_window_start_s=520,
            timing_window_end_s=700,
            responsible_operator=self.mission.control_lease.owner_operator_id,
            operating_conditions="Daylight, wind <= 9.5 m/s",
            parent_job_id="JOB-SOLAR-N",
        )
        if self.mission.payload_data:
            self.mission.payload_data[0].capture_frames_observed = 122
            self.mission.payload_data[0].coverage_pct = 87.1
            self.mission.payload_data[0].upload_progress_pct = 100.0
            self.mission.payload_data[0].missing_data_findings = [
                "18 thermal frames missing along North Solar Row 4-6 (gap 12.9%)."
            ]
            self.mission.payload_data[0].follow_up_job_id = followup.job_id
        self.create_job(followup)
        return followup, self.mission

    def acquire_lease(self, operator_id: str, device_id: str) -> ControlLease:
        self._now_ms = _now_ms()
        self.mission.control_lease = refresh_lease(
            self.mission.control_lease,
            operator_id=operator_id,
            device_id=device_id,
            coordinator_epoch=self.mission.coordinator_epoch,
            now_ms=self._now_ms,
        )
        return self.mission.control_lease

    def request_handover(self, to_operator_id: str) -> ControlLease:
        self.mission.control_lease = replace(
            self.mission.control_lease,
            status=ControlLeaseStatus.HANDOVER_PENDING,
            pending_handover_operator_id=to_operator_id,
        )
        return self.mission.control_lease

    def accept_handover(self, operator_id: str, device_id: str) -> ControlLease:
        self._now_ms = _now_ms()
        self.mission.control_lease = ControlLease(
            lease_id=f"LEASE-{uuid.uuid4().hex[:8].upper()}",
            mission_id=self.mission.mission_id,
            owner_operator_id=operator_id,
            owner_device_id=device_id,
            coordinator_epoch=self.mission.coordinator_epoch,
            expires_at_ms=self._now_ms + 180_000,
            status=ControlLeaseStatus.HELD,
            pending_handover_operator_id=None,
        )
        return self.mission.control_lease

    def acknowledge_exception(self, exception_id: str, operator_id: str) -> MissionException | None:
        self._now_ms = _now_ms()
        for exc in self.mission.exceptions:
            if exc.exception_id == exception_id:
                exc.status = ExceptionStatus.ACKNOWLEDGED
                exc.resolution_history.append(
                    ExceptionResolutionEntry(
                        timestamp_ms=self._now_ms,
                        operator_id=operator_id,
                        action="ACKNOWLEDGED",
                        note="Operator acknowledged exception; mitigation pending.",
                    )
                )
                return exc
        return None

    def resolve_exception(self, exception_id: str, operator_id: str, action: str, note: str) -> MissionException | None:
        self._now_ms = _now_ms()
        for exc in self.mission.exceptions:
            if exc.exception_id == exception_id:
                exc.status = ExceptionStatus.RESOLVED
                exc.resolution_history.append(
                    ExceptionResolutionEntry(
                        timestamp_ms=self._now_ms,
                        operator_id=operator_id,
                        action=action,
                        note=note,
                    )
                )
                return exc
        return None
