import { Routes } from '@angular/router';
import { ControlCentre } from './components/control-centre/control-centre';

export const routes: Routes = [
  {
    path: '',
    component: ControlCentre,
  },
  {
    path: '**',
    redirectTo: '',
  },
];

