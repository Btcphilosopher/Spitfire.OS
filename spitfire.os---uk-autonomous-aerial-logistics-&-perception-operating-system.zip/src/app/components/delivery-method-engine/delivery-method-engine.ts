import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MissionService } from '../../core/services/mission.service';
import { SpitfireRService } from '../../core/services/spitfire-r.service';

@Component({
  selector: 'app-delivery-method-engine',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-neutral-900 border-l border-neutral-800 font-sans text-xs overflow-y-auto p-4 space-y-4">
      <!-- Section Title -->
      <div>
        <div class="flex items-center justify-between">
          <h3 class="font-bold text-neutral-100 text-sm flex items-center gap-1.5">
            <mat-icon class="!w-4 !h-4 !text-[18px] text-cyan-400">precision_manufacturing</mat-icon>
            Delivery Method Selection Engine
          </h3>
          <span class="font-mono text-[10px] text-emerald-400 bg-emerald-950/60 border border-emerald-800/50 px-2 py-0.5 rounded">R Analytical Engine</span>
        </div>
        <p class="text-neutral-400 text-[11px] mt-1 leading-relaxed">
          Deterministic aerodynamic, geometric and risk evaluation of all 7 delivery mechanisms under current environmental constraints.
        </p>
      </div>

      <!-- Interactive Parameter Sliders -->
      <div class="bg-neutral-950 border border-neutral-800 rounded-lg p-3 space-y-3 font-mono text-[11px]">
        <div class="text-neutral-400 uppercase tracking-wider font-semibold">Simulation Parameters</div>
        
        <!-- Payload Mass Slider -->
        <div>
          <div class="flex justify-between text-neutral-300 mb-1">
            <span>PAYLOAD MASS:</span>
            <span class="text-cyan-400 font-bold tabular-nums">{{ payloadMass() }} kg</span>
          </div>
          <input
            type="range"
            min="0.5"
            max="6.0"
            step="0.1"
            [value]="payloadMass()"
            (input)="onPayloadChange($event)"
            class="w-full accent-cyan-400 cursor-pointer"
          />
        </div>

        <!-- Wind Speed Slider -->
        <div>
          <div class="flex justify-between text-neutral-300 mb-1">
            <span>SURFACE WIND:</span>
            <span class="text-amber-400 font-bold tabular-nums">{{ windSpeed() }} kts (Gusts: {{ (windSpeed() * 1.4).toFixed(1) }} kts)</span>
          </div>
          <input
            type="range"
            min="2"
            max="30"
            step="1"
            [value]="windSpeed()"
            (input)="onWindChange($event)"
            class="w-full accent-amber-400 cursor-pointer"
          />
        </div>

        <!-- Target Zone Selector -->
        <div>
          <label for="zone-select" class="text-neutral-400 block mb-1">TARGET ZONE:</label>
          <select
            id="zone-select"
            [value]="selectedZoneId()"
            (change)="onZoneSelect($event)"
            class="w-full bg-neutral-900 border border-neutral-700 rounded p-1.5 text-neutral-200 text-xs font-mono outline-none"
          >
            @for (z of activeSite().zones; track z.id) {
              <option [value]="z.id">{{ z.name }} ({{ z.type }}) - {{ z.currentStatus }}</option>
            }
          </select>
        </div>
      </div>

      <!-- Evaluated Delivery Methods Grid -->
      <div class="space-y-3">
        <div class="text-neutral-400 uppercase tracking-wider font-mono text-[11px]">Method Suitability Ranking</div>

        @for (m of rankedMethods(); track m.method; let idx = $index) {
          <div
            class="bg-neutral-950 border rounded-lg p-3 transition-all"
            [class.border-cyan-500]="idx === 0"
            [class.border-neutral-800]="idx !== 0"
          >
            <div class="flex items-center justify-between mb-1.5">
              <div class="flex items-center gap-2">
                <span class="font-mono text-[10px] w-4 h-4 rounded-full flex items-center justify-center" [class.bg-cyan-950]="idx === 0" [class.text-cyan-400]="idx === 0" [class.bg-neutral-800]="idx !== 0" [class.text-neutral-400]="idx !== 0">
                  {{ idx + 1 }}
                </span>
                <span class="font-semibold text-white text-xs">{{ m.displayName }}</span>
              </div>
              <div class="flex items-center gap-2 font-mono">
                <span class="text-[10px] px-1.5 py-0.5 rounded" [class.bg-emerald-950]="m.isFeasible" [class.text-emerald-300]="m.isFeasible" [class.bg-red-950]="!m.isFeasible" [class.text-red-400]="!m.isFeasible">
                  {{ m.isFeasible ? 'FEASIBLE' : 'RESTRICTED' }}
                </span>
                <span class="font-bold" [class.text-cyan-400]="idx === 0" [class.text-neutral-300]="idx !== 0">{{ m.suitabilityScore }}%</span>
              </div>
            </div>

            <!-- Score Progress Bar -->
            <div class="w-full bg-neutral-800 rounded-full h-1.5 mb-2 overflow-hidden">
              <div
                class="h-full rounded-full transition-all duration-300"
                [class.bg-cyan-400]="idx === 0"
                [class.bg-emerald-500]="idx !== 0 && m.isFeasible"
                [class.bg-neutral-600]="!m.isFeasible"
                [style.width.%]="m.suitabilityScore"
              ></div>
            </div>

            <!-- Key Metrics -->
            <div class="grid grid-cols-3 gap-1 font-mono text-[10px] text-neutral-400 mb-2">
              <div>ERROR: <span class="text-neutral-200">±{{ m.expectedLandingErrorMeters }}m</span></div>
              <div>ENERGY: <span class="text-amber-300">+{{ m.energyCostPercent }}%</span></div>
              <div>TIME: <span class="text-neutral-200">{{ m.timeSeconds }}s</span></div>
            </div>

            <!-- Transparent Reasoning -->
            <div class="space-y-1 text-[11px]">
              @for (r of m.reasonCodes; track r) {
                <div [class.text-emerald-400]="r.startsWith('+')" [class.text-red-400]="r.startsWith('-')" class="flex items-start gap-1">
                  <span>{{ r }}</span>
                </div>
              }
            </div>

            @if (m.simulationData) {
              <div class="mt-2 pt-2 border-t border-neutral-900 grid grid-cols-2 gap-2 font-mono text-[10px] text-neutral-400">
                @if (m.simulationData.oscillationDeg !== undefined) {
                  <div>CABLE SWAY: <span class="text-cyan-300">{{ m.simulationData.oscillationDeg }}°</span></div>
                }
                @if (m.simulationData.tetherTensionN !== undefined) {
                  <div>TENSION: <span class="text-amber-300">{{ m.simulationData.tetherTensionN }} N</span></div>
                }
                @if (m.simulationData.touchdownVelocityMs !== undefined) {
                  <div>TOUCHDOWN: <span class="text-white">{{ m.simulationData.touchdownVelocityMs }} m/s</span></div>
                }
              </div>
            }
          </div>
        }
      </div>
    </div>
  `,
})
export class DeliveryMethodEngine {
  private missionService = inject(MissionService);
  private spitfireR = inject(SpitfireRService);

  readonly activeSite = this.missionService.selectedSite;
  readonly selectedZoneId = this.missionService.selectedZoneId;

  readonly payloadMass = signal<number>(2.0);
  readonly windSpeed = signal<number>(11.0);

  readonly currentZone = computed(() => {
    const site = this.activeSite();
    const zoneId = this.selectedZoneId();
    return site.zones.find((z) => z.id === zoneId) ?? site.zones[0];
  });

  readonly rankedMethods = computed(() => {
    const site = this.activeSite();
    const zone = this.currentZone();
    const mass = this.payloadMass();
    const wind = this.windSpeed();
    const gust = wind * 1.4;
    return this.spitfireR.evaluateDeliveryMethods(site, zone, mass, wind, gust);
  });

  onPayloadChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.payloadMass.set(val);
  }

  onWindChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.windSpeed.set(val);
  }

  onZoneSelect(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.missionService.selectZone(val);
  }
}
