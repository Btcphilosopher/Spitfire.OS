import {
  ChangeDetectionStrategy,
  Component,
  inject,
  signal
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MissionService } from '../../core/services/mission.service';
import { ThreeViewport } from '../three-viewport/three-viewport';
import { SignatureFlow } from '../signature-flow/signature-flow';
import { DeliveryMethodEngine } from '../delivery-method-engine/delivery-method-engine';
import { MonteCarloSimulator } from '../monte-carlo-simulator/monte-carlo-simulator';
import { SiteReconstruction } from '../site-reconstruction/site-reconstruction';
import { CustomerPortal } from '../customer-portal/customer-portal';
import { DeliverySite } from '../../core/models/spitfire.types';

@Component({
  selector: 'app-control-centre',
  imports: [
    CommonModule,
    MatIconModule,
    ThreeViewport,
    SignatureFlow,
    DeliveryMethodEngine,
    MonteCarloSimulator,
    SiteReconstruction,
    CustomerPortal,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-screen w-screen flex flex-col bg-neutral-950 text-neutral-100 overflow-hidden font-sans select-none">
      <!-- TOP STATUS BAR (British Aerospace Operations Room Contract) -->
      <header class="h-12 border-b border-neutral-800 bg-neutral-900/90 px-4 flex items-center justify-between z-20 shrink-0">
        <!-- Brand / Identity -->
        <div class="flex items-center gap-3">
          <div class="flex items-center gap-2">
            <div class="w-6 h-6 rounded bg-neutral-800 border border-neutral-700 flex items-center justify-center font-black text-cyan-400 font-mono text-xs">
              S
            </div>
            <span class="font-bold tracking-tight text-white font-mono text-sm">SPITFIRE.OS</span>
          </div>
          <span class="text-neutral-600">|</span>
          <span class="text-xs text-neutral-400 font-mono hidden md:inline">UK AUTONOMOUS DELIVERY OPERATING SYSTEM</span>
        </div>

        <!-- Central High-Level Airspace & Network Telemetry -->
        <div class="hidden lg:flex items-center gap-6 text-xs font-mono text-neutral-300">
          <div class="flex items-center gap-1.5">
            <span class="text-neutral-500">AIRSPACE:</span>
            <span class="text-emerald-400 font-semibold flex items-center gap-1">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              UK CLASS G / BVLOS CLEAR
            </span>
          </div>
          <div class="flex items-center gap-1.5">
            <span class="text-neutral-500">FLEET:</span>
            <span class="text-white font-semibold tabular-nums">48 / 52 AVAILABLE</span>
          </div>
          <div class="flex items-center gap-1.5">
            <span class="text-neutral-500">MISSIONS:</span>
            <span class="text-cyan-400 font-semibold tabular-nums">17 ACTIVE</span>
          </div>
          <div class="flex items-center gap-1.5">
            <span class="text-neutral-500">DELIVERED TODAY:</span>
            <span class="text-white font-semibold tabular-nums">31</span>
          </div>
          <div class="flex items-center gap-1.5">
            <span class="text-neutral-500">LINK SNR:</span>
            <span class="text-emerald-400 font-semibold">99.98%</span>
          </div>
        </div>

        <!-- Right System Controls & Tab Switcher -->
        <div class="flex items-center gap-2">
          <!-- Create New Site Button -->
          <button
            (click)="showNewSiteModal.set(true)"
            class="px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 rounded text-neutral-200 text-xs font-mono transition-colors flex items-center gap-1"
          >
            <mat-icon class="!w-3.5 !h-3.5 !text-[14px] text-cyan-400">add_location_alt</mat-icon>
            New Site Survey
          </button>
        </div>
      </header>

      <!-- MAIN WORKSPACE (3-COLUMN LAYOUT) -->
      <div class="flex-1 flex overflow-hidden">
        <!-- LEFT COLUMN: FLEET & SITES SIDEBAR -->
        <aside class="w-64 border-r border-neutral-800 bg-neutral-900/60 flex flex-col shrink-0">
          <!-- Sidebar Section Tabs -->
          <div class="flex border-b border-neutral-800 text-[11px] font-mono">
            <button
              (click)="leftTab.set('fleet')"
              [class.bg-neutral-800]="leftTab() === 'fleet'"
              [class.text-white]="leftTab() === 'fleet'"
              [class.text-neutral-400]="leftTab() !== 'fleet'"
              class="flex-1 py-2 font-semibold text-center transition-colors"
            >
              FLEET (52)
            </button>
            <button
              (click)="leftTab.set('sites')"
              [class.bg-neutral-800]="leftTab() === 'sites'"
              [class.text-white]="leftTab() === 'sites'"
              [class.text-neutral-400]="leftTab() !== 'sites'"
              class="flex-1 py-2 font-semibold text-center transition-colors border-l border-neutral-800"
            >
              UK SITES (4)
            </button>
          </div>

          <!-- Fleet List View -->
          @if (leftTab() === 'fleet') {
            <div class="flex-1 overflow-y-auto p-2 space-y-1.5">
              @for (d of drones(); track d.id) {
                <button
                  type="button"
                  (click)="selectDrone(d.id)"
                  [class.bg-neutral-800]="selectedDroneId() === d.id"
                  [class.border-cyan-500]="selectedDroneId() === d.id"
                  [class.bg-neutral-950]="selectedDroneId() !== d.id"
                  [class.border-neutral-800]="selectedDroneId() !== d.id"
                  class="w-full text-left p-2 rounded border cursor-pointer hover:border-neutral-700 transition-colors text-xs font-mono"
                >
                  <div class="flex items-center justify-between">
                    <span class="font-bold text-white">{{ d.callsign }}</span>
                    <span
                      class="text-[10px] px-1 py-0.2 rounded"
                      [class.bg-emerald-950]="d.status === 'AVAILABLE'"
                      [class.text-emerald-400]="d.status === 'AVAILABLE'"
                      [class.bg-cyan-950]="d.status === 'IN_FLIGHT'"
                      [class.text-cyan-400]="d.status === 'IN_FLIGHT'"
                      [class.bg-amber-950]="d.status === 'CHARGING'"
                      [class.text-amber-400]="d.status === 'CHARGING'"
                      [class.bg-red-950]="d.status === 'MAINTENANCE'"
                      [class.text-red-400]="d.status === 'MAINTENANCE'"
                    >
                      {{ d.status }}
                    </span>
                  </div>
                  <div class="text-[11px] text-neutral-400 mt-1 flex justify-between">
                    <span>{{ d.model }}</span>
                    <span class="text-emerald-400">{{ d.batterySoc }}% SOC</span>
                  </div>
                  <div class="text-[10px] text-neutral-500 mt-0.5">
                    {{ d.directRemoteId }}
                  </div>
                </button>
              }
            </div>
          }

          <!-- Delivery Sites List View -->
          @if (leftTab() === 'sites') {
            <div class="flex-1 overflow-y-auto p-2 space-y-2">
              @for (s of deliverySites(); track s.id) {
                <button
                  type="button"
                  (click)="selectSite(s.id)"
                  [class.bg-neutral-800]="selectedSiteId() === s.id"
                  [class.border-cyan-500]="selectedSiteId() === s.id"
                  [class.bg-neutral-950]="selectedSiteId() !== s.id"
                  [class.border-neutral-800]="selectedSiteId() !== s.id"
                  class="w-full text-left p-2.5 rounded-lg border cursor-pointer hover:border-neutral-700 transition-colors text-xs"
                >
                  <div class="font-semibold text-white">{{ s.name }}</div>
                  <div class="text-[11px] text-neutral-400 font-mono mt-0.5">{{ s.postcode }} · {{ s.category }}</div>
                  <div class="flex items-center justify-between mt-2 pt-1 border-t border-neutral-800 text-[10px] font-mono">
                    <span class="text-neutral-500">CONFIDENCE:</span>
                    <span class="text-emerald-400 font-bold">{{ (s.siteConfidence * 100).toFixed(1) }}%</span>
                  </div>
                </button>
              }
            </div>
          }

          <!-- Selected Aircraft Digital Twin Quick Card -->
          <div class="p-3 border-t border-neutral-800 bg-neutral-950 font-mono text-xs space-y-1.5">
            <div class="text-[10px] text-neutral-500 uppercase tracking-wider">AIRCRAFT DIGITAL TWIN</div>
            <div class="flex justify-between text-neutral-200">
              <span>CALLSIGN:</span>
              <span class="text-cyan-400 font-bold">{{ selectedDrone().callsign }}</span>
            </div>
            <div class="flex justify-between text-neutral-400 text-[11px]">
              <span>AIRFRAME HOURS:</span>
              <span>{{ selectedDrone().airframeHours }} hrs</span>
            </div>
            <div class="flex justify-between text-neutral-400 text-[11px]">
              <span>NEXT SERVICE:</span>
              <span class="text-emerald-400">{{ selectedDrone().nextInspectionHours }} hrs</span>
            </div>
            <div class="flex justify-between text-neutral-400 text-[11px]">
              <span>RTK POSITION:</span>
              <span class="text-white">{{ selectedDrone().subsystemHealth.gnssRtk }}</span>
            </div>
          </div>
        </aside>

        <!-- CENTER COLUMN: 3D DIGITAL TWIN VIEWPORT -->
        <main class="flex-1 flex flex-col relative bg-neutral-950">
          <app-three-viewport class="flex-1 w-full h-full"></app-three-viewport>
        </main>

        <!-- RIGHT COLUMN: MODULAR ENGINE PANELS & WORKFLOW -->
        <aside class="w-96 border-l border-neutral-800 bg-neutral-900/90 flex flex-col shrink-0">
          <!-- Right Panel Navigation Tabs -->
          <div class="flex border-b border-neutral-800 text-[10px] font-mono overflow-x-auto bg-neutral-950">
            <button
              (click)="rightTab.set('pipeline')"
              [class.bg-neutral-800]="rightTab() === 'pipeline'"
              [class.text-cyan-400]="rightTab() === 'pipeline'"
              [class.text-neutral-400]="rightTab() !== 'pipeline'"
              class="px-3 py-2 font-semibold transition-colors shrink-0 flex items-center gap-1"
            >
              <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">timeline</mat-icon>
              Pipeline
            </button>
            <button
              (click)="rightTab.set('methods')"
              [class.bg-neutral-800]="rightTab() === 'methods'"
              [class.text-cyan-400]="rightTab() === 'methods'"
              [class.text-neutral-400]="rightTab() !== 'methods'"
              class="px-3 py-2 font-semibold transition-colors shrink-0 flex items-center gap-1"
            >
              <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">settings_input_component</mat-icon>
              Methods
            </button>
            <button
              (click)="rightTab.set('monteCarlo')"
              [class.bg-neutral-800]="rightTab() === 'monteCarlo'"
              [class.text-cyan-400]="rightTab() === 'monteCarlo'"
              [class.text-neutral-400]="rightTab() !== 'monteCarlo'"
              class="px-3 py-2 font-semibold transition-colors shrink-0 flex items-center gap-1"
            >
              <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">casino</mat-icon>
              Monte Carlo
            </button>
            <button
              (click)="rightTab.set('vision')"
              [class.bg-neutral-800]="rightTab() === 'vision'"
              [class.text-cyan-400]="rightTab() === 'vision'"
              [class.text-neutral-400]="rightTab() !== 'vision'"
              class="px-3 py-2 font-semibold transition-colors shrink-0 flex items-center gap-1"
            >
              <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">view_in_ar</mat-icon>
              Vision
            </button>
            <button
              (click)="rightTab.set('customer')"
              [class.bg-neutral-800]="rightTab() === 'customer'"
              [class.text-cyan-400]="rightTab() === 'customer'"
              [class.text-neutral-400]="rightTab() !== 'customer'"
              class="px-3 py-2 font-semibold transition-colors shrink-0 flex items-center gap-1"
            >
              <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">person</mat-icon>
              Tracking
            </button>
          </div>

          <!-- Dynamic Panel Content -->
          <div class="flex-1 overflow-hidden">
            @switch (rightTab()) {
              @case ('pipeline') {
                <app-signature-flow></app-signature-flow>
              }
              @case ('methods') {
                <app-delivery-method-engine></app-delivery-method-engine>
              }
              @case ('monteCarlo') {
                <app-monte-carlo-simulator></app-monte-carlo-simulator>
              }
              @case ('vision') {
                <app-site-reconstruction></app-site-reconstruction>
              }
              @case ('customer') {
                <app-customer-portal></app-customer-portal>
              }
            }
          </div>
        </aside>
      </div>

      <!-- NEW DELIVERY SITE MODAL -->
      @if (showNewSiteModal()) {
        <div class="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div class="bg-neutral-900 border border-neutral-700 rounded-xl p-6 max-w-md w-full shadow-2xl space-y-4 font-sans text-xs">
            <div class="flex items-center justify-between border-b border-neutral-800 pb-3">
              <h3 class="font-bold text-white text-sm flex items-center gap-1.5">
                <mat-icon class="!w-4 !h-4 !text-[18px] text-cyan-400">add_location_alt</mat-icon>
                Commission New Delivery Site Survey
              </h3>
              <button (click)="showNewSiteModal.set(false)" class="text-neutral-500 hover:text-white">
                <mat-icon class="!w-4 !h-4 !text-[18px]">close</mat-icon>
              </button>
            </div>

            <div class="space-y-3 font-mono">
              <div>
                <label for="new-site-name" class="text-neutral-400 block mb-1">SITE NAME:</label>
                <input
                  id="new-site-name"
                  #siteNameInput
                  type="text"
                  value="Silverstone Technology Park - Hangar 7"
                  class="w-full bg-neutral-950 border border-neutral-700 rounded p-2 text-white outline-none"
                />
              </div>

              <div class="grid grid-cols-2 gap-2">
                <div>
                  <label for="new-site-postcode" class="text-neutral-400 block mb-1">UK POSTCODE:</label>
                  <input
                    id="new-site-postcode"
                    #postcodeInput
                    type="text"
                    value="NN12 8TN"
                    class="w-full bg-neutral-950 border border-neutral-700 rounded p-2 text-white outline-none"
                  />
                </div>
                <div>
                  <label for="new-site-category" class="text-neutral-400 block mb-1">CATEGORY:</label>
                  <select
                    id="new-site-category"
                    #categoryInput
                    class="w-full bg-neutral-950 border border-neutral-700 rounded p-2 text-white outline-none"
                  >
                    <option value="INDUSTRIAL_YARD">Industrial Yard</option>
                    <option value="SUBURBAN_RESIDENTIAL">Suburban Residential</option>
                    <option value="COMMERCIAL_ROOFTOP">Commercial Rooftop</option>
                    <option value="RURAL_ESTATE">Rural Estate</option>
                  </select>
                </div>
              </div>
            </div>

            <div class="flex justify-end gap-2 pt-3 border-t border-neutral-800">
              <button
                (click)="showNewSiteModal.set(false)"
                class="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded text-xs transition-colors"
              >
                Cancel
              </button>
              <button
                (click)="submitNewSite(siteNameInput.value, postcodeInput.value, categoryInput.value)"
                class="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold rounded text-xs transition-colors flex items-center gap-1.5"
              >
                <mat-icon class="!w-4 !h-4 !text-[16px]">flight_takeoff</mat-icon>
                Commission Survey
              </button>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class ControlCentre {
  private missionService = inject(MissionService);

  readonly drones = this.missionService.drones;
  readonly deliverySites = this.missionService.deliverySites;
  readonly selectedDroneId = this.missionService.selectedDroneId;
  readonly selectedSiteId = this.missionService.selectedSiteId;
  readonly selectedDrone = this.missionService.selectedDrone;

  readonly leftTab = signal<'fleet' | 'sites'>('fleet');
  readonly rightTab = signal<'pipeline' | 'methods' | 'monteCarlo' | 'vision' | 'customer'>('pipeline');
  readonly showNewSiteModal = signal<boolean>(false);

  selectDrone(id: string): void {
    this.missionService.selectDrone(id);
  }

  selectSite(id: string): void {
    this.missionService.selectSite(id);
  }

  submitNewSite(name: string, postcode: string, categoryRaw: string): void {
    const id = `site-${Date.now().toString().slice(-4)}`;
    const category = (categoryRaw || 'INDUSTRIAL_YARD') as DeliverySite['category'];
    const newSite: DeliverySite = {
      id,
      code: `UK-SITE-${Math.floor(100000 + Math.random() * 900000)}`,
      name: name || 'New UK Autonomous Site',
      address: `${name}, Northamptonshire`,
      postcode: postcode || 'NN12 8TN',
      category: category || 'INDUSTRIAL_YARD',
      location: { lat: 52.078, lng: -1.016, altMeters: 142.0 },
      lastSurveyDate: new Date().toISOString().slice(0, 16) + ' UTC',
      siteConfidence: 0.975,
      surfaceAreaM2: 650.0,
      slopeDegrees: 1.2,
      obstacleDensity: 'LOW',
      overheadClearanceMeters: 30.0,
      provenance: {
        source: 'SPITFIRE VISION',
        timestamp: new Date().toISOString(),
        surveyFlightId: `SURVEY-NEW-${id}`,
        reprojectionErrorPx: 0.58,
        featurePointsCount: 5120,
      },
      historicalDeliveriesCount: 0,
      preferredMethod: 'TETHER_DROP',
      secondaryMethod: 'GROUND_LANDING',
      zones: [
        {
          id: `${id}-z1`,
          siteId: id,
          name: 'Primary Designated Platform',
          type: 'GROUND_PAD',
          center: { lat: 52.0781, lng: -1.0161, altMeters: 142.0, x: 0, y: 0, z: 0 },
          radiusMeters: 4.0,
          surfaceFlatnessScore: 98,
          overheadClearanceScore: 99,
          windExposureFactor: 0.4,
          currentStatus: 'APPROVED',
          targetAccuracyReqMeters: 0.5,
        },
      ],
    };

    this.missionService.addNewSite(newSite);
    this.showNewSiteModal.set(false);
    this.rightTab.set('pipeline');
    this.missionService.selectSignatureStep(1);
  }
}
