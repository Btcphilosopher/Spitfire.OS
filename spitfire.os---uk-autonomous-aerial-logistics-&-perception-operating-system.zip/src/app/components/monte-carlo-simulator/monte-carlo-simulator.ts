import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SpitfireRService } from '../../core/services/spitfire-r.service';
import { DeliveryMethodType, MonteCarloResult } from '../../core/models/spitfire.types';

@Component({
  selector: 'app-monte-carlo-simulator',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-neutral-900 border-l border-neutral-800 font-sans text-xs overflow-y-auto p-4 space-y-4">
      <!-- Header -->
      <div>
        <div class="flex items-center justify-between">
          <h3 class="font-bold text-neutral-100 text-sm flex items-center gap-1.5">
            <mat-icon class="!w-4 !h-4 !text-[18px] text-emerald-400">casino</mat-icon>
            spitfireR Monte Carlo Simulator
          </h3>
          <span class="font-mono text-[10px] text-cyan-400 bg-cyan-950/60 border border-cyan-800/50 px-2 py-0.5 rounded">R Engine Module</span>
        </div>
        <p class="text-neutral-400 text-[11px] mt-1 leading-relaxed">
          Stochastic multi-variable simulation (Gaussian wind turbulence, RTK dilution of precision, payload shift, cable oscillation).
        </p>
      </div>

      <!-- Simulator Controls -->
      <div class="bg-neutral-950 border border-neutral-800 rounded-lg p-3 space-y-3 font-mono text-[11px]">
        <div class="grid grid-cols-2 gap-3">
          <div>
            <label for="method-select" class="text-neutral-400 block mb-1">DELIVERY METHOD:</label>
            <select
              id="method-select"
              [value]="selectedMethod()"
              (change)="onMethodSelect($event)"
              class="w-full bg-neutral-900 border border-neutral-700 rounded p-1.5 text-neutral-200 text-xs font-mono outline-none"
            >
              <option value="TETHER_DROP">Tether Drop</option>
              <option value="WINCH_DELIVERY">Winch Delivery</option>
              <option value="GROUND_LANDING">Ground Landing</option>
              <option value="PRECISION_DROP">Precision Drop</option>
              <option value="PRECISION_PLACEMENT">Precision Placement</option>
              <option value="DELIVERY_STATION_DOCK">Automated Station Dock</option>
            </select>
          </div>

          <div>
            <label for="runs-select" class="text-neutral-400 block mb-1">SIMULATION RUNS (N):</label>
            <select
              id="runs-select"
              [value]="simRuns()"
              (change)="onRunsSelect($event)"
              class="w-full bg-neutral-900 border border-neutral-700 rounded p-1.5 text-neutral-200 text-xs font-mono outline-none"
            >
              <option [value]="500">500 Iterations</option>
              <option [value]="1500">1,500 Iterations</option>
              <option [value]="3000">3,000 Iterations</option>
              <option [value]="5000">5,000 Iterations</option>
            </select>
          </div>
        </div>

        <div class="grid grid-cols-2 gap-3 pt-1">
          <div>
            <div class="flex justify-between text-neutral-400 mb-1">
              <span>BASE WIND:</span>
              <span class="text-amber-400">{{ baseWind() }} kts</span>
            </div>
            <input
              type="range"
              min="4"
              max="26"
              step="1"
              [value]="baseWind()"
              (input)="onWindChange($event)"
              class="w-full accent-amber-400 cursor-pointer"
            />
          </div>

          <div>
            <div class="flex justify-between text-neutral-400 mb-1">
              <span>SEED (REPRODUCIBLE):</span>
              <span class="text-cyan-400">{{ seed() }}</span>
            </div>
            <button
              (click)="reseed()"
              class="w-full py-1 bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 rounded text-neutral-300 transition-colors"
            >
              Regenerate Seed
            </button>
          </div>
        </div>
      </div>

      <!-- Simulation Summary Metrics Grid -->
      <div class="grid grid-cols-2 gap-2 font-mono">
        <div class="bg-neutral-950 border border-neutral-800 rounded-lg p-3">
          <div class="text-[10px] text-neutral-500 uppercase tracking-wider">SUCCESS PROBABILITY</div>
          <div class="text-2xl font-bold text-emerald-400 mt-0.5 tabular-nums">{{ simResult().successRatePercent }}%</div>
          <div class="text-[10px] text-neutral-400 mt-1">Over {{ simResult().simulationsCount }} trials</div>
        </div>

        <div class="bg-neutral-950 border border-neutral-800 rounded-lg p-3">
          <div class="text-[10px] text-neutral-500 uppercase tracking-wider">MEAN ACCURACY ERROR</div>
          <div class="text-2xl font-bold text-cyan-400 mt-0.5 tabular-nums">±{{ simResult().meanPositionErrorMeters }}m</div>
          <div class="text-[10px] text-neutral-400 mt-1">P95 Error: ±{{ simResult().p95PositionErrorMeters }}m</div>
        </div>

        <div class="bg-neutral-950 border border-neutral-800 rounded-lg p-3">
          <div class="text-[10px] text-neutral-500 uppercase tracking-wider">EXPECTED MISSION ENERGY</div>
          <div class="text-xl font-bold text-white mt-0.5 tabular-nums">{{ simResult().expectedEnergyCostPercent }}%</div>
          <div class="text-[10px] text-neutral-400 mt-1">P95: {{ simResult().p95EnergyCostPercent }}% · P99: {{ simResult().p99EnergyCostPercent }}%</div>
        </div>

        <div class="bg-neutral-950 border border-neutral-800 rounded-lg p-3">
          <div class="text-[10px] text-neutral-500 uppercase tracking-wider">95% CONFIDENCE ELLIPSE</div>
          <div class="text-lg font-bold text-amber-400 mt-0.5 tabular-nums">
            {{ simResult().confidenceEllipseAxesMeters[0] }}m × {{ simResult().confidenceEllipseAxesMeters[1] }}m
          </div>
          <div class="text-[10px] text-neutral-400 mt-1">Major / Minor Semi-Axes</div>
        </div>
      </div>

      <!-- Histogram Frequency Distribution -->
      <div class="bg-neutral-950 border border-neutral-800 rounded-lg p-3 space-y-2 font-mono">
        <div class="text-neutral-400 text-[11px] uppercase tracking-wider">Landing Error Distribution Histogram</div>
        <div class="space-y-2 pt-1">
          @for (b of simResult().distributionBuckets; track b.errorRange) {
            <div>
              <div class="flex justify-between text-[10px] text-neutral-300 mb-0.5">
                <span>{{ b.errorRange }}</span>
                <span class="text-cyan-400 tabular-nums">{{ b.freq }}% ({{ b.count }} runs)</span>
              </div>
              <div class="w-full bg-neutral-900 rounded-full h-2 overflow-hidden">
                <div
                  class="bg-cyan-500 h-full rounded-full transition-all duration-300"
                  [style.width.%]="b.freq"
                ></div>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Failure Mode Breakdown -->
      <div class="bg-neutral-950 border border-neutral-800 rounded-lg p-3 space-y-2 font-mono text-[11px]">
        <div class="text-neutral-400 uppercase tracking-wider">Failure Mode Attribution</div>
        <div class="space-y-1.5 text-neutral-300">
          <div class="flex justify-between">
            <span class="text-neutral-400">Wind Limits Exceeded (>28 kts):</span>
            <span class="text-amber-400 tabular-nums">{{ simResult().failureBreakdown.windExceededPercent }}%</span>
          </div>
          <div class="flex justify-between">
            <span class="text-neutral-400">Corridor Clearance Breach (>1.2m error):</span>
            <span class="text-red-400 tabular-nums">{{ simResult().failureBreakdown.corridorBreachPercent }}%</span>
          </div>
          <div class="flex justify-between">
            <span class="text-neutral-400">Battery Threshold Breach (<25% RTB):</span>
            <span class="text-red-400 tabular-nums">{{ simResult().failureBreakdown.batteryLowPercent }}%</span>
          </div>
          <div class="flex justify-between">
            <span class="text-neutral-400">GNSS / Optical Uncertainty:</span>
            <span class="text-amber-400 tabular-nums">{{ simResult().failureBreakdown.sensorUncertaintyPercent }}%</span>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class MonteCarloSimulator {
  private spitfireR = inject(SpitfireRService);

  readonly selectedMethod = signal<DeliveryMethodType>('TETHER_DROP');
  readonly simRuns = signal<number>(1500);
  readonly baseWind = signal<number>(12.0);
  readonly seed = signal<number>(2026);

  readonly simResult = computed<MonteCarloResult>(() => {
    return this.spitfireR.runMonteCarloSimulation(
      this.selectedMethod(),
      this.simRuns(),
      this.baseWind(),
      2.0,
      this.seed()
    );
  });

  onMethodSelect(e: Event): void {
    this.selectedMethod.set((e.target as HTMLSelectElement).value as DeliveryMethodType);
  }

  onRunsSelect(e: Event): void {
    this.simRuns.set(Number((e.target as HTMLSelectElement).value));
  }

  onWindChange(e: Event): void {
    this.baseWind.set(Number((e.target as HTMLInputElement).value));
  }

  reseed(): void {
    this.seed.set(Math.floor(1000 + Math.random() * 9000));
  }
}
