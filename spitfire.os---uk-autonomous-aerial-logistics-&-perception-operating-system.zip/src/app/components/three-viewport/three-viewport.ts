import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  PLATFORM_ID,
  ViewChild,
  effect,
  inject,
  signal
} from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { MissionService } from '../../core/services/mission.service';
import { PointCloudPoint, TelemetryFrame } from '../../core/models/spitfire.types';

@Component({
  selector: 'app-three-viewport',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full min-h-[420px] bg-neutral-950 overflow-hidden flex flex-col select-none">
      <!-- Top HUD Overlay Bar -->
      <div class="absolute top-3 left-3 right-3 z-10 flex items-center justify-between pointer-events-none">
        <div class="flex items-center gap-2 bg-neutral-900/85 backdrop-blur-md border border-neutral-800 px-3 py-1.5 rounded-lg text-xs font-mono pointer-events-auto shadow-md">
          <span class="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span class="text-neutral-300 font-semibold tracking-wide">3D SPATIAL DIGITAL TWIN</span>
          <span class="text-neutral-500">·</span>
          <span class="text-neutral-400">{{ activeSite().name }}</span>
          <span class="text-neutral-500">·</span>
          <span class="text-emerald-400">RTK FIX (±1.4cm)</span>
        </div>

        <!-- Layer Toggles -->
        <div class="flex items-center gap-1.5 bg-neutral-900/85 backdrop-blur-md border border-neutral-800 p-1 rounded-lg text-xs pointer-events-auto shadow-md">
          <button
            (click)="toggleLayer('pointCloud')"
            [class.bg-neutral-800]="layers().pointCloud"
            [class.text-white]="layers().pointCloud"
            [class.text-neutral-400]="!layers().pointCloud"
            class="px-2.5 py-1 rounded transition-colors flex items-center gap-1 font-mono text-[11px]"
            title="Toggle Classified 3D Point Cloud"
          >
            <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">grain</mat-icon>
            Points
          </button>
          <button
            (click)="toggleLayer('mesh')"
            [class.bg-neutral-800]="layers().mesh"
            [class.text-white]="layers().mesh"
            [class.text-neutral-400]="!layers().mesh"
            class="px-2.5 py-1 rounded transition-colors flex items-center gap-1 font-mono text-[11px]"
            title="Toggle Reconstructed 3D Mesh Surfaces"
          >
            <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">view_in_ar</mat-icon>
            Mesh
          </button>
          <button
            (click)="toggleLayer('corridor')"
            [class.bg-neutral-800]="layers().corridor"
            [class.text-white]="layers().corridor"
            [class.text-neutral-400]="!layers().corridor"
            class="px-2.5 py-1 rounded transition-colors flex items-center gap-1 font-mono text-[11px]"
            title="Toggle 3D Flight Approach Corridor"
          >
            <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">airplanemode_active</mat-icon>
            Corridor
          </button>
          <button
            (click)="toggleLayer('cameras')"
            [class.bg-neutral-800]="layers().cameras"
            [class.text-white]="layers().cameras"
            [class.text-neutral-400]="!layers().cameras"
            class="px-2.5 py-1 rounded transition-colors flex items-center gap-1 font-mono text-[11px]"
            title="Toggle Photogrammetry Camera Poses"
          >
            <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">videocam</mat-icon>
            Survey Poses
          </button>
        </div>
      </div>

      <!-- 3D Canvas Element -->
      <canvas #renderCanvas class="w-full h-full flex-1 cursor-grab active:cursor-grabbing outline-none"></canvas>

      <!-- Bottom Floating Telemetry Bar on 3D Viewport -->
      <div class="absolute bottom-3 left-3 right-3 z-10 flex items-center justify-between pointer-events-none">
        <div class="flex items-center gap-4 bg-neutral-900/90 backdrop-blur-md border border-neutral-800 px-3.5 py-2 rounded-lg text-xs font-mono pointer-events-auto">
          <div>
            <div class="text-[10px] text-neutral-500 uppercase tracking-wider">AIRCRAFT ALT</div>
            <div class="text-neutral-100 font-semibold tabular-nums">{{ telemetry().altMeters }}m <span class="text-neutral-500 font-normal">AGL</span></div>
          </div>
          <div class="h-6 w-px bg-neutral-800"></div>
          <div>
            <div class="text-[10px] text-neutral-500 uppercase tracking-wider">SPEED</div>
            <div class="text-neutral-100 font-semibold tabular-nums">{{ telemetry().groundSpeedKts }} <span class="text-neutral-500 font-normal">kts</span></div>
          </div>
          <div class="h-6 w-px bg-neutral-800"></div>
          <div>
            <div class="text-[10px] text-neutral-500 uppercase tracking-wider">TETHER EXT</div>
            <div class="text-cyan-400 font-semibold tabular-nums">{{ telemetry().tetherExtensionMeters }}m</div>
          </div>
          <div class="h-6 w-px bg-neutral-800"></div>
          <div>
            <div class="text-[10px] text-neutral-500 uppercase tracking-wider">TENSION</div>
            <div class="text-amber-400 font-semibold tabular-nums">{{ telemetry().tetherTensionNewtons }} N</div>
          </div>
          <div class="h-6 w-px bg-neutral-800"></div>
          <div>
            <div class="text-[10px] text-neutral-500 uppercase tracking-wider">PHASE</div>
            <div class="text-emerald-400 font-semibold truncate max-w-[200px]">{{ telemetry().flightPhase }}</div>
          </div>
        </div>

        <!-- Camera Preset Controls -->
        <div class="flex items-center gap-1 bg-neutral-900/90 backdrop-blur-md border border-neutral-800 p-1 rounded-lg text-xs pointer-events-auto">
          <button (click)="setCameraView('iso')" class="px-2 py-1 text-neutral-300 hover:text-white rounded hover:bg-neutral-800 transition-colors font-mono text-[11px]">ISO</button>
          <button (click)="setCameraView('top')" class="px-2 py-1 text-neutral-300 hover:text-white rounded hover:bg-neutral-800 transition-colors font-mono text-[11px]">TOP-DOWN</button>
          <button (click)="setCameraView('drone')" class="px-2 py-1 text-neutral-300 hover:text-white rounded hover:bg-neutral-800 transition-colors font-mono text-[11px]">DRONE CHASE</button>
          <button (click)="resetView()" class="px-2 py-1 text-neutral-300 hover:text-white rounded hover:bg-neutral-800 transition-colors font-mono text-[11px]">RESET</button>
        </div>
      </div>

      <!-- Point Inspector Overlay when clicking on a point -->
      @if (inspectedPoint()) {
        <div class="absolute top-16 left-3 z-10 bg-neutral-900/95 backdrop-blur-md border border-neutral-700 p-3 rounded-lg text-xs font-mono shadow-xl max-w-xs pointer-events-auto">
          <div class="flex items-center justify-between pb-1.5 border-b border-neutral-800 mb-2">
            <span class="text-emerald-400 font-semibold">SPATIAL OBSERVATION</span>
            <button (click)="inspectedPoint.set(null)" class="text-neutral-500 hover:text-neutral-300">
              <mat-icon class="!w-4 !h-4 !text-[16px]">close</mat-icon>
            </button>
          </div>
          <div class="space-y-1 text-neutral-300">
            <div class="flex justify-between">
              <span class="text-neutral-500">CLASS:</span>
              <span class="text-amber-400 font-semibold">{{ inspectedPoint()?.classification }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-neutral-500">X / Y / Z:</span>
              <span class="text-white tabular-nums">{{ inspectedPoint()?.x?.toFixed(2) }}m / {{ inspectedPoint()?.y?.toFixed(2) }}m / {{ inspectedPoint()?.z?.toFixed(2) }}m</span>
            </div>
            <div class="flex justify-between">
              <span class="text-neutral-500">CONFIDENCE:</span>
              <span class="text-emerald-400 tabular-nums">{{ ((inspectedPoint()?.confidence || 0) * 100).toFixed(1) }}%</span>
            </div>
            <div class="flex justify-between">
              <span class="text-neutral-500">SURFACE NORMAL:</span>
              <span class="text-neutral-400">[0.0, 1.0, 0.0]</span>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class ThreeViewport implements OnInit, OnDestroy {
  @ViewChild('renderCanvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;

  private missionService = inject(MissionService);
  private platformId = inject(PLATFORM_ID);

  readonly activeSite = this.missionService.selectedSite;
  readonly activeSurvey = this.missionService.currentSurvey;
  readonly telemetry = this.missionService.liveTelemetry;
  readonly simProgress = this.missionService.simulationProgress;

  readonly layers = signal<{
    pointCloud: boolean;
    mesh: boolean;
    corridor: boolean;
    cameras: boolean;
    drone: boolean;
  }>({
    pointCloud: true,
    mesh: true,
    corridor: true,
    cameras: true,
    drone: true,
  });

  readonly inspectedPoint = signal<PointCloudPoint | null>(null);

  // Three.js instances
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animFrameId: number | null = null;

  // Visual scene groups
  private pointCloudGroup = new THREE.Group();
  private meshGroup = new THREE.Group();
  private corridorGroup = new THREE.Group();
  private cameraPosesGroup = new THREE.Group();
  private droneGroup = new THREE.Group();
  private tetherLine!: THREE.Line;
  private payloadBox!: THREE.Mesh;
  private rotors: THREE.Mesh[] = [];

  // Orbit navigation state
  private isDragging = false;
  private isPanning = false;
  private previousMousePosition = { x: 0, y: 0 };
  private cameraSpherical = { radius: 45, theta: Math.PI / 4, phi: Math.PI / 3 };
  private cameraTarget = new THREE.Vector3(0, 4, 0);

  constructor() {
    // Effect to update 3D scene whenever survey or site changes
    effect(() => {
      const survey = this.activeSurvey();
      if (isPlatformBrowser(this.platformId)) {
        this.rebuildScene(survey.points);
      }
    });

    // Effect to update drone position and tether in 3D scene from telemetry
    effect(() => {
      const telem = this.telemetry();
      const prog = this.simProgress();
      if (isPlatformBrowser(this.platformId)) {
        this.updateDroneIn3D(telem, prog);
      }
    });
  }

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.initThreeJs();
      this.setupEventListeners();
    }
  }

  ngOnDestroy(): void {
    if (this.animFrameId !== null && isPlatformBrowser(this.platformId)) {
      cancelAnimationFrame(this.animFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  toggleLayer(layer: 'pointCloud' | 'mesh' | 'corridor' | 'cameras' | 'drone'): void {
    this.layers.update((l) => ({ ...l, [layer]: !l[layer] }));
    this.pointCloudGroup.visible = this.layers().pointCloud;
    this.meshGroup.visible = this.layers().mesh;
    this.corridorGroup.visible = this.layers().corridor;
    this.cameraPosesGroup.visible = this.layers().cameras;
    this.droneGroup.visible = this.layers().drone;
  }

  private initThreeJs(): void {
    if (!isPlatformBrowser(this.platformId)) return;
    const canvas = this.canvasRef.nativeElement;
    const width = canvas.clientWidth || 800;
    const height = canvas.clientHeight || 500;

    // Scene setup
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a0a0c);
    this.scene.fog = new THREE.FogExp2(0x0a0a0c, 0.008);

    // Camera setup
    this.camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
    this.updateCameraTransform();

    // WebGL Renderer setup
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // Lighting (Aerospace studio rig)
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xfffaed, 1.4);
    dirLight.position.set(30, 50, 25);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    this.scene.add(dirLight);

    const fillLight = new THREE.DirectionalLight(0x7090b0, 0.6);
    fillLight.position.set(-25, 30, -25);
    this.scene.add(fillLight);

    // Ground Reference Grid
    const gridHelper = new THREE.GridHelper(80, 40, 0x334155, 0x1e293b);
    gridHelper.position.y = -0.05;
    this.scene.add(gridHelper);

    // Add Scene Groups
    this.scene.add(this.pointCloudGroup);
    this.scene.add(this.meshGroup);
    this.scene.add(this.corridorGroup);
    this.scene.add(this.cameraPosesGroup);
    this.scene.add(this.droneGroup);

    this.buildDroneModel();
    this.rebuildScene(this.activeSurvey().points);

    // Start Render Loop
    this.animate();
  }

  private updateCameraTransform(): void {
    const { radius, theta, phi } = this.cameraSpherical;
    const x = this.cameraTarget.x + radius * Math.sin(phi) * Math.sin(theta);
    const y = this.cameraTarget.y + radius * Math.cos(phi);
    const z = this.cameraTarget.z + radius * Math.sin(phi) * Math.cos(theta);
    this.camera.position.set(x, y, z);
    this.camera.lookAt(this.cameraTarget);
  }

  private rebuildScene(points: PointCloudPoint[]): void {
    if (!this.scene) return;

    // Clear old geometry
    while (this.pointCloudGroup.children.length > 0) {
      const obj = this.pointCloudGroup.children[0];
      this.pointCloudGroup.remove(obj);
    }
    while (this.meshGroup.children.length > 0) {
      const obj = this.meshGroup.children[0];
      this.meshGroup.remove(obj);
    }
    while (this.corridorGroup.children.length > 0) {
      const obj = this.corridorGroup.children[0];
      this.corridorGroup.remove(obj);
    }
    while (this.cameraPosesGroup.children.length > 0) {
      const obj = this.cameraPosesGroup.children[0];
      this.cameraPosesGroup.remove(obj);
    }

    // 1. Build Classified Point Cloud Buffer
    const pointCount = points.length;
    const positions = new Float32Array(pointCount * 3);
    const colors = new Float32Array(pointCount * 3);

    points.forEach((pt, i) => {
      positions[i * 3] = pt.x;
      positions[i * 3 + 1] = pt.y;
      positions[i * 3 + 2] = pt.z;

      // Map classifications to British Aerospace color tokens
      let r = pt.r / 255;
      let g = pt.g / 255;
      let b = pt.b / 255;

      if (pt.classification === 'DELIVERY_SURFACE') {
        r = 0.15; g = 0.88; b = 0.45; // Vibrant Green
      } else if (pt.classification === 'ROOF') {
        r = 0.85; g = 0.38; b = 0.28; // Brick Red
      } else if (pt.classification === 'BUILDING') {
        r = 0.75; g = 0.75; b = 0.82; // Concrete Grey
      } else if (pt.classification === 'VEHICLE') {
        r = 0.25; g = 0.55; b = 0.95; // Blue
      }

      colors[i * 3] = r;
      colors[i * 3 + 1] = g;
      colors[i * 3 + 2] = b;
    });

    const pointGeometry = new THREE.BufferGeometry();
    pointGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    pointGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const pointMaterial = new THREE.PointsMaterial({
      size: 0.22,
      vertexColors: true,
      transparent: true,
      opacity: 0.9,
    });

    const pointCloud = new THREE.Points(pointGeometry, pointMaterial);
    this.pointCloudGroup.add(pointCloud);

    // 2. Build 3D Reconstructed Mesh Shapes (House, Roof, Lawn Pad, Driveway, Vehicle)
    // House Body Mesh
    const houseGeo = new THREE.BoxGeometry(11, 6.5, 10);
    const houseMat = new THREE.MeshStandardMaterial({
      color: 0xd6d3d1,
      roughness: 0.7,
      metalness: 0.1,
      wireframe: false,
    });
    const houseMesh = new THREE.Mesh(houseGeo, houseMat);
    houseMesh.position.set(0.5, 3.25, 2.0);
    houseMesh.castShadow = true;
    houseMesh.receiveShadow = true;
    this.meshGroup.add(houseMesh);

    // Pitched Roof Mesh
    const roofGeo = new THREE.ConeGeometry(8.2, 3.4, 4);
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.6 });
    const roofMesh = new THREE.Mesh(roofGeo, roofMat);
    roofMesh.position.set(0.5, 8.2, 2.0);
    roofMesh.rotation.y = Math.PI / 4;
    this.meshGroup.add(roofMesh);

    // Delivery Target Pad (Lawn Zone)
    const targetGeo = new THREE.CylinderGeometry(3.2, 3.2, 0.08, 32);
    const targetMat = new THREE.MeshStandardMaterial({
      color: 0x10b981,
      transparent: true,
      opacity: 0.45,
      roughness: 0.3,
    });
    const targetPad = new THREE.Mesh(targetGeo, targetMat);
    targetPad.position.set(2.4, 0.04, -4.8);
    this.meshGroup.add(targetPad);

    // Target Bullseye Ring
    const ringGeo = new THREE.RingGeometry(2.9, 3.1, 32);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x34d399, side: THREE.DoubleSide });
    const ringMesh = new THREE.Mesh(ringGeo, ringMat);
    ringMesh.rotation.x = -Math.PI / 2;
    ringMesh.position.set(2.4, 0.09, -4.8);
    this.meshGroup.add(ringMesh);

    // Target Crosshair
    const crossGeo = new THREE.PlaneGeometry(0.1, 4.0);
    const crossMat = new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide });
    const cross1 = new THREE.Mesh(crossGeo, crossMat);
    cross1.rotation.x = -Math.PI / 2;
    cross1.position.set(2.4, 0.1, -4.8);
    const cross2 = new THREE.Mesh(crossGeo, crossMat);
    cross2.rotation.x = -Math.PI / 2;
    cross2.rotation.z = Math.PI / 2;
    cross2.position.set(2.4, 0.1, -4.8);
    this.meshGroup.add(cross1);
    this.meshGroup.add(cross2);

    // Vehicle Obstacle in Driveway
    const carGeo = new THREE.BoxGeometry(2.4, 1.4, 4.6);
    const carMat = new THREE.MeshStandardMaterial({ color: 0x1e3a8a, metalness: 0.7, roughness: 0.3 });
    const carMesh = new THREE.Mesh(carGeo, carMat);
    carMesh.position.set(-8.0, 0.7, 8.5);
    this.meshGroup.add(carMesh);

    // 3. Build 3D Volumetric Approach Corridor (Semi-transparent funnel from 35m down to 0m)
    const corridorPoints = [
      new THREE.Vector3(-25, 30, -35),
      new THREE.Vector3(-10, 22, -20),
      new THREE.Vector3(2.4, 15, -4.8),
      new THREE.Vector3(2.4, 0.2, -4.8),
    ];
    const curve = new THREE.CatmullRomCurve3(corridorPoints);
    const tubeGeo = new THREE.TubeGeometry(curve, 30, 2.5, 12, false);
    const tubeMat = new THREE.MeshBasicMaterial({
      color: 0x06b6d4,
      transparent: true,
      opacity: 0.18,
      wireframe: true,
    });
    const corridorTube = new THREE.Mesh(tubeGeo, tubeMat);
    this.corridorGroup.add(corridorTube);

    // 4. Build Photogrammetry Survey Camera Frustums
    const survey = this.activeSurvey();
    survey.cameraPoses.forEach((pose) => {
      const camHelper = new THREE.CameraHelper(new THREE.PerspectiveCamera(50, 1.33, 1, 6));
      camHelper.position.set(pose.pos.x || 0, (pose.pos.y || 25) * 0.7, pose.pos.z || 0);
      camHelper.lookAt(0, 3, 0);
      this.cameraPosesGroup.add(camHelper);
    });
  }

  private buildDroneModel(): void {
    // Airframe Center
    const bodyGeo = new THREE.BoxGeometry(1.2, 0.25, 1.2);
    const bodyMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8, roughness: 0.2 });
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    this.droneGroup.add(body);

    // Avionics Pod / Sensor Gimbal
    const domeGeo = new THREE.SphereGeometry(0.35, 16, 16);
    const domeMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.9, roughness: 0.1 });
    const dome = new THREE.Mesh(domeGeo, domeMat);
    dome.position.y = -0.15;
    this.droneGroup.add(dome);

    // 4 Rotor Arms & Propellers
    const armGeo = new THREE.CylinderGeometry(0.05, 0.05, 1.8);
    const armMat = new THREE.MeshStandardMaterial({ color: 0x475569 });

    const arm1 = new THREE.Mesh(armGeo, armMat);
    arm1.rotation.z = Math.PI / 2;
    arm1.rotation.y = Math.PI / 4;
    this.droneGroup.add(arm1);

    const arm2 = new THREE.Mesh(armGeo, armMat);
    arm2.rotation.z = Math.PI / 2;
    arm2.rotation.y = -Math.PI / 4;
    this.droneGroup.add(arm2);

    // Rotors
    this.rotors = [];
    const rotorOffsets = [
      { x: 0.9, z: 0.9 },
      { x: -0.9, z: 0.9 },
      { x: 0.9, z: -0.9 },
      { x: -0.9, z: -0.9 },
    ];
    rotorOffsets.forEach((offset) => {
      const rGeo = new THREE.BoxGeometry(0.8, 0.02, 0.08);
      const rMat = new THREE.MeshBasicMaterial({ color: 0x94a3b8 });
      const rotor = new THREE.Mesh(rGeo, rMat);
      rotor.position.set(offset.x, 0.15, offset.z);
      this.droneGroup.add(rotor);
      this.rotors.push(rotor);
    });

    // Tether Line & Payload Box
    const tetherGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(0, 0, 0),
      new THREE.Vector3(0, -1, 0),
    ]);
    const tetherMat = new THREE.LineBasicMaterial({ color: 0x38bdf8, linewidth: 2 });
    this.tetherLine = new THREE.Line(tetherGeo, tetherMat);
    this.droneGroup.add(this.tetherLine);

    const payloadGeo = new THREE.BoxGeometry(0.4, 0.3, 0.3);
    const payloadMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.4 });
    this.payloadBox = new THREE.Mesh(payloadGeo, payloadMat);
    this.payloadBox.position.set(0, -0.2, 0);
    this.droneGroup.add(this.payloadBox);

    // Default drone position
    this.droneGroup.position.set(2.4, 18, -4.8);
  }

  private updateDroneIn3D(telem: TelemetryFrame, progress: number): void {
    if (!this.droneGroup) return;

    // Calculate 3D position along the route
    let x = 2.4;
    let y = 18.0;
    let z = -4.8;

    if (progress < 0.2) {
      // Ascending from Depot
      const sub = progress / 0.2;
      x = -25 + sub * 10;
      y = 10 + sub * 15;
      z = -35 + sub * 15;
    } else if (progress < 0.6) {
      // Cruising along corridor
      const sub = (progress - 0.2) / 0.4;
      x = -15 + sub * 17.4;
      y = 25 - sub * 7;
      z = -20 + sub * 15.2;
    } else if (progress < 0.85) {
      // Hovering directly above Lawn Zone A during tether delivery
      x = 2.4;
      y = 18.0;
      z = -4.8;
    } else {
      // RTB
      const sub = (progress - 0.85) / 0.15;
      x = 2.4 - sub * 25;
      y = 18.0 + sub * 8;
      z = -4.8 - sub * 30;
    }

    this.droneGroup.position.set(x, y, z);
    this.droneGroup.rotation.y = (telem.headingDeg * Math.PI) / 180;
    this.droneGroup.rotation.x = (telem.pitchDeg * Math.PI) / 180;
    this.droneGroup.rotation.z = (telem.rollDeg * Math.PI) / 180;

    // Update tether extension line & payload position
    const tetherLen = (telem.tetherExtensionMeters || 0) * 0.75; // scale for visualization
    const sway = Math.sin(Date.now() * 0.005) * 0.15;

    if (tetherLen > 0.1) {
      this.tetherLine.visible = true;
      this.payloadBox.visible = true;
      const positions = new Float32Array([0, 0, 0, sway, -tetherLen, 0]);
      this.tetherLine.geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      this.payloadBox.position.set(sway, -tetherLen, 0);
    } else {
      this.tetherLine.visible = false;
      this.payloadBox.position.set(0, -0.2, 0);
      this.payloadBox.visible = progress < 0.8; // released after delivery
    }
  }

  private animate = (): void => {
    if (!isPlatformBrowser(this.platformId)) return;
    this.animFrameId = requestAnimationFrame(this.animate);

    // Rotate propellers
    this.rotors.forEach((rotor, idx) => {
      rotor.rotation.y += (idx % 2 === 0 ? 1 : -1) * 0.4;
    });

    if (this.renderer && this.scene && this.camera) {
      this.renderer.render(this.scene, this.camera);
    }
  };

  private setupEventListeners(): void {
    if (!isPlatformBrowser(this.platformId)) return;
    const canvas = this.canvasRef.nativeElement;

    canvas.addEventListener('mousedown', (e) => {
      if (e.button === 0) this.isDragging = true;
      if (e.button === 2) this.isPanning = true;
      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
      this.isPanning = false;
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.isDragging && !this.isPanning) return;

      const deltaX = e.clientX - this.previousMousePosition.x;
      const deltaY = e.clientY - this.previousMousePosition.y;

      if (this.isDragging) {
        this.cameraSpherical.theta -= deltaX * 0.008;
        this.cameraSpherical.phi = Math.max(0.1, Math.min(Math.PI / 2 - 0.05, this.cameraSpherical.phi - deltaY * 0.008));
        this.updateCameraTransform();
      } else if (this.isPanning) {
        const factor = this.cameraSpherical.radius * 0.0015;
        this.cameraTarget.x -= deltaX * factor;
        this.cameraTarget.z += deltaY * factor;
        this.updateCameraTransform();
      }

      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.cameraSpherical.radius = Math.max(8, Math.min(120, this.cameraSpherical.radius + e.deltaY * 0.05));
      this.updateCameraTransform();
    }, { passive: false });

    // Window resize observer
    if (typeof ResizeObserver !== 'undefined') {
      const resizeObserver = new ResizeObserver(() => {
        if (!this.renderer || !canvas) return;
        const w = canvas.clientWidth;
        const h = canvas.clientHeight;
        this.camera.aspect = w / h;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(w, h);
      });
      resizeObserver.observe(canvas);
    }

    // Canvas click raycasting for point inspector
    canvas.addEventListener('click', (e) => {
      const rect = canvas.getBoundingClientRect();
      const mouse = new THREE.Vector2(
        ((e.clientX - rect.left) / rect.width) * 2 - 1,
        -((e.clientY - rect.top) / rect.height) * 2 + 1
      );
      const raycaster = new THREE.Raycaster();
      raycaster.params.Points = { threshold: 0.8 };
      raycaster.setFromCamera(mouse, this.camera);
      const intersects = raycaster.intersectObjects(this.pointCloudGroup.children);

      if (intersects.length > 0 && intersects[0].index !== undefined) {
        const idx = intersects[0].index;
        const survey = this.activeSurvey();
        if (survey.points[idx]) {
          this.inspectedPoint.set(survey.points[idx]);
        }
      }
    });

    canvas.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  setCameraView(view: 'iso' | 'top' | 'drone'): void {
    if (view === 'iso') {
      this.cameraSpherical = { radius: 45, theta: Math.PI / 4, phi: Math.PI / 3 };
      this.cameraTarget.set(0, 4, 0);
    } else if (view === 'top') {
      this.cameraSpherical = { radius: 55, theta: 0, phi: 0.02 };
      this.cameraTarget.set(2, 0, -2);
    } else if (view === 'drone') {
      const dp = this.droneGroup.position;
      this.cameraSpherical = { radius: 12, theta: Math.PI / 3, phi: Math.PI / 2.8 };
      this.cameraTarget.set(dp.x, dp.y, dp.z);
    }
    this.updateCameraTransform();
  }

  resetView(): void {
    this.setCameraView('iso');
  }
}

