import {
  ChangeDetectionStrategy,
  Component,
  inject
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MissionService } from '../../core/services/mission.service';

@Component({
  selector: 'app-customer-portal',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-neutral-950 text-neutral-100 font-sans overflow-y-auto p-6 max-w-4xl mx-auto space-y-6">
      <!-- Top Brand Header -->
      <div class="flex items-center justify-between border-b border-neutral-800 pb-4">
        <div class="flex items-center gap-3">
          <div class="w-9 h-9 rounded-lg bg-neutral-900 border border-neutral-700 flex items-center justify-center font-black text-cyan-400 font-mono tracking-widest text-sm shadow-md">
            SPF
          </div>
          <div>
            <h1 class="text-lg font-bold tracking-tight text-white">SPITFIRE EXPRESS DELIVERY</h1>
            <div class="text-xs text-neutral-400">Autonomous Aerial Logistics · United Kingdom</div>
          </div>
        </div>
        <div class="text-right font-mono text-xs">
          <div class="text-neutral-500">TRACKING NUMBER</div>
          <div class="text-cyan-400 font-bold">GB-SPF-8849-2026</div>
        </div>
      </div>

      <!-- Main Tracking Status Card -->
      <div class="bg-neutral-900 border border-neutral-800 rounded-xl p-6 shadow-xl space-y-6">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div class="text-xs font-mono text-neutral-400 uppercase tracking-wider">ESTIMATED DELIVERY TIME</div>
            <div class="text-3xl font-bold text-white mt-1 tabular-nums">
              {{ simProgress() >= 0.8 ? 'DELIVERED AT 14:42' : 'TODAY, 14:42 UTC' }}
            </div>
            <div class="text-xs text-emerald-400 mt-1 flex items-center gap-1.5">
              <span class="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
              {{ simProgress() >= 0.8 ? 'Package safely lowered to garden platform' : 'Spitfire M4 aircraft in transit to Woodstock Road' }}
            </div>
          </div>

          <div class="bg-neutral-950 border border-neutral-800 rounded-lg p-3 font-mono text-xs space-y-1">
            <div class="text-neutral-500">DELIVERY MECHANISM</div>
            <div class="text-cyan-300 font-semibold flex items-center gap-1">
              <mat-icon class="!w-4 !h-4 !text-[16px]">vertical_align_bottom</mat-icon>
              Precision Controlled Tether Lowering
            </div>
            <div class="text-neutral-400 text-[11px]">Zero ground rotor hazard · Quiet descent</div>
          </div>
        </div>

        <!-- 4-Stage Progress Timeline -->
        <div class="relative pt-4">
          <div class="absolute top-7 left-4 right-4 h-0.5 bg-neutral-800"></div>
          <div
            class="absolute top-7 left-4 h-0.5 bg-cyan-400 transition-all duration-500"
            [style.width.%]="simProgress() >= 0.8 ? 100 : simProgress() >= 0.2 ? 66 : 33"
          ></div>

          <div class="relative grid grid-cols-4 text-center">
            <!-- Stage 1 -->
            <div class="flex flex-col items-center">
              <div class="w-7 h-7 rounded-full bg-cyan-500 text-neutral-950 flex items-center justify-center font-bold text-xs mb-2">
                <mat-icon class="!w-4 !h-4 !text-[16px]">check</mat-icon>
              </div>
              <div class="text-xs font-semibold text-white">Dispatched</div>
              <div class="text-[11px] text-neutral-500 font-mono">Depot 01 (Culham)</div>
            </div>

            <!-- Stage 2 -->
            <div class="flex flex-col items-center">
              <div class="w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs mb-2" [class.bg-cyan-500]="simProgress() >= 0.2" [class.text-neutral-950]="simProgress() >= 0.2" [class.bg-neutral-800]="simProgress() < 0.2" [class.text-neutral-400]="simProgress() < 0.2">
                <mat-icon class="!w-4 !h-4 !text-[16px]">flight</mat-icon>
              </div>
              <div class="text-xs font-semibold" [class.text-white]="simProgress() >= 0.2" [class.text-neutral-500]="simProgress() < 0.2">In Flight</div>
              <div class="text-[11px] text-neutral-500 font-mono">90m Corridor</div>
            </div>

            <!-- Stage 3 -->
            <div class="flex flex-col items-center">
              <div class="w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs mb-2" [class.bg-cyan-500]="simProgress() >= 0.6" [class.text-neutral-950]="simProgress() >= 0.6" [class.bg-neutral-800]="simProgress() < 0.6" [class.text-neutral-400]="simProgress() < 0.6">
                <mat-icon class="!w-4 !h-4 !text-[16px]">pin_drop</mat-icon>
              </div>
              <div class="text-xs font-semibold" [class.text-white]="simProgress() >= 0.6" [class.text-neutral-500]="simProgress() < 0.6">Arriving</div>
              <div class="text-[11px] text-neutral-500 font-mono">Woodstock Rd</div>
            </div>

            <!-- Stage 4 -->
            <div class="flex flex-col items-center">
              <div class="w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs mb-2" [class.bg-emerald-500]="simProgress() >= 0.8" [class.text-neutral-950]="simProgress() >= 0.8" [class.bg-neutral-800]="simProgress() < 0.8" [class.text-neutral-400]="simProgress() < 0.8">
                <mat-icon class="!w-4 !h-4 !text-[16px]">done_all</mat-icon>
              </div>
              <div class="text-xs font-semibold" [class.text-emerald-400]="simProgress() >= 0.8" [class.text-neutral-500]="simProgress() < 0.8">Delivered</div>
              <div class="text-[11px] text-neutral-500 font-mono">Verified Safe</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Package & Location Details Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div class="bg-neutral-900 border border-neutral-800 rounded-xl p-5 space-y-3">
          <div class="text-xs font-semibold text-neutral-300 uppercase tracking-wider font-mono">Delivery Location</div>
          <div class="space-y-1">
            <div class="font-bold text-white text-base">The Gables, Woodstock Road</div>
            <div class="text-neutral-400 text-xs">Oxford, Oxfordshire, OX2 6NN</div>
            <div class="text-neutral-400 text-xs">Designated Zone: Rear Garden Lawn Platform</div>
          </div>
          <div class="pt-2 border-t border-neutral-800 flex items-center gap-2 text-xs text-neutral-400">
            <mat-icon class="!w-4 !h-4 !text-[16px] text-emerald-400">lock</mat-icon>
            <span>Pre-screened with 3D SPITFIRE.OS Photogrammetry (96.8% confidence)</span>
          </div>
        </div>

        <div class="bg-neutral-900 border border-neutral-800 rounded-xl p-5 space-y-3">
          <div class="text-xs font-semibold text-neutral-300 uppercase tracking-wider font-mono">Package Details</div>
          <div class="space-y-1 text-xs">
            <div class="flex justify-between">
              <span class="text-neutral-400">Recipient:</span>
              <span class="text-white font-medium">Dr. Eleanor Vance</span>
            </div>
            <div class="flex justify-between">
              <span class="text-neutral-400">Contents:</span>
              <span class="text-white font-medium">Critical Medical Diagnostic Kit (Cold-chain)</span>
            </div>
            <div class="flex justify-between">
              <span class="text-neutral-400">Mass:</span>
              <span class="text-white font-mono">1.85 kg</span>
            </div>
            <div class="flex justify-between">
              <span class="text-neutral-400">Carrier Aircraft:</span>
              <span class="text-cyan-400 font-mono">Spitfire M4 (G-SPIT-042)</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Verified Digital Delivery Receipt -->
      @if (simProgress() >= 0.8) {
        <div class="bg-emerald-950/30 border border-emerald-500/40 rounded-xl p-5 space-y-3 shadow-lg">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2 text-emerald-400 font-bold">
              <mat-icon class="!w-5 !h-5 !text-[20px]">verified</mat-icon>
              <span>Verified Digital Proof of Delivery</span>
            </div>
            <span class="font-mono text-xs text-emerald-300 bg-emerald-900/60 px-2 py-0.5 rounded border border-emerald-700">CAA COMPLIANT</span>
          </div>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-3 font-mono text-xs text-neutral-300 pt-2 border-t border-emerald-900/50">
            <div>TOUCHDOWN TIME: <span class="text-white">14:42:18 UTC</span></div>
            <div>POSITION ACCURACY: <span class="text-emerald-400">0.28m (Target Center)</span></div>
            <div>VERIFICATION: <span class="text-white">Computer Vision Lock</span></div>
          </div>
        </div>
      }
    </div>
  `,
})
export class CustomerPortal {
  private missionService = inject(MissionService);

  readonly simProgress = this.missionService.simulationProgress;
}
