import {
  ChangeDetectionStrategy,
  Component,
  inject,
  signal
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MissionService } from '../../core/services/mission.service';

@Component({
  selector: 'app-signature-flow',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-neutral-900 border-r border-neutral-800 font-sans text-xs">
      <!-- Header -->
      <div class="p-3 border-b border-neutral-800 bg-neutral-950/40">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <span class="w-2 h-2 rounded-full bg-cyan-400"></span>
            <span class="font-bold text-neutral-200 uppercase tracking-wider text-[11px]">Workflow Pipeline</span>
          </div>
          <span class="font-mono text-[10px] text-neutral-400">STEP {{ currentStep() }} / 11</span>
        </div>
        <div class="text-neutral-400 text-[11px] mt-1">SCAN → RECONSTRUCT → PLAN → DELIVER</div>
      </div>

      <!-- Step Navigation Pills / Stepper -->
      <div class="p-2 border-b border-neutral-800 bg-neutral-900/90 overflow-x-auto">
        <div class="flex items-center gap-1 min-w-max">
          @for (s of stepTitles; track $index) {
            <button
              (click)="goToStep($index + 1)"
              [class.bg-cyan-950]="currentStep() === $index + 1"
              [class.border-cyan-500]="currentStep() === $index + 1"
              [class.text-cyan-200]="currentStep() === $index + 1"
              [class.bg-neutral-950]="currentStep() !== $index + 1"
              [class.border-neutral-800]="currentStep() !== $index + 1"
              [class.text-neutral-400]="currentStep() !== $index + 1"
              class="px-2 py-1 rounded border text-[10px] font-mono transition-colors flex items-center gap-1 hover:border-neutral-600"
            >
              <span>{{ $index + 1 }}.</span>
              <span>{{ s }}</span>
            </button>
          }
        </div>
      </div>

      <!-- Step Content Body -->
      <div class="flex-1 overflow-y-auto p-4 space-y-4">
        <!-- STEP 1: Survey Flight Planning -->
        @if (currentStep() === 1) {
          <div class="space-y-3">
            <div class="text-sm font-semibold text-white">01. Autonomous Aerial Survey Definition</div>
            <p class="text-neutral-400 leading-relaxed">
              Define the target area bounds for photogrammetric capture. SPITFIRE.OS generates a high-overlap (80% forward, 75% lateral) serpentine survey grid.
            </p>

            <div class="bg-neutral-950 border border-neutral-800 rounded-lg p-3 space-y-2 font-mono">
              <div class="text-neutral-400 text-[11px] uppercase tracking-wider">Flight Parameters</div>
              <div class="grid grid-cols-2 gap-2 text-neutral-300">
                <div>SURVEY ALTITUDE: <span class="text-white">35.0m AGL</span></div>
                <div>GSD RESOLUTION: <span class="text-emerald-400">0.82 cm/px</span></div>
                <div>FLIGHT SPEED: <span class="text-white">14.0 kts</span></div>
                <div>CAMERA PITCH: <span class="text-cyan-400">-65° Oblique / Nadir</span></div>
                <div>EST. IMAGES: <span class="text-white">38 Frames</span></div>
                <div>AIRSPACE: <span class="text-emerald-400">CLASS G - AUTHORISED</span></div>
              </div>
            </div>

            <div class="p-3 bg-neutral-950/60 border border-neutral-800 rounded-lg flex items-center justify-between">
              <div>
                <div class="text-neutral-300 font-medium">Assigned Survey Aircraft</div>
                <div class="text-neutral-500 font-mono">SPF-089 (Spitfire Survey-Pro) · RTK GNSS</div>
              </div>
              <button (click)="goToStep(2)" class="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white font-medium rounded text-xs transition-colors flex items-center gap-1.5">
                <mat-icon class="!w-4 !h-4 !text-[16px]">play_arrow</mat-icon>
                Execute Survey
              </button>
            </div>
          </div>
        }

        <!-- STEP 2: Synthetic Camera Imagery Capture -->
        @if (currentStep() === 2) {
          <div class="space-y-3">
            <div class="text-sm font-semibold text-white">02. Multi-Angle Photogrammetric Image Acquisition</div>
            <p class="text-neutral-400 leading-relaxed">
              38 calibrated stereo/oblique frames captured with embedded RTK coordinates, IMU orientation, and timestamped EXIF telemetry.
            </p>

            <div class="grid grid-cols-2 gap-2">
              <div class="bg-neutral-950 border border-neutral-800 rounded p-2 text-center">
                <div class="h-20 bg-neutral-900 rounded flex items-center justify-center text-neutral-500 font-mono text-[10px] relative overflow-hidden">
                  <div class="absolute inset-0 bg-tech-grid opacity-30"></div>
                  <span>CAM-01 (Nadir 90°)</span>
                </div>
                <div class="text-[10px] font-mono text-neutral-400 mt-1">GSD: 0.78cm · Lat: 51.7648</div>
              </div>
              <div class="bg-neutral-950 border border-neutral-800 rounded p-2 text-center">
                <div class="h-20 bg-neutral-900 rounded flex items-center justify-center text-neutral-500 font-mono text-[10px] relative overflow-hidden">
                  <div class="absolute inset-0 bg-tech-grid opacity-30"></div>
                  <span>CAM-02 (Oblique 55° N)</span>
                </div>
                <div class="text-[10px] font-mono text-neutral-400 mt-1">GSD: 0.85cm · Feature Count: 1,420</div>
              </div>
            </div>

            <div class="p-3 bg-neutral-950 border border-neutral-800 rounded-lg space-y-1 font-mono text-[11px]">
              <div class="flex justify-between text-neutral-400">
                <span>IMAGE QUALITY METRIC:</span>
                <span class="text-emerald-400 font-bold">98.4% (Sharp / Zero Blur)</span>
              </div>
              <div class="flex justify-between text-neutral-400">
                <span>STEREO PARALLAX BASELINE:</span>
                <span class="text-neutral-200">12.4m</span>
              </div>
            </div>

            <button (click)="goToStep(3)" class="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-medium rounded text-xs transition-colors flex items-center justify-center gap-1.5">
              <mat-icon class="!w-4 !h-4 !text-[16px]">view_in_ar</mat-icon>
              Run Photogrammetry Pipeline
            </button>
          </div>
        }

        <!-- STEP 3: 3D Photogrammetry & Bundle Adjustment -->
        @if (currentStep() === 3) {
          <div class="space-y-3">
            <div class="text-sm font-semibold text-white">03. Structure from Motion & Bundle Adjustment</div>
            <p class="text-neutral-400 leading-relaxed">
              The photogrammetry engine extracts feature descriptors (SIFT/ORB), solves camera intrinsic/extrinsic parameters, and computes dense multi-view stereo depth maps.
            </p>

            <div class="bg-neutral-950 border border-neutral-800 rounded-lg p-3 space-y-2 font-mono text-[11px]">
              <div class="text-neutral-400 uppercase tracking-wider">Survey Quality Metrics</div>
              <div class="space-y-1.5 text-neutral-300">
                <div class="flex justify-between">
                  <span>FEATURE MATCHING:</span>
                  <span class="text-emerald-400">95.2%</span>
                </div>
                <div class="flex justify-between">
                  <span>REPROJECTION ERROR:</span>
                  <span class="text-emerald-400 font-bold">0.64 px (Sub-pixel)</span>
                </div>
                <div class="flex justify-between">
                  <span>DEPTH MAP CONFIDENCE:</span>
                  <span class="text-emerald-400">93.8%</span>
                </div>
                <div class="flex justify-between">
                  <span>POINT CLOUD DENSITY:</span>
                  <span class="text-white">1,840 pts/m²</span>
                </div>
              </div>
            </div>

            <button (click)="goToStep(4)" class="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-medium rounded text-xs transition-colors flex items-center justify-center gap-1.5">
              <mat-icon class="!w-4 !h-4 !text-[16px]">category</mat-icon>
              Classify Spatial Geometry
            </button>
          </div>
        }

        <!-- STEP 4: Object Classification -->
        @if (currentStep() === 4) {
          <div class="space-y-3">
            <div class="text-sm font-semibold text-white">04. 3D Semantic Object Classification</div>
            <p class="text-neutral-400 leading-relaxed">
              Every 3D point is categorized using geometric normal estimation and spatial clustering:
            </p>

            <div class="grid grid-cols-2 gap-2 font-mono text-[11px]">
              <div class="p-2 bg-neutral-950 border border-neutral-800 rounded flex items-center justify-between">
                <span class="text-emerald-400">● DELIVERY LAWN</span>
                <span class="text-neutral-400">420 pts</span>
              </div>
              <div class="p-2 bg-neutral-950 border border-neutral-800 rounded flex items-center justify-between">
                <span class="text-red-400">● ROOF TILES</span>
                <span class="text-neutral-400">680 pts</span>
              </div>
              <div class="p-2 bg-neutral-950 border border-neutral-800 rounded flex items-center justify-between">
                <span class="text-blue-400">● PARKED VEHICLE</span>
                <span class="text-neutral-400">180 pts</span>
              </div>
              <div class="p-2 bg-neutral-950 border border-neutral-800 rounded flex items-center justify-between">
                <span class="text-green-500">● TREES / FOLIAGE</span>
                <span class="text-neutral-400">500 pts</span>
              </div>
            </div>

            <button (click)="goToStep(5)" class="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-medium rounded text-xs transition-colors flex items-center justify-center gap-1.5">
              <mat-icon class="!w-4 !h-4 !text-[16px]">gps_fixed</mat-icon>
              Identify Delivery Zones
            </button>
          </div>
        }

        <!-- STEP 5: Zone Identification & Slope/Obstacle Analysis -->
        @if (currentStep() === 5) {
          <div class="space-y-3">
            <div class="text-sm font-semibold text-white">05. Delivery Zone Identification & Slope Assessment</div>
            <p class="text-neutral-400 leading-relaxed">
              The spatial engine analyzes candidate zones within the property perimeter:
            </p>

            <div class="space-y-2">
              <div class="p-2.5 bg-neutral-950 border border-emerald-500/40 rounded-lg">
                <div class="flex items-center justify-between">
                  <span class="font-semibold text-emerald-400">Zone A: Rear Lawn Platform</span>
                  <span class="text-[10px] font-mono px-1.5 py-0.5 bg-emerald-950 text-emerald-300 rounded border border-emerald-800">APPROVED</span>
                </div>
                <div class="text-neutral-400 text-[11px] mt-1">Area: 3.2m rad · Slope: 2.1° · Overhead: 14.5m Clear</div>
              </div>

              <div class="p-2.5 bg-neutral-950 border border-amber-500/40 rounded-lg">
                <div class="flex items-center justify-between">
                  <span class="font-semibold text-amber-400">Zone B: Front Driveway Hardstand</span>
                  <span class="text-[10px] font-mono px-1.5 py-0.5 bg-amber-950 text-amber-300 rounded border border-amber-800">CONDITIONAL</span>
                </div>
                <div class="text-neutral-400 text-[11px] mt-1">Vehicle parked 1.8m from center; risk of ground hazard</div>
              </div>

              <div class="p-2.5 bg-neutral-950 border border-red-500/40 rounded-lg">
                <div class="flex items-center justify-between">
                  <span class="font-semibold text-red-400">Zone C: Main Roof Pitch</span>
                  <span class="text-[10px] font-mono px-1.5 py-0.5 bg-red-950 text-red-300 rounded border border-red-800">REJECTED</span>
                </div>
                <div class="text-neutral-400 text-[11px] mt-1">Roof pitch 38° exceeds safe 8° limit for landing or placement</div>
              </div>
            </div>

            <button (click)="goToStep(6)" class="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-medium rounded text-xs transition-colors flex items-center justify-center gap-1.5">
              <mat-icon class="!w-4 !h-4 !text-[16px]">compare_arrows</mat-icon>
              Run Change Detection & Confidence
            </button>
          </div>
        }

        <!-- STEP 6: Change Detection & Site Confidence -->
        @if (currentStep() === 6) {
          <div class="space-y-3">
            <div class="text-sm font-semibold text-white">06. Temporal Delta Change Detection</div>
            <p class="text-neutral-400 leading-relaxed">
              Comparing Survey A (Historical) vs Survey B (Today):
            </p>

            <div class="p-3 bg-neutral-950 border border-amber-600/40 rounded-lg space-y-1 font-mono text-[11px]">
              <div class="text-amber-400 font-semibold flex items-center gap-1">
                <mat-icon class="!w-4 !h-4 !text-[16px]">warning</mat-icon>
                CHANGE DETECTED: DRIVEWAY ZONE B
              </div>
              <div class="text-neutral-300">Previous: CLEAR ASPHALT</div>
              <div class="text-neutral-300">Current: STATIONARY VEHICLE DETECTED (Confidence: 98.2%)</div>
              <div class="text-red-400">ACTION: DRIVEWAY ZONE DOWNGRADED TO CONDITIONAL</div>
            </div>

            <div class="p-3 bg-neutral-950 border border-neutral-800 rounded-lg flex justify-between font-mono text-[11px]">
              <span class="text-neutral-400">TOTAL SITE CONFIDENCE:</span>
              <span class="text-emerald-400 font-bold text-sm">96.8% (HIGH TRUST)</span>
            </div>

            <button (click)="goToStep(7)" class="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-medium rounded text-xs transition-colors flex items-center justify-center gap-1.5">
              <mat-icon class="!w-4 !h-4 !text-[16px]">analytics</mat-icon>
              Simulate Delivery Methods (R-Model)
            </button>
          </div>
        }

        <!-- STEP 7: Delivery Methods Evaluation -->
        @if (currentStep() === 7) {
          <div class="space-y-3">
            <div class="text-sm font-semibold text-white">07. R-Based Delivery Method Scoring</div>
            <p class="text-neutral-400 leading-relaxed">
              The R analytical engine evaluates all 7 British autonomous delivery mechanisms against target geometry and wind field:
            </p>

            <div class="space-y-2">
              @for (ev of evaluations(); track ev.method) {
                <div class="p-2.5 bg-neutral-950 border rounded-lg" [class.border-cyan-500]="ev.method === 'TETHER_DROP'" [class.border-neutral-800]="ev.method !== 'TETHER_DROP'">
                  <div class="flex items-center justify-between">
                    <span class="font-medium text-white">{{ ev.displayName }}</span>
                    <span class="font-mono text-cyan-400 font-bold">{{ ev.suitabilityScore }} / 100</span>
                  </div>
                  <div class="text-neutral-400 text-[11px] mt-1 font-mono">
                    Acc Error: ±{{ ev.expectedLandingErrorMeters }}m · Energy: +{{ ev.energyCostPercent }}% · Time: {{ ev.timeSeconds }}s
                  </div>
                  <div class="text-[10px] text-neutral-400 mt-1">
                    {{ ev.reasonCodes[0] }}
                  </div>
                </div>
              }
            </div>

            <button (click)="goToStep(8)" class="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-medium rounded text-xs transition-colors flex items-center justify-center gap-1.5">
              <mat-icon class="!w-4 !h-4 !text-[16px]">check_circle</mat-icon>
              Select Proposed Method
            </button>
          </div>
        }

        <!-- STEP 8: Best Method Selection & Transparency -->
        @if (currentStep() === 8) {
          <div class="space-y-3">
            <div class="text-sm font-semibold text-white">08. Proposed Method: CONTROLLED TETHER DROP</div>
            <p class="text-neutral-400 leading-relaxed">
              Transparent R-decision explanation (no black-box AI):
            </p>

            <div class="bg-neutral-950 border border-emerald-500/40 rounded-lg p-3 space-y-2 font-mono text-[11px]">
              <div class="text-emerald-400 font-semibold">METHOD SELECTION RATIONALE</div>
              <ul class="space-y-1 text-neutral-300 list-disc list-inside">
                <li>Clear vertical overhead corridor (14.5m unobstructed)</li>
                <li>Surface boundary wind (5.2 kts) well within 15 kts limit</li>
                <li>Eliminates rotor downwash hazard in domestic garden</li>
                <li>Soft lawn impact absorbs touchdown kinetic energy</li>
              </ul>
              <div class="pt-2 border-t border-neutral-800 text-neutral-400">
                FALLBACK METHOD: <span class="text-cyan-300 font-semibold">PRECISION BALLISTIC DROP</span>
              </div>
            </div>

            <button (click)="goToStep(9)" class="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-medium rounded text-xs transition-colors flex items-center justify-center gap-1.5">
              <mat-icon class="!w-4 !h-4 !text-[16px]">alt_route</mat-icon>
              Compute 3D Corridor & Energy Profile
            </button>
          </div>
        }

        <!-- STEP 9: 3D Approach Corridor & Battery/Weather Verification -->
        @if (currentStep() === 9) {
          <div class="space-y-3">
            <div class="text-sm font-semibold text-white">09. 3D Approach Corridor & Energy Reserve</div>
            <p class="text-neutral-400 leading-relaxed">
              Volumetric trajectory calculated avoiding local terrain, building eaves, and trees.
            </p>

            <div class="bg-neutral-950 border border-neutral-800 rounded-lg p-3 space-y-2 font-mono text-[11px]">
              <div class="grid grid-cols-2 gap-2 text-neutral-300">
                <div>ROUTE DISTANCE: <span class="text-white">7.4 km</span></div>
                <div>EST. TIME: <span class="text-white">12m 00s</span></div>
                <div>MISSION ENERGY: <span class="text-amber-400">58.5%</span></div>
                <div>RESERVE AT RTB: <span class="text-emerald-400 font-bold">39.5%</span> (Min 25%)</div>
                <div>WIND HEADWIND: <span class="text-white">+4.2% power</span></div>
                <div>CAA NOTAM CHECK: <span class="text-emerald-400">CLEARED</span></div>
              </div>
            </div>

            <button (click)="goToStep(10)" class="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-medium rounded text-xs transition-colors flex items-center justify-center gap-1.5">
              <mat-icon class="!w-4 !h-4 !text-[16px]">verified_user</mat-icon>
              Proceed to Operator Review
            </button>
          </div>
        }

        <!-- STEP 10: Operator Human Oversight & Approval -->
        @if (currentStep() === 10) {
          <div class="space-y-3">
            <div class="text-sm font-semibold text-white">10. Operator Mission Authorisation</div>
            <p class="text-neutral-400 leading-relaxed">
              Human-in-the-loop oversight under UK CAA BVLOS Specific Category Operational Authorisation.
            </p>

            <div class="bg-neutral-950 border border-neutral-800 rounded-lg p-3 space-y-2 text-[11px]">
              <div class="font-mono text-neutral-400 uppercase tracking-wider">Pre-Flight Safety Checks</div>
              <div class="space-y-1 font-mono text-neutral-300">
                <div class="flex items-center gap-2 text-emerald-400">
                  <mat-icon class="!w-4 !h-4 !text-[16px]">check</mat-icon>
                  <span>Direct Remote ID: GBR-DRI-2026-042-CAA ACTIVE</span>
                </div>
                <div class="flex items-center gap-2 text-emerald-400">
                  <mat-icon class="!w-4 !h-4 !text-[16px]">check</mat-icon>
                  <span>Dual 5G / Iridium Failover: 99.98% SNR</span>
                </div>
                <div class="flex items-center gap-2 text-emerald-400">
                  <mat-icon class="!w-4 !h-4 !text-[16px]">check</mat-icon>
                  <span>Automatic Winch Shear Release Armed</span>
                </div>
              </div>
            </div>

            <button (click)="authorizeAndLaunch()" class="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded text-xs transition-colors flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-950">
              <mat-icon class="!w-4 !h-4 !text-[16px]">flight_takeoff</mat-icon>
              AUTHORISE & EXECUTE MISSION
            </button>
          </div>
        }

        <!-- STEP 11: Live Execution & Delivery Confirmation -->
        @if (currentStep() === 11) {
          <div class="space-y-3">
            <div class="text-sm font-semibold text-white">11. Autonomous Delivery Execution</div>
            <p class="text-neutral-400 leading-relaxed">
              Active mission execution. Scrub the progress bar or watch real-time simulated telemetry:
            </p>

            <div class="bg-neutral-950 border border-neutral-800 rounded-lg p-3 space-y-2 font-mono text-[11px]">
              <div class="flex justify-between text-neutral-400">
                <span>SIMULATION PROGRESS:</span>
                <span class="text-cyan-400 font-bold">{{ (simProgress() * 100).toFixed(0) }}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                [value]="simProgress()"
                (input)="onProgressChange($event)"
                class="w-full accent-cyan-400 cursor-pointer"
              />
              <div class="flex justify-between text-[10px] text-neutral-500">
                <span>DEPOT LAUNCH</span>
                <span>CRUISE</span>
                <span>TETHER DROP</span>
                <span>RTB LANDED</span>
              </div>
            </div>

            <!-- Auto-play simulation toggle -->
            <div class="flex gap-2">
              <button
                (click)="toggleAutoPlay()"
                [class.bg-amber-600]="isPlaying()"
                [class.bg-cyan-600]="!isPlaying()"
                class="flex-1 py-2 text-white font-medium rounded text-xs transition-colors flex items-center justify-center gap-1.5"
              >
                <mat-icon class="!w-4 !h-4 !text-[16px]">{{ isPlaying() ? 'pause' : 'play_arrow' }}</mat-icon>
                {{ isPlaying() ? 'Pause Flight Simulation' : 'Auto-Play Mission' }}
              </button>
            </div>

            <!-- Digital Delivery Receipt if completed -->
            @if (simProgress() >= 0.8) {
              <div class="bg-emerald-950/40 border border-emerald-500/50 rounded-lg p-3 space-y-1.5 font-mono text-[11px]">
                <div class="text-emerald-400 font-bold flex items-center gap-1">
                  <mat-icon class="!w-4 !h-4 !text-[16px]">verified</mat-icon>
                  IMMUTABLE DIGITAL DELIVERY RECEIPT
                </div>
                <div class="text-neutral-300">MISSION: MSN-28491 · SPF-042</div>
                <div class="text-neutral-300">DELIVERED: Lawn Platform Zone A (Target Acc: 0.28m)</div>
                <div class="text-neutral-300">CV CONFIRMATION: Touchdown verified by optical flow</div>
                <div class="text-[10px] text-neutral-400 truncate">SHA256: 8f4b7a1c9e8d2f0a5b3c4e6d7f8a9b0c1d2e3f4a</div>
              </div>
            }
          </div>
        }
      </div>
    </div>
  `,
})
export class SignatureFlow {
  private missionService = inject(MissionService);

  readonly currentStep = this.missionService.signatureStep;
  readonly simProgress = this.missionService.simulationProgress;
  readonly evaluations = this.missionService.currentMethodEvaluations;

  readonly isPlaying = signal<boolean>(false);
  private playInterval: ReturnType<typeof setInterval> | null = null;

  readonly stepTitles = [
    'Survey',
    'Capture',
    'Reconstruct',
    'Classify',
    'Zones',
    'Delta',
    'R-Score',
    'Method',
    'Corridor',
    'Review',
    'Execute',
  ];

  goToStep(step: number): void {
    this.missionService.selectSignatureStep(step);
    if (step === 11 && this.simProgress() === 0) {
      this.missionService.setSimulationProgress(0.25);
    }
  }

  authorizeAndLaunch(): void {
    this.missionService.authorizeMission('msn-28491');
    this.missionService.selectSignatureStep(11);
    this.startAutoPlay();
  }

  onProgressChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.missionService.setSimulationProgress(val);
  }

  toggleAutoPlay(): void {
    if (this.isPlaying()) {
      this.stopAutoPlay();
    } else {
      this.startAutoPlay();
    }
  }

  private startAutoPlay(): void {
    this.isPlaying.set(true);
    if (this.simProgress() >= 1.0) {
      this.missionService.setSimulationProgress(0);
    }
    if (this.playInterval) clearInterval(this.playInterval);
    this.playInterval = setInterval(() => {
      const current = this.simProgress();
      if (current >= 1.0) {
        this.stopAutoPlay();
        return;
      }
      this.missionService.setSimulationProgress(current + 0.008);
    }, 100);
  }

  private stopAutoPlay(): void {
    this.isPlaying.set(false);
    if (this.playInterval) {
      clearInterval(this.playInterval);
      this.playInterval = null;
    }
  }
}
