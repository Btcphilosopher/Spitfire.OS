import {
  ChangeDetectionStrategy,
  Component,
  inject
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MissionService } from '../../core/services/mission.service';

@Component({
  selector: 'app-site-reconstruction',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-neutral-900 border-l border-neutral-800 font-sans text-xs overflow-y-auto p-4 space-y-4">
      <!-- Header -->
      <div>
        <div class="flex items-center justify-between">
          <h3 class="font-bold text-neutral-100 text-sm flex items-center gap-1.5">
            <mat-icon class="!w-4 !h-4 !text-[18px] text-cyan-400">filter_center_focus</mat-icon>
            SPITFIRE VISION Photogrammetry Pipeline
          </h3>
          <span class="font-mono text-[10px] text-emerald-400 bg-emerald-950/60 border border-emerald-800/50 px-2 py-0.5 rounded">Structure from Motion</span>
        </div>
        <p class="text-neutral-400 text-[11px] mt-1 leading-relaxed">
          Multi-view stereo photogrammetry, bundle adjustment, dense 3D point cloud generation, and surface normal reconstruction.
        </p>
      </div>

      <!-- Survey Summary Card -->
      <div class="bg-neutral-950 border border-neutral-800 rounded-lg p-3 space-y-2 font-mono text-[11px]">
        <div class="flex justify-between border-b border-neutral-800 pb-1.5">
          <span class="text-neutral-400">SURVEY ID:</span>
          <span class="text-white font-bold">{{ survey().id }}</span>
        </div>
        <div class="flex justify-between">
          <span class="text-neutral-400">TIMESTAMP:</span>
          <span class="text-neutral-300">{{ survey().timestamp }}</span>
        </div>
        <div class="flex justify-between">
          <span class="text-neutral-400">ACQUIRED FRAMES:</span>
          <span class="text-cyan-400">{{ survey().imagesCount }} RGB + Stereo Depth</span>
        </div>
        <div class="flex justify-between">
          <span class="text-neutral-400">REPROJECTION ERROR:</span>
          <span class="text-emerald-400 font-bold">{{ survey().reprojectionErrorPx }} px (Optimal < 1.0px)</span>
        </div>
        <div class="flex justify-between">
          <span class="text-neutral-400">DENSE POINT COUNT:</span>
          <span class="text-white">{{ survey().points.length.toLocaleString() }} Classified Vertices</span>
        </div>
      </div>

      <!-- Photogrammetry Pipeline Stages -->
      <div class="space-y-2">
        <div class="text-neutral-400 uppercase tracking-wider font-mono text-[11px]">Pipeline Execution Telemetry</div>

        <div class="p-2.5 bg-neutral-950 border border-neutral-800 rounded-lg space-y-1 font-mono text-[11px]">
          <div class="flex justify-between">
            <span class="text-neutral-300">1. Image Quality & Sharpness</span>
            <span class="text-emerald-400 font-bold">100% PASS</span>
          </div>
          <div class="text-[10px] text-neutral-500">Laplacian variance threshold > 420; zero motion blur</div>
        </div>

        <div class="p-2.5 bg-neutral-950 border border-neutral-800 rounded-lg space-y-1 font-mono text-[11px]">
          <div class="flex justify-between">
            <span class="text-neutral-300">2. Feature Extraction & Matching</span>
            <span class="text-emerald-400 font-bold">{{ survey().featureMatchingPercent }}%</span>
          </div>
          <div class="text-[10px] text-neutral-500">4,280 SIFT/ORB tie points matched across overlapping baselines</div>
        </div>

        <div class="p-2.5 bg-neutral-950 border border-neutral-800 rounded-lg space-y-1 font-mono text-[11px]">
          <div class="flex justify-between">
            <span class="text-neutral-300">3. Bundle Adjustment & Camera Poses</span>
            <span class="text-emerald-400 font-bold">CONVERGED (6 Poses)</span>
          </div>
          <div class="text-[10px] text-neutral-500">Levenberg-Marquardt non-linear optimization with RTK constraints</div>
        </div>

        <div class="p-2.5 bg-neutral-950 border border-neutral-800 rounded-lg space-y-1 font-mono text-[11px]">
          <div class="flex justify-between">
            <span class="text-neutral-300">4. Dense Multi-View Stereo Depth</span>
            <span class="text-emerald-400 font-bold">{{ survey().depthConfidencePercent }}%</span>
          </div>
          <div class="text-[10px] text-neutral-500">Semi-global matching (SGM) dense disparity field</div>
        </div>
      </div>

      <!-- Site Change Detection Card -->
      @if (survey().detectedChanges && survey().detectedChanges!.length > 0) {
        <div class="bg-amber-950/40 border border-amber-500/50 rounded-lg p-3 space-y-2">
          <div class="flex items-center gap-1.5 text-amber-400 font-semibold font-mono text-[11px]">
            <mat-icon class="!w-4 !h-4 !text-[16px]">change_circle</mat-icon>
            TEMPORAL CHANGE DETECTION ALERT
          </div>
          @for (c of survey().detectedChanges; track c.zoneId) {
            <div class="space-y-1 text-neutral-300 font-mono text-[11px]">
              <div>TARGET ZONE: <span class="text-white">{{ c.zoneId }}</span></div>
              <div>OBSTACLE: <span class="text-amber-300">{{ c.detectedObstacle }}</span></div>
              <div>CONFIDENCE: <span class="text-emerald-400">{{ (c.confidence * 100).toFixed(1) }}%</span></div>
            </div>
          }
        </div>
      }
    </div>
  `,
})
export class SiteReconstruction {
  private missionService = inject(MissionService);

  readonly survey = this.missionService.currentSurvey;
}
