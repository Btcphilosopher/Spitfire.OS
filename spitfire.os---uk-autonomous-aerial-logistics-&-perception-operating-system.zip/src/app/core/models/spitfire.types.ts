// SPITFIRE.OS - Core TypeScript Type Definitions
// British Autonomous Aerial Logistics, Perception & Delivery Infrastructure

export type AirspaceClass = 'CLASS_A' | 'CLASS_C' | 'CLASS_D' | 'CLASS_E' | 'CLASS_G' | 'RESTRICTED_EG_R' | 'DANGER_EG_D' | 'PROHIBITED_EG_P' | 'NOTAM_TEMP';

export type MissionState =
  | 'CREATED'
  | 'SURVEY_REQUIRED'
  | 'SITE_ANALYSIS'
  | 'SITE_APPROVED'
  | 'DRONE_ASSIGNED'
  | 'PAYLOAD_ASSIGNED'
  | 'ROUTE_PLANNED'
  | 'MISSION_REVIEW'
  | 'AUTHORISED'
  | 'LAUNCH_READY'
  | 'IN_FLIGHT'
  | 'ARRIVING'
  | 'DELIVERY_MANOEUVRE'
  | 'DELIVERY_CONFIRMED'
  | 'RETURNING'
  | 'LANDED'
  | 'COMPLETED'
  // Failure / Hold states
  | 'ABORTED'
  | 'DIVERTED'
  | 'LOST_LINK'
  | 'WEATHER_HOLD'
  | 'SITE_INVALID'
  | 'BATTERY_ABORT'
  | 'SYSTEM_FAULT';

export type DeliveryMethodType =
  | 'GROUND_LANDING'
  | 'PRECISION_DROP'
  | 'TETHER_DROP'
  | 'WINCH_DELIVERY'
  | 'PRECISION_PLACEMENT'
  | 'MANOEUVRE_INTO_PLACE'
  | 'DELIVERY_STATION_DOCK';

export type PointClass =
  | 'GROUND'
  | 'BUILDING'
  | 'TREE'
  | 'VEHICLE'
  | 'ROAD'
  | 'WALL'
  | 'FENCE'
  | 'ROOF'
  | 'DELIVERY_SURFACE'
  | 'UNKNOWN';

export type DroneStatus = 'AVAILABLE' | 'IN_FLIGHT' | 'CHARGING' | 'MAINTENANCE' | 'WEATHER_HOLD' | 'SURVEYING';

export interface Coordinate3D {
  lat: number;
  lng: number;
  altMeters: number;
  x?: number; // local relative coordinates in meters
  y?: number;
  z?: number;
}

export interface DroneDigitalTwin {
  id: string;
  callsign: string; // e.g., "SPF-042"
  model: 'SPITFIRE M4' | 'SPITFIRE HEAVY-LIFT' | 'SPITFIRE RAPID-VTOL' | 'SPITFIRE SURVEY-PRO';
  caaRegistration: string; // e.g., "G-SPIT-042"
  directRemoteId: string; // UK CAA Remote ID compliant
  status: DroneStatus;
  batterySoc: number; // % (0-100)
  batteryVoltage: number; // Volts
  batteryTempC: number;
  batteryHealthCycles: number;
  payloadCapacityKg: number;
  currentPayloadKg: number;
  maxWindToleranceKts: number;
  position: Coordinate3D;
  headingDeg: number;
  groundSpeedKts: number;
  airframeHours: number;
  nextInspectionHours: number;
  assignedDepotId: string;
  activeMissionId?: string;
  subsystemHealth: {
    motors: 'EXCELLENT' | 'GOOD' | 'FAIR' | 'DEGRADED';
    imu: 'CALIBRATED' | 'NOMINAL' | 'DEVIATION';
    gnssRtk: 'FIX_RTK' | 'FLOAT' | '3D_FIX' | 'DEGRADED';
    sensors: 'ALL_OPERATIONAL' | 'WARN_OPTICAL' | 'FAULT';
    commsLink: '99.9% 5G/SAT' | '98.2% DUAL-LINK' | 'FAILOVER';
    payloadHarness: 'LOCKED' | 'DEPLOYED' | 'DISENGAGED';
  };
}

export interface Depot {
  id: string;
  name: string;
  code: string; // e.g., "SPF-DEPOT-03"
  location: Coordinate3D;
  region: string; // e.g., "Greater Manchester", "Oxfordshire Corridor"
  totalPads: number;
  availablePads: number;
  chargingStations: number;
  activeDrones: number;
  weatherStation: {
    windSpeedKts: number;
    windDirectionDeg: number;
    gustKts: number;
    tempC: number;
    visibilityKm: number;
    cloudBaseFt: number;
    precipitationMm: number;
    baroHpa: number;
  };
}

export interface DeliverySite {
  id: string;
  code: string;
  name: string;
  address: string;
  postcode: string; // e.g. "OX2 6NN", "M1 4BT"
  location: Coordinate3D;
  category: 'SUBURBAN_RESIDENTIAL' | 'COMMERCIAL_ROOFTOP' | 'INDUSTRIAL_YARD' | 'RURAL_ESTATE' | 'HOSPITAL_PAD' | 'RECEIVING_STATION';
  lastSurveyDate: string;
  siteConfidence: number; // 0.0 - 1.0 (e.g. 0.96)
  surfaceAreaM2: number;
  slopeDegrees: number;
  obstacleDensity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CONSTRAINED';
  overheadClearanceMeters: number;
  provenance: {
    source: 'SPITFIRE VISION' | 'ORDNANCE SURVEY 3D' | 'LIDAR SURVEY';
    timestamp: string;
    surveyFlightId: string;
    reprojectionErrorPx: number;
    featurePointsCount: number;
  };
  zones: DeliveryZone[];
  historicalDeliveriesCount: number;
  preferredMethod: DeliveryMethodType;
  secondaryMethod: DeliveryMethodType;
}

export interface DeliveryZone {
  id: string;
  siteId: string;
  name: string; // e.g., "Garden Platform A", "Driveway East", "Roof Pad 01"
  type: 'GROUND_PAD' | 'GARDEN_LAWN' | 'WINCH_BAY' | 'ROOF_PLATFORM' | 'RECEIVING_STATION';
  center: Coordinate3D;
  radiusMeters: number;
  surfaceFlatnessScore: number; // 0-100
  overheadClearanceScore: number; // 0-100
  windExposureFactor: number;
  currentStatus: 'APPROVED' | 'CONDITIONAL' | 'REJECTED' | 'INVALIDATED_CHANGE_DETECTED';
  rejectionReason?: string;
  targetAccuracyReqMeters: number;
}

export interface MethodEvaluation {
  method: DeliveryMethodType;
  displayName: string;
  suitabilityScore: number; // 0 - 100
  confidence: number; // 0.0 - 1.0
  isFeasible: boolean;
  expectedLandingErrorMeters: number;
  energyCostPercent: number;
  timeSeconds: number;
  reasonCodes: string[];
  riskFactors: string[];
  simulationData?: {
    oscillationDeg?: number;
    tetherTensionN?: number;
    windDriftMeters?: number;
    touchdownVelocityMs?: number;
  };
}

export interface PointCloudPoint {
  x: number;
  y: number;
  z: number;
  r: number;
  g: number;
  b: number;
  classification: PointClass;
  confidence: number;
}

export interface PhotogrammetrySurvey {
  id: string;
  siteId: string;
  timestamp: string;
  imagesCount: number;
  coveragePercent: number;
  featureMatchingPercent: number;
  reprojectionErrorPx: number;
  depthConfidencePercent: number;
  surfaceCoveragePercent: number;
  cameraPoses: {
    id: string;
    pos: Coordinate3D;
    pitch: number;
    yaw: number;
    roll: number;
    fov: number;
    frameThumbnailUrl?: string;
  }[];
  points: PointCloudPoint[];
  detectedChanges?: {
    zoneId: string;
    previousState: string;
    currentState: string;
    confidence: number;
    detectedObstacle: string;
  }[];
}

export interface Waypoint {
  lat: number;
  lng: number;
  altMeters: number;
  speedKts: number;
  action?: 'CRUISE' | 'DESCEND' | 'HOVER' | 'DELIVER' | 'ASCEND' | 'TURN';
  corridorWidthMeters: number;
}

export interface Mission {
  id: string;
  code: string; // e.g., "MSN-28491"
  depotId: string;
  siteId: string;
  targetZoneId: string;
  droneId: string;
  payload: {
    trackingNumber: string;
    recipientName: string;
    massKg: number;
    dimensionsCm: [number, number, number];
    category: 'MEDICAL_CRITICAL' | 'URGENT_PARTS' | 'ELECTRONICS' | 'EXPRESS_PARCELS';
    temperatureSensitive: boolean;
  };
  state: MissionState;
  selectedMethod: DeliveryMethodType;
  methodEvaluation: MethodEvaluation[];
  route: {
    totalDistanceKm: number;
    estimatedFlightDurationSec: number;
    waypoints: Waypoint[];
    cruisingAltitudeMeters: number;
    corridorClearanceMeters: number;
  };
  energyAnalysis: {
    outboundEnergyPercent: number;
    manoeuvreEnergyPercent: number;
    returnEnergyPercent: number;
    totalExpectedEnergyPercent: number;
    reserveSocAtLandingPercent: number;
    minimumAllowedReservePercent: number; // 25%
    approvedByRModel: boolean;
  };
  weatherAssessment: {
    meanWindKts: number;
    gustKts: number;
    windDirectionDeg: number;
    tempC: number;
    operationalEffect: string;
  };
  airspaceCompliance: {
    caaAuthorizationRef: string;
    isBvlosAuthorized: boolean;
    directRemoteIdActive: boolean;
    controlledAirspaceClearance: 'CLEARED_AUTOMATED_UTM' | 'CLASS_G_OPEN' | 'TRANSIT_APPROVED';
    notamClearance: boolean;
  };
  operatorApproval?: {
    operatorId: string;
    operatorCallsign: string;
    approvedTimestamp: string;
    rationale: string;
    riskMitigations: string[];
  };
  receipt?: {
    deliveredTimestamp: string;
    actualMethod: DeliveryMethodType;
    targetAccuracyMeters: number;
    packageConfirmedByVision: boolean;
    digitalSignatureSha256: string;
  };
}

export interface MonteCarloResult {
  seed: number;
  simulationsCount: number;
  successRatePercent: number;
  expectedEnergyCostPercent: number;
  p95EnergyCostPercent: number;
  p99EnergyCostPercent: number;
  meanPositionErrorMeters: number;
  p95PositionErrorMeters: number;
  confidenceEllipseAxesMeters: [number, number];
  failureBreakdown: {
    windExceededPercent: number;
    corridorBreachPercent: number;
    batteryLowPercent: number;
    sensorUncertaintyPercent: number;
  };
  distributionBuckets: { errorRange: string; count: number; freq: number }[];
}

export interface TelemetryFrame {
  timestampMs: number;
  droneId: string;
  lat: number;
  lng: number;
  altMeters: number;
  groundSpeedKts: number;
  headingDeg: number;
  pitchDeg: number;
  rollDeg: number;
  batterySoc: number;
  batteryCurrentAmps: number;
  motorRpmMean: number;
  tetherExtensionMeters?: number;
  tetherTensionNewtons?: number;
  opticalFlowConfidence: number;
  rtkAccuracyCm: number;
  downwardCameraImage?: string;
  flightPhase: string;
}
