import { Injectable, signal, computed, inject } from '@angular/core';
import {
  DroneDigitalTwin,
  Depot,
  DeliverySite,
  Mission,
  MissionState,
  PhotogrammetrySurvey,
  TelemetryFrame
} from '../models/spitfire.types';
import { SyntheticDataService } from './synthetic-data.service';
import { SpitfireRService } from './spitfire-r.service';

@Injectable({
  providedIn: 'root',
})
export class MissionService {
  private syntheticData = inject(SyntheticDataService);
  private spitfireR = inject(SpitfireRService);

  // Core reactive signals
  readonly drones = signal<DroneDigitalTwin[]>(this.syntheticData.generate52Drones());
  readonly depots = signal<Depot[]>(this.syntheticData.depots);
  readonly deliverySites = signal<DeliverySite[]>(this.syntheticData.generateDeliverySites());
  readonly activeMissions = signal<Mission[]>(this.syntheticData.generateSampleMissions());

  // Selected entities
  readonly selectedDroneId = signal<string>('drone-042');
  readonly selectedSiteId = signal<string>('site-01');
  readonly selectedZoneId = signal<string>('zone-01-a');
  readonly selectedMissionId = signal<string>('msn-28491');

  // Interactive step in the signature workflow: SCAN -> RECONSTRUCT -> PLAN -> DELIVER
  readonly signatureStep = signal<number>(1);
  readonly isSimulationRunning = signal<boolean>(false);
  readonly simulationProgress = signal<number>(0); // 0.0 to 1.0
  readonly simulationPhase = signal<string>('IDLE');

  // Photogrammetry Surveys indexed by site ID
  readonly surveys = signal<Record<string, PhotogrammetrySurvey>>({
    'site-01': this.syntheticData.generateSurvey('site-01'),
    'site-02': this.syntheticData.generateSurvey('site-02'),
    'site-03': this.syntheticData.generateSurvey('site-03'),
    'site-04': this.syntheticData.generateSurvey('site-04'),
  });

  // Current selected entities (computed)
  readonly selectedDrone = computed(() => {
    const id = this.selectedDroneId();
    return this.drones().find((d) => d.id === id) ?? this.drones()[0];
  });

  readonly selectedSite = computed(() => {
    const id = this.selectedSiteId();
    return this.deliverySites().find((s) => s.id === id) ?? this.deliverySites()[0];
  });

  readonly currentSurvey = computed(() => {
    const siteId = this.selectedSite().id;
    return this.surveys()[siteId] ?? this.surveys()['site-01'];
  });

  readonly selectedZone = computed(() => {
    const site = this.selectedSite();
    const zoneId = this.selectedZoneId();
    return site.zones.find((z) => z.id === zoneId) ?? site.zones[0];
  });

  readonly currentMission = computed(() => {
    const id = this.selectedMissionId();
    return this.activeMissions().find((m) => m.id === id) ?? this.activeMissions()[0];
  });

  // Computed method evaluation for current site and zone
  readonly currentMethodEvaluations = computed(() => {
    const site = this.selectedSite();
    const zone = this.selectedZone();
    return this.spitfireR.evaluateDeliveryMethods(site, zone, 2.0, 11.4, 16.2);
  });

  // Live telemetry computed from simulation progress
  readonly liveTelemetry = computed<TelemetryFrame>(() => {
    const progress = this.simulationProgress();
    const drone = this.selectedDrone();

    // 5 flight phases: 0.0-0.2 Ascend/Transit, 0.2-0.5 Cruise, 0.5-0.7 Approach, 0.7-0.85 Delivery Manoeuvre, 0.85-1.0 Return/Complete
    let phase = 'STATIONARY';
    let alt = 65.0;
    let speed = 0;
    let tetherExt = 0;
    let tetherTension = 0;
    let pitch = 0;
    let roll = 0;

    if (progress > 0 && progress < 0.2) {
      phase = 'ASCENT & DEPARTURE';
      alt = 62.0 + (progress / 0.2) * 28.0;
      speed = (progress / 0.2) * 38.0;
      pitch = -4.5;
    } else if (progress >= 0.2 && progress < 0.5) {
      phase = 'CORRIDOR TRANSIT (CRUISE)';
      alt = 90.0;
      speed = 42.0;
      pitch = -2.0;
      roll = Math.sin(progress * 40) * 1.5;
    } else if (progress >= 0.5 && progress < 0.7) {
      phase = 'PRECISION SITE APPROACH';
      alt = 90.0 - ((progress - 0.5) / 0.2) * 65.0;
      speed = 42.0 - ((progress - 0.5) / 0.2) * 36.0;
      pitch = 3.2;
    } else if (progress >= 0.7 && progress < 0.85) {
      phase = 'DELIVERY MANOEUVRE (TETHER EXTENSION)';
      alt = 25.0;
      speed = 0.5;
      const subProg = (progress - 0.7) / 0.15;
      tetherExt = subProg < 0.7 ? (subProg / 0.7) * 22.0 : 22.0 * (1 - (subProg - 0.7) / 0.3);
      tetherTension = subProg < 0.7 ? 18.5 + Math.sin(subProg * 25) * 1.8 : 0.0;
      pitch = 0.5;
      roll = Math.sin(progress * 60) * 0.8;
    } else if (progress >= 0.85 && progress < 1.0) {
      phase = 'RETURN TO BASE (RTB)';
      alt = 85.0;
      speed = 44.0;
      pitch = -3.0;
    } else if (progress >= 1.0) {
      phase = 'MISSION COMPLETED - LANDED';
      alt = 62.0;
      speed = 0.0;
    }

    const currentSoc = Math.max(15, drone.batterySoc - progress * 24.5);

    return {
      timestampMs: Date.now(),
      droneId: drone.id,
      lat: Number((drone.position.lat + progress * 0.0128).toFixed(6)),
      lng: Number((drone.position.lng - progress * 0.0116).toFixed(6)),
      altMeters: Number(alt.toFixed(1)),
      groundSpeedKts: Number(speed.toFixed(1)),
      headingDeg: (drone.headingDeg + Math.floor(progress * 80)) % 360,
      pitchDeg: Number(pitch.toFixed(1)),
      rollDeg: Number(roll.toFixed(1)),
      batterySoc: Number(currentSoc.toFixed(1)),
      batteryCurrentAmps: Number((18.4 + (speed / 40.0) * 14.2 + (tetherTension > 0 ? 8.5 : 0)).toFixed(1)),
      motorRpmMean: Number((4800 + (speed / 40.0) * 1200 + (alt > 80 ? 400 : 0)).toFixed(0)),
      tetherExtensionMeters: Number(tetherExt.toFixed(2)),
      tetherTensionNewtons: Number(tetherTension.toFixed(1)),
      opticalFlowConfidence: 0.96,
      rtkAccuracyCm: 1.4,
      flightPhase: phase,
    };
  });

  // State Transitions
  updateMissionState(missionId: string, newState: MissionState): void {
    this.activeMissions.update((missions) =>
      missions.map((m) => (m.id === missionId ? { ...m, state: newState } : m))
    );
  }

  selectDrone(droneId: string): void {
    this.selectedDroneId.set(droneId);
  }

  selectSite(siteId: string): void {
    this.selectedSiteId.set(siteId);
    const site = this.deliverySites().find((s) => s.id === siteId);
    if (site && site.zones.length > 0) {
      this.selectedZoneId.set(site.zones[0].id);
    }
  }

  selectZone(zoneId: string): void {
    this.selectedZoneId.set(zoneId);
  }

  selectSignatureStep(step: number): void {
    this.signatureStep.set(step);
  }

  setSimulationProgress(prog: number): void {
    this.simulationProgress.set(Math.max(0, Math.min(1, prog)));
  }

  // Authorize Mission
  authorizeMission(missionId: string, operatorCallsign = 'Flt. Ops C. Sterling'): void {
    this.activeMissions.update((missions) =>
      missions.map((m) => {
        if (m.id === missionId) {
          return {
            ...m,
            state: 'AUTHORISED',
            operatorApproval: {
              operatorId: 'OP-RAF-7704',
              operatorCallsign,
              approvedTimestamp: new Date().toISOString(),
              rationale: 'CAA BVLOS Specific category authorization confirmed. Photogrammetry and approach corridor verified.',
              riskMitigations: ['Automatic winch shear link active', 'RTK Fix confirmed with 1.4cm precision', 'Dynamic geofence active'],
            },
          };
        }
        return m;
      })
    );
  }

  // Create new delivery site
  addNewSite(newSite: DeliverySite): void {
    this.deliverySites.update((sites) => [newSite, ...sites]);
    const survey = this.syntheticData.generateSurvey(newSite.id);
    this.surveys.update((s) => ({ ...s, [newSite.id]: survey }));
    this.selectSite(newSite.id);
  }
}
