import { Injectable } from '@angular/core';
import {
  DeliveryMethodType,
  DeliverySite,
  DeliveryZone,
  MethodEvaluation,
  MonteCarloResult
} from '../models/spitfire.types';

@Injectable({
  providedIn: 'root',
})
export class SpitfireRService {
  /**
   * R Analytical Decision Model for Delivery Method Selection
   * Evaluates all 7 British Autonomous delivery mechanisms deterministically based on
   * surface geometry, obstacle density, wind field, payload characteristics, and safety envelopes.
   */
  evaluateDeliveryMethods(
    site: DeliverySite,
    targetZone: DeliveryZone,
    payloadMassKg: number,
    windSpeedKts: number,
    windGustKts: number
  ): MethodEvaluation[] {
    const methods: DeliveryMethodType[] = [
      'TETHER_DROP',
      'WINCH_DELIVERY',
      'GROUND_LANDING',
      'PRECISION_DROP',
      'PRECISION_PLACEMENT',
      'MANOEUVRE_INTO_PLACE',
      'DELIVERY_STATION_DOCK',
    ];

    return methods.map((m: DeliveryMethodType): MethodEvaluation => {
      switch (m) {
        case 'TETHER_DROP': {
          const windPenalty = Math.max(0, (windGustKts - 12) * 3.5);
          const massPenalty = payloadMassKg > 4.0 ? (payloadMassKg - 4.0) * 12 : 0;
          const clearanceBonus = targetZone.overheadClearanceScore > 85 ? 15 : -20;
          const flatnessBonus = targetZone.surfaceFlatnessScore > 75 ? 10 : 0;
          const score = Math.max(10, Math.min(99, 88 + clearanceBonus + flatnessBonus - windPenalty - massPenalty));
          const feasible = score >= 60 && windGustKts <= 24 && targetZone.overheadClearanceScore >= 70;

          const oscillation = Number((1.2 + (windSpeedKts / 8) * (payloadMassKg / 2.0)).toFixed(1));
          const expectedError = Number((0.2 + (windSpeedKts * 0.015) + (oscillation * 0.05)).toFixed(2));

          const reasons: string[] = [];
          if (targetZone.overheadClearanceScore > 80) reasons.push('+ Unobstructed vertical delivery corridor');
          if (windSpeedKts <= 15) reasons.push('+ Low surface boundary layer wind (< 15 kts)');
          if (targetZone.type === 'GARDEN_LAWN') reasons.push('+ Verified residential ground buffer: eliminates low-altitude rotor hazard');
          if (windGustKts > 18) reasons.push('- Gusts require active pendulum dampening');

          return {
            method: 'TETHER_DROP' as DeliveryMethodType,
            displayName: 'Controlled Tether Drop',
            suitabilityScore: score,
            confidence: Number((0.85 + (score / 100) * 0.12).toFixed(2)),
            isFeasible: feasible,
            expectedLandingErrorMeters: expectedError,
            energyCostPercent: 4.5,
            timeSeconds: 38,
            reasonCodes: reasons,
            riskFactors: windGustKts > 18 ? ['Lateral cable sway under wind gusts'] : ['Ground impact speed check required'],
            simulationData: {
              oscillationDeg: oscillation,
              tetherTensionN: Number((payloadMassKg * 9.81 * 1.15).toFixed(1)),
              windDriftMeters: Number((windSpeedKts * 0.012).toFixed(2)),
              touchdownVelocityMs: 0.32,
            },
          };
        }

        case 'WINCH_DELIVERY': {
          const isHighAltitude = site.overheadClearanceMeters > 20;
          const windPenalty = Math.max(0, (windGustKts - 14) * 3.0);
          const score = Math.max(10, Math.min(98, 82 + (isHighAltitude ? 12 : 2) - windPenalty));
          const feasible = score >= 55 && windGustKts <= 26;

          return {
            method: 'WINCH_DELIVERY' as DeliveryMethodType,
            displayName: 'Powered Precision Winch',
            suitabilityScore: score,
            confidence: 0.94,
            isFeasible: feasible,
            expectedLandingErrorMeters: 0.34,
            energyCostPercent: 6.2,
            timeSeconds: 52,
            reasonCodes: [
              '+ High-torque active spool control with tension sensor feedback',
              '+ Real-time package altitude & optical touchdown detection',
              isHighAltitude ? '+ Excellent for high hover standoff (25m+)' : '+ Standard winch descent profile',
            ],
            riskFactors: ['Winch mechanical payout latency', 'Slightly higher hover energy consumption'],
            simulationData: {
              oscillationDeg: 1.4,
              tetherTensionN: Number((payloadMassKg * 9.81 * 1.2).toFixed(1)),
              windDriftMeters: 0.16,
              touchdownVelocityMs: 0.25,
            },
          };
        }

        case 'GROUND_LANDING': {
          const isConstrained = site.obstacleDensity === 'HIGH' || site.category === 'SUBURBAN_RESIDENTIAL';
          const padScore = targetZone.type === 'GROUND_PAD' ? 95 : 45;
          const flatness = targetZone.surfaceFlatnessScore;
          const score = Math.max(10, Math.min(99, padScore * 0.6 + flatness * 0.4 - (isConstrained ? 35 : 0)));
          const feasible = score >= 70 && !isConstrained && targetZone.surfaceFlatnessScore >= 80;

          return {
            method: 'GROUND_LANDING' as DeliveryMethodType,
            displayName: 'Full Touchdown Landing',
            suitabilityScore: score,
            confidence: 0.92,
            isFeasible: feasible,
            expectedLandingErrorMeters: 0.15,
            energyCostPercent: 7.8,
            timeSeconds: 65,
            reasonCodes: feasible
              ? ['+ Certified dedicated landing pad present', '+ Zero drop impact, safe manual payload removal']
              : ['- Obstacle proximity / residential ground rotor hazard restricts touchdown', '- Insufficient verified landing perimeter (min 5m required)'],
            riskFactors: ['Propeller wash ground risk', 'Potential unexpected obstacles during final flare'],
            simulationData: {
              touchdownVelocityMs: 0.18,
            },
          };
        }

        case 'PRECISION_DROP': {
          const isLawnOrRural = site.category === 'RURAL_ESTATE' || targetZone.type === 'GARDEN_LAWN';
          const windPenalty = windSpeedKts * 2.8;
          const score = Math.max(10, Math.min(95, (isLawnOrRural ? 85 : 40) - windPenalty));
          const feasible = score >= 60 && windSpeedKts <= 14;

          return {
            method: 'PRECISION_DROP' as DeliveryMethodType,
            displayName: 'Ballistic Precision Drop',
            suitabilityScore: score,
            confidence: 0.86,
            isFeasible: feasible,
            expectedLandingErrorMeters: Number((0.45 + windSpeedKts * 0.04).toFixed(2)),
            energyCostPercent: 1.8,
            timeSeconds: 12,
            reasonCodes: [
              '+ Ultra-rapid delivery cycle (<15s on station)',
              '+ Minimal hover power requirement',
              isLawnOrRural ? '+ Soft impact surface verified' : '- Hard pavement/urban surface not recommended for non-cushioned payloads',
            ],
            riskFactors: ['Impact acceleration (1.8 - 2.5g)', 'Wind gust drift during freefall trajectory'],
            simulationData: {
              touchdownVelocityMs: 1.85,
              windDriftMeters: Number((windSpeedKts * 0.035).toFixed(2)),
            },
          };
        }

        case 'PRECISION_PLACEMENT': {
          const isRoofOrBay = targetZone.type === 'ROOF_PLATFORM' || site.category === 'COMMERCIAL_ROOFTOP';
          const score = isRoofOrBay ? 90 : 50;
          return {
            method: 'PRECISION_PLACEMENT' as DeliveryMethodType,
            displayName: 'Direct Surface Placement',
            suitabilityScore: score,
            confidence: 0.93,
            isFeasible: score >= 65 && windGustKts <= 18,
            expectedLandingErrorMeters: 0.12,
            energyCostPercent: 5.4,
            timeSeconds: 35,
            reasonCodes: [
              '+ Millimetre mechanical gripper placement',
              '+ Verified horizontal table/pedestal geometry',
            ],
            riskFactors: ['Close obstacle clearance during surface contact'],
          };
        }

        case 'MANOEUVRE_INTO_PLACE': {
          const isIndustrial = site.category === 'INDUSTRIAL_YARD' || targetZone.type === 'WINCH_BAY';
          const score = isIndustrial ? 86 : 42;
          return {
            method: 'MANOEUVRE_INTO_PLACE' as DeliveryMethodType,
            displayName: 'Constrained Space Manoeuvre',
            suitabilityScore: score,
            confidence: 0.89,
            isFeasible: score >= 60 && windSpeedKts <= 12,
            expectedLandingErrorMeters: 0.18,
            energyCostPercent: 6.8,
            timeSeconds: 48,
            reasonCodes: ['+ 3D LiDAR corridor guided approach', '+ Multi-sensor obstacle proximity lock'],
            riskFactors: ['Tight lateral margins (<1.5m) requiring RTK positioning'],
          };
        }

        case 'DELIVERY_STATION_DOCK': {
          const hasStation = targetZone.type === 'RECEIVING_STATION' || site.category === 'RECEIVING_STATION';
          const score = hasStation ? 99 : 15;
          return {
            method: 'DELIVERY_STATION_DOCK' as DeliveryMethodType,
            displayName: 'Automated Station Docking',
            suitabilityScore: score,
            confidence: 0.99,
            isFeasible: hasStation,
            expectedLandingErrorMeters: 0.05,
            energyCostPercent: 4.0,
            timeSeconds: 28,
            reasonCodes: hasStation
              ? ['+ Automated Spitfire Smart-Receptacle optical/IR docking alignment', '+ Weather-sealed payload transfer hatch', '+ Integrated battery top-up interface']
              : ['- No Spitfire Automated Delivery Station present at target location'],
            riskFactors: ['Station optical beacon acquisition lock'],
          };
        }
      }
    }).sort((a, b) => b.suitabilityScore - a.suitabilityScore);
  }

  /**
   * High-Performance Monte Carlo Delivery Simulator
   * Simulates N missions with Gaussian noise on wind, GPS covariance, payload shift, and cable tension.
   */
  runMonteCarloSimulation(
    method: DeliveryMethodType,
    runsCount = 1500,
    baseWindKts = 12.0,
    payloadKg = 2.0,
    seed = 2026
  ): MonteCarloResult {
    let currentSeed = seed;
    const seededRandom = () => {
      currentSeed = (currentSeed * 1664525 + 1013904223) % 4294967296;
      return currentSeed / 4294967296;
    };

    // Box-Muller transform for normal distribution
    const randn = () => {
      const u = Math.max(0.0001, seededRandom());
      const v = seededRandom();
      return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
    };

    const errors: number[] = [];
    const energyCosts: number[] = [];
    let successCount = 0;
    let windExceededCount = 0;
    let corridorBreachCount = 0;
    let batteryLowCount = 0;
    let sensorNoiseCount = 0;

    const baseError = method === 'DELIVERY_STATION_DOCK' ? 0.04 : method === 'TETHER_DROP' ? 0.22 : method === 'GROUND_LANDING' ? 0.12 : 0.45;
    const baseEnergy = method === 'PRECISION_DROP' ? 45.0 : method === 'TETHER_DROP' ? 58.0 : 64.0;

    for (let i = 0; i < runsCount; i++) {
      // Stochastic variables
      const windSample = Math.max(0, baseWindKts + randn() * 4.2);
      const gnssJitterMeters = Math.abs(randn() * 0.08);
      const payloadShift = randn() * 0.15;
      const energyVariance = randn() * 3.5;

      // Method specific physics model
      let errorM = baseError + gnssJitterMeters + Math.abs(payloadShift);
      if (method === 'TETHER_DROP' || method === 'WINCH_DELIVERY') {
        const sway = (windSample / 10.0) * (payloadKg / 2.0) * 0.09 * (1 + randn() * 0.2);
        errorM += Math.abs(sway);
      } else if (method === 'PRECISION_DROP') {
        const drift = (windSample / 8.0) * 0.18 * (1 + randn() * 0.25);
        errorM += Math.abs(drift);
      }

      const simEnergy = baseEnergy + energyVariance + (windSample * 0.6) + (payloadKg * 2.2);

      errors.push(errorM);
      energyCosts.push(simEnergy);

      // Failure condition checks
      let failed = false;
      if (windSample > 28.0) {
        windExceededCount++;
        failed = true;
      }
      if (errorM > 1.2 && (method === 'TETHER_DROP' || method === 'PRECISION_PLACEMENT')) {
        corridorBreachCount++;
        failed = true;
      }
      if (simEnergy > 82.0) {
        batteryLowCount++;
        failed = true;
      }
      if (gnssJitterMeters > 0.35) {
        sensorNoiseCount++;
        failed = true;
      }

      if (!failed) {
        successCount++;
      }
    }

    errors.sort((a, b) => a - b);
    energyCosts.sort((a, b) => a - b);

    const meanError = errors.reduce((acc, v) => acc + v, 0) / runsCount;
    const p95Error = errors[Math.floor(runsCount * 0.95)];
    const expectedEnergy = energyCosts.reduce((acc, v) => acc + v, 0) / runsCount;
    const p95Energy = energyCosts[Math.floor(runsCount * 0.95)];
    const p99Energy = energyCosts[Math.floor(runsCount * 0.99)];

    // Distribution histogram buckets
    const bucketRanges = [
      { label: '< 0.15m', max: 0.15 },
      { label: '0.15 - 0.30m', max: 0.30 },
      { label: '0.30 - 0.50m', max: 0.50 },
      { label: '0.50 - 0.75m', max: 0.75 },
      { label: '0.75 - 1.00m', max: 1.00 },
      { label: '> 1.00m', max: Infinity },
    ];

    const distributionBuckets = bucketRanges.map((b, idx) => {
      const min = idx === 0 ? 0 : bucketRanges[idx - 1].max;
      const count = errors.filter((e) => e >= min && e < b.max).length;
      return {
        errorRange: b.label,
        count,
        freq: Number(((count / runsCount) * 100).toFixed(1)),
      };
    });

    return {
      seed,
      simulationsCount: runsCount,
      successRatePercent: Number(((successCount / runsCount) * 100).toFixed(1)),
      expectedEnergyCostPercent: Number(expectedEnergy.toFixed(1)),
      p95EnergyCostPercent: Number(p95Energy.toFixed(1)),
      p99EnergyCostPercent: Number(p99Energy.toFixed(1)),
      meanPositionErrorMeters: Number(meanError.toFixed(2)),
      p95PositionErrorMeters: Number(p95Error.toFixed(2)),
      confidenceEllipseAxesMeters: [
        Number((p95Error * 0.85).toFixed(2)),
        Number((p95Error * 1.15).toFixed(2)),
      ],
      failureBreakdown: {
        windExceededPercent: Number(((windExceededCount / runsCount) * 100).toFixed(2)),
        corridorBreachPercent: Number(((corridorBreachCount / runsCount) * 100).toFixed(2)),
        batteryLowPercent: Number(((batteryLowCount / runsCount) * 100).toFixed(2)),
        sensorUncertaintyPercent: Number(((sensorNoiseCount / runsCount) * 100).toFixed(2)),
      },
      distributionBuckets,
    };
  }
}
