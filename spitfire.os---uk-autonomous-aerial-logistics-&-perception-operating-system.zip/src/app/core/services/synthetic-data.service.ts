import { Injectable } from '@angular/core';
import {
  Depot,
  DroneDigitalTwin,
  DeliverySite,
  PhotogrammetrySurvey,
  PointCloudPoint,
  Mission
} from '../models/spitfire.types';

@Injectable({
  providedIn: 'root',
})
export class SyntheticDataService {
  readonly depots: Depot[] = [
    {
      id: 'depot-01',
      code: 'SPF-DEPOT-01',
      name: 'Oxfordshire Autonomous Drone Hub',
      region: 'Oxfordshire & Thames Valley',
      location: { lat: 51.752, lng: -1.257, altMeters: 62.0 },
      totalPads: 12,
      availablePads: 7,
      chargingStations: 8,
      activeDrones: 6,
      weatherStation: {
        windSpeedKts: 11.4,
        windDirectionDeg: 240,
        gustKts: 16.2,
        tempC: 14.8,
        visibilityKm: 18.0,
        cloudBaseFt: 3200,
        precipitationMm: 0.0,
        baroHpa: 1018.2,
      },
    },
    {
      id: 'depot-02',
      code: 'SPF-DEPOT-02',
      name: 'Manchester Barton Aerial Hub',
      region: 'North West & Greater Manchester',
      location: { lat: 53.472, lng: -2.391, altMeters: 23.5 },
      totalPads: 16,
      availablePads: 9,
      chargingStations: 12,
      activeDrones: 8,
      weatherStation: {
        windSpeedKts: 14.2,
        windDirectionDeg: 260,
        gustKts: 21.0,
        tempC: 13.1,
        visibilityKm: 14.0,
        cloudBaseFt: 2400,
        precipitationMm: 0.2,
        baroHpa: 1014.6,
      },
    },
    {
      id: 'depot-03',
      code: 'SPF-DEPOT-03',
      name: 'Sheffield Advanced Manufacturing Hub',
      region: 'Yorkshire Aerospace Zone',
      location: { lat: 53.381, lng: -1.47, altMeters: 84.0 },
      totalPads: 10,
      availablePads: 5,
      chargingStations: 6,
      activeDrones: 5,
      weatherStation: {
        windSpeedKts: 9.8,
        windDirectionDeg: 210,
        gustKts: 13.5,
        tempC: 15.2,
        visibilityKm: 22.0,
        cloudBaseFt: 4000,
        precipitationMm: 0.0,
        baroHpa: 1019.5,
      },
    },
    {
      id: 'depot-04',
      code: 'SPF-DEPOT-04',
      name: 'Thames Corridor Maritime Gateway',
      region: 'London & Thames Estuary',
      location: { lat: 51.507, lng: 0.054, altMeters: 9.0 },
      totalPads: 14,
      availablePads: 8,
      chargingStations: 10,
      activeDrones: 7,
      weatherStation: {
        windSpeedKts: 12.0,
        windDirectionDeg: 190,
        gustKts: 17.8,
        tempC: 16.0,
        visibilityKm: 15.0,
        cloudBaseFt: 2800,
        precipitationMm: 0.0,
        baroHpa: 1017.0,
      },
    },
  ];

  generate52Drones(): DroneDigitalTwin[] {
    const drones: DroneDigitalTwin[] = [];
    const models: ('SPITFIRE M4' | 'SPITFIRE HEAVY-LIFT' | 'SPITFIRE RAPID-VTOL' | 'SPITFIRE SURVEY-PRO')[] = [
      'SPITFIRE M4',
      'SPITFIRE M4',
      'SPITFIRE HEAVY-LIFT',
      'SPITFIRE RAPID-VTOL',
      'SPITFIRE SURVEY-PRO',
    ];

    for (let i = 1; i <= 52; i++) {
      const padNum = i.toString().padStart(3, '0');
      const model = models[i % models.length];
      const depot = this.depots[i % this.depots.length];
      
      let status: DroneDigitalTwin['status'] = 'AVAILABLE';
      if (i === 1 || i === 7 || i === 12 || i === 24 || i === 31 || i === 42) {
        status = 'IN_FLIGHT';
      } else if (i % 9 === 0) {
        status = 'CHARGING';
      } else if (i === 18 || i === 37) {
        status = 'MAINTENANCE';
      } else if (i === 49) {
        status = 'WEATHER_HOLD';
      }

      const soc = status === 'CHARGING' ? 42 + (i * 3) % 45 : Math.max(28, 88 - (i * 4) % 55);

      drones.push({
        id: `drone-${padNum}`,
        callsign: `SPF-${padNum}`,
        model,
        caaRegistration: `G-SPIT-${padNum}`,
        directRemoteId: `GBR-DRI-2026-${padNum}-CAA`,
        status,
        batterySoc: soc,
        batteryVoltage: Number((48.2 + (soc / 100) * 4.8).toFixed(1)),
        batteryTempC: Number((24.0 + (i % 7) * 1.8).toFixed(1)),
        batteryHealthCycles: 85 + (i * 13) % 240,
        payloadCapacityKg: model === 'SPITFIRE HEAVY-LIFT' ? 8.5 : model === 'SPITFIRE RAPID-VTOL' ? 3.0 : 4.5,
        currentPayloadKg: status === 'IN_FLIGHT' ? 1.8 : 0.0,
        maxWindToleranceKts: model === 'SPITFIRE HEAVY-LIFT' ? 32 : 25,
        position: {
          lat: depot.location.lat + (Math.sin(i * 0.7) * 0.035),
          lng: depot.location.lng + (Math.cos(i * 0.7) * 0.045),
          altMeters: status === 'IN_FLIGHT' ? 85 + (i % 5) * 15 : depot.location.altMeters,
        },
        headingDeg: (i * 47) % 360,
        groundSpeedKts: status === 'IN_FLIGHT' ? 38.5 + (i % 6) * 3.2 : 0,
        airframeHours: Number((120 + i * 14.6).toFixed(1)),
        nextInspectionHours: Number((18.4 + (i % 12) * 4.2).toFixed(1)),
        assignedDepotId: depot.id,
        activeMissionId: status === 'IN_FLIGHT' ? `MSN-284${padNum}` : undefined,
        subsystemHealth: {
          motors: i === 18 ? 'DEGRADED' : 'EXCELLENT',
          imu: 'CALIBRATED',
          gnssRtk: 'FIX_RTK',
          sensors: 'ALL_OPERATIONAL',
          commsLink: '99.9% 5G/SAT',
          payloadHarness: status === 'IN_FLIGHT' ? 'LOCKED' : 'DISENGAGED',
        },
      });
    }

    return drones;
  }

  // Pre-configured authentic UK Delivery Sites with full 3D spatial properties
  generateDeliverySites(): DeliverySite[] {
    return [
      {
        id: 'site-01',
        code: 'UK-SITE-109283',
        name: 'The Gables, Woodstock Road',
        address: 'Woodstock Road, Oxford, Oxfordshire',
        postcode: 'OX2 6NN',
        category: 'SUBURBAN_RESIDENTIAL',
        location: { lat: 51.7648, lng: -1.2685, altMeters: 65.4 },
        lastSurveyDate: '2026-09-28 14:32 UTC',
        siteConfidence: 0.968,
        surfaceAreaM2: 480.0,
        slopeDegrees: 2.1,
        obstacleDensity: 'MEDIUM',
        overheadClearanceMeters: 14.5,
        provenance: {
          source: 'SPITFIRE VISION',
          timestamp: '2026-09-28T14:32:00Z',
          surveyFlightId: 'SURVEY-OXF-8821',
          reprojectionErrorPx: 0.68,
          featurePointsCount: 4280,
        },
        historicalDeliveriesCount: 184,
        preferredMethod: 'TETHER_DROP',
        secondaryMethod: 'PRECISION_DROP',
        zones: [
          {
            id: 'zone-01-a',
            siteId: 'site-01',
            name: 'Rear Garden Lawn Platform',
            type: 'GARDEN_LAWN',
            center: { lat: 51.76485, lng: -1.2686, altMeters: 65.2, x: 2.4, y: 0.0, z: -4.8 },
            radiusMeters: 3.2,
            surfaceFlatnessScore: 96,
            overheadClearanceScore: 98,
            windExposureFactor: 0.35,
            currentStatus: 'APPROVED',
            targetAccuracyReqMeters: 0.45,
          },
          {
            id: 'zone-01-b',
            siteId: 'site-01',
            name: 'Front Driveway Hardstand',
            type: 'GROUND_PAD',
            center: { lat: 51.76472, lng: -1.2684, altMeters: 65.5, x: -6.2, y: 0.2, z: 8.5 },
            radiusMeters: 2.8,
            surfaceFlatnessScore: 92,
            overheadClearanceScore: 78,
            windExposureFactor: 0.6,
            currentStatus: 'CONDITIONAL',
            rejectionReason: 'Vehicle parked nearby (1.8m margin)',
            targetAccuracyReqMeters: 0.6,
          },
          {
            id: 'zone-01-c',
            siteId: 'site-01',
            name: 'Main Tiled Roof Pitch',
            type: 'ROOF_PLATFORM',
            center: { lat: 51.7648, lng: -1.2685, altMeters: 74.2, x: 0.0, y: 8.8, z: 0.0 },
            radiusMeters: 2.0,
            surfaceFlatnessScore: 24,
            overheadClearanceScore: 100,
            windExposureFactor: 0.95,
            currentStatus: 'REJECTED',
            rejectionReason: 'Roof pitch 38° exceeds safe 8° limit for landing/drop',
            targetAccuracyReqMeters: 0.3,
          },
        ],
      },
      {
        id: 'site-02',
        code: 'UK-SITE-204192',
        name: 'Advanced Materials Technology Park - Bay 4',
        address: 'Europa Link, Sheffield Business Park',
        postcode: 'S9 1XZ',
        category: 'INDUSTRIAL_YARD',
        location: { lat: 53.3895, lng: -1.4025, altMeters: 88.0 },
        lastSurveyDate: '2026-09-29 07:15 UTC',
        siteConfidence: 0.992,
        surfaceAreaM2: 1250.0,
        slopeDegrees: 0.4,
        obstacleDensity: 'LOW',
        overheadClearanceMeters: 28.0,
        provenance: {
          source: 'SPITFIRE VISION',
          timestamp: '2026-09-29T07:15:00Z',
          surveyFlightId: 'SURVEY-SHF-9014',
          reprojectionErrorPx: 0.52,
          featurePointsCount: 6840,
        },
        historicalDeliveriesCount: 312,
        preferredMethod: 'GROUND_LANDING',
        secondaryMethod: 'WINCH_DELIVERY',
        zones: [
          {
            id: 'zone-02-a',
            siteId: 'site-02',
            name: 'Designated Drone Delivery Pad 1',
            type: 'GROUND_PAD',
            center: { lat: 53.38955, lng: -1.4026, altMeters: 88.0, x: 4.0, y: 0.0, z: 2.0 },
            radiusMeters: 5.0,
            surfaceFlatnessScore: 99,
            overheadClearanceScore: 100,
            windExposureFactor: 0.4,
            currentStatus: 'APPROVED',
            targetAccuracyReqMeters: 0.8,
          },
          {
            id: 'zone-02-b',
            siteId: 'site-02',
            name: 'Rooftop Secure Receptacle Bay',
            type: 'RECEIVING_STATION',
            center: { lat: 53.3894, lng: -1.4023, altMeters: 102.5, x: -12.0, y: 14.5, z: -8.0 },
            radiusMeters: 1.8,
            surfaceFlatnessScore: 100,
            overheadClearanceScore: 100,
            windExposureFactor: 0.75,
            currentStatus: 'APPROVED',
            targetAccuracyReqMeters: 0.25,
          },
        ],
      },
      {
        id: 'site-03',
        code: 'UK-SITE-308819',
        name: 'Hilltop Organic Farmstead',
        address: 'Stow-on-the-Wold, Gloucestershire',
        postcode: 'GL54 1AA',
        category: 'RURAL_ESTATE',
        location: { lat: 51.9312, lng: -1.722, altMeters: 235.0 },
        lastSurveyDate: '2026-09-27 16:40 UTC',
        siteConfidence: 0.941,
        surfaceAreaM2: 2400.0,
        slopeDegrees: 4.5,
        obstacleDensity: 'LOW',
        overheadClearanceMeters: 35.0,
        provenance: {
          source: 'SPITFIRE VISION',
          timestamp: '2026-09-27T16:40:00Z',
          surveyFlightId: 'SURVEY-GLO-7711',
          reprojectionErrorPx: 0.84,
          featurePointsCount: 3950,
        },
        historicalDeliveriesCount: 68,
        preferredMethod: 'PRECISION_DROP',
        secondaryMethod: 'GROUND_LANDING',
        zones: [
          {
            id: 'zone-03-a',
            siteId: 'site-03',
            name: 'Paddock Drop Target Alpha',
            type: 'GARDEN_LAWN',
            center: { lat: 51.9314, lng: -1.7222, altMeters: 234.8, x: 0.0, y: 0.0, z: 0.0 },
            radiusMeters: 6.0,
            surfaceFlatnessScore: 88,
            overheadClearanceScore: 100,
            windExposureFactor: 0.85,
            currentStatus: 'APPROVED',
            targetAccuracyReqMeters: 1.2,
          },
        ],
      },
      {
        id: 'site-04',
        code: 'UK-SITE-401129',
        name: 'Canary Wharf South Quay Tower 2',
        address: 'Marsh Wall, Isle of Dogs, London',
        postcode: 'E14 9SH',
        category: 'COMMERCIAL_ROOFTOP',
        location: { lat: 51.5015, lng: -0.0185, altMeters: 182.0 },
        lastSurveyDate: '2026-09-29 08:30 UTC',
        siteConfidence: 0.985,
        surfaceAreaM2: 320.0,
        slopeDegrees: 0.0,
        obstacleDensity: 'CONSTRAINED',
        overheadClearanceMeters: 50.0,
        provenance: {
          source: 'SPITFIRE VISION',
          timestamp: '2026-09-29T08:30:00Z',
          surveyFlightId: 'SURVEY-LDN-3002',
          reprojectionErrorPx: 0.44,
          featurePointsCount: 7120,
        },
        historicalDeliveriesCount: 418,
        preferredMethod: 'DELIVERY_STATION_DOCK',
        secondaryMethod: 'PRECISION_PLACEMENT',
        zones: [
          {
            id: 'zone-04-a',
            siteId: 'site-04',
            name: 'Automated Station Dock Unit 04',
            type: 'RECEIVING_STATION',
            center: { lat: 51.50152, lng: -0.01848, altMeters: 182.2, x: 0.0, y: 0.0, z: 0.0 },
            radiusMeters: 1.5,
            surfaceFlatnessScore: 100,
            overheadClearanceScore: 100,
            windExposureFactor: 0.9,
            currentStatus: 'APPROVED',
            targetAccuracyReqMeters: 0.15,
          },
        ],
      },
    ];
  }

  // Generate deterministic 3D Point Cloud for a UK Suburban Site with building, roof, garden lawn, driveway, vehicles, trees, and fences
  generateSuburbanPointCloud(): PointCloudPoint[] {
    const points: PointCloudPoint[] = [];

    // Seeded random helper for deterministic reproducibility
    let seed = 42;
    const random = () => {
      seed = (seed * 9301 + 49297) % 233280;
      return seed / 233280;
    };

    // 1. GROUND & LAWN (y approx 0)
    for (let x = -20; x <= 20; x += 0.8) {
      for (let z = -20; z <= 20; z += 0.8) {
        const jitterX = (random() - 0.5) * 0.3;
        const jitterZ = (random() - 0.5) * 0.3;
        const posX = x + jitterX;
        const posZ = z + jitterZ;
        const posY = (random() - 0.5) * 0.1;

        // Is it inside delivery lawn area? (x: 0 to 8, z: -14 to -4)
        if (posX >= 0 && posX <= 8 && posZ >= -14 && posZ <= -4) {
          points.push({
            x: posX,
            y: posY,
            z: posZ,
            r: 34 + Math.floor(random() * 20),
            g: 139 + Math.floor(random() * 40),
            b: 34 + Math.floor(random() * 20),
            classification: 'DELIVERY_SURFACE',
            confidence: 0.98,
          });
        } else if (posX <= -6 && posZ >= 2 && posZ <= 16) {
          // Driveway / Road
          points.push({
            x: posX,
            y: posY + 0.02,
            z: posZ,
            r: 90,
            g: 95,
            b: 105,
            classification: 'ROAD',
            confidence: 0.95,
          });
        } else {
          // General Garden / Ground
          points.push({
            x: posX,
            y: posY,
            z: posZ,
            r: 45 + Math.floor(random() * 15),
            g: 110 + Math.floor(random() * 30),
            b: 40,
            classification: 'GROUND',
            confidence: 0.94,
          });
        }
      }
    }

    // 2. MAIN BUILDING (Walls from y=0 to y=6.5, x: -5 to 6, z: -3 to 7)
    for (let y = 0.2; y <= 6.5; y += 0.5) {
      for (let x = -5; x <= 6; x += 0.5) {
        // North wall & South wall
        points.push({ x, y, z: -3, r: 180, g: 140, b: 120, classification: 'BUILDING', confidence: 0.96 });
        points.push({ x, y, z: 7, r: 180, g: 140, b: 120, classification: 'BUILDING', confidence: 0.96 });
      }
      for (let z = -3; z <= 7; z += 0.5) {
        // West & East walls
        points.push({ x: -5, y, z, r: 175, g: 135, b: 115, classification: 'BUILDING', confidence: 0.96 });
        points.push({ x: 6, y, z, r: 175, g: 135, b: 115, classification: 'BUILDING', confidence: 0.96 });
      }
    }

    // 3. PITCHED ROOF (from y=6.5 to peak at y=9.8 at x=0.5)
    for (let z = -3.2; z <= 7.2; z += 0.6) {
      for (let x = -5.2; x <= 6.2; x += 0.5) {
        const distFromCenter = Math.abs(x - 0.5);
        const roofY = 9.8 - distFromCenter * 0.62;
        points.push({
          x,
          y: roofY,
          z,
          r: 160 + Math.floor(random() * 20),
          g: 68 + Math.floor(random() * 15),
          b: 54,
          classification: 'ROOF',
          confidence: 0.97,
        });
      }
    }

    // 4. TREES (2 realistic tree crowns)
    // Tree 1: x: 12, z: -10, height: 10.5m
    for (let i = 0; i < 280; i++) {
      const u = random();
      const v = random();
      const theta = u * 2.0 * Math.PI;
      const phi = Math.acos(2.0 * v - 1.0);
      const rad = Math.cbrt(random()) * 3.5;
      const tx = 12 + rad * Math.sin(phi) * Math.cos(theta);
      const ty = 6.5 + rad * Math.sin(phi) * Math.sin(theta);
      const tz = -10 + rad * Math.cos(phi);
      points.push({
        x: tx,
        y: Math.max(0.5, ty),
        z: tz,
        r: 30 + Math.floor(random() * 20),
        g: 90 + Math.floor(random() * 40),
        b: 25,
        classification: 'TREE',
        confidence: 0.92,
      });
    }

    // Tree 2: x: -14, z: -8
    for (let i = 0; i < 220; i++) {
      const u = random();
      const v = random();
      const theta = u * 2.0 * Math.PI;
      const phi = Math.acos(2.0 * v - 1.0);
      const rad = Math.cbrt(random()) * 2.8;
      const tx = -14 + rad * Math.sin(phi) * Math.cos(theta);
      const ty = 5.2 + rad * Math.sin(phi) * Math.sin(theta);
      const tz = -8 + rad * Math.cos(phi);
      points.push({
        x: tx,
        y: Math.max(0.5, ty),
        z: tz,
        r: 25 + Math.floor(random() * 20),
        g: 80 + Math.floor(random() * 35),
        b: 20,
        classification: 'TREE',
        confidence: 0.91,
      });
    }

    // 5. PARKED VEHICLE (in driveway at x: -8, z: 8)
    for (let vx = -9.2; vx <= -6.8; vx += 0.3) {
      for (let vz = 6.2; vz <= 10.8; vz += 0.3) {
        for (let vy = 0.2; vy <= 1.6; vy += 0.3) {
          points.push({
            x: vx + (random() - 0.5) * 0.05,
            y: vy,
            z: vz + (random() - 0.5) * 0.05,
            r: 30,
            g: 65,
            b: 140,
            classification: 'VEHICLE',
            confidence: 0.98,
          });
        }
      }
    }

    // 6. PERIMETER FENCES & WALLS
    for (let fx = -18; fx <= 18; fx += 0.5) {
      points.push({ x: fx, y: 0.9, z: -18, r: 120, g: 90, b: 60, classification: 'FENCE', confidence: 0.94 });
      points.push({ x: fx, y: 1.8, z: -18, r: 120, g: 90, b: 60, classification: 'FENCE', confidence: 0.94 });
      points.push({ x: fx, y: 0.9, z: 18, r: 140, g: 140, b: 140, classification: 'WALL', confidence: 0.95 });
    }

    return points;
  }

  // Generate complete Photogrammetry Survey object with synthetic camera poses
  generateSurvey(siteId: string): PhotogrammetrySurvey {
    const cameraPoses = [
      { id: 'cam-01', pos: { lat: 51.765, lng: -1.2688, altMeters: 95.0, x: -15, y: 30, z: -15 }, pitch: -55, yaw: 45, roll: 0, fov: 68 },
      { id: 'cam-02', pos: { lat: 51.7651, lng: -1.2682, altMeters: 95.0, x: 15, y: 30, z: -15 }, pitch: -55, yaw: -45, roll: 0, fov: 68 },
      { id: 'cam-03', pos: { lat: 51.7645, lng: -1.2682, altMeters: 95.0, x: 15, y: 30, z: 15 }, pitch: -55, yaw: -135, roll: 0, fov: 68 },
      { id: 'cam-04', pos: { lat: 51.7645, lng: -1.2688, altMeters: 95.0, x: -15, y: 30, z: 15 }, pitch: -55, yaw: 135, roll: 0, fov: 68 },
      { id: 'cam-05', pos: { lat: 51.7648, lng: -1.2685, altMeters: 92.0, x: 0, y: 28, z: 0 }, pitch: -90, yaw: 0, roll: 0, fov: 74 },
      { id: 'cam-06', pos: { lat: 51.7649, lng: -1.2686, altMeters: 80.0, x: 3, y: 15, z: -6 }, pitch: -65, yaw: 20, roll: 0, fov: 64 },
    ];

    return {
      id: `SURVEY-${siteId}-V2`,
      siteId,
      timestamp: '2026-09-29T08:45:00Z',
      imagesCount: 38,
      coveragePercent: 98.4,
      featureMatchingPercent: 95.2,
      reprojectionErrorPx: 0.64,
      depthConfidencePercent: 93.8,
      surfaceCoveragePercent: 97.5,
      cameraPoses,
      points: this.generateSuburbanPointCloud(),
      detectedChanges: [
        {
          zoneId: 'zone-01-b',
          previousState: 'CLEAR_ASPHALT',
          currentState: 'VEHICLE_OBSTRUCTION',
          confidence: 0.982,
          detectedObstacle: 'Stationary Blue Estate Vehicle detected at driveway margin (1.8m clearance)',
        },
      ],
    };
  }

  generateSampleMissions(): Mission[] {
    return [
      {
        id: 'msn-28491',
        code: 'MSN-28491',
        depotId: 'depot-01',
        siteId: 'site-01',
        targetZoneId: 'zone-01-a',
        droneId: 'drone-042',
        payload: {
          trackingNumber: 'GB-SPF-8849-2026',
          recipientName: 'Dr. Eleanor Vance',
          massKg: 1.85,
          dimensionsCm: [26, 18, 12],
          category: 'MEDICAL_CRITICAL',
          temperatureSensitive: true,
        },
        state: 'IN_FLIGHT',
        selectedMethod: 'TETHER_DROP',
        methodEvaluation: [
          {
            method: 'TETHER_DROP',
            displayName: 'Controlled Tether Drop',
            suitabilityScore: 96,
            confidence: 0.95,
            isFeasible: true,
            expectedLandingErrorMeters: 0.28,
            energyCostPercent: 4.8,
            timeSeconds: 42,
            reasonCodes: [
              '+ Clear vertical overhead corridor (14.5m clearance)',
              '+ Low wind speed at ground level (5.2 kts)',
              '+ Verified soft lawn target with minimal rebound',
              '+ Eliminates drone ground-rotor hazards in residential garden',
            ],
            riskFactors: ['Minor lateral pendulum oscillation if gusts exceed 18 kts'],
            simulationData: {
              oscillationDeg: 1.8,
              tetherTensionN: 22.4,
              windDriftMeters: 0.14,
              touchdownVelocityMs: 0.35,
            },
          },
          {
            method: 'GROUND_LANDING',
            displayName: 'Full Aircraft Ground Landing',
            suitabilityScore: 58,
            confidence: 0.72,
            isFeasible: false,
            expectedLandingErrorMeters: 0.4,
            energyCostPercent: 7.2,
            timeSeconds: 65,
            reasonCodes: ['- Residential garden perimeter trees within 8m safety buffer', '- Ground risk policy restricts rotor contact in domestic premises'],
            riskFactors: ['Proximity of garden fence and overhanging foliage'],
          },
          {
            method: 'PRECISION_DROP',
            displayName: 'High-Accuracy Parachute/Gravity Drop',
            suitabilityScore: 78,
            confidence: 0.88,
            isFeasible: true,
            expectedLandingErrorMeters: 0.65,
            energyCostPercent: 2.1,
            timeSeconds: 15,
            reasonCodes: ['+ Rapid release execution', '- Temperature-sensitive medical vial requires shock < 2.0g (Tether preferred)'],
            riskFactors: ['Package impact velocity 1.8 m/s'],
          },
        ],
        route: {
          totalDistanceKm: 7.4,
          estimatedFlightDurationSec: 720,
          cruisingAltitudeMeters: 90.0,
          corridorClearanceMeters: 35.0,
          waypoints: [
            { lat: 51.752, lng: -1.257, altMeters: 62.0, speedKts: 0, action: 'ASCEND', corridorWidthMeters: 20 },
            { lat: 51.756, lng: -1.26, altMeters: 90.0, speedKts: 40, action: 'CRUISE', corridorWidthMeters: 40 },
            { lat: 51.761, lng: -1.264, altMeters: 90.0, speedKts: 42, action: 'CRUISE', corridorWidthMeters: 40 },
            { lat: 51.7645, lng: -1.268, altMeters: 55.0, speedKts: 22, action: 'DESCEND', corridorWidthMeters: 25 },
            { lat: 51.76485, lng: -1.2686, altMeters: 22.0, speedKts: 0, action: 'DELIVER', corridorWidthMeters: 10 },
          ],
        },
        energyAnalysis: {
          outboundEnergyPercent: 26.5,
          manoeuvreEnergyPercent: 4.8,
          returnEnergyPercent: 27.2,
          totalExpectedEnergyPercent: 58.5,
          reserveSocAtLandingPercent: 39.5,
          minimumAllowedReservePercent: 25.0,
          approvedByRModel: true,
        },
        weatherAssessment: {
          meanWindKts: 11.4,
          gustKts: 16.2,
          windDirectionDeg: 240,
          tempC: 14.8,
          operationalEffect: '+4.2% power compensation for WSW crosswind; within normal envelope',
        },
        airspaceCompliance: {
          caaAuthorizationRef: 'CAA-BVLOS-SPEC-2026-0491',
          isBvlosAuthorized: true,
          directRemoteIdActive: true,
          controlledAirspaceClearance: 'CLASS_G_OPEN',
          notamClearance: true,
        },
        operatorApproval: {
          operatorId: 'OP-RAF-7704',
          operatorCallsign: 'Flt. Ops C. Sterling',
          approvedTimestamp: '2026-09-29 08:35:10 UTC',
          rationale: 'Photogrammetry survey verified OXF-8821. Tether delivery approved over verified Lawn Zone A with 14.5m clear corridor.',
          riskMitigations: ['Automatic winch shear link active', 'RTK Fix confirmed with 1.4cm precision', 'Dynamic geofence active'],
        },
      },
    ];
  }
}
